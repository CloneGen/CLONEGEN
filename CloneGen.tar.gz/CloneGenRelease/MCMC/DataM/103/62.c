int main () {
    int fDU2jJ;
    int j;
    int m;
    int s5HeASJZ;
    int t;
    int s;
    int l;
    int r;
    int wcbfvEJ [(1762 - 762)];
    char hSY9Vm8ysMiT [1000];
    char vVKNyu [1000];
    scanf ("%s", hSY9Vm8ysMiT);
    l = strlen (hSY9Vm8ysMiT);
    {
        fDU2jJ = 160 - 160;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (l > fDU2jJ) {
            if (hSY9Vm8ysMiT[fDU2jJ] >= 'a' && hSY9Vm8ysMiT[fDU2jJ] <= 'z')
                hSY9Vm8ysMiT[fDU2jJ] = hSY9Vm8ysMiT[fDU2jJ] - 'a' + 'A';
            fDU2jJ++;
        };
    }
    {
        fDU2jJ = 355 - 355;
        while (fDU2jJ < l) {
            t = (104 - 103);
            {
                j = 119 - 118;
                while (fDU2jJ + j < l) {
                    if (hSY9Vm8ysMiT[fDU2jJ] == hSY9Vm8ysMiT[fDU2jJ + j])
                        t = t + 1;
                    else
                        break;
                    j++;
                };
            }
            printf ("(%c,%d)", hSY9Vm8ysMiT[fDU2jJ], t);
            fDU2jJ = fDU2jJ + j - 1;
            fDU2jJ++;
        };
    }
    getchar ();
    getchar ();
}

