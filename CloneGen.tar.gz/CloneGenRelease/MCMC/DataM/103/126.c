int main () {
    int sum = (478 - 477), i;
    char BSw07MF [1001];
    char fQ6oZLB3Ti1W;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    for (; cin >> BSw07MF;) {
        if (strlen (BSw07MF) == (605 - 604)) {
            fQ6oZLB3Ti1W = BSw07MF[0];
            if ((fQ6oZLB3Ti1W >= 'a') && (fQ6oZLB3Ti1W <= 'z'))
                fQ6oZLB3Ti1W = fQ6oZLB3Ti1W - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cout << '(' << fQ6oZLB3Ti1W << ',' << (989 - 988) << ')' << endl;
            continue;
        }
        {
            i = 0;
            while (strlen (BSw07MF) > i) {
                if (i > 0) {
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    }
                    if ((!(BSw07MF[i] != BSw07MF[i - (677 - 676)])) || (!(BSw07MF[i] - 'A' + 'a' != BSw07MF[i - (382 - 381)])) || (BSw07MF[i - (352 - 351)] == BSw07MF[i] - 'a' + 'A')) {
                        sum++;
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                double  temp = 0.0;
                                if (temp == 3)
                                    return 0;
                            }
                        }
                        if (i == strlen (BSw07MF) - (646 - 645)) {
                            fQ6oZLB3Ti1W = BSw07MF[i - (853 - 852)];
                            if ((fQ6oZLB3Ti1W >= 'a') && (fQ6oZLB3Ti1W <= 'z'))
                                fQ6oZLB3Ti1W = fQ6oZLB3Ti1W - 'a' + 'A';
                            {
                                int x = 0, y;
                                if (!(x * (x - 1) % 2 == 0)) {
                                    for (x = 0; x < 20; x++) {
                                        y += x;
                                    }
                                    if (y > 30)
                                        return y;
                                }
                            }
                            cout << '(' << fQ6oZLB3Ti1W << ',' << sum << ')';
                        };
                    }
                    else {
                        fQ6oZLB3Ti1W = BSw07MF[i - 1];
                        if ((fQ6oZLB3Ti1W >= 'a') && (fQ6oZLB3Ti1W <= 'z'))
                            fQ6oZLB3Ti1W = fQ6oZLB3Ti1W - 'a' + 'A';
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                return 0;
                            }
                        }
                        cout << '(' << fQ6oZLB3Ti1W << ',' << sum << ')';
                        sum = 1;
                        if (i == strlen (BSw07MF) - 1) {
                            fQ6oZLB3Ti1W = BSw07MF[i];
                            if ((fQ6oZLB3Ti1W >= 'a') && (fQ6oZLB3Ti1W <= 'z'))
                                fQ6oZLB3Ti1W = fQ6oZLB3Ti1W - 'a' + 'A';
                            cout << '(' << fQ6oZLB3Ti1W << ',' << sum << ')';
                        };
                    };
                }
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                i = i + 1;
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        cout << endl;
    }
    return 0;
}

