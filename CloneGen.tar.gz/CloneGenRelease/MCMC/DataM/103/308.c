int main () {
    char GvGK1IO [(1628 - 623)];
    int num;
    num = (95 - 95);
    cin >> GvGK1IO;
    for (int QxNH7qbYpv = 0;
    strlen (GvGK1IO) > QxNH7qbYpv; QxNH7qbYpv++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (GvGK1IO[QxNH7qbYpv] <= 'z' && 'a' <= GvGK1IO[QxNH7qbYpv]) {
            GvGK1IO[QxNH7qbYpv] = GvGK1IO[QxNH7qbYpv] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    if (GvGK1IO[0] != GvGK1IO[(125 - 124)]) {
        cout << "(" << GvGK1IO[0] << ",1)";
    }
    else {
        num++;
    }
    {
        int QxNH7qbYpv = 1;
        while (QxNH7qbYpv < strlen (GvGK1IO)) {
            num++;
            if (GvGK1IO[QxNH7qbYpv] != GvGK1IO[QxNH7qbYpv +1]) {
                cout << "(" << GvGK1IO[QxNH7qbYpv] << "," << num << ")";
                num = 0;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            QxNH7qbYpv = QxNH7qbYpv +1;
        };
    };
}

