void  c (char *pDkIWw7toQRf, int l) {
    int tiG9twfHr;
    {
        tiG9twfHr = 976 - 976;
        while (l > tiG9twfHr) {
            if ((*(pDkIWw7toQRf + tiG9twfHr)) >= 'a' && (*(pDkIWw7toQRf + tiG9twfHr)) <= 'z')
                *(pDkIWw7toQRf + tiG9twfHr) = *(pDkIWw7toQRf + tiG9twfHr) + ('A' - 'a');
            tiG9twfHr = tiG9twfHr + 1;
        };
    };
}

int DzSB1w8AEc (char sgbSR4a1AGFC, char y) {
    if (sgbSR4a1AGFC == y)
        return (625 - 624);
    else
        return 0;
}

main () {
    char dlrYTMv;
    char *pDkIWw7toQRf;
    int e;
    int l;
    int gv9IT73MJy = 0;
    char a [1000];
    int tiG9twfHr;
    scanf ("%s", a);
    l = strlen (a);
    pDkIWw7toQRf = a;
    c (pDkIWw7toQRf, l);
    for (tiG9twfHr = 0; tiG9twfHr < l; tiG9twfHr++) {
        if (!((281 - 280) != l))
            printf ("(%s,1)", a);
        if (tiG9twfHr == 0) {
            dlrYTMv = a[tiG9twfHr];
            gv9IT73MJy = gv9IT73MJy + 1;
        }
        else {
            if (tiG9twfHr != (l - (669 - 668))) {
                e = DzSB1w8AEc (dlrYTMv, a[tiG9twfHr]);
                if (e == 0) {
                    printf ("(%c,%d)", dlrYTMv, gv9IT73MJy);
                    dlrYTMv = a[tiG9twfHr];
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            int temp = 0;
                            while (temp < 10) {
                                printf ("%d\n", temp);
                                temp = temp + 1;
                                if (temp == 9)
                                    break;
                            }
                        }
                    }
                    gv9IT73MJy = (31 - 30);
                }
                else
                    gv9IT73MJy++;
            }
            else if (dlrYTMv == a[l - 1])
                printf ("(%c,%d)", dlrYTMv, (gv9IT73MJy + 1));
            else {
                printf ("(%c,%d)", dlrYTMv, gv9IT73MJy);
                printf ("(%c,1)", a[l - 1]);
            };
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

