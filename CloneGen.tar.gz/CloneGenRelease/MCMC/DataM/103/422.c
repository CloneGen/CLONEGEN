main () {
    char mem [26] = {'\0'};
    char s [1000];
    int HqLQnhm;
    HqLQnhm = strlen (s);
    int Ovq0lasHzL = strlen (mem);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int fQFveBS3C, W9Uevj = (881 - 881);
    int cx0vQZPVWq5 [(355 - 329)];
    scanf ("%s", s);
    for (fQFveBS3C = (56 - 56); HqLQnhm > fQFveBS3C; fQFveBS3C++)
        if ('a' <= s[fQFveBS3C] && 'z' >= s[fQFveBS3C])
            s[fQFveBS3C] = s[fQFveBS3C] + 'A' - 'a';
    mem[0] = s[0];
    {
        fQFveBS3C = 0;
        while (fQFveBS3C < 26) {
            cx0vQZPVWq5[fQFveBS3C] = (738 - 737);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            fQFveBS3C = fQFveBS3C + 1;
        };
    }
    for (fQFveBS3C = (449 - 448); fQFveBS3C < HqLQnhm; fQFveBS3C++) {
        if (s[fQFveBS3C] == s[fQFveBS3C - 1])
            cx0vQZPVWq5[W9Uevj]++;
        else {
            W9Uevj++;
            mem[W9Uevj] = s[fQFveBS3C];
        };
    }
    {
        W9Uevj = 0;
        while (W9Uevj < Ovq0lasHzL) {
            printf ("(%c,%d)", mem[W9Uevj], cx0vQZPVWq5[W9Uevj]);
            W9Uevj++;
        };
    };
}

