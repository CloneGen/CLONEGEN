main () {
    int adhDwEPi7g8X;
    int j;
    int d10YS7VN;
    int RxB4yHl7;
    int RkmhT9fZrJno;
    int m;
    char a [(1665 - 665)];
    gets (a);
    getchar ();
    RxB4yHl7 = strlen (a);
    for (adhDwEPi7g8X = 0; RxB4yHl7 > adhDwEPi7g8X; adhDwEPi7g8X++) {
        if ('a' <= a[adhDwEPi7g8X] && 'z' >= a[adhDwEPi7g8X])
            a[adhDwEPi7g8X] = a[adhDwEPi7g8X] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    d10YS7VN = (798 - 797);
    for (adhDwEPi7g8X = 0; adhDwEPi7g8X < RxB4yHl7; adhDwEPi7g8X++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (a[adhDwEPi7g8X] == a[adhDwEPi7g8X + 1])
            d10YS7VN++;
        else {
            printf ("(%c,%d)", a[adhDwEPi7g8X], d10YS7VN);
            d10YS7VN = 1;
        };
    }
    getchar ();
}

