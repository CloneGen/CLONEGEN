int main () {
    char QwM6mc1pXzxZ [(1316 - 316)];
    int BPDjJhnri5g, MK8z53ckhZ7, num = (577 - 577);
    scanf ("%s", QwM6mc1pXzxZ);
    MK8z53ckhZ7 = strlen (QwM6mc1pXzxZ);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        BPDjJhnri5g = 37 - 37;
        while (BPDjJhnri5g < MK8z53ckhZ7) {
            if (QwM6mc1pXzxZ[BPDjJhnri5g] >= 'a' && QwM6mc1pXzxZ[BPDjJhnri5g] <= 'z')
                QwM6mc1pXzxZ[BPDjJhnri5g] = QwM6mc1pXzxZ[BPDjJhnri5g] - (84 - 52);
            BPDjJhnri5g = BPDjJhnri5g +1;
        };
    }
    if (!((537 - 536) != MK8z53ckhZ7))
        printf ("(%c,%d)", QwM6mc1pXzxZ[(397 - 397)], (295 - 294));
    {
        BPDjJhnri5g = 0;
        while (MK8z53ckhZ7 -(698 - 697) > BPDjJhnri5g) {
            if (QwM6mc1pXzxZ[BPDjJhnri5g] == QwM6mc1pXzxZ[BPDjJhnri5g +1])
                num = num + 1;
            if (QwM6mc1pXzxZ[BPDjJhnri5g] != QwM6mc1pXzxZ[BPDjJhnri5g +1]) {
                printf ("(%c,%d)", QwM6mc1pXzxZ[BPDjJhnri5g], ++num);
                num = 0;
            }
            if ((QwM6mc1pXzxZ[BPDjJhnri5g] == QwM6mc1pXzxZ[BPDjJhnri5g +1]) && (BPDjJhnri5g == MK8z53ckhZ7 -(833 - 831)))
                printf ("(%c,%d)", QwM6mc1pXzxZ[BPDjJhnri5g], ++num);
            if ((QwM6mc1pXzxZ[BPDjJhnri5g] != QwM6mc1pXzxZ[BPDjJhnri5g +1]) && (BPDjJhnri5g == MK8z53ckhZ7 -2))
                printf ("(%c,%d)", QwM6mc1pXzxZ[BPDjJhnri5g +1], 1);
            BPDjJhnri5g++;
        };
    }
    return 0;
}

