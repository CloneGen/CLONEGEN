int main () {
    int mem [(1839 - 838)];
    int count;
    count = (623 - 622);
    int hc0xgw6YRdb;
    int j;
    int f7StpG9U0, ObO0T8IhWx;
    char RoVigs [(1742 - 741)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char s [(1770 - 769)];
    memset (mem, (349 - 349), sizeof (mem));
    cin.getline (s, sizeof (s));
    j = (493 - 492);
    RoVigs[(365 - 364)] = s[(769 - 769)];
    for (hc0xgw6YRdb = (695 - 695); !(0 == s[hc0xgw6YRdb]); hc0xgw6YRdb++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(RoVigs[j] != s[hc0xgw6YRdb]) || s[hc0xgw6YRdb] - 'a' == RoVigs[j] - 'A' || s[hc0xgw6YRdb] - 'A' == RoVigs[j] - 'a') {
            mem[j]++;
        }
        else {
            count++;
            j++;
            RoVigs[j] = s[hc0xgw6YRdb];
            mem[j]++;
        };
    }
    for (hc0xgw6YRdb = (242 - 241); hc0xgw6YRdb <= count; hc0xgw6YRdb++) {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (RoVigs[hc0xgw6YRdb] >= 'a' && RoVigs[hc0xgw6YRdb] <= 'z') {
            RoVigs[hc0xgw6YRdb] = RoVigs[hc0xgw6YRdb] - 'a' + 'A';
        };
    }
    {
        hc0xgw6YRdb = 1;
        while (hc0xgw6YRdb <= count) {
            cout << "(" << RoVigs[hc0xgw6YRdb] << "," << mem[hc0xgw6YRdb] << ")";
            hc0xgw6YRdb++;
        };
    }
    return 0;
}

