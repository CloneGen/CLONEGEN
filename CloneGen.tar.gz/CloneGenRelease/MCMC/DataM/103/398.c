int main () {
    char wB18zhu [(1425 - 425)];
    char x;
    char p6v2NDOdHput [1000];
    int RDcW84Hy;
    int j;
    int k;
    int MmFid5Oz4BeK;
    int oZHFn3cjWC [1000] = {(282 - 282)};
    scanf ("%s", wB18zhu);
    k = strlen (wB18zhu);
    for (RDcW84Hy = (754 - 754); k > RDcW84Hy; RDcW84Hy++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if ('a' <= wB18zhu[RDcW84Hy] && wB18zhu[RDcW84Hy] <= 'z') {
            wB18zhu[RDcW84Hy] -= 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    p6v2NDOdHput[(981 - 981)] = wB18zhu[(522 - 522)];
    x = wB18zhu[0];
    {
        MmFid5Oz4BeK = 449 - 448;
        RDcW84Hy = 979 - 978;
        while (k > RDcW84Hy) {
            if (x != wB18zhu[RDcW84Hy]) {
                oZHFn3cjWC[MmFid5Oz4BeK] = RDcW84Hy;
                x = wB18zhu[RDcW84Hy];
                p6v2NDOdHput[MmFid5Oz4BeK] = wB18zhu[RDcW84Hy];
                MmFid5Oz4BeK = MmFid5Oz4BeK +1;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            RDcW84Hy++;
        };
    }
    oZHFn3cjWC[MmFid5Oz4BeK] = k;
    {
        RDcW84Hy = 0;
        while (RDcW84Hy <= MmFid5Oz4BeK -1) {
            printf ("(%c,%d)", p6v2NDOdHput[RDcW84Hy], oZHFn3cjWC[RDcW84Hy +1] - oZHFn3cjWC[RDcW84Hy]);
            RDcW84Hy++;
        };
    }
    return 0;
}

