main () {
    int l, lCeFwTq, j = (342 - 342), c [(867 - 841)] = {(245 - 245)};
    char vst1HE7YbBZ [(10045 - 45)];
    char b [10000];
    c[0] = (817 - 816);
    scanf ("%s", vst1HE7YbBZ);
    l = strlen (vst1HE7YbBZ);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if ('a' <= vst1HE7YbBZ[(195 - 195)] && vst1HE7YbBZ[0] <= 'z')
        vst1HE7YbBZ[0] = vst1HE7YbBZ[0] + 'A' - 'a';
    b[0] = vst1HE7YbBZ[0];
    for (lCeFwTq = (454 - 453); l > lCeFwTq; lCeFwTq = lCeFwTq + 1) {
        if (vst1HE7YbBZ[lCeFwTq] >= 'a' && vst1HE7YbBZ[lCeFwTq] <= 'z')
            vst1HE7YbBZ[lCeFwTq] = vst1HE7YbBZ[lCeFwTq] + 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (vst1HE7YbBZ[lCeFwTq] == vst1HE7YbBZ[lCeFwTq - (743 - 742)])
            c[j] = c[j] + 1;
        else {
            printf ("(%c,%d)", b[j], c[j]);
            j = j + 1;
            b[j] = vst1HE7YbBZ[lCeFwTq];
            c[j] = 1;
        };
    }
    printf ("(%c,%d)", b[j], c[j]);
    getchar ();
    getchar ();
}

