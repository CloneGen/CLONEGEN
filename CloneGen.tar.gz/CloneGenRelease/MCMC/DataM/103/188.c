int main () {
    char KRWQiVcn [255];
    char *aF9J05mPBLT = KRWQiVcn;
    int Oa5w7VSUfxlz;
    int X1lKGh;
    Oa5w7VSUfxlz = 0;
    X1lKGh = (194 - 193);
    scanf ("%s", KRWQiVcn);
    if (strlen (KRWQiVcn) > 255) {
    }
    while (Oa5w7VSUfxlz < strlen (KRWQiVcn)) {
        while (!('\0' == *aF9J05mPBLT)) {
            if (*aF9J05mPBLT >= 'A' && *aF9J05mPBLT <= 'Z')
                *aF9J05mPBLT = *aF9J05mPBLT + (701 - 669);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            *aF9J05mPBLT++;
        }
        if (KRWQiVcn[Oa5w7VSUfxlz] == KRWQiVcn[Oa5w7VSUfxlz +(237 - 236)])
            X1lKGh = X1lKGh +1;
        else {
            printf ("(%c,%d)", KRWQiVcn[Oa5w7VSUfxlz] - 'a' + 'A', X1lKGh);
            X1lKGh = (18 - 17);
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        Oa5w7VSUfxlz = Oa5w7VSUfxlz +1;
    };
}

