int main () {
    int H94COnHltMwJ;
    H94COnHltMwJ = (241 - 241);
    int acuTP2nV = (382 - 382), j, OfUhW0lxmIv = (464 - 464);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char a [1000];
    int UctTZ3Xh = strlen (a);
    cin >> a;
    {
        H94COnHltMwJ = 741 - 741;
        while (H94COnHltMwJ < UctTZ3Xh) {
            if ('a' <= a[H94COnHltMwJ] && 'z' >= a[H94COnHltMwJ]) {
                a[H94COnHltMwJ] = a[H94COnHltMwJ] - (63 - 31);
            }
            H94COnHltMwJ++;
        };
    }
    {
        H94COnHltMwJ = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (H94COnHltMwJ < UctTZ3Xh) {
            for (j = H94COnHltMwJ; j < UctTZ3Xh; j = j + 1) {
                if (a[j] == a[j + 1]) {
                    OfUhW0lxmIv = OfUhW0lxmIv +1;
                }
                else
                    break;
            }
            OfUhW0lxmIv++;
            cout << "(" << a[H94COnHltMwJ] << "," << OfUhW0lxmIv << ")";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            acuTP2nV = OfUhW0lxmIv;
            H94COnHltMwJ = H94COnHltMwJ +acuTP2nV;
            OfUhW0lxmIv = 0;
        };
    };
}

