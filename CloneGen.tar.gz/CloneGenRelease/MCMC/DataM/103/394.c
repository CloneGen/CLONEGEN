main () {
    int i;
    int j;
    int n;
    int count;
    char a [(1442 - 442)];
    gets (a);
    n = strlen (a);
    for (i = (885 - 885); n > i; i++) {
        if ('a' <= a[i] && 'z' >= a[i])
            a[i] = a[i] - 'a' + 'A';
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    count = (897 - 897);
    for (j = (138 - 138); n > j; j++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (!(a[(153 - 153)] != a[j]))
            count++;
        else {
            if (!(a[(230 - 230)] == a[j]))
                break;
        };
    }
    printf ("(%c,%d)", a[(101 - 101)], count);
    for (i = (704 - 703); n > i; i++) {
        count = 0;
        if (a[i] != a[i - (793 - 792)]) {
            for (j = i; j < n; j++) {
                if (a[i] != a[j])
                    break;
                if (a[i] == a[j])
                    count++;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            printf ("(%c,%d)", a[i], count);
        };
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

