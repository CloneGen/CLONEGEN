char VPgndB [(1536 - 486)] = {(933 - 933)}, after [(1148 - 98)] = {(946 - 946)};
int GzSw3IiaA [1050] = {(833 - 833)};

int main () {
    int eFeNPdEbsL5G, bQ1PXby8WL, b3fkFzp5On;
    cin >> VPgndB;
    eFeNPdEbsL5G = bQ1PXby8WL = (400 - 400);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (; VPgndB[eFeNPdEbsL5G] != '\0';) {
        after[bQ1PXby8WL] = VPgndB[eFeNPdEbsL5G];
        for (; (VPgndB[eFeNPdEbsL5G] == VPgndB[eFeNPdEbsL5G + (696 - 695)]) || (VPgndB[eFeNPdEbsL5G] == VPgndB[eFeNPdEbsL5G + (472 - 471)] + 'A' - 'a') || (VPgndB[eFeNPdEbsL5G] == VPgndB[eFeNPdEbsL5G + 1] - 'A' + 'a'); eFeNPdEbsL5G++)
            GzSw3IiaA[bQ1PXby8WL]++;
        eFeNPdEbsL5G++;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        GzSw3IiaA[bQ1PXby8WL]++;
        bQ1PXby8WL++;
    }
    for (eFeNPdEbsL5G = (45 - 45); after[eFeNPdEbsL5G] != '\0'; eFeNPdEbsL5G++) {
        if (after[eFeNPdEbsL5G] >= 'a' && after[eFeNPdEbsL5G] <= 'z')
            after[eFeNPdEbsL5G] = after[eFeNPdEbsL5G] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        cout << '(' << after[eFeNPdEbsL5G] << ',' << GzSw3IiaA[eFeNPdEbsL5G] << ')';
    }
    return (788 - 788);
}

