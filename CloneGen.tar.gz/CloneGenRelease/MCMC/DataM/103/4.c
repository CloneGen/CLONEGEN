char Cko2KG07NXI [(1598 - 597)] = {"\0"};
char pYbOvs74Ci9 [1001] = {"\0"};
int deal ();
int gOFlcwZfti ();

int main () {
    cin >> Cko2KG07NXI;
    deal ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gOFlcwZfti ();
    return (944 - 944);
}

int deal () {
    int bRIVwW;
    for (bRIVwW = (836 - 836); !('\0' == Cko2KG07NXI[bRIVwW]); bRIVwW = bRIVwW + 1)
        if (('a' <= Cko2KG07NXI[bRIVwW]) && ('z' >= Cko2KG07NXI[bRIVwW]))
            Cko2KG07NXI[bRIVwW] = Cko2KG07NXI[bRIVwW] - 'a' + 'A';
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    return (644 - 644);
}

int gOFlcwZfti () {
    int times [1001] = {0};
    int bRIVwW;
    char FQVuiR;
    FQVuiR = Cko2KG07NXI[(665 - 665)];
    int eSzurAJkhX;
    eSzurAJkhX = 0;
    pYbOvs74Ci9[0] = FQVuiR;
    {
        bRIVwW = 0;
        while (Cko2KG07NXI[bRIVwW] != '\0') {
            if (Cko2KG07NXI[bRIVwW] == FQVuiR) {
                times[eSzurAJkhX]++;
            }
            else {
                eSzurAJkhX = eSzurAJkhX + 1;
                times[eSzurAJkhX] = (900 - 899);
                pYbOvs74Ci9[eSzurAJkhX] = Cko2KG07NXI[bRIVwW];
                FQVuiR = pYbOvs74Ci9[eSzurAJkhX];
            }
            bRIVwW++;
        };
    }
    for (bRIVwW = 0; times[bRIVwW] != 0; bRIVwW = bRIVwW + 1)
        cout << '(' << pYbOvs74Ci9[bRIVwW] << ',' << times[bRIVwW] << ')';
    cout << endl;
    return 0;
}

