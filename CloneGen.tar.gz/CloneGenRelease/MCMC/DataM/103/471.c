int main () {
    char WsSy4hDM0eJ6 [(1696 - 696)];
    int l;
    int k;
    cin >> WsSy4hDM0eJ6;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    l = strlen (WsSy4hDM0eJ6);
    {
        int CqjcoYDztIbi = (225 - 225);
        while (l > CqjcoYDztIbi) {
            if (WsSy4hDM0eJ6[CqjcoYDztIbi] >= 'a' && WsSy4hDM0eJ6[CqjcoYDztIbi] <= 'z')
                WsSy4hDM0eJ6[CqjcoYDztIbi] = WsSy4hDM0eJ6[CqjcoYDztIbi] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            CqjcoYDztIbi = CqjcoYDztIbi +1;
        };
    }
    {
        int CqjcoYDztIbi = (992 - 992);
        while (CqjcoYDztIbi < l) {
            k = 0;
            for (int j = CqjcoYDztIbi;
            j < l; j++) {
                if (WsSy4hDM0eJ6[j] == WsSy4hDM0eJ6[CqjcoYDztIbi])
                    k++;
                else
                    break;
            }
            cout << "(" << WsSy4hDM0eJ6[CqjcoYDztIbi] << "," << k << ")";
            CqjcoYDztIbi = CqjcoYDztIbi +k - (392 - 391);
            CqjcoYDztIbi++;
        };
    }
    cout << endl;
    return 0;
}

