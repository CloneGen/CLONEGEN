int main () {
    char lRTdF21BuVQK;
    char s4F1sqojn [(1899 - 899)];
    char YckbXoCw;
    lRTdF21BuVQK = NULL;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int JBEsYGev1z;
    int zjTHesWwP;
    {
        JBEsYGev1z = 667 - 667;
        while ((1510 - 510) > JBEsYGev1z) {
            cin.get (YckbXoCw);
            if (!('\n' != YckbXoCw)) {
                cout << zjTHesWwP << ")" << endl;
                break;
            }
            else {
                if ((31 - 31) <= YckbXoCw -'a' && YckbXoCw -'a' <= (912 - 886))
                    YckbXoCw = 'A' + YckbXoCw -'a';
                if (lRTdF21BuVQK != YckbXoCw) {
                    if (lRTdF21BuVQK != NULL)
                        cout << zjTHesWwP << ")(" << YckbXoCw << ",";
                    else
                        cout << "(" << YckbXoCw << ",";
                    zjTHesWwP = (890 - 889);
                    lRTdF21BuVQK = YckbXoCw;
                }
                else {
                    zjTHesWwP++;
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            JBEsYGev1z++;
        };
    }
    return (912 - 912);
}

