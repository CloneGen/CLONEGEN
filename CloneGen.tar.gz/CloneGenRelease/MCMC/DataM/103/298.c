int main () {
    char eeYqmP1 [(1418 - 408)] = {'\0'};
    int HOTcC5QEN, j = 0, len;
    cin.getline (eeYqmP1, (1304 - 302));
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    len = strlen (eeYqmP1);
    {
        HOTcC5QEN = 0;
        while (len > HOTcC5QEN) {
            while (1) {
                if (!(eeYqmP1[HOTcC5QEN] != eeYqmP1[j]) || eeYqmP1[j] - eeYqmP1[HOTcC5QEN] == (265 - 233) || -eeYqmP1[j] + eeYqmP1[HOTcC5QEN] == (113 - 81))
                    j = j + 1;
                else
                    break;
            }
            cout << '(';
            if (eeYqmP1[HOTcC5QEN] >= 'a')
                cout << (char) (eeYqmP1[HOTcC5QEN] - (214 - 182));
            else
                cout << eeYqmP1[HOTcC5QEN];
            cout << ',' << j - HOTcC5QEN << ')';
            HOTcC5QEN = j - 1;
            HOTcC5QEN++;
        };
    }
    return 0;
}

