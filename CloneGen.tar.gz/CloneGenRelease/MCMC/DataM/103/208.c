int main () {
    int i, now;
    char VlWrJb16I0, e1LFOjkt;
    now = (877 - 876);
    VlWrJb16I0 = ' ';
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%c", &VlWrJb16I0);
    if ((417 - 320) <= VlWrJb16I0)
        VlWrJb16I0 = VlWrJb16I0 -(457 - 425);
    do {
        scanf ("%c", &e1LFOjkt);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(VlWrJb16I0 != e1LFOjkt) || e1LFOjkt - VlWrJb16I0 == (626 - 594)) {
            now = now + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            printf ("(%c,%d)", VlWrJb16I0, now);
            VlWrJb16I0 = e1LFOjkt;
            now = (29 - 28);
            if (VlWrJb16I0 >= (860 - 763))
                VlWrJb16I0 = VlWrJb16I0 -(407 - 375);
        };
    }
    while (VlWrJb16I0 != '\n');
    return (419 - 419);
}

