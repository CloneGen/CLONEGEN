int main () {
    int ZydEalL2B;
    int oZC0AlEO;
    int FzYaUspG90;
    int Nyq8gl;
    ZydEalL2B = 0;
    int BJsSBG2e5 [1005] = {(81 - 81)};
    int pXDLA7zdbiSh [1005] = {0};
    int ACIJiMh [1005] = {0};
    char P9TAYupHdtX [1005] = {(213 - 213)};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    ACIJiMh[0] = (666 - 665);
    cin.getline (P9TAYupHdtX, 1000);
    Nyq8gl = strlen (P9TAYupHdtX);
    {
        oZC0AlEO = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (oZC0AlEO < Nyq8gl) {
            if ((P9TAYupHdtX[oZC0AlEO] - 'A') >= 0 && (P9TAYupHdtX[oZC0AlEO] - 'A') <= (810 - 784))
                BJsSBG2e5[oZC0AlEO] = P9TAYupHdtX[oZC0AlEO] - 'A';
            if ((P9TAYupHdtX[oZC0AlEO] - 'a') >= 0 && (P9TAYupHdtX[oZC0AlEO] - 'a') <= 26)
                BJsSBG2e5[oZC0AlEO] = P9TAYupHdtX[oZC0AlEO] - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            oZC0AlEO++;
        };
    }
    FzYaUspG90 = BJsSBG2e5[0];
    pXDLA7zdbiSh[0] = BJsSBG2e5[0];
    {
        oZC0AlEO = 1;
        while (oZC0AlEO < Nyq8gl) {
            if (BJsSBG2e5[oZC0AlEO] == FzYaUspG90)
                ACIJiMh[ZydEalL2B]++;
            else {
                ZydEalL2B = ZydEalL2B +1;
                FzYaUspG90 = BJsSBG2e5[oZC0AlEO];
                pXDLA7zdbiSh[ZydEalL2B] = BJsSBG2e5[oZC0AlEO];
                ACIJiMh[ZydEalL2B] = 1;
            }
            oZC0AlEO++;
        };
    }
    {
        oZC0AlEO = 0;
        while (oZC0AlEO <= ZydEalL2B) {
            cout << '(' << (char) (pXDLA7zdbiSh[oZC0AlEO] + 'A') << ',' << ACIJiMh[oZC0AlEO] << ')';
            oZC0AlEO++;
        };
    }
    return 0;
}

