main () {
    int MTin36w;
    MTin36w = (977 - 976);
    char o2hpQldS5T [1000];
    gets (o2hpQldS5T);
    int QwQFUL0;
    for (QwQFUL0 = (999 - 999); strlen (o2hpQldS5T) - (595 - 594) >= QwQFUL0; QwQFUL0 = QwQFUL0 +1)
        if (((o2hpQldS5T[QwQFUL0] >= 'a') && ('z' >= o2hpQldS5T[QwQFUL0]))) {
            o2hpQldS5T[QwQFUL0] = o2hpQldS5T[QwQFUL0] + 'A' - 'a';
        }
    if (strlen (o2hpQldS5T) == (23 - 22))
        printf ("(%c,%d)", o2hpQldS5T[(130 - 130)], (465 - 464));
    else {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        for (QwQFUL0 = (146 - 145); QwQFUL0 <= strlen (o2hpQldS5T) - (786 - 785); QwQFUL0++) {
            if (o2hpQldS5T[QwQFUL0] == o2hpQldS5T[QwQFUL0 -(776 - 775)])
                MTin36w++;
            else {
                printf ("(%c,%d)", o2hpQldS5T[QwQFUL0 -(327 - 326)], MTin36w);
                MTin36w = (431 - 430);
            }
            if (o2hpQldS5T[QwQFUL0 +1] == (818 - 818))
                printf ("(%c,%d)", o2hpQldS5T[QwQFUL0], MTin36w);
        };
    }
    return 0;
}

