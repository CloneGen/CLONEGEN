int main () {
    int s [(517 - 491)];
    int n = 1, q0zajGBZun5, zlFtm6BI2, m = (752 - 752);
    char vwfOegRW [1001], y [(526 - 499)] = "abcdefghijklmnopqrstuvwxyz", z [(483 - 456)] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", vwfOegRW);
    for (q0zajGBZun5 = (916 - 916); strlen (vwfOegRW) > q0zajGBZun5; q0zajGBZun5 = q0zajGBZun5 + 1) {
        {
            zlFtm6BI2 = 0;
            while (zlFtm6BI2 < 26) {
                if (vwfOegRW[q0zajGBZun5] == y[zlFtm6BI2])
                    vwfOegRW[q0zajGBZun5] = z[zlFtm6BI2];
                zlFtm6BI2++;
            };
        };
    }
    for (q0zajGBZun5 = 0; q0zajGBZun5 < strlen (vwfOegRW); q0zajGBZun5 = q0zajGBZun5 + n) {
        printf ("(%c,", vwfOegRW[q0zajGBZun5]);
        {
            n = 0;
            while ((strlen (vwfOegRW) - q0zajGBZun5) > n) {
                if (vwfOegRW[q0zajGBZun5 + n] == vwfOegRW[q0zajGBZun5])
                    m++;
                else
                    break;
                n = n + 1;
            };
        }
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        printf ("%d)", m);
        m = 0;
    };
}

