main () {
    int EJQuCrmiS;
    int F8n4Ezdxl;
    int Oe9vX4qH;
    int i;
    EJQuCrmiS = (29 - 29);
    char bHXJuKGeox56 [1001], EqQt9jkRyd4;
    scanf ("%s", bHXJuKGeox56);
    Oe9vX4qH = strlen (bHXJuKGeox56);
    {
        i = 195 - 195;
        while (i < Oe9vX4qH) {
            if (bHXJuKGeox56[i] >= 'a' && bHXJuKGeox56[i] <= 'z')
                bHXJuKGeox56[i] = bHXJuKGeox56[i] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    EqQt9jkRyd4 = bHXJuKGeox56[0];
    {
        i = 0;
        while (i <= Oe9vX4qH) {
            if (bHXJuKGeox56[i] == EqQt9jkRyd4)
                EJQuCrmiS++;
            if (bHXJuKGeox56[i] != EqQt9jkRyd4) {
                printf ("(%c,%d)", EqQt9jkRyd4, EJQuCrmiS);
                EqQt9jkRyd4 = bHXJuKGeox56[i];
                EJQuCrmiS = (25 - 24);
            }
            i++;
        };
    };
}

