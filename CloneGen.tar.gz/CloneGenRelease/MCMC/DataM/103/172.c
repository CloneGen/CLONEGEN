main () {
    int ncount;
    ncount = (331 - 330);
    int nu0Top6Adf;
    char a [(1676 - 675)];
    int sE0xkXWzi7t = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    getchar ();
    getchar ();
    getchar ();
    scanf ("%s", a);
    {
        nu0Top6Adf = 937 - 937;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (nu0Top6Adf < sE0xkXWzi7t) {
            if ('a' <= a[nu0Top6Adf] && a[nu0Top6Adf] <= 'z')
                a[nu0Top6Adf] = a[nu0Top6Adf] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            nu0Top6Adf = nu0Top6Adf + 1;
        };
    }
    {
        nu0Top6Adf = 0;
        while (nu0Top6Adf < sE0xkXWzi7t) {
            if (a[nu0Top6Adf + (504 - 503)] == a[nu0Top6Adf])
                ncount = ncount + 1;
            else {
                printf ("(%c,%d)", a[nu0Top6Adf], ncount);
                ncount = 1;
            }
            nu0Top6Adf++;
        };
    };
}

