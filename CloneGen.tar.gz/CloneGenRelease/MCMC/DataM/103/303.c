int main () {
    char B0GacUA, bu68Cbf = '0';
    int Fcqm2d = (634 - 633), ErqdB9csWb6N = (772 - 771);
    while (!('\n' == (B0GacUA = cin.get ()))) {
        ErqdB9csWb6N = (721 - 720);
        if (bu68Cbf >= 'a' && bu68Cbf <= 'z')
            if (B0GacUA == bu68Cbf || B0GacUA == bu68Cbf - (234 - 202)) {
                Fcqm2d = Fcqm2d +1;
                ErqdB9csWb6N = (249 - 249);
            }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (bu68Cbf >= 'A' && bu68Cbf <= 'Z')
            if (B0GacUA == bu68Cbf || B0GacUA == bu68Cbf + 32) {
                ErqdB9csWb6N = (230 - 230);
                Fcqm2d++;
            }
        if (ErqdB9csWb6N) {
            if (bu68Cbf != '0')
                cout << Fcqm2d << ")";
            if (B0GacUA == 'a') {
                cout << "(A,";
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                };
            }
            else if (B0GacUA == 'A') {
                cout << "(A,";
            }
            else if (B0GacUA == 'b') {
                cout << "(B,";
            }
            else if (B0GacUA == 'B') {
                cout << "(B,";
            }
            else if (B0GacUA == 'c') {
                cout << "(C,";
            }
            else if (B0GacUA == 'C') {
                cout << "(C,";
            }
            else if (B0GacUA == 'd') {
                cout << "(D,";
            }
            else if (B0GacUA == 'D') {
                cout << "(D,";
            }
            else if (B0GacUA == 'e') {
                cout << "(E,";
            }
            else if (B0GacUA == 'E') {
                cout << "(E,";
            }
            else if (B0GacUA == 'f') {
                cout << "(F,";
            }
            else if (B0GacUA == 'F') {
                cout << "(F,";
            }
            else if (B0GacUA == 'g') {
                cout << "(G,";
            }
            else if (B0GacUA == 'G') {
                cout << "(G,";
            }
            else if (B0GacUA == 'h') {
                cout << "(H,";
            }
            else if (B0GacUA == 'H') {
                cout << "(H,";
            }
            else if (B0GacUA == 'i') {
                cout << "(I,";
            }
            else if (B0GacUA == 'I') {
                cout << "(I,";
            }
            else if (B0GacUA == 'j') {
                cout << "(J,";
            }
            else if (B0GacUA == 'J') {
                cout << "(J,";
            }
            else if (B0GacUA == 'k') {
                cout << "(K,";
            }
            else if (B0GacUA == 'K') {
                cout << "(K,";
            }
            else if (B0GacUA == 'l') {
                cout << "(L,";
            }
            else if (B0GacUA == 'L') {
                cout << "(L,";
            }
            else if (B0GacUA == 'm') {
                cout << "(M,";
            }
            else if (B0GacUA == 'M') {
                cout << "(M,";
            }
            else if (B0GacUA == 'n') {
                cout << "(N,";
            }
            else if (B0GacUA == 'N') {
                cout << "(N,";
            }
            else if (B0GacUA == 'o') {
                cout << "(O,";
            }
            else if (B0GacUA == 'O') {
                cout << "(O,";
            }
            else if (B0GacUA == 'p') {
                cout << "(P,";
            }
            else if (B0GacUA == 'P') {
                cout << "(P,";
            }
            else if (B0GacUA == 'q') {
                cout << "(Q,";
            }
            else if (B0GacUA == 'Q') {
                cout << "(Q,";
            }
            else if (B0GacUA == 'r') {
                cout << "(R,";
            }
            else if (B0GacUA == 'R') {
                cout << "(R,";
            }
            else if (B0GacUA == 's') {
                cout << "(S,";
            }
            else if (B0GacUA == 'S') {
                cout << "(S,";
            }
            else if (B0GacUA == 't') {
                cout << "(T,";
            }
            else if (B0GacUA == 'T') {
                cout << "(T,";
            }
            else if (B0GacUA == 'u') {
                cout << "(U,";
            }
            else if (B0GacUA == 'U') {
                cout << "(U,";
            }
            else if (B0GacUA == 'v') {
                cout << "(V,";
            }
            else if (B0GacUA == 'V') {
                cout << "(V,";
            }
            else if (B0GacUA == 'w') {
                cout << "(W,";
            }
            else if (B0GacUA == 'W') {
                cout << "(W,";
            }
            else if (B0GacUA == 'x') {
                cout << "(X,";
            }
            else if (B0GacUA == 'X') {
                cout << "(X,";
            }
            else if (B0GacUA == 'y') {
                cout << "(Y,";
            }
            else if (B0GacUA == 'Y') {
                cout << "(Y,";
            }
            else if (B0GacUA == 'z') {
                cout << "(Z,";
            }
            else if (B0GacUA == 'Z') {
                cout << "(Z,";
            }
            else {
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            bu68Cbf = B0GacUA;
            Fcqm2d = (255 - 254);
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cout << Fcqm2d << ")" << endl;
    return 0;
}

