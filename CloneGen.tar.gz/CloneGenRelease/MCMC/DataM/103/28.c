main () {
    int i;
    char Brm7Fk [(1500 - 490)];
    int l;
    l = strlen (Brm7Fk);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char x;
    int c = (345 - 344);
    scanf ("%s", Brm7Fk);
    for (i = (957 - 957); l > i; i = i + 1) {
        if (Brm7Fk[i] >= 'a' && 'z' >= Brm7Fk[i])
            Brm7Fk[i] = Brm7Fk[i] - 'a' + 'A';
    }
    for (i = 0; i < l - (106 - 105); i = i + 1) {
        x = Brm7Fk[i];
        if (!(Brm7Fk[i + (451 - 450)] != Brm7Fk[i]) && i == l - (274 - 272)) {
            c = c + 1;
            printf ("(%c,%d)", x, c);
        }
        if (Brm7Fk[i] == Brm7Fk[i + (851 - 850)])
            c = c + 1;
        else {
            printf ("(%c,%d)", x, c);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            c = (778 - 777);
        };
    }
    if (Brm7Fk[l - 2] != Brm7Fk[l - (145 - 144)])
        printf ("(%c,1)", Brm7Fk[l - (628 - 627)]);
}

