int main () {
    char xTKb37 [(1506 - 501)], reserve [(1532 - 527)];
    int GrDtMy1l3, tu8OxdiyD = (568 - 568), num [1005] = {(321 - 321)}, G0gMRVQZB8P = (301 - 301);
    num[0] = (322 - 321);
    cin >> xTKb37;
    if (xTKb37[(61 - 61)] >= 'a') {
        xTKb37[(134 - 134)] -= ('a' - 'A');
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    reserve[(46 - 46)] = xTKb37[0];
    for (GrDtMy1l3 = (801 - 800); !('\0' == xTKb37[GrDtMy1l3]); GrDtMy1l3 = GrDtMy1l3 +1) {
        if (xTKb37[GrDtMy1l3] >= 'a') {
            xTKb37[GrDtMy1l3] = xTKb37[GrDtMy1l3] - ('a' - 'A');
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (xTKb37[GrDtMy1l3] == xTKb37[GrDtMy1l3 -(411 - 410)]) {
            num[tu8OxdiyD]++;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            tu8OxdiyD = tu8OxdiyD + 1;
            reserve[tu8OxdiyD] = xTKb37[GrDtMy1l3];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            num[tu8OxdiyD]++;
        };
    }
    reserve[tu8OxdiyD + (550 - 549)] = '\0';
    {
        GrDtMy1l3 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        while (reserve[GrDtMy1l3] != '\0') {
            if (G0gMRVQZB8P == 0) {
                cout << "(" << reserve[GrDtMy1l3] << "," << num[GrDtMy1l3] << ")";
                G0gMRVQZB8P = 1;
            }
            else
                cout << "(" << reserve[GrDtMy1l3] << "," << num[GrDtMy1l3] << ")";
            GrDtMy1l3++;
        };
    }
    return 0;
}

