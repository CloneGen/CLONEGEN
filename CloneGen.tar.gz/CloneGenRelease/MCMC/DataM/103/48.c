int main () {
    int num [1000] = {(971 - 971)};
    int i4dkxtTgmwI;
    int Ld504oUL7CB;
    int LT5Mnsej1zwU;
    char vMHfT9X [(1510 - 510)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    cin >> vMHfT9X;
    LT5Mnsej1zwU = strlen (vMHfT9X);
    {
        i4dkxtTgmwI = 916 - 916;
        while (LT5Mnsej1zwU > i4dkxtTgmwI) {
            if (vMHfT9X[i4dkxtTgmwI] > 'Z') {
                vMHfT9X[i4dkxtTgmwI] = vMHfT9X[i4dkxtTgmwI] - 'a' + 'A';
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i4dkxtTgmwI = i4dkxtTgmwI + 1;
        };
    }
    {
        i4dkxtTgmwI = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i4dkxtTgmwI < LT5Mnsej1zwU) {
            Ld504oUL7CB = i4dkxtTgmwI;
            while (vMHfT9X[Ld504oUL7CB] == vMHfT9X[i4dkxtTgmwI]) {
                Ld504oUL7CB = Ld504oUL7CB +1;
                num[i4dkxtTgmwI]++;
            }
            cout << "(" << vMHfT9X[i4dkxtTgmwI] << "," << num[i4dkxtTgmwI] << ")";
            i4dkxtTgmwI = Ld504oUL7CB -(356 - 355);
            i4dkxtTgmwI = i4dkxtTgmwI + 1;
        };
    }
    return 0;
}

