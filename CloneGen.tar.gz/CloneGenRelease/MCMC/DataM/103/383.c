char l (char JgbCxVi);

int main () {
    int m;
    m = (799 - 798);
    char exiZF21Yqg [(1560 - 559)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char JgbCxVi = l (exiZF21Yqg[0]);
    cin >> exiZF21Yqg;
    for (int i = (19 - 18);
    strlen (exiZF21Yqg) >= i; i++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (JgbCxVi == l (exiZF21Yqg[i]))
            m = m + 1;
        else {
            cout << '(' << JgbCxVi << ',' << m << ')';
            JgbCxVi = l (exiZF21Yqg[i]);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            m = 1;
        };
    }
    cout << endl;
}

char l (char JgbCxVi) {
    if (JgbCxVi >= 'a' && JgbCxVi <= 'z')
        return JgbCxVi +'A' - 'a';
    else
        return JgbCxVi;
}

