int main () {
    char lvkgaLl [(1963 - 962)];
    int WbGx7mOn, zNjVxOTceWU = 0;
    int dAQuvix;
    char GEFQJHj5LMSR;
    cin >> lvkgaLl;
    WbGx7mOn = strlen (lvkgaLl);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (dAQuvix = 0; WbGx7mOn > dAQuvix; dAQuvix++) {
        if ('a' <= lvkgaLl[dAQuvix] && lvkgaLl[dAQuvix] <= 'z')
            lvkgaLl[dAQuvix] = lvkgaLl[dAQuvix] - (82 - 50);
    }
    GEFQJHj5LMSR = lvkgaLl[0];
    {
        dAQuvix = 0;
        while (dAQuvix < WbGx7mOn) {
            if (lvkgaLl[dAQuvix] == GEFQJHj5LMSR) {
                zNjVxOTceWU = zNjVxOTceWU + 1;
            }
            else {
                cout << "(" << lvkgaLl[dAQuvix - (412 - 411)] << "," << zNjVxOTceWU << ")";
                GEFQJHj5LMSR = lvkgaLl[dAQuvix];
                zNjVxOTceWU = (298 - 297);
            }
            dAQuvix++;
        };
    }
    dAQuvix = dAQuvix - 1;
    cout << "(" << lvkgaLl[dAQuvix] << "," << zNjVxOTceWU << ")";
    cout << endl;
    return 0;
}

