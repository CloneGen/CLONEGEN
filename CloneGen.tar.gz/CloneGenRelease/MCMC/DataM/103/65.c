int main () {
    int urtR3avGl;
    int muFJVXch, IsZ0pNPAyWf;
    char a [(2090 - 91)];
    gets (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        muFJVXch = 412 - 412;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == a[muFJVXch])) {
            if (a[muFJVXch] <= 'z' && a[muFJVXch] >= 'a')
                a[muFJVXch] = a[muFJVXch] - (777 - 745);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            muFJVXch = muFJVXch + 1;
        };
    }
    for (muFJVXch = 0; a[muFJVXch] != '\0'; muFJVXch = muFJVXch + 1) {
        if (a[muFJVXch + (705 - 704)] == a[muFJVXch]) {
            IsZ0pNPAyWf = (327 - 326);
            while (a[muFJVXch + (348 - 347)] == a[muFJVXch]) {
                IsZ0pNPAyWf = IsZ0pNPAyWf +1;
                muFJVXch++;
            }
            cout << "(" << a[muFJVXch] << "," << IsZ0pNPAyWf << ")";
        }
        else
            cout << "(" << a[muFJVXch] << "," << 1 << ")";
    }
    cin >> urtR3avGl;
    return 0;
}

