int main () {
    int TOrH2kY3nD4;
    TOrH2kY3nD4 = (665 - 665);
    char a [1000];
    gets (a);
    char letter;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    letter = a[0];
    int again;
    again = 0;
    for (; a[TOrH2kY3nD4] != '\0';) {
        if (a[TOrH2kY3nD4] >= 'a' && a[TOrH2kY3nD4] <= 'z')
            a[TOrH2kY3nD4] += 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        TOrH2kY3nD4 = TOrH2kY3nD4 +1;
    }
    TOrH2kY3nD4 = (860 - 860);
    for (; 1;) {
        if (a[TOrH2kY3nD4] == letter)
            again++;
        if (a[TOrH2kY3nD4] != letter) {
            printf ("(%c,%d)", letter, again);
            again = 1;
            letter = a[TOrH2kY3nD4];
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (a[TOrH2kY3nD4] == '\0')
            break;
        TOrH2kY3nD4++;
    }
    return 0;
}

