int main () {
    char ya68pvCsyNK [1000];
    int O8Xs31, k, lo69eJ2F, FwP5icFxp8bG;
    gets (ya68pvCsyNK);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    FwP5icFxp8bG = strlen (ya68pvCsyNK);
    {
        O8Xs31 = 886 - 886;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (O8Xs31 <= FwP5icFxp8bG -1) {
            if (ya68pvCsyNK[O8Xs31] > 'Z')
                ya68pvCsyNK[O8Xs31] = ya68pvCsyNK[O8Xs31] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            O8Xs31 = O8Xs31 +1;
        };
    }
    for (O8Xs31 = (627 - 627); (1871 - 872) >= O8Xs31; O8Xs31++) {
        for (k = 1; k < (1700 - 702); k++) {
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (ya68pvCsyNK[O8Xs31 +k] != ya68pvCsyNK[O8Xs31]) {
                cout << "(" << ya68pvCsyNK[O8Xs31] << "," << k << ")";
                O8Xs31 = O8Xs31 +k - 1;
                break;
            };
        }
        if (O8Xs31 >= FwP5icFxp8bG -1)
            break;
    }
    return 0;
}

