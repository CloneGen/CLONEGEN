int main () {
    char MLD4jIfG [2000];
    int xZ5se2hdyaQY = 0;
    cin >> MLD4jIfG;
    while (!(0 == MLD4jIfG[xZ5se2hdyaQY])) {
        char cp9jM1OV8bdQ = MLD4jIfG[xZ5se2hdyaQY];
        int UVDfczeNgoKM = (779 - 778);
        char nVx50WO;
        for (; (!(0 != MLD4jIfG[xZ5se2hdyaQY + (294 - 293)] - MLD4jIfG[xZ5se2hdyaQY])) || (MLD4jIfG[xZ5se2hdyaQY + 1] - MLD4jIfG[xZ5se2hdyaQY]) == 'A' - 'a' || (MLD4jIfG[xZ5se2hdyaQY + 1] - MLD4jIfG[xZ5se2hdyaQY]) == 'a' - 'A';) {
            UVDfczeNgoKM++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            xZ5se2hdyaQY = xZ5se2hdyaQY + 1;
        }
        xZ5se2hdyaQY++;
        if (cp9jM1OV8bdQ >= 'a')
            nVx50WO = (char) (cp9jM1OV8bdQ - 'a' + 'A');
        else
            nVx50WO = cp9jM1OV8bdQ;
        cout << '(' << nVx50WO << ',' << UVDfczeNgoKM << ')';
    }
    return 0;
}

