int main () {
    int i, n, pSOpg7mly, ZE9eHJmfXqcl, lyKQduT4O9l;
    char TilbyV48dMO [(1717 - 717)];
    scanf ("%s", TilbyV48dMO);
    n = strlen (TilbyV48dMO);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (lyKQduT4O9l = (238 - 238); n > lyKQduT4O9l; lyKQduT4O9l++) {
        if (TilbyV48dMO[lyKQduT4O9l] > 'Z')
            TilbyV48dMO[lyKQduT4O9l] = TilbyV48dMO[lyKQduT4O9l] - 'a' + 'A';
    }
    for (i = 0; n > i;) {
        pSOpg7mly = 1;
        {
            ZE9eHJmfXqcl = i + 1;
            while (n > ZE9eHJmfXqcl) {
                if (TilbyV48dMO[i] == TilbyV48dMO[ZE9eHJmfXqcl])
                    pSOpg7mly += 1;
                else {
                    printf ("(%c,%d)", TilbyV48dMO[i], pSOpg7mly);
                    i = ZE9eHJmfXqcl;
                    break;
                }
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                ZE9eHJmfXqcl = ZE9eHJmfXqcl +1;
            };
        }
        i = ZE9eHJmfXqcl;
    }
    printf ("(%c,%d)", TilbyV48dMO[i - 1], pSOpg7mly);
    return 0;
}

