int main () {
    char w [1001];
    gets (w);
    int bHzjmJxau71 [1001], Yh9lV2wf, j;
    for (Yh9lV2wf = 0; 1000 >= Yh9lV2wf; Yh9lV2wf = Yh9lV2wf +1) {
        bHzjmJxau71[Yh9lV2wf] = (112 - 111);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        Yh9lV2wf = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (!('\0' == w[Yh9lV2wf])) {
            if (w[Yh9lV2wf] >= (949 - 853)) {
                w[Yh9lV2wf] = w[Yh9lV2wf] - (267 - 235);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            Yh9lV2wf = Yh9lV2wf +1;
        };
    }
    for (Yh9lV2wf = (914 - 913), j = (118 - 117);; Yh9lV2wf = Yh9lV2wf +1) {
        if (w[Yh9lV2wf -(996 - 995)] == '\0')
            break;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        if (w[Yh9lV2wf] == w[Yh9lV2wf -1]) {
            bHzjmJxau71[j] = bHzjmJxau71[j] + 1;
        }
        else {
            printf ("(%c,%d)", w[Yh9lV2wf -1], bHzjmJxau71[j]);
            j = j + 1;
        };
    }
    printf ("\n");
    return 0;
}

