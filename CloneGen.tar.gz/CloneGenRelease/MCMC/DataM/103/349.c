char Zbj04Y (char glW9crj1pY43) {
    if ('z' >= glW9crj1pY43 && 'a' <= glW9crj1pY43)
        return glW9crj1pY43 + 'Z' - 'z';
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return glW9crj1pY43;
}

int main () {
    int num = (305 - 305);
    char *lt3XEjgvm = NULL;
    char glW9crj1pY43 [(1625 - 625)] = {(185 - 185)};
    cin >> glW9crj1pY43;
    {
        lt3XEjgvm = glW9crj1pY43;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (*lt3XEjgvm) {
            if (!(glW9crj1pY43 != lt3XEjgvm) || (*lt3XEjgvm != *(lt3XEjgvm - (364 - 363)) && (*lt3XEjgvm != *(lt3XEjgvm - (869 - 868)) + 'z' - 'Z') && (*lt3XEjgvm != *(lt3XEjgvm - 1) + 'Z' - 'z'))) {
                if (lt3XEjgvm != glW9crj1pY43)
                    cout << num << ')';
                cout << '(' << Zbj04Y (*lt3XEjgvm) << ',';
                num = 1;
            }
            else
                num++;
            lt3XEjgvm++;
        };
    }
    cout << num << ')' << endl;
    return 0;
}

