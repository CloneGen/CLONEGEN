int main () {
    int JmwEs1r7H = (344 - 343);
    int Clh2NiLyJw5 = 0;
    char F1mFoRZ [(1502 - 502)] = {'\0'};
    cin >> F1mFoRZ;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    while (!('\0' == F1mFoRZ[Clh2NiLyJw5])) {
        if ('a' <= F1mFoRZ[Clh2NiLyJw5] && F1mFoRZ[Clh2NiLyJw5] <= 'z')
            F1mFoRZ[Clh2NiLyJw5] = F1mFoRZ[Clh2NiLyJw5] - (304 - 272);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        Clh2NiLyJw5 = Clh2NiLyJw5 +1;
    }
    Clh2NiLyJw5 = (39 - 38);
    while (F1mFoRZ[Clh2NiLyJw5] != '\0') {
        if (F1mFoRZ[Clh2NiLyJw5] == F1mFoRZ[Clh2NiLyJw5 -(515 - 514)])
            JmwEs1r7H = JmwEs1r7H +1;
        else {
            cout << '(' << F1mFoRZ[Clh2NiLyJw5 -(704 - 703)] << ',' << JmwEs1r7H << ')';
            JmwEs1r7H = 1;
        }
        Clh2NiLyJw5++;
    }
    cout << '(' << F1mFoRZ[Clh2NiLyJw5 -1] << ',' << JmwEs1r7H << ')';
    return 0;
}

