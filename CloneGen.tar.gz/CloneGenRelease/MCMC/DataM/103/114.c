int main () {
    int i, j;
    char words [(1233 - 231)] = {(772 - 772)};
    int g9Mnw3ivISse = {(778 - 778)};
    cin.getline (words, (1308 - 307), '\n');
    for (i = (172 - 172); !((648 - 648) == words[i]); i = i + 1) {
        g9Mnw3ivISse = (333 - 333);
        {
            j = i;
            while (!((922 - 922) == words[j])) {
                if (!(words[i] != words[j]) || words[j] == (words[i] + 'A' - 'a') || words[i] == (words[j] + 'A' - 'a'))
                    g9Mnw3ivISse = g9Mnw3ivISse + 1;
                else {
                    break;
                }
                j = j + 1;
            };
        }
        i = j - (261 - 260);
        if (words[i] <= 'z' && words[i] >= 'a')
            words[i] = words[i] + 'A' - 'a';
        cout << "(" << words[i] << "," << g9Mnw3ivISse << ")";
    }
    return (669 - 669);
}

