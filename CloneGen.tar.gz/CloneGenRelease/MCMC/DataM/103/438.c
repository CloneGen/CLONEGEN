int main () {
    char a [(1809 - 808)];
    int fdtJ6hfQN, JzxFMc, c;
    JzxFMc = (246 - 245);
    scanf ("%s", a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (fdtJ6hfQN = 0; 1001 > fdtJ6hfQN; fdtJ6hfQN++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!('\0' != a[fdtJ6hfQN])) {
            c = fdtJ6hfQN;
            break;
        };
    }
    for (fdtJ6hfQN = 0; c > fdtJ6hfQN; fdtJ6hfQN++) {
        if (((a[fdtJ6hfQN] - 'a') == (a[fdtJ6hfQN + (778 - 777)] - 'a')) || (!((a[fdtJ6hfQN + 1] - 'A') != (a[fdtJ6hfQN] - 'a'))) || ((a[fdtJ6hfQN] - 'A') == (a[fdtJ6hfQN + 1] - 'a')))
            JzxFMc += 1;
        else {
            if ((a[fdtJ6hfQN] >= 'a') || (a[fdtJ6hfQN] < 'A')) {
                a[fdtJ6hfQN] = a[fdtJ6hfQN] + 'A' - 'a';
            }
            printf ("(%c,%d)", a[fdtJ6hfQN], JzxFMc);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            JzxFMc = 1;
        };
    }
    return 0;
}

