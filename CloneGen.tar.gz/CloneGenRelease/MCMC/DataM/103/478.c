int main () {
    char str [2000] = {(522 - 522)};
    char SzMcONb3iV4B;
    int UGv93yefC;
    int ZdKMfPvri;
    int nTIvDmBt0d;
    int i0GAae [(2797 - 797)] = {(367 - 367)};
    int pOji0q6mr;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    cin.getline (str, 1003);
    nTIvDmBt0d = strlen (str);
    {
        UGv93yefC = 774 - 774;
        while (nTIvDmBt0d > UGv93yefC) {
            if ('a' <= str[UGv93yefC] && 'z' >= str[UGv93yefC])
                str[UGv93yefC] -= 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            UGv93yefC = UGv93yefC +1;
        };
    }
    for (UGv93yefC = 0; UGv93yefC < nTIvDmBt0d; UGv93yefC = UGv93yefC +1) {
        SzMcONb3iV4B = str[UGv93yefC];
        {
            ZdKMfPvri = 628 - 627;
            while (ZdKMfPvri < nTIvDmBt0d - UGv93yefC &&str[UGv93yefC +ZdKMfPvri] == SzMcONb3iV4B) {
                ZdKMfPvri++;
            };
        }
        i0GAae[UGv93yefC] = ZdKMfPvri;
        UGv93yefC = UGv93yefC +ZdKMfPvri-(233 - 232);
    }
    for (UGv93yefC = 0; UGv93yefC < nTIvDmBt0d; UGv93yefC++) {
        if (i0GAae[UGv93yefC] != 0)
            cout << '(' << str[UGv93yefC] << ',' << i0GAae[UGv93yefC] << ')';
    }
    return 0;
}

