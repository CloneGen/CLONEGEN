int main () {
    int CUaEgbn, LoBq3RGyQX = (704 - 704);
    char pM7X6A8D9TC [(1779 - 679)], QDM5Em;
    cin >> pM7X6A8D9TC;
    for (CUaEgbn = (369 - 369); CUaEgbn < strlen (pM7X6A8D9TC); CUaEgbn = CUaEgbn +1) {
        if (pM7X6A8D9TC[CUaEgbn] > (520 - 424))
            pM7X6A8D9TC[CUaEgbn] = pM7X6A8D9TC[CUaEgbn] - (996 - 964);
        if (pM7X6A8D9TC[CUaEgbn] == QDM5Em)
            LoBq3RGyQX++;
        else {
            if (CUaEgbn != 0)
                cout << LoBq3RGyQX << ')';
            cout << '(' << pM7X6A8D9TC[CUaEgbn] << ',';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            QDM5Em = pM7X6A8D9TC[CUaEgbn];
            LoBq3RGyQX = (113 - 112);
        };
    }
    cout << LoBq3RGyQX << ')' << endl;
    return 0;
}

