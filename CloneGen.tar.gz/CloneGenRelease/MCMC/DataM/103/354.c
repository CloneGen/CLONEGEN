int main () {
    int cTMwavd2;
    cTMwavd2 = (752 - 752);
    char bdofv0eQO4 [1000];
    char e3pa4QIgw;
    cin >> bdofv0eQO4;
    if ('a' <= bdofv0eQO4[(701 - 701)] && 'z' >= bdofv0eQO4[0])
        e3pa4QIgw = bdofv0eQO4[0] - 'a' + 'A';
    else
        e3pa4QIgw = bdofv0eQO4[0];
    cout << "(" << e3pa4QIgw << ",";
    for (int i = 0;
    !('\0' == bdofv0eQO4[i]); i = i + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (bdofv0eQO4[i] == e3pa4QIgw || bdofv0eQO4[i] == e3pa4QIgw - 'A' + 'a') {
            cTMwavd2 = cTMwavd2 + 1;
        }
        else {
            if (bdofv0eQO4[0] >= 'a' && bdofv0eQO4[0] <= 'z')
                e3pa4QIgw = bdofv0eQO4[i] - 'a' + 'A';
            else
                e3pa4QIgw = bdofv0eQO4[i];
            cout << cTMwavd2 << ")(" << e3pa4QIgw << ",";
            cTMwavd2 = 1;
        };
    }
    cout << cTMwavd2 << ")" << endl;
    return 0;
}

