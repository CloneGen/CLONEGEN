int main () {
    int l3VFmQK, j, QF2huqAyxiEj;
    char st [1010];
    char a8KheYBP;
    gets (st);
    QF2huqAyxiEj = (896 - 895);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        l3VFmQK = 326 - 326;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (st[l3VFmQK] != '\0') {
            if ('a' <= st[l3VFmQK] && st[l3VFmQK] <= 'z')
                st[l3VFmQK] = st[l3VFmQK] - 'a' + 'A';
            l3VFmQK = l3VFmQK + 1;
        };
    }
    a8KheYBP = st[0];
    for (l3VFmQK = 1; st[l3VFmQK] != '\0'; l3VFmQK = l3VFmQK + 1) {
        if (st[l3VFmQK] != a8KheYBP) {
            printf ("(%c,%d)", a8KheYBP, QF2huqAyxiEj);
            QF2huqAyxiEj = 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            a8KheYBP = st[l3VFmQK];
        }
        else {
            QF2huqAyxiEj = QF2huqAyxiEj +1;
        };
    }
    printf ("(%c,%d)\n", a8KheYBP, QF2huqAyxiEj);
    return 0;
}

