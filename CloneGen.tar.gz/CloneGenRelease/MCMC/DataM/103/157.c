main () {
    int ATL1VRDr82;
    int P4QJABczN3L;
    ATL1VRDr82 = (280 - 279);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char u456yt [(1122 - 121)];
    char ceLB4ROA;
    scanf ("%s", u456yt);
    {
        P4QJABczN3L = 889 - 888;
        while (1) {
            if (u456yt[P4QJABczN3L] == u456yt[P4QJABczN3L -(781 - 780)] && u456yt[P4QJABczN3L] != '\0' || !(u456yt[P4QJABczN3L -(26 - 25)] + (258 - 226) != u456yt[P4QJABczN3L]) || !(u456yt[P4QJABczN3L -(627 - 626)] - 32 != u456yt[P4QJABczN3L])) {
                ATL1VRDr82++;
            }
            if (!(u456yt[P4QJABczN3L -(358 - 357)] == u456yt[P4QJABczN3L]) && u456yt[P4QJABczN3L] != '\0' && !(u456yt[P4QJABczN3L -(671 - 670)] + 32 == u456yt[P4QJABczN3L]) && u456yt[P4QJABczN3L] != u456yt[P4QJABczN3L -(300 - 299)] - 32) {
                if (u456yt[P4QJABczN3L -(59 - 58)] >= 'A' && u456yt[P4QJABczN3L -(472 - 471)] <= 'Z')
                    printf ("(%c,%d)", u456yt[P4QJABczN3L -(212 - 211)], ATL1VRDr82);
                if (u456yt[P4QJABczN3L -1] >= 'a' && u456yt[P4QJABczN3L -1] <= 'z')
                    printf ("(%c,%d)", u456yt[P4QJABczN3L -1] + 'A' - 'a', ATL1VRDr82);
                ATL1VRDr82 = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (u456yt[P4QJABczN3L] == '\0') {
                if (u456yt[P4QJABczN3L -1] >= 'A' && u456yt[P4QJABczN3L -1] <= 'Z')
                    printf ("(%c,%d)", u456yt[P4QJABczN3L -1], ATL1VRDr82);
                if (u456yt[P4QJABczN3L -1] >= 'a' && u456yt[P4QJABczN3L -1] <= 'z')
                    printf ("(%c,%d)", u456yt[P4QJABczN3L -1] + 'A' - 'a', ATL1VRDr82);
                break;
            }
            P4QJABczN3L++;
        };
    };
}

