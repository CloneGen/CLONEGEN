main () {
    int i, m, j;
    char a [1000];
    char n;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    m = 1;
    scanf ("%s", a);
    for (i = 1; i < 1000; i = i + 1) {
        if (!('\0' != a[i - 1]))
            break;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (a[i] == a[i - 1])
            m = m + 1;
        else {
            if (!(a[i - 1] + ('A' - 'a') != a[i]))
                m = m + 1;
            else if (a[i] == a[i - 1] - ('A' - 'a'))
                m = m + 1;
            else {
                if ('A' <= a[i - 1] && a[i - 1] <= 'Z')
                    printf ("(%c,%d)", a[i - 1], m);
                else {
                    printf ("(%c,%d)", a[i - 1] + 'A' - 'a', m);
                }
                m = 1;
            };
        };
    };
}

