void  change (char *a) {
    char *IvdLSiD = a;
    for (; *IvdLSiD != '\0';) {
        if ('a' <= *IvdLSiD&&*IvdLSiD <= 'z')
            *IvdLSiD = *IvdLSiD+'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        IvdLSiD = IvdLSiD +1;
    }
    return;
}

int main () {
    int fy7E9tTC8;
    fy7E9tTC8 = (817 - 816);
    char str [(1787 - 786)];
    change (str);
    char *IvdLSiD = str;
    cin >> str;
    while (*IvdLSiD != '\0') {
        if (*IvdLSiD == *(IvdLSiD +1)) {
            fy7E9tTC8++;
        }
        else {
            printf ("(%c,%d)", *IvdLSiD, fy7E9tTC8);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            fy7E9tTC8 = 1;
        }
        IvdLSiD++;
    }
    return 0;
}

