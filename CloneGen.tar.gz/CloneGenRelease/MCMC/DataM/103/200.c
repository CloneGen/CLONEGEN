int main () {
    char s [1000];
    int num;
    int l;
    int EshXU52K1pHT;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    num = (381 - 380);
    getchar ();
    getchar ();
    scanf ("%s", s);
    l = strlen (s);
    if ((!((516 - 516) != s[l - (379 - 378)] - s[l - (918 - 916)])) || !(('a' - 'A') != (s[l - (97 - 96)] - s[l])) || (s[l - 1] - s[l - 2]) == ('A' - 'a'))
        for (EshXU52K1pHT = (231 - 231); EshXU52K1pHT < l; EshXU52K1pHT = EshXU52K1pHT +1) {
            if ((!(0 != s[EshXU52K1pHT +1] - s[EshXU52K1pHT])) || (s[EshXU52K1pHT +1] - s[EshXU52K1pHT]) == ('a' - 'A') || !(('A' - 'a') != (s[EshXU52K1pHT +1] - s[EshXU52K1pHT]))) {
                num = num + 1;
            }
            else {
                if (s[EshXU52K1pHT] - 'a' >= 0)
                    printf ("(%c,%d)", s[EshXU52K1pHT] - 32, num);
                else
                    printf ("(%c,%d)", s[EshXU52K1pHT], num);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                }
                num = 1;
            };
        }
    else {
        for (EshXU52K1pHT = 0; EshXU52K1pHT < l - 1; EshXU52K1pHT = EshXU52K1pHT +1) {
            if ((s[EshXU52K1pHT +1] - s[EshXU52K1pHT] == 0) || (s[EshXU52K1pHT +1] - s[EshXU52K1pHT]) == ('a' - 'A') || (s[EshXU52K1pHT +1] - s[EshXU52K1pHT]) == ('A' - 'a')) {
                num = num + 1;
            }
            else {
                if (s[EshXU52K1pHT] - 'a' >= 0)
                    printf ("(%c,%d)", s[EshXU52K1pHT] - 32, num);
                else
                    printf ("(%c,%d)", s[EshXU52K1pHT], num);
                num = 1;
            };
        }
        if (s[l - 1] - 'a' >= 0)
            printf ("(%c,1)", s[l - 1] - 32);
        else
            printf ("(%c,1)", s[l - 1]);
    };
}

