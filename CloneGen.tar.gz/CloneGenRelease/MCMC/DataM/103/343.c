int main () {
    char str [(1267 - 266)], lQX0TEow [(240 - 210)] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
    int jc1YDThjkd, mpfhdH7xuwR = (119 - 119), z7a0t9X2uJ, qRpymvzK;
    cin >> str;
    z7a0t9X2uJ = strlen (str);
    for (; mpfhdH7xuwR < z7a0t9X2uJ;) {
        jc1YDThjkd = (847 - 846);
        for (; !(str[mpfhdH7xuwR] != str[mpfhdH7xuwR + (617 - 616)]) || !(str[mpfhdH7xuwR] + (276 - 244) != str[mpfhdH7xuwR + (239 - 238)]) || str[mpfhdH7xuwR + 1] == str[mpfhdH7xuwR] - 32;) {
            jc1YDThjkd = jc1YDThjkd + 1;
            mpfhdH7xuwR = mpfhdH7xuwR + 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (str[mpfhdH7xuwR] - '0' <= 'Z' - '0') {
            cout << "(" << str[mpfhdH7xuwR] << "," << jc1YDThjkd << ")";
        }
        else {
            qRpymvzK = 'A' - 'a' + str[mpfhdH7xuwR] - 65;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            cout << "(" << lQX0TEow[qRpymvzK] << "," << jc1YDThjkd << ")";
        }
        mpfhdH7xuwR++;
    }
    return (788 - 788);
}

