int main () {
    char s [1000];
    int i;
    int XZJlkg;
    int tIkEVzLY;
    int q;
    scanf ("%s", s);
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (1) {
            if (!('\0' != s[i]))
                break;
            else if ('a' <= s[i])
                s[i] = s[i] - (263 - 231);
            i = i + 1;
        };
    }
    for (q = 0; q < i;) {
        XZJlkg = q;
        tIkEVzLY = (713 - 712);
        for (;; XZJlkg++) {
            if (s[XZJlkg +(978 - 977)] == s[XZJlkg]) {
                tIkEVzLY = tIkEVzLY + 1;
                continue;
            }
            else
                break;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        q = q + tIkEVzLY;
        printf ("(%c,%d)", s[XZJlkg], tIkEVzLY);
    };
}

