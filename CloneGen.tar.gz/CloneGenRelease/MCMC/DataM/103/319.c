char fb8iWsgOQZK [(1645 - 645)];
int len;

int operation (int Jmogk46q2x5n) {
    int ZVXetbLO;
    ZVXetbLO = Jmogk46q2x5n;
    int m6tbGHZ;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    m6tbGHZ = (109 - 109);
    for (; fb8iWsgOQZK[ZVXetbLO] == fb8iWsgOQZK[Jmogk46q2x5n]; ZVXetbLO = ZVXetbLO +1)
        m6tbGHZ++;
    cout << "(" << fb8iWsgOQZK[Jmogk46q2x5n] << "," << m6tbGHZ << ")";
    return m6tbGHZ;
}

int main () {
    int ZVXetbLO;
    cout << endl;
    cin >> fb8iWsgOQZK;
    len = strlen (fb8iWsgOQZK);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    {
        ZVXetbLO = 703 - 703;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (ZVXetbLO < len) {
            if (fb8iWsgOQZK[ZVXetbLO] > 90)
                fb8iWsgOQZK[ZVXetbLO] = fb8iWsgOQZK[ZVXetbLO] - 32;
            ZVXetbLO = ZVXetbLO +1;
        };
    }
    {
        ZVXetbLO = 0;
        while (ZVXetbLO < len) {
            ZVXetbLO += operation (ZVXetbLO) - (933 - 932);
            ZVXetbLO = ZVXetbLO +1;
        };
    }
    return 0;
}

