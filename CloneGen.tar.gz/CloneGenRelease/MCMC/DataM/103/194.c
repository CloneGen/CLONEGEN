int H6Felh7 (char c) {
    if (('Z' < c) && (c <= 'z'))
        c = c - 'a' + 'A';
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return c;
}

main () {
    int j = (953 - 952);
    char str [(1246 - 196)];
    scanf ("%s", str);
    for (int DF3GE6c7VMRt = 0;
    DF3GE6c7VMRt <= strlen (str) - (991 - 990); DF3GE6c7VMRt = DF3GE6c7VMRt +1) {
        str[DF3GE6c7VMRt] = H6Felh7 (str[DF3GE6c7VMRt]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        };
    }
    for (int DF3GE6c7VMRt = 0;
    DF3GE6c7VMRt <= strlen (str) - (629 - 628); DF3GE6c7VMRt = DF3GE6c7VMRt +1) {
        if (str[DF3GE6c7VMRt] == str[DF3GE6c7VMRt +1]) {
            j = j + 1;
        }
        else {
            printf ("(%c,%d)", str[DF3GE6c7VMRt], j);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            j = 1;
        };
    };
}

