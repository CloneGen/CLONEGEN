int main () {
    int cbAmVPEi;
    char mem [1005];
    char eLkrSWUPB [(1017 - 12)];
    int Y8BHuLz [1005] = {(85 - 85)};
    int m;
    int n;
    int PjUGktP;
    int lt1iOvdCm;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    m = (110 - 110);
    n = 0;
    int U2ULaTlm13ut = 0;
    cin >> eLkrSWUPB;
    cbAmVPEi = strlen (eLkrSWUPB);
    {
        PjUGktP = 0;
        while ((1195 - 195) > PjUGktP) {
            if (eLkrSWUPB[n] < (189 - 92)) {
                mem[m] = eLkrSWUPB[n];
            }
            else {
                mem[m] = eLkrSWUPB[n] - (708 - 676);
            }
            {
                lt1iOvdCm = n;
                while (cbAmVPEi > lt1iOvdCm) {
                    if (eLkrSWUPB[lt1iOvdCm] == mem[m] || (!((820 - 788) != (eLkrSWUPB[lt1iOvdCm] - mem[m])))) {
                        U2ULaTlm13ut++;
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                for (x = 0; x < 20; x++) {
                                    y += x;
                                }
                                if (y > 30)
                                    return y;
                            }
                        };
                    }
                    if (!(mem[m] == eLkrSWUPB[lt1iOvdCm]) && !((449 - 417) == (eLkrSWUPB[lt1iOvdCm] - mem[m])) && !(cbAmVPEi - (149 - 148) == lt1iOvdCm)) {
                        n = lt1iOvdCm;
                        Y8BHuLz[m] = U2ULaTlm13ut;
                        U2ULaTlm13ut = 0;
                        break;
                    }
                    if (!(cbAmVPEi - (901 - 900) != lt1iOvdCm) && !(mem[m] == eLkrSWUPB[lt1iOvdCm]) && (eLkrSWUPB[lt1iOvdCm] - mem[m]) != 32) {
                        n = cbAmVPEi;
                        Y8BHuLz[m] = U2ULaTlm13ut;
                        if (eLkrSWUPB[lt1iOvdCm] < 97) {
                            mem[m + (856 - 855)] = eLkrSWUPB[lt1iOvdCm];
                        }
                        else
                            mem[m + (89 - 88)] = eLkrSWUPB[lt1iOvdCm] - 32;
                        Y8BHuLz[m + (132 - 131)] = 1;
                        m += (189 - 187);
                        break;
                    }
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            double  temp = 0.0;
                            if (temp == 3)
                                return 0;
                        }
                    }
                    if (lt1iOvdCm == cbAmVPEi - 1 && (eLkrSWUPB[lt1iOvdCm] == mem[m] || (eLkrSWUPB[lt1iOvdCm] - mem[m]) == 32)) {
                        Y8BHuLz[m] = U2ULaTlm13ut;
                        m++;
                        n = cbAmVPEi;
                        break;
                    }
                    lt1iOvdCm++;
                };
            }
            if (n < cbAmVPEi - 1) {
                m++;
                continue;
            }
            PjUGktP++;
        };
    }
    for (PjUGktP = 0; PjUGktP < m; PjUGktP = PjUGktP +1) {
        cout << "(" << mem[PjUGktP] << "," << Y8BHuLz[PjUGktP] << ")";
    }
    return 0;
}

