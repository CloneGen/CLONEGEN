main () {
    int AJXo5fV, FU1SF7e3n;
    int mpJ3kGT4twV7;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    mpJ3kGT4twV7 = (221 - 220);
    char a [(1734 - 734)];
    gets (a);
    for (AJXo5fV = (850 - 850); a[AJXo5fV] != '\0'; AJXo5fV = AJXo5fV +1) {
        if (a[AJXo5fV] == a[AJXo5fV +(292 - 291)] || a[AJXo5fV] == a[AJXo5fV +(936 - 935)] + (1009 - 977) || a[AJXo5fV] == a[AJXo5fV +1] - 32) {
            mpJ3kGT4twV7 = mpJ3kGT4twV7 + 1;
        }
        else {
            if (a[AJXo5fV] < (256 - 165))
                printf ("(%c,%d)", a[AJXo5fV], mpJ3kGT4twV7);
            else
                printf ("(%c,%d)", a[AJXo5fV] - 32, mpJ3kGT4twV7);
            mpJ3kGT4twV7 = 1;
        };
    };
}

