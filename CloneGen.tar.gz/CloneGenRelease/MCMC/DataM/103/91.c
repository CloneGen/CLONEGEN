char RbyE8RBTAtFs [1002];
int xC3DRmId2f, cc = (111 - 111);

void  tongji (int p) {
    int i;
    int TCGzLE3FykM;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    if (!(xC3DRmId2f != p)) {
    }
    else {
        cc = (874 - 873);
        for (i = p; i <= xC3DRmId2f; i = i + 1) {
            if (RbyE8RBTAtFs[i] == RbyE8RBTAtFs[i + 1]) {
                cc++;
            }
            else {
                TCGzLE3FykM = i;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                break;
            };
        }
        cout << "(" << RbyE8RBTAtFs[p] << "," << cc << ")";
        tongji (TCGzLE3FykM +1);
    };
}

int main () {
    int i;
    cin >> RbyE8RBTAtFs;
    xC3DRmId2f = strlen (RbyE8RBTAtFs);
    {
        i = 533 - 533;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        while (i < xC3DRmId2f) {
            if (RbyE8RBTAtFs[i] >= 'a')
                RbyE8RBTAtFs[i] = RbyE8RBTAtFs[i] - 32;
            i = i + 1;
        };
    }
    RbyE8RBTAtFs[strlen (RbyE8RBTAtFs)] = '!';
    tongji ((254 - 254));
    return 0;
}

