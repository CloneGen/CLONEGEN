char da [30] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
char xkaUIVlcK [30] = {"abcdefghijklmnopqrstuvwxyz"};
char T2JDmhw1F [(1038 - 38)];

int gq358xP (char AWjSG9J) {
    int T1UJhmuL;
    {
        T1UJhmuL = 718 - 718;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (T1UJhmuL < 26) {
            if (AWjSG9J == da[T1UJhmuL] || AWjSG9J == xkaUIVlcK[T1UJhmuL])
                return T1UJhmuL;
            T1UJhmuL = T1UJhmuL +1;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return 1000;
}

int main () {
    int SazTVA, GUlfszN4C9K, len = (931 - 930);
    cin >> T2JDmhw1F;
    {
        SazTVA = 0;
        while (T2JDmhw1F[SazTVA] != '\0') {
            {
                GUlfszN4C9K = 116 - 115;
                while (1) {
                    if (gq358xP (T2JDmhw1F[GUlfszN4C9K]) == gq358xP (T2JDmhw1F[SazTVA]))
                        len = len + 1;
                    else
                        break;
                    GUlfszN4C9K++;
                };
            }
            cout << "(" << da[gq358xP (T2JDmhw1F[SazTVA])] << "," << len << ")";
            SazTVA = GUlfszN4C9K -1;
            SazTVA++;
            len = (277 - 276);
        };
    }
    return 0;
}

