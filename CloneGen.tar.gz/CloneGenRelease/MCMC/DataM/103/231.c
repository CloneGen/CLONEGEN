struct   point {
    char AtMTVcgd31;
    int b;
}
poi [(959 - 919)];

int main () {
    char AIiPa1NO [(1315 - 315)];
    int dJFHstX7leSB;
    int i;
    int Y2h7dWEj0Kn;
    dJFHstX7leSB = (897 - 897);
    scanf ("%s", &AIiPa1NO);
    poi[dJFHstX7leSB].AtMTVcgd31 = AIiPa1NO[0];
    {
        i = 1;
        while (!('\0' == AIiPa1NO[i])) {
            if (!(AIiPa1NO[i - 1] != AIiPa1NO[i]) || AIiPa1NO[i] == AIiPa1NO[i - 1] - 32 || AIiPa1NO[i] == AIiPa1NO[i - 1] + 32) {
                poi[dJFHstX7leSB].b++;
            }
            else {
                dJFHstX7leSB++;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                poi[dJFHstX7leSB].AtMTVcgd31 = AIiPa1NO[i];
            }
            i = i + 1;
        };
    }
    {
        Y2h7dWEj0Kn = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        while (Y2h7dWEj0Kn <= dJFHstX7leSB) {
            if (poi[Y2h7dWEj0Kn].AtMTVcgd31 > 96) {
                poi[Y2h7dWEj0Kn].AtMTVcgd31 = poi[Y2h7dWEj0Kn].AtMTVcgd31 - 32;
            }
            printf ("(%c,%d)", poi[Y2h7dWEj0Kn].AtMTVcgd31, poi[Y2h7dWEj0Kn].b + 1);
            Y2h7dWEj0Kn++;
        };
    }
    return 0;
}

