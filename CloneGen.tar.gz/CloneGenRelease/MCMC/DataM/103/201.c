main () {
    char nsyqQWzEertm [1001];
    gets (nsyqQWzEertm);
    int V5Cn2ATVGJ1, i;
    for (i = (915 - 915); !('\0' == nsyqQWzEertm[i]); i = i + 1) {
        if ((nsyqQWzEertm[i] >= 'a') && ('z' >= nsyqQWzEertm[i]))
            nsyqQWzEertm[i] = nsyqQWzEertm[i] + 'A' - 'a';
        else
            nsyqQWzEertm[i] = nsyqQWzEertm[i];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    V5Cn2ATVGJ1 = (929 - 928);
    if (!(nsyqQWzEertm[0] == nsyqQWzEertm[(390 - 389)]))
        printf ("(%c,%d)", nsyqQWzEertm[0], V5Cn2ATVGJ1);
    for (i = (965 - 964); !('\0' == nsyqQWzEertm[i]); i++) {
        if (nsyqQWzEertm[i] == nsyqQWzEertm[i - 1]) {
            V5Cn2ATVGJ1 = V5Cn2ATVGJ1 +1;
            if ((nsyqQWzEertm[i] != nsyqQWzEertm[i + 1]) || (nsyqQWzEertm[i + 1] == '\0')) {
                printf ("(%c,%d)", nsyqQWzEertm[i], V5Cn2ATVGJ1);
                V5Cn2ATVGJ1 = 1;
            };
        }
        else {
            if ((nsyqQWzEertm[i] != nsyqQWzEertm[i + 1]) || (nsyqQWzEertm[i + 1] == '\0'))
                printf ("(%c,%d)", nsyqQWzEertm[i], V5Cn2ATVGJ1);
            else
                continue;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            };
        };
    };
}

