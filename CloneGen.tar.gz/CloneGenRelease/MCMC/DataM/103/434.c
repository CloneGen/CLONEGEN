main () {
    int P5lMH7U3q;
    int i;
    P5lMH7U3q = (451 - 450);
    char x [1001], ymaMI6fw [1001];
    {
        i = 676 - 676;
        while (i < 1001) {
            x[i] = '\0';
            ymaMI6fw[i] = '\0';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", x);
    {
        i = 670 - 670;
        while (!('\0' == x[i])) {
            if ('a' <= x[i] && x[i] <= 'z')
                ymaMI6fw[i] = x[i] - 'a' + 'A';
            else
                ymaMI6fw[i] = x[i];
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i++;
        };
    }
    {
        i = 0;
        while (ymaMI6fw[i] != '\0') {
            if (ymaMI6fw[i] == ymaMI6fw[i + 1])
                P5lMH7U3q = P5lMH7U3q +1;
            else {
                printf ("(%c,%d)", ymaMI6fw[i], P5lMH7U3q);
                P5lMH7U3q = 1;
            }
            i++;
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

