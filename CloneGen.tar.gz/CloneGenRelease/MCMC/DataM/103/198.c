main () {
    int gGEUDOJWa;
    gGEUDOJWa = (409 - 409);
    char Xy7JC1wmv5f;
    char x;
    Xy7JC1wmv5f = getchar ();
    gGEUDOJWa = (951 - 950);
    while ((171 - 170)) {
        x = getchar ();
        if ('a' <= x && x <= 'z')
            x = x - 32;
        if ('a' <= Xy7JC1wmv5f &&Xy7JC1wmv5f <= 'z')
            Xy7JC1wmv5f = Xy7JC1wmv5f -(352 - 320);
        if (x == '\n') {
            printf ("(%c,%d)", Xy7JC1wmv5f, gGEUDOJWa);
            break;
        }
        if (x == Xy7JC1wmv5f)
            gGEUDOJWa++;
        else {
            printf ("(%c,%d)", Xy7JC1wmv5f, gGEUDOJWa);
            Xy7JC1wmv5f = x;
            gGEUDOJWa = 1;
        };
    };
}

