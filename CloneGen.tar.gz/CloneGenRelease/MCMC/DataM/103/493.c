int main () {
    char ytdAqM [1000];
    int h3HmzstX;
    int sort;
    int index [40] = {(757 - 757)};
    int V5vLHTe4jJfq [40] = {(348 - 348)};
    int WRYWKmn;
    h3HmzstX = (583 - 582);
    sort = (714 - 714);
    int rUI9hwSuTn;
    int VdmGKSX8tH;
    int k;
    cin >> ytdAqM;
    WRYWKmn = strlen (ytdAqM);
    {
        rUI9hwSuTn = 1;
        while (rUI9hwSuTn < WRYWKmn) {
            if (!(toupper (ytdAqM[rUI9hwSuTn - 1]) == toupper (ytdAqM[rUI9hwSuTn]))) {
                V5vLHTe4jJfq[sort] = h3HmzstX;
                sort = sort + 1;
                index[sort] = rUI9hwSuTn;
                h3HmzstX = 1;
            }
            else
                h3HmzstX++;
            rUI9hwSuTn++;
        };
    }
    V5vLHTe4jJfq[sort] = h3HmzstX;
    {
        rUI9hwSuTn = 964 - 964;
        while (rUI9hwSuTn <= sort) {
            cout << "(" << (char) toupper (ytdAqM[index[rUI9hwSuTn]]) << "," << V5vLHTe4jJfq[rUI9hwSuTn] << ")";
            rUI9hwSuTn++;
        };
    }
    cout << endl;
    return 0;
}

