int main () {
    char a;
    {
        char fGg57iKeCL [(977 - 877)];
        char a [(878 - 378)];
        int len;
        len = strlen (a);
        int CBUPrj [(832 - 732)];
        int dYse9DCRXTb;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        dYse9DCRXTb = (584 - 584);
        cin.getline (a, (712 - 212));
        fGg57iKeCL[(431 - 431)] = a[(283 - 283)];
        CBUPrj[(659 - 659)] = (669 - 668);
        for (int i = (547 - 546);
        (791 - 691) > i; i = i + 1)
            CBUPrj[i] = (196 - 196);
        for (int i = (653 - 652);
        len > i; i = i + 1) {
            if (!(fGg57iKeCL[dYse9DCRXTb] == a[i]) && !(fGg57iKeCL[dYse9DCRXTb] + (776 - 744) == a[i]) && !(fGg57iKeCL[dYse9DCRXTb] - (809 - 777) == a[dYse9DCRXTb])) {
                dYse9DCRXTb = dYse9DCRXTb + 1;
                fGg57iKeCL[dYse9DCRXTb] = a[i];
                CBUPrj[dYse9DCRXTb]++;
            }
            else {
                if (!(fGg57iKeCL[dYse9DCRXTb] != a[i]) || a[i] == fGg57iKeCL[dYse9DCRXTb] + (327 - 295) || !(fGg57iKeCL[dYse9DCRXTb] - 32 != a[i])) {
                    CBUPrj[dYse9DCRXTb]++;
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    };
                };
            };
        }
        for (int i = (445 - 445);
        dYse9DCRXTb >= i; i++)
            if ('a' <= fGg57iKeCL[i] && 'z' >= fGg57iKeCL[i])
                fGg57iKeCL[i] -= 32;
        for (int i = (419 - 419);
        dYse9DCRXTb >= i; i++)
            cout << '(' << fGg57iKeCL[i] << ',' << CBUPrj[i] << ')';
        cout << endl;
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (; cin.get (a);) {
        int dYse9DCRXTb = 0;
        char fGg57iKeCL [100];
        char a [(701 - 201)];
        int CBUPrj [100];
        int len = strlen (a);
        if (!('?' == a))
            break;
        cout << "?" << endl;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        cin.get ();
        cin.getline (a, 500);
        fGg57iKeCL[(24 - 24)] = a[0];
        CBUPrj[0] = 1;
        {
            int i = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    for (x = 0; x < 20; x++) {
                        y += x;
                    }
                    if (y > 30)
                        return y;
                }
            }
            while (100 > i) {
                CBUPrj[i] = 0;
                i++;
            };
        }
        {
            int i = 1;
            while (i < len) {
                if (a[i] != fGg57iKeCL[dYse9DCRXTb] && a[i] != fGg57iKeCL[dYse9DCRXTb] + 32 && a[dYse9DCRXTb] != fGg57iKeCL[dYse9DCRXTb] - 32) {
                    dYse9DCRXTb++;
                    fGg57iKeCL[dYse9DCRXTb] = a[i];
                    CBUPrj[dYse9DCRXTb]++;
                }
                else if (a[i] == fGg57iKeCL[dYse9DCRXTb] || a[i] == fGg57iKeCL[dYse9DCRXTb] + 32 || a[i] == fGg57iKeCL[dYse9DCRXTb] - 32) {
                    CBUPrj[dYse9DCRXTb]++;
                }
                i++;
            };
        }
        for (int i = 0;
        i <= dYse9DCRXTb; i++)
            if (fGg57iKeCL[i] >= 'a' && fGg57iKeCL[i] <= 'z')
                fGg57iKeCL[i] -= 32;
        for (int i = 0;
        i <= dYse9DCRXTb; i++)
            cout << '(' << fGg57iKeCL[i] << ',' << CBUPrj[i] << ')';
        cout << endl;
    }
    return 0;
}

