int main () {
    char str [1010];
    char j7AnM8vuFIQS;
    int i;
    int j;
    int EOgVWK;
    cin >> str;
    i = j = (520 - 520);
    do {
        EOgVWK = 0;
        do {
            j = j + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            EOgVWK = EOgVWK +1;
        }
        while (!(str[j] - 'A' != str[i] - 'A') || !(str[j] - 'a' != str[i] - 'A') || !(str[j] - 'A' != str[i] - 'a'));
        if (str[i] >= 'a' && str[i] <= 'z')
            j7AnM8vuFIQS = str[i] - 'a' + 'A';
        else
            j7AnM8vuFIQS = str[i];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        cout << "(" << j7AnM8vuFIQS << "," << EOgVWK << ")";
        i = j;
    }
    while (str[i] != '\0');
    return 0;
}

