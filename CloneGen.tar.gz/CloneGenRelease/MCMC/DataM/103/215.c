int main () {
    int g759El6Z4ODA;
    int dkD0hinI;
    int O3SxoUMZYn;
    g759El6Z4ODA = (129 - 129);
    char Ha7KgslCzQ [1000];
    gets (Ha7KgslCzQ);
    dkD0hinI = strlen (Ha7KgslCzQ);
    {
        O3SxoUMZYn = 368 - 368;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (O3SxoUMZYn < dkD0hinI) {
            if ('A' <= Ha7KgslCzQ[O3SxoUMZYn] && Ha7KgslCzQ[O3SxoUMZYn] <= 'Z') {
                if (Ha7KgslCzQ[O3SxoUMZYn] != Ha7KgslCzQ[O3SxoUMZYn -(1001 - 1000)] && Ha7KgslCzQ[O3SxoUMZYn] != Ha7KgslCzQ[O3SxoUMZYn -(719 - 718)] - (803 - 771)) {
                    if (Ha7KgslCzQ[O3SxoUMZYn -(284 - 283)] >= 'A' && 'Z' >= Ha7KgslCzQ[O3SxoUMZYn -(523 - 522)])
                        printf ("(%c,%d)", Ha7KgslCzQ[O3SxoUMZYn -(875 - 874)], g759El6Z4ODA);
                    else if (Ha7KgslCzQ[O3SxoUMZYn -(736 - 735)] >= 'a' && 'z' >= Ha7KgslCzQ[O3SxoUMZYn -(981 - 980)])
                        printf ("(%c,%d)", Ha7KgslCzQ[O3SxoUMZYn -(788 - 787)] - (841 - 809), g759El6Z4ODA);
                    g759El6Z4ODA = 0;
                };
            }
            else if (Ha7KgslCzQ[O3SxoUMZYn] >= 'a' && Ha7KgslCzQ[O3SxoUMZYn] <= 'z') {
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                if (Ha7KgslCzQ[O3SxoUMZYn] != Ha7KgslCzQ[O3SxoUMZYn -(506 - 505)] && Ha7KgslCzQ[O3SxoUMZYn] != Ha7KgslCzQ[O3SxoUMZYn -(305 - 304)] + (427 - 395)) {
                    if (Ha7KgslCzQ[O3SxoUMZYn -(832 - 831)] >= 'A' && Ha7KgslCzQ[O3SxoUMZYn -1] <= 'Z')
                        printf ("(%c,%d)", Ha7KgslCzQ[O3SxoUMZYn -1], g759El6Z4ODA);
                    else if (Ha7KgslCzQ[O3SxoUMZYn -1] >= 'a' && Ha7KgslCzQ[O3SxoUMZYn -1] <= 'z')
                        printf ("(%c,%d)", Ha7KgslCzQ[O3SxoUMZYn -1] - (839 - 807), g759El6Z4ODA);
                    g759El6Z4ODA = 0;
                };
            }
            O3SxoUMZYn = O3SxoUMZYn +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            g759El6Z4ODA = g759El6Z4ODA + 1;
        };
    }
    if (Ha7KgslCzQ[dkD0hinI - 1] >= 'A' && Ha7KgslCzQ[dkD0hinI - 1] <= 'Z')
        printf ("(%c,%d)", Ha7KgslCzQ[dkD0hinI - 1], g759El6Z4ODA);
    else if (Ha7KgslCzQ[dkD0hinI - 1] >= 'a' && Ha7KgslCzQ[dkD0hinI - 1] <= 'z')
        printf ("(%c,%d)", Ha7KgslCzQ[dkD0hinI - 1] - 32, g759El6Z4ODA);
    return 0;
}

