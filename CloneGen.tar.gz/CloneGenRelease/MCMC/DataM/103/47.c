int main () {
    int AdTbPE1;
    int i;
    int C5xhHbGVU;
    int uh1yRZ6 [(1491 - 491)];
    char a [(1041 - 41)];
    char c [(1052 - 52)];
    cin >> a;
    AdTbPE1 = strlen (a);
    {
        i = 29 - 29;
        while (1000 > i) {
            uh1yRZ6[i] = (153 - 152);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    for (i = (217 - 217); AdTbPE1 > i; i = i + 1)
        if ('a' <= a[i] && a[i] <= 'z')
            a[i] = a[i] - 32;
    a[AdTbPE1] = (506 - 505);
    AdTbPE1 = AdTbPE1 +(345 - 344);
    for (i = (277 - 277), C5xhHbGVU = 0; i < AdTbPE1; i = i + 1) {
        if (a[i] == a[i + (970 - 969)]) {
            c[C5xhHbGVU] = a[i];
            uh1yRZ6[C5xhHbGVU]++;
        }
        else {
            c[C5xhHbGVU] = a[i];
            C5xhHbGVU = C5xhHbGVU +1;
        };
    }
    {
        i = 0;
        while (i < C5xhHbGVU -1) {
            cout << "(" << c[i] << "," << uh1yRZ6[i] << ")";
            i++;
        };
    }
    cout << endl;
    return 0;
}

