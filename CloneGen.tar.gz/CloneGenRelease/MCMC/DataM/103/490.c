main () {
    char D9YRS4GaTQiw [(288 - 187)];
    gets (D9YRS4GaTQiw);
    int RUmN1wCix7;
    int ZXjPI7DC;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    RUmN1wCix7 = (368 - 368);
    ZXjPI7DC = 1;
    getchar ();
    {
        RUmN1wCix7;
        while (D9YRS4GaTQiw[RUmN1wCix7] != '\0') {
            if ('a' <= D9YRS4GaTQiw[RUmN1wCix7] && D9YRS4GaTQiw[RUmN1wCix7] <= 'z')
                D9YRS4GaTQiw[RUmN1wCix7] += 'A' - 'a';
            RUmN1wCix7 = RUmN1wCix7 +1;
        };
    }
    for (RUmN1wCix7 = 0; D9YRS4GaTQiw[RUmN1wCix7] != '\0'; RUmN1wCix7 = RUmN1wCix7 +1) {
        if (D9YRS4GaTQiw[RUmN1wCix7] == D9YRS4GaTQiw[RUmN1wCix7 +1])
            ZXjPI7DC++;
        else {
            printf ("(%c,%d)", D9YRS4GaTQiw[RUmN1wCix7], ZXjPI7DC);
            ZXjPI7DC = 1;
        };
    };
}

