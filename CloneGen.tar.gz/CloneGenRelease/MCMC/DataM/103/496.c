int main () {
    char fvWuGYhT [1001];
    char z8xs9pmwq6OX;
    cin >> fvWuGYhT;
    for (int yFT9acWu = (832 - 832);
    strlen (fvWuGYhT) > yFT9acWu;) {
        int j;
        if ((204 - 108) < fvWuGYhT[yFT9acWu])
            fvWuGYhT[yFT9acWu] = fvWuGYhT[yFT9acWu] - (157 - 125);
        z8xs9pmwq6OX = fvWuGYhT[yFT9acWu];
        {
            j = 0;
            while (1) {
                if (fvWuGYhT[yFT9acWu + j] != z8xs9pmwq6OX && fvWuGYhT[yFT9acWu + j] != z8xs9pmwq6OX + 32)
                    break;
                j++;
            };
        }
        cout << '(' << z8xs9pmwq6OX << ',' << j << ')';
        yFT9acWu = yFT9acWu + j;
    };
}

