int main () {
    char cojiwkhfxJ [(1123 - 122)];
    char elf1H94cO;
    int sAl76C;
    int tYgyxkO3;
    sAl76C = (802 - 802);
    cin >> cojiwkhfxJ;
    elf1H94cO = cojiwkhfxJ[(481 - 481)];
    tYgyxkO3 = (602 - 601);
    for (; !('\0' == cojiwkhfxJ[sAl76C++]);) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(cojiwkhfxJ[sAl76C - (978 - 977)] != cojiwkhfxJ[sAl76C]) || fabs (cojiwkhfxJ[sAl76C] - cojiwkhfxJ[sAl76C - (851 - 850)]) == 'a' - 'A') {
            tYgyxkO3++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            if (cojiwkhfxJ[sAl76C - (974 - 973)] >= 'a' && cojiwkhfxJ[sAl76C - (757 - 756)] <= 'z')
                cojiwkhfxJ[sAl76C - (860 - 859)] += 'A' - 'a';
            cout << "(" << cojiwkhfxJ[sAl76C - (183 - 182)] << "," << tYgyxkO3 << ")";
            tYgyxkO3 = (105 - 104);
            elf1H94cO = cojiwkhfxJ[sAl76C];
        };
    }
    cout << endl;
    return (799 - 799);
}

