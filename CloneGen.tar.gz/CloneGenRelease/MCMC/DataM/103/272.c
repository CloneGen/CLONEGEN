int main () {
    int M1SKhsvwAD = (761 - 761), lrbKIUtfGx8O;
    char CVFnkzcHOwAM [1000];
    cin >> CVFnkzcHOwAM;
    for (lrbKIUtfGx8O = (735 - 735); CVFnkzcHOwAM[lrbKIUtfGx8O] != '\0'; lrbKIUtfGx8O++) {
        if (!(CVFnkzcHOwAM[lrbKIUtfGx8O + 1] != CVFnkzcHOwAM[lrbKIUtfGx8O]) || CVFnkzcHOwAM[lrbKIUtfGx8O] == CVFnkzcHOwAM[lrbKIUtfGx8O + 1] + 'a' - 'A' || CVFnkzcHOwAM[lrbKIUtfGx8O] == CVFnkzcHOwAM[lrbKIUtfGx8O + 1] + 'A' - 'a')
            M1SKhsvwAD++;
        else {
            M1SKhsvwAD++;
            if (CVFnkzcHOwAM[lrbKIUtfGx8O] >= 'A' && CVFnkzcHOwAM[lrbKIUtfGx8O] <= 'Z')
                cout << "(" << CVFnkzcHOwAM[lrbKIUtfGx8O] << "," << M1SKhsvwAD << ")";
            else {
                CVFnkzcHOwAM[lrbKIUtfGx8O] = CVFnkzcHOwAM[lrbKIUtfGx8O] + 'A' - 'a';
                cout << "(" << CVFnkzcHOwAM[lrbKIUtfGx8O] << "," << M1SKhsvwAD << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            M1SKhsvwAD = 0;
        };
    }
    cout << endl;
    return 0;
}

