char HBR2waS [1001];

int main () {
    int LCGNLfyVXi;
    int i;
    LCGNLfyVXi = strlen (HBR2waS);
    i = (452 - 452);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int num = (303 - 302);
    cin >> HBR2waS;
    for (i = 0; i < LCGNLfyVXi; i = i + 1) {
        if ('a' <= HBR2waS[i] && HBR2waS[i] <= 'z')
            HBR2waS[i] = HBR2waS[i] + 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        i = 0;
        while (i < LCGNLfyVXi) {
            if (HBR2waS[i + 1] == HBR2waS[i]) {
                num++;
            }
            if (HBR2waS[i + 1] != HBR2waS[i]) {
                cout << "(" << HBR2waS[i] << "," << num << ")";
                num = 1;
            }
            i = i + 1;
        };
    }
    return 0;
}

