int main () {
    char c [1100];
    char U2bLZrh [(1668 - 568)];
    int p;
    int n;
    p = (609 - 609);
    int b [1100];
    cin >> U2bLZrh;
    n = strlen (U2bLZrh);
    for (int DC81wiW = (894 - 894);
    n > DC81wiW; DC81wiW = DC81wiW +1)
        b[DC81wiW] = (256 - 255);
    for (int DC81wiW = (499 - 499);
    n > DC81wiW; DC81wiW++) {
        if (U2bLZrh[DC81wiW] - 'a' >= (309 - 309))
            U2bLZrh[DC81wiW] = U2bLZrh[DC81wiW] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int DC81wiW = (295 - 294);
        while (DC81wiW < n) {
            if (U2bLZrh[DC81wiW] == U2bLZrh[DC81wiW -1]) {
                b[p]++;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                c[p] = U2bLZrh[DC81wiW];
            }
            else {
                p = p + 1;
                c[p] = U2bLZrh[DC81wiW];
            }
            DC81wiW++;
        };
    }
    c[(846 - 846)] = U2bLZrh[0];
    for (int j = 0;
    j <= p; j = j + 1)
        cout << "(" << c[j] << "," << b[j] << ")";
    return 0;
}

