main () {
    int Y8N4cdZ;
    int RoxFpkzRvKLi;
    int t0b7JriBv2QV;
    int j;
    int G07suY4;
    Y8N4cdZ = (624 - 624);
    char s [1001];
    char c;
    for (t0b7JriBv2QV = (806 - 806); 1001 > t0b7JriBv2QV; t0b7JriBv2QV = t0b7JriBv2QV + 1)
        s[t0b7JriBv2QV] = '\0';
    scanf ("%s", s);
    for (t0b7JriBv2QV = (695 - 695); !('\0' == s[t0b7JriBv2QV]);) {
        G07suY4 = 0;
        for (j = t0b7JriBv2QV; 1001 > j; j++) {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (s[t0b7JriBv2QV] == s[j] || !(s[j] + (1015 - 983) != s[t0b7JriBv2QV]) || s[t0b7JriBv2QV] == s[j] - 32)
                G07suY4 = G07suY4 +1;
            else {
                if (s[t0b7JriBv2QV] != s[j] && s[t0b7JriBv2QV] != s[j] + 32 && s[t0b7JriBv2QV] != s[j] - 32) {
                    printf ("(%c,%d)", (s[t0b7JriBv2QV] >= 'a' && s[t0b7JriBv2QV] <= 'z') ? (s[t0b7JriBv2QV] - 32) : s[t0b7JriBv2QV], G07suY4);
                    Y8N4cdZ = Y8N4cdZ +G07suY4;
                    t0b7JriBv2QV = Y8N4cdZ;
                    break;
                };
            };
        };
    };
}

