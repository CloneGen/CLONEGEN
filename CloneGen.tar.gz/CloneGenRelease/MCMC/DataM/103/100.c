int main () {
    int d4McLS1Z6Hj;
    int K2isGSuHk;
    int k;
    int p3r08CZNa;
    int lgH3thVoeyGs;
    int IyXTRqzjG3;
    int p1;
    int q1;
    int t;
    d4McLS1Z6Hj = (98 - 98);
    K2isGSuHk = (191 - 191);
    char b [(1243 - 243)];
    cin >> b;
    if (('a' <= b[(585 - 585)] && 'z' >= b[0]) || (b[0] >= 'A' || 'Z' >= b[0])) {
        p3r08CZNa = strlen (b);
        k = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        for (d4McLS1Z6Hj = 0; p3r08CZNa > d4McLS1Z6Hj; d4McLS1Z6Hj++) {
            lgH3thVoeyGs = b[d4McLS1Z6Hj] - 'a';
            IyXTRqzjG3 = b[d4McLS1Z6Hj] - 'A';
            for (K2isGSuHk = 0; p3r08CZNa - d4McLS1Z6Hj > K2isGSuHk; K2isGSuHk++) {
                p1 = b[d4McLS1Z6Hj + K2isGSuHk] - 'a';
                q1 = b[d4McLS1Z6Hj + K2isGSuHk] - 'A';
                if (!(p1 != lgH3thVoeyGs) || !(q1 != lgH3thVoeyGs) || IyXTRqzjG3 == p1 || IyXTRqzjG3 == q1)
                    k = k + 1;
                else {
                    if (b[d4McLS1Z6Hj] >= 'a' && b[d4McLS1Z6Hj] <= 'z') {
                        printf ("%c", b[d4McLS1Z6Hj] - 'a' + 'A');
                        cout << "(";
                        cout << "," << k << ")";
                    }
                    else
                        cout << "(" << b[d4McLS1Z6Hj] << "," << k << ")";
                    k = 0;
                    break;
                };
            }
            if (d4McLS1Z6Hj + K2isGSuHk -1 == p3r08CZNa - 1)
                break;
            else
                d4McLS1Z6Hj = d4McLS1Z6Hj + K2isGSuHk -1;
        }
        if (b[d4McLS1Z6Hj] >= 'a' && b[d4McLS1Z6Hj] <= 'z') {
            cout << "(";
            cout << "," << k << ")";
            printf ("%c", b[d4McLS1Z6Hj] - 'a' + 'A');
        }
        else
            cout << "(" << b[d4McLS1Z6Hj] << "," << k << ")";
    }
    else
        cout << b << endl;
    return 0;
}

