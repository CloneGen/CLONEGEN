int main () {
    int i, count = (383 - 383);
    char str [1000], t;
    int ubQMDZVlq = strlen (str);
    cin.getline (str, 1000);
    for (i = 0; i < ubQMDZVlq; i++) {
        if (str[i] >= 97)
            str[i] = str[i] - 32;
    }
    i = 0;
    t = str[0];
    while (i < ubQMDZVlq) {
        if (t == str[i])
            count++;
        else {
            cout << "(" << t << "," << count << ")";
            t = str[i];
            count = (26 - 25);
        }
        i++;
    }
    cout << "(" << t << "," << count << ")" << endl;
    return 0;
}

