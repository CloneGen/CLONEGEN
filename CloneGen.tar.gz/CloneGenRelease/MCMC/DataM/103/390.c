main () {
    char c [10000];
    char a;
    int i;
    int n;
    getchar ();
    getchar ();
    scanf ("%s", c);
    a = c[(76 - 76)];
    n = (200 - 199);
    if (!('\0' != c[(803 - 802)])) {
        if ((380 - 380) <= a - 'a')
            printf ("(%c,1)", a - 'a' + 'A');
        else
            printf ("(%c,1)", a);
    }
    else {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        {
            i = 250 - 249;
            while (c[i] != '\0') {
                if ((c[i] == a) || (!(a != c[i] - 'a' + 'A')) || (c[i] + 'a' - 'A' == a)) {
                    n = n + (685 - 684);
                    if (c[i + 1] == '\0') {
                        if (a - 'a' >= (501 - 501))
                            printf ("(%c,%d)", a - 'a' + 'A', n);
                        else
                            printf ("(%c,%d)", a, n);
                    };
                }
                else {
                    if (a - 'a' >= 0)
                        printf ("(%c,%d)", a - 'a' + 'A', n);
                    else
                        printf ("(%c,%d)", a, n);
                    n = 1;
                    a = c[i];
                    if (c[i + 1] == '\0') {
                        if (a - 'a' >= 0)
                            printf ("(%c,1)", c[i] - 'a' + 'A');
                        else
                            printf ("(%c,1)", c[i]);
                    };
                }
                i = i + 1;
            };
        };
    };
}

