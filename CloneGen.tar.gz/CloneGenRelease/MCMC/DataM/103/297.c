int main () {
    int U3LGBt5;
    int CRbTBYvfLrS;
    int k;
    int h;
    char WRBdt9T [(1324 - 324)];
    char c [(1480 - 480)];
    int UNUXmt2n5 [1000];
    for (U3LGBt5 = (259 - 259); 1000 > U3LGBt5; U3LGBt5 = U3LGBt5 +1) {
        scanf ("%c", &WRBdt9T[U3LGBt5]);
        if (WRBdt9T[U3LGBt5] >= 'a' && 'z' >= WRBdt9T[U3LGBt5])
            WRBdt9T[U3LGBt5] = WRBdt9T[U3LGBt5] - 'a' + 'A';
        if (!('\n' != WRBdt9T[U3LGBt5]))
            break;
    }
    for (h = (281 - 281), CRbTBYvfLrS = 0; h < U3LGBt5; h = h + 1) {
        c[CRbTBYvfLrS] = WRBdt9T[h];
        if (WRBdt9T[h] == WRBdt9T[h + 1]) {
            UNUXmt2n5[CRbTBYvfLrS]++;
        }
        else
            CRbTBYvfLrS++;
    }
    {
        k = 0;
        while (k < CRbTBYvfLrS) {
            printf ("(%c,%d)", c[k], UNUXmt2n5[k] + 1);
            k++;
        };
    }
    return 0;
}

