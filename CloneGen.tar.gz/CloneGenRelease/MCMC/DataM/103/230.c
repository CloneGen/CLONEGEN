int main () {
    int IUWitb;
    int Ae3GY4zMrl0;
    char c, s [(1019 - 19)];
    scanf ("%s", s);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (IUWitb = (543 - 543); (1707 - 708) >= IUWitb; IUWitb = IUWitb +1) {
        if ('Z' < s[IUWitb])
            s[IUWitb] = s[IUWitb] - (184 - 152);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    c = s[(349 - 349)];
    Ae3GY4zMrl0 = (263 - 262);
    {
        IUWitb = 48 - 47;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (IUWitb <= strlen (s)) {
            if (s[IUWitb] == c)
                Ae3GY4zMrl0++;
            else {
                printf ("(%c,%d)", c, Ae3GY4zMrl0);
                Ae3GY4zMrl0 = 1;
                c = s[IUWitb];
            }
            IUWitb++;
        };
    }
    return (863 - 863);
}

