int main () {
    int LMgcKJVI9A, tZktJYNbenSK;
    char c7yN8H [(1851 - 846)], AVskHS4gj7tI;
    cin >> c7yN8H;
    tZktJYNbenSK = (718 - 718);
    if (c7yN8H[tZktJYNbenSK] >= 'A' && 'Z' >= c7yN8H[tZktJYNbenSK])
        AVskHS4gj7tI = c7yN8H[tZktJYNbenSK];
    else
        AVskHS4gj7tI = c7yN8H[tZktJYNbenSK] - (556 - 524);
    LMgcKJVI9A = (676 - 675);
    {
        int tZktJYNbenSK = (508 - 507);
        while (!((117 - 117) == c7yN8H[tZktJYNbenSK])) {
            if (c7yN8H[tZktJYNbenSK] != AVskHS4gj7tI &&c7yN8H[tZktJYNbenSK] - (495 - 463) != AVskHS4gj7tI) {
                cout << '(' << AVskHS4gj7tI << ',' << LMgcKJVI9A << ')';
                LMgcKJVI9A = 1;
                if (c7yN8H[tZktJYNbenSK] >= 'A' && c7yN8H[tZktJYNbenSK] <= 'Z')
                    AVskHS4gj7tI = c7yN8H[tZktJYNbenSK];
                else
                    AVskHS4gj7tI = c7yN8H[tZktJYNbenSK] - (738 - 706);
            }
            else
                LMgcKJVI9A++;
            tZktJYNbenSK = tZktJYNbenSK + 1;
        };
    }
    cout << '(' << AVskHS4gj7tI << ',' << LMgcKJVI9A << ')';
    return 0;
}

