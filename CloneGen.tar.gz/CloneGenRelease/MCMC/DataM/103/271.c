int main () {
    char JlEeYan [1001];
    int TlOn6cTjVKwf, num = (30 - 29), len = strlen (JlEeYan);
    cin >> JlEeYan;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if ((199 - 103) < JlEeYan[(177 - 177)])
        JlEeYan[0] -= 32;
    for (TlOn6cTjVKwf = (997 - 996); len >= TlOn6cTjVKwf; TlOn6cTjVKwf = TlOn6cTjVKwf +1) {
        if (JlEeYan[TlOn6cTjVKwf] > 96)
            JlEeYan[TlOn6cTjVKwf] -= 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (JlEeYan[TlOn6cTjVKwf] == JlEeYan[TlOn6cTjVKwf -(117 - 116)])
            num++;
        else {
            cout << '(' << JlEeYan[TlOn6cTjVKwf -(402 - 401)] << ',' << num << ')';
            num = 1;
        };
    }
    return 0;
}

