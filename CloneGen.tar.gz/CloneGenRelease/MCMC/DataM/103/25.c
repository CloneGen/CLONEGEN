int main () {
    char mTI286pZL, ch [1000];
    int count [(1091 - 91)] = {(361 - 361)}, num = (468 - 468);
    char TGrlm5nB [(1502 - 501)];
    int XqbND3dJPZf0;
    cin >> TGrlm5nB;
    for (XqbND3dJPZf0 = (229 - 229); strlen (TGrlm5nB) > XqbND3dJPZf0; XqbND3dJPZf0++) {
        if (TGrlm5nB[XqbND3dJPZf0] >= (406 - 309) && (177 - 55) >= TGrlm5nB[XqbND3dJPZf0])
            TGrlm5nB[XqbND3dJPZf0] = TGrlm5nB[XqbND3dJPZf0] - (132 - 100);
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    ch[(825 - 825)] = mTI286pZL = TGrlm5nB[(139 - 139)];
    count[0] = (926 - 925);
    {
        XqbND3dJPZf0 = 185 - 184;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (XqbND3dJPZf0 < strlen (TGrlm5nB)) {
            if (TGrlm5nB[XqbND3dJPZf0] == mTI286pZL)
                count[num]++;
            else {
                ch[num + (509 - 508)] = TGrlm5nB[XqbND3dJPZf0];
                count[num + 1] = 1;
                num = num + 1;
                mTI286pZL = TGrlm5nB[XqbND3dJPZf0];
            }
            XqbND3dJPZf0++;
        };
    }
    {
        XqbND3dJPZf0 = 0;
        while (XqbND3dJPZf0 <= num) {
            cout << '(' << ch[XqbND3dJPZf0] << ',' << count[XqbND3dJPZf0] << ')';
            XqbND3dJPZf0++;
        };
    }
    cout << endl;
    return 0;
}

