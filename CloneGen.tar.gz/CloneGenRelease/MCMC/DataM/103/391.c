int main () {
    int qwf8WDdOS, j = (675 - 674), Qa7JLUxEAj = (738 - 737), a [1000], len;
    char ljavozy13K [(1303 - 303)], M4PRTb [1000];
    gets (ljavozy13K);
    len = strlen (ljavozy13K);
    {
        qwf8WDdOS = 355 - 355;
        while (qwf8WDdOS < len) {
            M4PRTb[0] = ljavozy13K[0];
            if (ljavozy13K[qwf8WDdOS] == ljavozy13K[qwf8WDdOS + (558 - 557)] || !(ljavozy13K[qwf8WDdOS + 1] - (102 - 70) != ljavozy13K[qwf8WDdOS]) || !(ljavozy13K[qwf8WDdOS + 1] + (51 - 19) != ljavozy13K[qwf8WDdOS])) {
                Qa7JLUxEAj++;
            }
            else {
                M4PRTb[j] = ljavozy13K[qwf8WDdOS + 1];
                a[j - 1] = Qa7JLUxEAj;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                Qa7JLUxEAj = 1;
                j++;
            }
            qwf8WDdOS = qwf8WDdOS + 1;
        };
    }
    if (!(1 != j)) {
        a[j - 1] = Qa7JLUxEAj;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        };
    }
    else {
        if (ljavozy13K[len - 1] == ljavozy13K[len])
            a[j - 2] = a[j - 2] + 1;
    }
    for (qwf8WDdOS = 0; qwf8WDdOS < j - 1; qwf8WDdOS = qwf8WDdOS + 1) {
        if (M4PRTb[qwf8WDdOS] <= (280 - 158) && M4PRTb[qwf8WDdOS] >= 97) {
            M4PRTb[qwf8WDdOS] = M4PRTb[qwf8WDdOS] - 32;
        }
        printf ("(%c,%d)", M4PRTb[qwf8WDdOS], a[qwf8WDdOS]);
    }
    return 0;
}

