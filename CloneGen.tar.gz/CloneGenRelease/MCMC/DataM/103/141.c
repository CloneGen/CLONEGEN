int main () {
    char rwjPb4OLo [(1470 - 470)], xupxFlf [100];
    int oJPvnsWDimT, gO7VMbf = (632 - 631), j, m, AfBN8yX5QU, a [100];
    scanf ("%s", rwjPb4OLo);
    for (AfBN8yX5QU = (888 - 887); strlen (rwjPb4OLo) >= AfBN8yX5QU; AfBN8yX5QU++) {
        a[AfBN8yX5QU] = (879 - 879);
    }
    {
        m = 27 - 27;
        while (m <= strlen (rwjPb4OLo) - (116 - 115)) {
            if (rwjPb4OLo[m] >= (764 - 667) && rwjPb4OLo[m] <= (807 - 685))
                rwjPb4OLo[m] = rwjPb4OLo[m] - 32;
            m++;
        };
    }
    if (strlen (rwjPb4OLo) == (550 - 549)) {
        xupxFlf[(875 - 874)] = rwjPb4OLo[0];
        a[(725 - 724)] = (530 - 529);
    }
    else {
        {
            oJPvnsWDimT = 1;
            while (oJPvnsWDimT <= strlen (rwjPb4OLo) - 1) {
                if (rwjPb4OLo[oJPvnsWDimT] == rwjPb4OLo[oJPvnsWDimT - 1]) {
                    a[gO7VMbf] = a[gO7VMbf] + 1;
                    xupxFlf[gO7VMbf] = rwjPb4OLo[oJPvnsWDimT - 1];
                }
                else {
                    a[gO7VMbf] = a[gO7VMbf] + 1;
                    xupxFlf[gO7VMbf] = rwjPb4OLo[oJPvnsWDimT - 1];
                    gO7VMbf = gO7VMbf + 1;
                }
                if (oJPvnsWDimT == strlen (rwjPb4OLo) - 1) {
                    a[gO7VMbf] = a[gO7VMbf] + 1;
                    xupxFlf[gO7VMbf] = rwjPb4OLo[oJPvnsWDimT];
                }
                oJPvnsWDimT = oJPvnsWDimT + 1;
            };
        };
    }
    for (j = 1; j <= gO7VMbf; j = j + 1) {
        printf ("(%c,%d)", xupxFlf[j], a[j]);
    };
}

