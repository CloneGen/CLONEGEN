char change (char CyKVrGCWLgi) {
    if ('a' <= CyKVrGCWLgi &&CyKVrGCWLgi <= 'z')
        return CyKVrGCWLgi -'a' + 'A';
    else
        return CyKVrGCWLgi;
}

int main () {
    char N1dLNAW9eh [100];
    int v1EVgufY5Wj, num = (642 - 641), len;
    cin.getline (N1dLNAW9eh, 100);
    len = strlen (N1dLNAW9eh);
    cout << "(" << change (N1dLNAW9eh[0]) << ",";
    for (v1EVgufY5Wj = 1; v1EVgufY5Wj < len; v1EVgufY5Wj++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (change (N1dLNAW9eh[v1EVgufY5Wj]) == change (N1dLNAW9eh[v1EVgufY5Wj - 1]))
            num = num + 1;
        else {
            cout << num << ")(" << change (N1dLNAW9eh[v1EVgufY5Wj]) << ",";
            num = 1;
        };
    }
    cout << num << ")" << endl;
    return 0;
}

