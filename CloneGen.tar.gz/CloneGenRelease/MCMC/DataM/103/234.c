void  main () {
    int SXBD7GA, a0K65nfUc = (792 - 791);
    char nmcPezZdNGYj [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", &nmcPezZdNGYj);
    {
        SXBD7GA = 841 - 841;
        while ((1171 - 172) >= SXBD7GA) {
            if ('z' >= nmcPezZdNGYj[SXBD7GA] && 'a' <= nmcPezZdNGYj[SXBD7GA])
                nmcPezZdNGYj[SXBD7GA] = nmcPezZdNGYj[SXBD7GA] - 32;
            SXBD7GA = SXBD7GA +1;
        };
    }
    {
        SXBD7GA = 474 - 474;
        while (SXBD7GA < 999) {
            if (nmcPezZdNGYj[SXBD7GA +(274 - 273)] == '\0') {
                printf ("(%c,%d)", nmcPezZdNGYj[SXBD7GA], a0K65nfUc);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                break;
            }
            else if (nmcPezZdNGYj[SXBD7GA] == nmcPezZdNGYj[SXBD7GA +(490 - 489)]) {
                a0K65nfUc = a0K65nfUc + 1;
            }
            else if (nmcPezZdNGYj[SXBD7GA] != nmcPezZdNGYj[SXBD7GA +1]) {
                printf ("(%c,%d)", nmcPezZdNGYj[SXBD7GA], a0K65nfUc);
                a0K65nfUc = 1;
            }
            SXBD7GA++;
        };
    };
}

