int main () {
    char NHjTnArSpqC7 [1001];
    char WIjFsT1Ppun;
    int i, kmNBo7DvL, KhA3pJG79;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (NHjTnArSpqC7);
    KhA3pJG79 = strlen (NHjTnArSpqC7);
    {
        i = 158 - 158;
        while (i < KhA3pJG79) {
            kmNBo7DvL = (472 - 471);
            WIjFsT1Ppun = NHjTnArSpqC7[i];
            if ((WIjFsT1Ppun >= 97) && ((505 - 383) >= WIjFsT1Ppun))
                WIjFsT1Ppun = WIjFsT1Ppun -32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            while ((NHjTnArSpqC7[i + 1] == WIjFsT1Ppun) || (NHjTnArSpqC7[i + 1] == WIjFsT1Ppun +32)) {
                i = i + 1;
                kmNBo7DvL = kmNBo7DvL + 1;
            }
            printf ("(%c,%d)", WIjFsT1Ppun, kmNBo7DvL);
            i = i + 1;
        };
    }
    return 0;
}

