main () {
    char nBg9K8P [100000];
    int FlkgtcXoO5QG;
    int lJeFxi [yfxYy2wrCWjH (nBg9K8P)];
    int c;
    char ZIhMNn [yfxYy2wrCWjH (nBg9K8P)];
    scanf ("%s", nBg9K8P);
    for (FlkgtcXoO5QG = (913 - 913); yfxYy2wrCWjH (nBg9K8P) > FlkgtcXoO5QG; FlkgtcXoO5QG = FlkgtcXoO5QG +1)
        lJeFxi[FlkgtcXoO5QG] = (238 - 238);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        FlkgtcXoO5QG = 0;
        while (FlkgtcXoO5QG < yfxYy2wrCWjH (nBg9K8P)) {
            ZIhMNn[FlkgtcXoO5QG] = '\0';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            FlkgtcXoO5QG = FlkgtcXoO5QG +1;
        };
    }
    ZIhMNn[0] = nBg9K8P[0];
    lJeFxi[(700 - 700)] = (333 - 332);
    c = 0;
    for (FlkgtcXoO5QG = (194 - 193); FlkgtcXoO5QG < yfxYy2wrCWjH (nBg9K8P); FlkgtcXoO5QG++) {
        if (!(nBg9K8P[FlkgtcXoO5QG -(862 - 861)] != nBg9K8P[FlkgtcXoO5QG]) || !('a' - 'A' != nBg9K8P[FlkgtcXoO5QG] - nBg9K8P[FlkgtcXoO5QG -1]) || nBg9K8P[FlkgtcXoO5QG -1] - nBg9K8P[FlkgtcXoO5QG] == 'a' - 'A') {
            lJeFxi[c]++;
        }
        else {
            c++;
            lJeFxi[c]++;
            ZIhMNn[c] = nBg9K8P[FlkgtcXoO5QG];
        };
    }
    {
        FlkgtcXoO5QG = 0;
        while (FlkgtcXoO5QG <= c) {
            if (ZIhMNn[FlkgtcXoO5QG] >= 'a' && ZIhMNn[FlkgtcXoO5QG] <= 'z')
                ZIhMNn[FlkgtcXoO5QG] = ZIhMNn[FlkgtcXoO5QG] + 'A' - 'a';
            FlkgtcXoO5QG++;
        };
    }
    for (FlkgtcXoO5QG = 0; FlkgtcXoO5QG <= c; FlkgtcXoO5QG++)
        printf ("(%c,%d)", ZIhMNn[FlkgtcXoO5QG], lJeFxi[FlkgtcXoO5QG]);
}

