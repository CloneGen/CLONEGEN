int main () {
    char a [(1280 - 281)];
    int THMdu1gW06;
    int x;
    THMdu1gW06 = (670 - 670);
    gets (a);
    for (; a[THMdu1gW06] != '\0'; THMdu1gW06 = THMdu1gW06 +1) {
        x = (149 - 148);
        for (;; THMdu1gW06 = THMdu1gW06 +1) {
            if (!(a[THMdu1gW06 +(456 - 455)] != a[THMdu1gW06]) || (a[THMdu1gW06] - a[THMdu1gW06 +1]) == ('A' - 'a') || (a[THMdu1gW06 +1] - a[THMdu1gW06]) == ('A' - 'a'))
                x++;
            else
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (a[THMdu1gW06] < 'Z')
            printf ("(%c,%d)", a[THMdu1gW06], x);
        else
            printf ("(%c,%d)", (a[THMdu1gW06] + 'A' - 'a'), x);
    };
}

