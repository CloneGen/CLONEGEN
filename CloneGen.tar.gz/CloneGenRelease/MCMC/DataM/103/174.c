int main () {
    char OH1A5OjE4 [(1460 - 460)], CHcSBl [(1031 - 31)];
    int c [1000] = {(650 - 650)}, cl97OYshNeyI, j, D6OGgZ0l, m;
    m = 0;
    c[0] = (435 - 434);
    scanf ("%s", OH1A5OjE4);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cl97OYshNeyI = strlen (OH1A5OjE4);
    if (OH1A5OjE4[(139 - 139)] <= (955 - 865))
        CHcSBl[0] = OH1A5OjE4[0];
    else
        CHcSBl[0] = OH1A5OjE4[0] - (555 - 523);
    D6OGgZ0l = 0;
    for (j = (434 - 433); cl97OYshNeyI > j; j = j + 1) {
        if (OH1A5OjE4[j] == OH1A5OjE4[j - (982 - 981)] || !(OH1A5OjE4[j - 1] - (179 - 147) != OH1A5OjE4[j]) || OH1A5OjE4[j] == OH1A5OjE4[j - 1] + 32)
            c[D6OGgZ0l] = c[D6OGgZ0l] + 1;
        else {
            D6OGgZ0l = D6OGgZ0l +1;
            c[D6OGgZ0l] = c[D6OGgZ0l] + 1;
            m = m + 1;
            if (OH1A5OjE4[j] <= (571 - 481))
                CHcSBl[m] = OH1A5OjE4[j];
            else
                CHcSBl[m] = OH1A5OjE4[j] - 32;
        };
    }
    {
        cl97OYshNeyI = 0;
        while (cl97OYshNeyI <= m) {
            printf ("(%c,%d)", CHcSBl[cl97OYshNeyI], c[cl97OYshNeyI]);
            cl97OYshNeyI++;
        };
    };
}

