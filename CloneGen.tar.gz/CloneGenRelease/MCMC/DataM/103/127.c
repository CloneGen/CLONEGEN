char a [500];

void  main () {
    char WOpymJ3ezlaV;
    int sum;
    int dhCYdOpx3ZR;
    int flag;
    sum = (161 - 161);
    gets (a);
    for (dhCYdOpx3ZR = (467 - 467); !((298 - 298) == a[dhCYdOpx3ZR]); dhCYdOpx3ZR++)
        if (a[dhCYdOpx3ZR] >= 'a' && a[dhCYdOpx3ZR] <= 'z')
            a[dhCYdOpx3ZR] = a[dhCYdOpx3ZR] + 'A' - 'a';
    WOpymJ3ezlaV = a[(155 - 155)];
    {
        flag = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        dhCYdOpx3ZR = 595 - 595;
        while (a[dhCYdOpx3ZR] != 0) {
            if (a[dhCYdOpx3ZR] != WOpymJ3ezlaV) {
                printf ("(%c,%d)", WOpymJ3ezlaV, sum);
                WOpymJ3ezlaV = a[dhCYdOpx3ZR];
                sum = (242 - 241);
            }
            else
                sum++;
            dhCYdOpx3ZR = dhCYdOpx3ZR + 1;
        };
    }
    printf ("(%c,%d)", WOpymJ3ezlaV, sum);
}

