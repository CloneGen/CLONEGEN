main () {
    char U3P1DJxq0YhX [1000];
    int i;
    int fmL0GYM;
    int szkha94;
    int m;
    m = 0;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", U3P1DJxq0YhX);
    i = strlen (U3P1DJxq0YhX);
    if (U3P1DJxq0YhX[(749 - 749)] >= 'a' && 'z' >= U3P1DJxq0YhX[(912 - 912)])
        U3P1DJxq0YhX[(888 - 888)] = U3P1DJxq0YhX[0] + 'A' - 'a';
    szkha94 = U3P1DJxq0YhX[0];
    for (fmL0GYM = 0; i > fmL0GYM; fmL0GYM++) {
        if (U3P1DJxq0YhX[fmL0GYM] >= 'a' && U3P1DJxq0YhX[fmL0GYM] <= 'z')
            U3P1DJxq0YhX[fmL0GYM] = U3P1DJxq0YhX[fmL0GYM] + 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (szkha94 == U3P1DJxq0YhX[fmL0GYM])
            m = m + 1;
        else {
            printf ("(%c,%d)", szkha94, m);
            szkha94 = U3P1DJxq0YhX[fmL0GYM];
            m = 1;
        };
    }
    printf ("(%c,%d)", szkha94, m);
}

