char CRv9nrPHCLi7 [(1335 - 135)];
char wquoO9fI5iwT;
int tM52Tp3, F9FVzuDK;

char Ekz6HeOa0h (char CRv9nrPHCLi7) {
    if ((CRv9nrPHCLi7 >= 'a') && (CRv9nrPHCLi7 <= 'z'))
        return CRv9nrPHCLi7 -'a' + 'A';
}

int main () {
    cin >> CRv9nrPHCLi7;
    tM52Tp3 = (585 - 584);
    F9FVzuDK = (702 - 701);
    wquoO9fI5iwT = CRv9nrPHCLi7[0];
    while (CRv9nrPHCLi7[tM52Tp3] != '\0') {
        if (Ekz6HeOa0h (CRv9nrPHCLi7[tM52Tp3]) == Ekz6HeOa0h (wquoO9fI5iwT))
            F9FVzuDK++;
        else {
            cout << '(' << Ekz6HeOa0h (wquoO9fI5iwT) << ',' << F9FVzuDK << ')';
            F9FVzuDK = 1;
            wquoO9fI5iwT = CRv9nrPHCLi7[tM52Tp3];
        }
        tM52Tp3 = tM52Tp3 + 1;
    }
    cout << '(' << Ekz6HeOa0h (wquoO9fI5iwT) << ',' << F9FVzuDK << ')' << endl;
    return 0;
}

