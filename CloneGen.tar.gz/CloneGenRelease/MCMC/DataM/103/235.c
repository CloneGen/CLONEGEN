void  a2uqHNv (char FG9jr2 []) {
    int cQLN0bk3;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        cQLN0bk3 = 404 - 404;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == FG9jr2[cQLN0bk3])) {
            if ('a' <= FG9jr2[cQLN0bk3] && FG9jr2[cQLN0bk3] <= 'z') {
                FG9jr2[cQLN0bk3] = FG9jr2[cQLN0bk3] + 'A' - 'a';
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cQLN0bk3 = cQLN0bk3 + 1;
        };
    };
}

int main () {
    char FG9jr2 [(1144 - 143)];
    gets (FG9jr2);
    int n;
    int cQLN0bk3;
    int KNZeE3U;
    n = (100 - 99);
    a2uqHNv (FG9jr2);
    {
        cQLN0bk3 = 783 - 782;
        while (FG9jr2[cQLN0bk3 - (713 - 712)] != '\0') {
            if (FG9jr2[cQLN0bk3] == FG9jr2[cQLN0bk3 - (125 - 124)]) {
                n = n + 1;
            }
            else {
                printf ("(%c,%d)", FG9jr2[cQLN0bk3 - (535 - 534)], n);
                n = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            cQLN0bk3++;
        };
    }
    return ((579 - 579));
}

