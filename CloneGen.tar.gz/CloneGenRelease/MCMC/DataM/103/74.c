int main () {
    char temp;
    char a [(1290 - 289)];
    int Lo02yTMNwh, wvVExzm309SC;
    int UJqHRT = strlen (a);
    int sCOUTRBlgt;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> a;
    for (Lo02yTMNwh = (160 - 160); UJqHRT > Lo02yTMNwh; Lo02yTMNwh = Lo02yTMNwh +1)
        if ('a' <= a[Lo02yTMNwh] && 'z' >= a[Lo02yTMNwh])
            a[Lo02yTMNwh] = a[Lo02yTMNwh] + 'A' - 'a';
    for (Lo02yTMNwh = (946 - 946); Lo02yTMNwh < UJqHRT; Lo02yTMNwh++) {
        sCOUTRBlgt = (828 - 828);
        for (wvVExzm309SC = Lo02yTMNwh;; wvVExzm309SC++)
            if (a[wvVExzm309SC] == a[Lo02yTMNwh])
                sCOUTRBlgt = sCOUTRBlgt + (105 - 104);
            else
                break;
        temp = a[Lo02yTMNwh];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        cout << '(' << temp << ',' << sCOUTRBlgt << ')';
        Lo02yTMNwh = Lo02yTMNwh +sCOUTRBlgt - 1;
    }
    return (279 - 279);
}

