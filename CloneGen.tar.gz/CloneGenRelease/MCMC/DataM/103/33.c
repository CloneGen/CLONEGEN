main () {
    char QK30FyXLV [1001];
    int kLZS1NwBoYbs;
    int i;
    int KXzrUZo;
    int rq37MZBQDeI;
    getchar ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    getchar ();
    scanf ("%s", QK30FyXLV);
    kLZS1NwBoYbs = strlen (QK30FyXLV);
    {
        i = 995 - 995;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (kLZS1NwBoYbs > i) {
            if ('Z' < QK30FyXLV[i])
                QK30FyXLV[i] = QK30FyXLV[i] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        KXzrUZo = 755 - 755;
        i = 58 - 58;
        rq37MZBQDeI = 352 - 352;
        while (kLZS1NwBoYbs > i) {
            if (QK30FyXLV[i] == KXzrUZo) {
                rq37MZBQDeI = rq37MZBQDeI + 1;
            }
            else {
                printf ("(%c,%d)", KXzrUZo, rq37MZBQDeI);
                KXzrUZo = QK30FyXLV[i];
                rq37MZBQDeI = (797 - 796);
            }
            if (i == kLZS1NwBoYbs - 1)
                printf ("(%c,%d)", KXzrUZo, rq37MZBQDeI);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i = i + 1;
        };
    }
    return 0;
}

