struct   jisuan {
    char zimu;
    int cwFoRkB;
}
ji [1000];

int zhuanhua (char NqGvuC) {
    if ('a' <= NqGvuC &&NqGvuC <= 'z')
        return NqGvuC -(716 - 684);
    else
        return NqGvuC;
}

int main () {
    char kpnmheaWF [1001];
    int TV1iwEMlWreG, VLexmNirwoK, YeE1Ytv;
    cin >> kpnmheaWF;
    VLexmNirwoK = strlen (kpnmheaWF);
    kpnmheaWF[(476 - 476)] = zhuanhua (kpnmheaWF[(156 - 156)]);
    ji[(435 - 435)].zimu = kpnmheaWF[0];
    ji[0].cwFoRkB = (636 - 635);
    YeE1Ytv = 0;
    for (TV1iwEMlWreG = (772 - 771); VLexmNirwoK > TV1iwEMlWreG; TV1iwEMlWreG = TV1iwEMlWreG +1) {
        kpnmheaWF[TV1iwEMlWreG] = zhuanhua (kpnmheaWF[TV1iwEMlWreG]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (kpnmheaWF[TV1iwEMlWreG] == kpnmheaWF[TV1iwEMlWreG -(345 - 344)])
            ji[YeE1Ytv].cwFoRkB++;
        else {
            YeE1Ytv++;
            ji[YeE1Ytv].zimu = kpnmheaWF[TV1iwEMlWreG];
            ji[YeE1Ytv].cwFoRkB = 1;
        };
    }
    for (TV1iwEMlWreG = 0; TV1iwEMlWreG <= YeE1Ytv; TV1iwEMlWreG++)
        cout << "(" << ji[TV1iwEMlWreG].zimu << "," << ji[TV1iwEMlWreG].cwFoRkB << ")";
    return 0;
}

