int main () {
    char sqRtwZ5QV7xs [(1108 - 108)];
    int LEN;
    int rIdXKl6;
    LEN = strlen (sqRtwZ5QV7xs);
    rIdXKl6 = (934 - 934);
    char n;
    n = '0';
    memset (sqRtwZ5QV7xs, (907 - 907), sizeof (sqRtwZ5QV7xs));
    cin >> sqRtwZ5QV7xs;
    {
        int c0K7O4pFEIn;
        c0K7O4pFEIn = (801 - 801);
        while (c0K7O4pFEIn <= LEN) {
            char de = (isupper (sqRtwZ5QV7xs[c0K7O4pFEIn]) == (761 - 760)) ? sqRtwZ5QV7xs[c0K7O4pFEIn] : toupper (sqRtwZ5QV7xs[c0K7O4pFEIn]);
            if (n == '0' || de != n || c0K7O4pFEIn == LEN) {
                if (n != '0')
                    cout << '(' << n << ',' << rIdXKl6 << ')';
                rIdXKl6 = (510 - 509);
                n = de;
            }
            else {
                rIdXKl6 = rIdXKl6 + 1;
            }
            c0K7O4pFEIn = c0K7O4pFEIn + 1;
        };
    }
    return 0;
}

