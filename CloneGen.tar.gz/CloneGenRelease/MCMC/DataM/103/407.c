main () {
    char FzgTj7Ep [(1073 - 72)];
    int yKHR4Fs = (616 - 615), CvFsPaHpckz6;
    scanf ("%s", FzgTj7Ep);
    {
        CvFsPaHpckz6 = 841 - 841;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (CvFsPaHpckz6 < strlen (FzgTj7Ep)) {
            if (FzgTj7Ep[CvFsPaHpckz6] <= 'z' && FzgTj7Ep[CvFsPaHpckz6] >= 'a')
                FzgTj7Ep[CvFsPaHpckz6] = FzgTj7Ep[CvFsPaHpckz6] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            CvFsPaHpckz6 = CvFsPaHpckz6 +1;
        };
    }
    for (CvFsPaHpckz6 = 1; CvFsPaHpckz6 <= strlen (FzgTj7Ep); CvFsPaHpckz6 = CvFsPaHpckz6 +1) {
        if (FzgTj7Ep[CvFsPaHpckz6] == FzgTj7Ep[CvFsPaHpckz6 -1])
            yKHR4Fs++;
        else {
            printf ("(%c,%d)", FzgTj7Ep[CvFsPaHpckz6 -1], yKHR4Fs);
            yKHR4Fs = 1;
        };
    };
}

