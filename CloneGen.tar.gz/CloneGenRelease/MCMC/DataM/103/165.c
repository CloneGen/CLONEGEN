int main () {
    int TbdxT5shpIAX;
    int i;
    int tBe59ZDYrR;
    int j;
    int XvhIjHDsy4u3 [26] = {(936 - 936)};
    TbdxT5shpIAX = (208 - 208);
    char CkwzbL [1000];
    scanf ("%s", CkwzbL);
    tBe59ZDYrR = strlen (CkwzbL);
    {
        i = 0;
        while (tBe59ZDYrR > i) {
            if ((CkwzbL[i] >= 'a') && (CkwzbL[i] <= 'z')) {
                CkwzbL[i] = CkwzbL[i] - 'a' + 'A';
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        i = 0;
        while (i < tBe59ZDYrR) {
            TbdxT5shpIAX = TbdxT5shpIAX +1;
            if (CkwzbL[i + 1] != CkwzbL[i]) {
                printf ("(%c,%d)", CkwzbL[i], TbdxT5shpIAX);
                TbdxT5shpIAX = 0;
            }
            i = i + 1;
        };
    };
}

