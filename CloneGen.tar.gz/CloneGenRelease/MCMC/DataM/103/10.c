int main () {
    char ktSryQLl [1001];
    char suo [1001];
    int h10d9govV, eDG9aSbBfnQk, j, sj3bp6E, ya [1001] = {(646 - 646)};
    j = 0;
    cin >> ktSryQLl;
    h10d9govV = strlen (ktSryQLl);
    {
        eDG9aSbBfnQk = 422 - 422;
        while (h10d9govV > eDG9aSbBfnQk) {
            if ('a' <= ktSryQLl[eDG9aSbBfnQk] && 'z' >= ktSryQLl[eDG9aSbBfnQk])
                ktSryQLl[eDG9aSbBfnQk] = ktSryQLl[eDG9aSbBfnQk] + 'A' - 'a';
            eDG9aSbBfnQk = eDG9aSbBfnQk + 1;
        };
    }
    suo[(73 - 73)] = ktSryQLl[0];
    for (eDG9aSbBfnQk = 0; h10d9govV > eDG9aSbBfnQk; eDG9aSbBfnQk = eDG9aSbBfnQk + 1) {
        if (ktSryQLl[eDG9aSbBfnQk] == suo[j])
            ya[j]++;
        else {
            j = j + 1;
            suo[j] = ktSryQLl[eDG9aSbBfnQk];
            ya[j] = 1;
        };
    }
    {
        eDG9aSbBfnQk = 0;
        while (eDG9aSbBfnQk <= j) {
            cout << "(" << suo[eDG9aSbBfnQk] << "," << ya[eDG9aSbBfnQk] << ")";
            eDG9aSbBfnQk++;
        };
    }
    return 0;
}

