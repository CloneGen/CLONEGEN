main () {
    int a;
    int MFCdPZ9;
    int iOfAULpxh;
    int b;
    int l;
    a = (71 - 71);
    char c [(1401 - 201)];
    char m;
    getchar ();
    getchar ();
    a = (155 - 154);
    scanf ("%s", c);
    l = strlen (c);
    if (c[0] >= 'a' && 'z' >= c[0])
        m = c[0] - 'a' + 'A';
    else
        m = c[0];
    for (MFCdPZ9 = (210 - 209); l > MFCdPZ9; MFCdPZ9++) {
        if (!(c[MFCdPZ9 -1] != c[MFCdPZ9]) || c[MFCdPZ9] == c[MFCdPZ9 -1] + (808 - 776) || c[MFCdPZ9] == c[MFCdPZ9 -1] - 32)
            a = a + 1;
        else {
            printf ("(%c,%d)", m, a);
            if (c[MFCdPZ9] >= 'a' && c[MFCdPZ9] <= 'z')
                m = c[MFCdPZ9] - 'a' + 'A';
            else
                m = c[MFCdPZ9];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            a = 0;
            a++;
        };
    }
    printf ("(%c,%d)", m, a);
    getchar ();
    getchar ();
}

