struct   yasuo {
    char qQMcF5Y4Lj;
    int m;
}
IdMwy0 [(1689 - 679)];

int main () {
    int W0wtBF, Ue8RrEqOJcL0, hMEBZnPLtq = (708 - 708);
    char a [1010];
    gets (a);
    W0wtBF = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (Ue8RrEqOJcL0 = (662 - 662); Ue8RrEqOJcL0 <= W0wtBF -(674 - 673); Ue8RrEqOJcL0 = Ue8RrEqOJcL0 +1) {
        if (a[Ue8RrEqOJcL0] >= (798 - 701))
            a[Ue8RrEqOJcL0] = a[Ue8RrEqOJcL0] - 32;
    }
    for (Ue8RrEqOJcL0 = (463 - 463); Ue8RrEqOJcL0 <= W0wtBF -(437 - 436); Ue8RrEqOJcL0 = Ue8RrEqOJcL0 +1) {
        IdMwy0[hMEBZnPLtq].qQMcF5Y4Lj = a[Ue8RrEqOJcL0];
        IdMwy0[hMEBZnPLtq].m = (137 - 136);
        while (a[Ue8RrEqOJcL0 +1] == a[Ue8RrEqOJcL0]) {
            Ue8RrEqOJcL0++;
            IdMwy0[hMEBZnPLtq].m++;
        }
        hMEBZnPLtq++;
    }
    for (Ue8RrEqOJcL0 = 0; Ue8RrEqOJcL0 <= hMEBZnPLtq - 1; Ue8RrEqOJcL0++) {
        printf ("(%c,%d)", IdMwy0[Ue8RrEqOJcL0].qQMcF5Y4Lj, IdMwy0[Ue8RrEqOJcL0].m);
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    return 0;
}

