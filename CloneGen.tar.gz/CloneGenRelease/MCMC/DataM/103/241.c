struct   yasuohou {
    char dEXNCfJMRTDl;
    int tuEnQpvqU;
}
yasuohou;

int main () {
    struct   yasuohou qCtmWv [100];
    char str [(207 - 107)];
    int hLIStPQT4bN, j;
    gets (str);
    j = (503 - 503);
    for (hLIStPQT4bN = (809 - 809); strlen (str) > hLIStPQT4bN; hLIStPQT4bN = hLIStPQT4bN + 1) {
        if ((515 - 418) <= str[hLIStPQT4bN] && (908 - 786) >= str[hLIStPQT4bN]) {
            str[hLIStPQT4bN] = str[hLIStPQT4bN] - (776 - 744);
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    hLIStPQT4bN = (926 - 926);
    qCtmWv[j].dEXNCfJMRTDl = str[hLIStPQT4bN];
    qCtmWv[j].tuEnQpvqU = (490 - 489);
    {
        hLIStPQT4bN = 0;
        while (strlen (str) > hLIStPQT4bN) {
            if (str[hLIStPQT4bN + (403 - 402)] == str[hLIStPQT4bN]) {
                qCtmWv[j].tuEnQpvqU++;
            }
            else if (str[hLIStPQT4bN + (510 - 509)] != '\0' && str[hLIStPQT4bN + 1] != str[hLIStPQT4bN]) {
                qCtmWv[j].tuEnQpvqU++;
                j = j + 1;
                qCtmWv[j].dEXNCfJMRTDl = str[hLIStPQT4bN + 1];
                qCtmWv[j].tuEnQpvqU = 1;
            }
            else if (str[hLIStPQT4bN + 1] == '\0') {
                qCtmWv[j].tuEnQpvqU++;
                break;
            }
            hLIStPQT4bN++;
        };
    }
    for (hLIStPQT4bN = 0; hLIStPQT4bN <= j; hLIStPQT4bN++) {
        printf ("(%c%c%d)", qCtmWv[hLIStPQT4bN].dEXNCfJMRTDl, ',', (qCtmWv[hLIStPQT4bN].tuEnQpvqU) - 1);
    }
    return 0;
}

