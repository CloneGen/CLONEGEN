main () {
    int TughXoEOKA;
    int eoprJ3A8W5;
    TughXoEOKA = (488 - 488);
    char QFxGTN4gMlEL [(1090 - 90)];
    char KfH2SZYD1n;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char a;
    scanf ("%s", QFxGTN4gMlEL);
    {
        eoprJ3A8W5 = 383 - 383;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (eoprJ3A8W5 < strlen (QFxGTN4gMlEL)) {
            {
                KfH2SZYD1n = 'A';
                while (KfH2SZYD1n <= 'Z') {
                    if (!(KfH2SZYD1n != QFxGTN4gMlEL[eoprJ3A8W5]) || QFxGTN4gMlEL[eoprJ3A8W5] == KfH2SZYD1n +(605 - 573)) {
                        TughXoEOKA = TughXoEOKA +(856 - 855);
                        break;
                    }
                    KfH2SZYD1n++;
                };
            }
            if (QFxGTN4gMlEL[eoprJ3A8W5 + (552 - 551)] != KfH2SZYD1n &&QFxGTN4gMlEL[eoprJ3A8W5 + (150 - 149)] != KfH2SZYD1n +32) {
                printf ("(%c,%d)", KfH2SZYD1n, TughXoEOKA);
                TughXoEOKA = 0;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            eoprJ3A8W5 = eoprJ3A8W5 + 1;
        };
    }
    return (0);
}

