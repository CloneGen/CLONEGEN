int main () {
    int n;
    int xgEKvWjieQmY;
    char WrGOByR [(1705 - 704)];
    scanf ("%s", WrGOByR);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if (((1067 - 971) < WrGOByR[(757 - 757)]) && (WrGOByR[(758 - 758)] < (845 - 722)))
        WrGOByR[0] = WrGOByR[0] - 32;
    n = (999 - 998);
    if ((634 - 633) == strlen (WrGOByR)) {
        printf ("(%c,%d)", WrGOByR[0], n);
    }
    {
        xgEKvWjieQmY = 93 - 92;
        while (strlen (WrGOByR) > xgEKvWjieQmY) {
            if ((WrGOByR[xgEKvWjieQmY] > (170 - 74)) && (WrGOByR[xgEKvWjieQmY] < (925 - 802)))
                WrGOByR[xgEKvWjieQmY] = WrGOByR[xgEKvWjieQmY] - 32;
            if (WrGOByR[xgEKvWjieQmY - (375 - 374)] == WrGOByR[xgEKvWjieQmY]) {
                n = n + (554 - 553);
            }
            else {
                printf ("(%c,%d)", WrGOByR[xgEKvWjieQmY - 1], n);
                n = 1;
            }
            if (xgEKvWjieQmY == (strlen (WrGOByR) - 1))
                printf ("(%c,%d)", WrGOByR[xgEKvWjieQmY], n);
            xgEKvWjieQmY++;
        };
    }
    return 0;
}

