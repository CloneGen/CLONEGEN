int main () {
    int kAPEYS = 1;
    char m [1010];
    char t;
    cin >> m;
    t = m[(992 - 992)];
    for (int i = 1;
    i < strlen (m); i = i + 1) {
        if (m[i] == t || m[i] - 32 == t || m[i] + 32 == t) {
            kAPEYS = kAPEYS + 1;
        }
        else {
            if (t >= 'A' && t <= 'Z')
                cout << "(" << (char) t << "," << kAPEYS << ")";
            else
                cout << "(" << (char) (t - 32) << "," << kAPEYS << ")";
            t = m[i];
            kAPEYS = 1;
        };
    }
    if (t >= 'A' && t <= 'Z')
        cout << "(" << (char) t << "," << kAPEYS << ")" << endl;
    else
        cout << "(" << (char) (t - 32) << "," << kAPEYS << ")" << endl;
    return 0;
}

