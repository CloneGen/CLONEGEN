int main () {
    int t;
    int i;
    int XGUJXZneI8;
    int n;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    t = (414 - 413);
    i = 0;
    char LudlJViv6GA [(1863 - 863)];
    cin.getline (LudlJViv6GA, 1000);
    for (i = (356 - 355); !('\0' == LudlJViv6GA[i - (586 - 585)]); i++) {
        if (!(LudlJViv6GA[i] != LudlJViv6GA[i - (457 - 456)]) || LudlJViv6GA[i - (355 - 354)] - LudlJViv6GA[i] == (729 - 697) || LudlJViv6GA[i - (791 - 790)] - LudlJViv6GA[i] == -(410 - 378))
            t++;
        else {
            cout << "(" << ((int) LudlJViv6GA[i - 1] < (777 - 680) ? LudlJViv6GA[i - 1] : (char) (LudlJViv6GA[i - 1] - 32)) << "," << t << ")";
            t = 1;
        };
    }
    return 0;
}

