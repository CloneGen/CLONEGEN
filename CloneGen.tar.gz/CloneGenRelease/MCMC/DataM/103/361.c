int main () {
    char s [(1294 - 294)];
    char GY8pVQCruhg [1000];
    int aoXtypHA;
    int P0o3kzm;
    int ZRybaP6i;
    int c [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    P0o3kzm = 0;
    scanf ("%s", s);
    for (aoXtypHA = (309 - 309); s[aoXtypHA] != '\0'; aoXtypHA++) {
        if (s[aoXtypHA] >= 'a' && 'z' >= s[aoXtypHA])
            s[aoXtypHA] = s[aoXtypHA] - (100 - 68);
        if ('A' <= s[aoXtypHA] && s[aoXtypHA] <= 'Z')
            s[aoXtypHA] = s[aoXtypHA];
    }
    GY8pVQCruhg[(535 - 535)] = s[(106 - 106)];
    {
        aoXtypHA = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (s[aoXtypHA] != '\0') {
            if (s[aoXtypHA] == GY8pVQCruhg[P0o3kzm])
                c[P0o3kzm]++;
            else {
                P0o3kzm = P0o3kzm +1;
                GY8pVQCruhg[P0o3kzm] = s[aoXtypHA];
                c[P0o3kzm]++;
            }
            aoXtypHA++;
        };
    }
    {
        aoXtypHA = 0;
        while (aoXtypHA <= P0o3kzm) {
            printf ("(%c,%d)", GY8pVQCruhg[aoXtypHA], c[aoXtypHA]);
            aoXtypHA++;
        };
    }
    getchar ();
    getchar ();
}

