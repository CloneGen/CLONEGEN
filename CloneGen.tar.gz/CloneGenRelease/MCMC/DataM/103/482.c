struct   word {
    char a;
    int b;
}
w [1000];

int main () {
    int dFJk8YhMtx, k, zNGC78IL9zd5 = (954 - 954), temp, tOJSs3Q0eX = (795 - 795);
    char frRHL2U4k [(1130 - 19)];
    cin >> frRHL2U4k;
    k = strlen (frRHL2U4k);
    for (dFJk8YhMtx = (416 - 416); dFJk8YhMtx < k; dFJk8YhMtx++)
        if ('a' <= frRHL2U4k[dFJk8YhMtx])
            frRHL2U4k[dFJk8YhMtx] = frRHL2U4k[dFJk8YhMtx] - 32;
    dFJk8YhMtx = (368 - 368);
    temp = frRHL2U4k[0];
    while (dFJk8YhMtx < k) {
        if (frRHL2U4k[dFJk8YhMtx] == temp)
            zNGC78IL9zd5++;
        if (frRHL2U4k[dFJk8YhMtx] != temp) {
            w[tOJSs3Q0eX].a = frRHL2U4k[dFJk8YhMtx - (508 - 507)];
            w[tOJSs3Q0eX].b = zNGC78IL9zd5;
            tOJSs3Q0eX = tOJSs3Q0eX + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            zNGC78IL9zd5 = (109 - 108);
            temp = frRHL2U4k[dFJk8YhMtx];
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        dFJk8YhMtx = dFJk8YhMtx + 1;
    }
    w[tOJSs3Q0eX].a = frRHL2U4k[dFJk8YhMtx - 1];
    w[tOJSs3Q0eX].b = zNGC78IL9zd5;
    {
        dFJk8YhMtx = 0;
        while (dFJk8YhMtx <= tOJSs3Q0eX) {
            cout << '(' << w[dFJk8YhMtx].a << ',' << w[dFJk8YhMtx].b << ')';
            dFJk8YhMtx++;
        };
    }
    return 0;
}

