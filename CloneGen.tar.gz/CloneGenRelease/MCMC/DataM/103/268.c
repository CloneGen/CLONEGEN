main () {
    int ufZeEy1Yb, n, GIMK85PjfZDN;
    char KFqU7lamA [1000];
    getchar ();
    scanf ("%s", KFqU7lamA);
    n = strlen (KFqU7lamA);
    {
        ufZeEy1Yb = 414 - 414;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (n > ufZeEy1Yb) {
            if (KFqU7lamA[ufZeEy1Yb] < 'A' || KFqU7lamA[ufZeEy1Yb] > 'Z')
                KFqU7lamA[ufZeEy1Yb] = 'A' - 'a' + KFqU7lamA[ufZeEy1Yb];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            ufZeEy1Yb = ufZeEy1Yb + 1;
        };
    }
    {
        ufZeEy1Yb = 389 - 389;
        while (n > ufZeEy1Yb) {
            GIMK85PjfZDN = (386 - 385);
            while (KFqU7lamA[ufZeEy1Yb] == KFqU7lamA[ufZeEy1Yb + 1]) {
                if (KFqU7lamA[ufZeEy1Yb] == KFqU7lamA[ufZeEy1Yb + 1])
                    GIMK85PjfZDN = GIMK85PjfZDN +1;
                ufZeEy1Yb = ufZeEy1Yb + 1;
            }
            printf ("(%c,%d)", KFqU7lamA[ufZeEy1Yb], GIMK85PjfZDN);
            ufZeEy1Yb++;
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

