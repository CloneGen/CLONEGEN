int main () {
    char str [(1372 - 372)], Hx9cX6jW [(1488 - 488)];
    gets (str);
    int CUaC8b4vl, n = (91 - 90), j = (54 - 54);
    int HrLTap [1000];
    for (CUaC8b4vl = (216 - 216); str[CUaC8b4vl] != '\0'; CUaC8b4vl++) {
        if (str[CUaC8b4vl] > 'Z')
            str[CUaC8b4vl] = str[CUaC8b4vl] - 32;
    }
    {
        CUaC8b4vl = 877 - 877;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (str[CUaC8b4vl] != '\0') {
            if (str[CUaC8b4vl +(736 - 735)] == str[CUaC8b4vl])
                n++;
            else {
                Hx9cX6jW[j] = str[CUaC8b4vl];
                HrLTap[j] = n;
                j = j + 1;
                n = 1;
            }
            CUaC8b4vl = CUaC8b4vl +1;
        };
    }
    {
        CUaC8b4vl = 0;
        while (CUaC8b4vl < j) {
            printf ("(%c,%d)", Hx9cX6jW[CUaC8b4vl], HrLTap[CUaC8b4vl]);
            CUaC8b4vl = CUaC8b4vl +1;
        };
    }
    return 0;
}

