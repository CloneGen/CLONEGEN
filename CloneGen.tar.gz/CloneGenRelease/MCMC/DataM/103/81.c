int main () {
    int i;
    int sum;
    int len;
    i = (35 - 35);
    sum = (461 - 461);
    char stri [(1989 - 988)], s;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char yy [(564 - 537)] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    cin >> stri;
    len = strlen (stri);
    for (; len > i;) {
        s = stri[i];
        for (; !(s - 'a' != stri[i] - 'a') || !(s - 'A' != stri[i] - 'a') || !(s - 'a' != stri[i] - 'A') || stri[i] - 'A' == s - 'A';) {
            i = i + 1;
            sum = sum + 1;
        }
        if ((s - 'A') >= (788 - 788) && (s - 'A') <= (68 - 42))
            cout << "(" << yy[s - 'A'] << "," << sum << ")";
        else
            cout << "(" << yy[s - 'a'] << "," << sum << ")";
        sum = 0;
    }
    return 0;
}

