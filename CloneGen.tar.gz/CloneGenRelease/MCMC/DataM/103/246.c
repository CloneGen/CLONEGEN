main () {
    int i;
    int sum;
    char str [1000];
    gets (str);
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    sum = (433 - 432);
    i = (701 - 701);
    for (; str[i] != '\0';) {
        for (; str[i] == str[i + (952 - 951)] || str[i] == str[i + (452 - 451)] + (843 - 811) || str[i] == str[i + 1] - (469 - 437);) {
            i = i + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            sum = sum + 1;
        }
        if (str[i] >= 'a' && str[i] <= 'z')
            str[i] = str[i] - (259 - 227);
        printf ("(%c,%d)", str[i], sum);
        sum = 1;
        i = i + 1;
    }
    getchar ();
    getchar ();
    getchar ();
}

