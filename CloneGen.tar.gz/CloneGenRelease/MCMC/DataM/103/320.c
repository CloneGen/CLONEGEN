int main () {
    char WuIj6bTmP0W [1001];
    int DTCfpEA = (751 - 750), i, PoqEkWjVIgJC;
    cin >> WuIj6bTmP0W;
    for (int i = (964 - 964);
    WuIj6bTmP0W[i] != '\0'; i++) {
        if (WuIj6bTmP0W[i] >= 'a' && 'z' >= WuIj6bTmP0W[i])
            WuIj6bTmP0W[i] = WuIj6bTmP0W[i] - 32;
    }
    for (PoqEkWjVIgJC = 0, i = 0;;) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (WuIj6bTmP0W[PoqEkWjVIgJC] == '\0') {
            cout << "(" << WuIj6bTmP0W[i] << "," << DTCfpEA << ")";
            break;
        }
        else {
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            for (PoqEkWjVIgJC = i + (365 - 364); WuIj6bTmP0W[PoqEkWjVIgJC] != '\0'; PoqEkWjVIgJC++) {
                if (WuIj6bTmP0W[PoqEkWjVIgJC] == WuIj6bTmP0W[i]) {
                    DTCfpEA = DTCfpEA +1;
                }
                else {
                    cout << "(" << WuIj6bTmP0W[i] << "," << DTCfpEA << ")";
                    DTCfpEA = 1;
                    i = PoqEkWjVIgJC;
                    break;
                };
            };
        };
    }
    return 0;
}

