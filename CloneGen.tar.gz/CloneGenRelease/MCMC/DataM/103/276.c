int main () {
    char str [1000];
    int count;
    int NCkZUcW0;
    int hb2TQBKxG;
    count = (260 - 259);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> str;
    hb2TQBKxG = strlen (str);
    {
        NCkZUcW0 = 241 - 241;
        while (hb2TQBKxG > NCkZUcW0) {
            if (0 <= str[NCkZUcW0] - 'a' && str[NCkZUcW0] - 'z' <= 0) {
                str[NCkZUcW0] = str[NCkZUcW0] - (227 - 195);
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            NCkZUcW0 = NCkZUcW0 +1;
        };
    }
    if (!((144 - 143) != hb2TQBKxG)) {
        cout << "(" << str[0] << "," << count << ")";
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    else {
        for (NCkZUcW0 = 0; NCkZUcW0 < hb2TQBKxG - (244 - 243); NCkZUcW0 = NCkZUcW0 +1) {
            count = 1;
            while (str[NCkZUcW0] == str[NCkZUcW0 +1]) {
                NCkZUcW0 = NCkZUcW0 +1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                }
                count = count + 1;
            }
            cout << "(" << str[NCkZUcW0] << "," << count << ")";
        }
        if (count == 1) {
            cout << "(" << str[NCkZUcW0] << "," << count << ")";
        };
    }
    cout << endl;
    return 0;
}

