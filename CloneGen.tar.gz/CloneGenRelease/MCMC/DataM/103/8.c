int main () {
    char Nyu64V [(1294 - 293)];
    int i, hDk5vZTsz;
    char Tsb4mE;
    cin.getline (Nyu64V, 1001);
    for (i = (377 - 377); Nyu64V[i]; i++) {
        if ('z' >= Nyu64V[i] && Nyu64V[i] >= 'a')
            Nyu64V[i] = Nyu64V[i] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (i = (95 - 95); Nyu64V[i];) {
        hDk5vZTsz = (83 - 83);
        Tsb4mE = Nyu64V[i];
        for (; Nyu64V[i] == Tsb4mE;) {
            hDk5vZTsz++;
            i = i + 1;
        }
        cout << "(" << Tsb4mE << "," << hDk5vZTsz << ")";
    }
    return 0;
}

