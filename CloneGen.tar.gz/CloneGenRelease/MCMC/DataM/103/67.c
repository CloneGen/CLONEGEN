int main () {
    int In9yW1YXuK, cnt = (688 - 688);
    char Py6YU4Eh9r;
    char B6UXbOLJ9CqI [(2284 - 284)];
    cin.getline (B6UXbOLJ9CqI, 2000);
    for (In9yW1YXuK = (660 - 660); !('\0' == B6UXbOLJ9CqI[In9yW1YXuK]); In9yW1YXuK = In9yW1YXuK +1) {
        if (B6UXbOLJ9CqI[In9yW1YXuK +(163 - 162)] - B6UXbOLJ9CqI[In9yW1YXuK] == 0 || !('a' - 'A' != B6UXbOLJ9CqI[In9yW1YXuK +(836 - 835)] - B6UXbOLJ9CqI[In9yW1YXuK]) || B6UXbOLJ9CqI[In9yW1YXuK +1] - B6UXbOLJ9CqI[In9yW1YXuK] == 'A' - 'a')
            cnt++;
        else {
            if (B6UXbOLJ9CqI[In9yW1YXuK] >= 'a' && B6UXbOLJ9CqI[In9yW1YXuK] <= 'z') {
                Py6YU4Eh9r = B6UXbOLJ9CqI[In9yW1YXuK] - (985 - 953);
                cout << "(" << Py6YU4Eh9r << "," << cnt + 1 << ")";
            }
            else {
                Py6YU4Eh9r = B6UXbOLJ9CqI[In9yW1YXuK];
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                cout << "(" << Py6YU4Eh9r << "," << cnt + 1 << ")";
            }
            cnt = 0;
        };
    }
    return 0;
}

