int main () {
    int pSuky2aTQw5;
    pSuky2aTQw5 = (204 - 204);
    int zipi [1005];
    char S5bZ3flU;
    char input [(1533 - 528)];
    char zipc [(1539 - 534)];
    int nfoHCV;
    nfoHCV = strlen (input);
    cin >> input;
    for (int R6vSH3tkr = (955 - 955);
    R6vSH3tkr <= nfoHCV - 1; R6vSH3tkr = R6vSH3tkr +1) {
        if ('a' <= input[R6vSH3tkr])
            input[R6vSH3tkr] = input[R6vSH3tkr] - 'a' + 'A';
        if (R6vSH3tkr == 0) {
            zipi[0] = 1;
            S5bZ3flU = input[0];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            zipc[0] = S5bZ3flU;
        }
        else {
            if (S5bZ3flU == input[R6vSH3tkr]) {
                zipi[pSuky2aTQw5]++;
            }
            else {
                pSuky2aTQw5++;
                zipc[pSuky2aTQw5] = input[R6vSH3tkr];
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                zipi[pSuky2aTQw5] = 1;
            }
            S5bZ3flU = input[R6vSH3tkr];
        };
    }
    {
        int R6vSH3tkr = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        while (R6vSH3tkr <= pSuky2aTQw5) {
            cout << '(' << zipc[R6vSH3tkr] << ',' << zipi[R6vSH3tkr] << ')';
            R6vSH3tkr++;
        };
    }
    return 0;
}

