int main () {
    char MdNFI0 [(1374 - 374)], dNBR3i2Esd [(1329 - 329)] = {(493 - 492)}, MLiTpMUNBcx3 [1000] = {(38 - 38)};
    int AIxlXs = (624 - 624);
    scanf ("%s", MdNFI0);
    for (int KcwUeJ5 = (659 - 659);
    MdNFI0[KcwUeJ5] != '0'; KcwUeJ5++) {
        if (('a' <= MdNFI0[KcwUeJ5]) && ('z' >= MdNFI0[KcwUeJ5]))
            MdNFI0[KcwUeJ5] = MdNFI0[KcwUeJ5] - 'a' + 'A';
        else
            MdNFI0[KcwUeJ5] = MdNFI0[KcwUeJ5];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    MLiTpMUNBcx3[(840 - 840)] = MdNFI0[(410 - 410)];
    for (int i = 0;
    MdNFI0[i] != '\0'; i = i + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (MdNFI0[i] == MdNFI0[i + (188 - 187)]) {
            dNBR3i2Esd[AIxlXs] = dNBR3i2Esd[AIxlXs] + 1;
        }
        else {
            MLiTpMUNBcx3[AIxlXs] = MdNFI0[i];
            AIxlXs = AIxlXs +1;
            dNBR3i2Esd[AIxlXs] = 1;
        };
    }
    {
        int k = 0;
        while (MLiTpMUNBcx3[k] != '\0') {
            printf ("(%c,%d)", MLiTpMUNBcx3[k], dNBR3i2Esd[k]);
            k = k + 1;
        };
    };
}

