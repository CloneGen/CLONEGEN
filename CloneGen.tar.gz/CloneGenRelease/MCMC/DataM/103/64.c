int main () {
    int count;
    int i;
    count = (972 - 971);
    char a [1001];
    char xQbphjndUZ;
    cin >> a;
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < strlen (a)) {
            xQbphjndUZ = a[i];
            if (a[i + (205 - 204)] == xQbphjndUZ || !('A' - 'a' != a[i + (136 - 135)] - xQbphjndUZ) || a[i + 1] - xQbphjndUZ == 'a' - 'A')
                count = count + 1;
            else {
                if (xQbphjndUZ > 'Z')
                    cout << "(" << (char) (xQbphjndUZ - 'a' + 'A');
                else
                    cout << "(" << (char) xQbphjndUZ;
                cout << "," << count << ")";
                count = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    return 0;
}

