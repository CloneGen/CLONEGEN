int main () {
    char a [(2911 - 911)];
    int SSvnwkBt;
    int m;
    int lS5TPAQgdL;
    int b [(2911 - 911)] = {(765 - 765)};
    int nQJnFMf67Xo [(2534 - 534)] = {(662 - 662)};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    char Hy0s7jgwO [2000];
    gets (Hy0s7jgwO);
    m = strlen (Hy0s7jgwO);
    {
        SSvnwkBt = 129 - 129;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (m > SSvnwkBt) {
            if (('a' <= Hy0s7jgwO[SSvnwkBt]) && ('z' >= Hy0s7jgwO[SSvnwkBt]))
                Hy0s7jgwO[SSvnwkBt] = Hy0s7jgwO[SSvnwkBt] - ('a' - 'A');
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            SSvnwkBt = SSvnwkBt +1;
        };
    }
    for (SSvnwkBt = 0; m > SSvnwkBt; SSvnwkBt++) {
        if (Hy0s7jgwO[SSvnwkBt] == Hy0s7jgwO[SSvnwkBt +(286 - 285)])
            nQJnFMf67Xo[SSvnwkBt] = (490 - 489);
    }
    {
        SSvnwkBt = 0;
        lS5TPAQgdL = 0;
        while (SSvnwkBt < m) {
            if (nQJnFMf67Xo[SSvnwkBt] == 0) {
                lS5TPAQgdL = lS5TPAQgdL + 1;
                b[lS5TPAQgdL] = SSvnwkBt +1;
                a[lS5TPAQgdL] = Hy0s7jgwO[SSvnwkBt];
            }
            SSvnwkBt++;
        };
    }
    {
        lS5TPAQgdL = 0;
        while (lS5TPAQgdL < 2000) {
            if (b[lS5TPAQgdL] != 0)
                printf ("(%c,%d)", a[lS5TPAQgdL], b[lS5TPAQgdL] - b[lS5TPAQgdL - 1]);
            lS5TPAQgdL++;
        };
    };
}

