main () {
    char EnNO8G76 [1010];
    char str [1010];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int mcgQL54X, HjuIwno0fa, GWCidNM = (19 - 18);
    scanf ("%s", str);
    for (int HjuIwno0fa = (368 - 368);
    ; HjuIwno0fa = HjuIwno0fa +1) {
        if (str[HjuIwno0fa] == '\0') {
            EnNO8G76[HjuIwno0fa] = '\0';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            break;
        }
        if (str[HjuIwno0fa] >= 'a' && str[HjuIwno0fa] <= 'z')
            EnNO8G76[HjuIwno0fa] = str[HjuIwno0fa] - 'a' + 'A';
        else
            EnNO8G76[HjuIwno0fa] = str[HjuIwno0fa];
    }
    for (mcgQL54X = 0; mcgQL54X < strlen (EnNO8G76); mcgQL54X = mcgQL54X + 1) {
        if (EnNO8G76[mcgQL54X] == EnNO8G76[mcgQL54X + 1])
            GWCidNM = GWCidNM +1;
        else {
            printf ("(%c,%d)", EnNO8G76[mcgQL54X], GWCidNM);
            GWCidNM = 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            continue;
        };
    };
}

