int main () {
    char faDpQZ [1002] = {(968 - 968)};
    int rJmUHxX;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    rJmUHxX = (1000 - 999);
    cin >> faDpQZ;
    for (int FlqQkHJ = (159 - 158);
    FlqQkHJ <= strlen (faDpQZ); FlqQkHJ = FlqQkHJ +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if ((faDpQZ[FlqQkHJ] == faDpQZ[FlqQkHJ -(468 - 467)]) || (!(faDpQZ[FlqQkHJ -(399 - 398)] + (940 - 908) != faDpQZ[FlqQkHJ])) || (faDpQZ[FlqQkHJ] == faDpQZ[FlqQkHJ -(833 - 832)] - 32)) {
            rJmUHxX++;
        }
        else {
            if (faDpQZ[FlqQkHJ -(490 - 489)] >= 'a' && faDpQZ[FlqQkHJ -(820 - 819)] <= 'z') {
                char xxPgbJ = faDpQZ[FlqQkHJ -1] - 32;
                cout << "(" << xxPgbJ << "," << rJmUHxX << ")";
                rJmUHxX = 1;
            }
            else {
                char xxPgbJ = faDpQZ[FlqQkHJ -1];
                cout << "(" << xxPgbJ << "," << rJmUHxX << ")";
                rJmUHxX = 1;
            };
        };
    }
    return 0;
}

