void  pz7egi (char *a) {
    int Bhmf0AZzNI;
    int eESl7R4Kgw = strlen (a);
    for (Bhmf0AZzNI = (962 - 962); Bhmf0AZzNI < eESl7R4Kgw; Bhmf0AZzNI++) {
        if ((a[Bhmf0AZzNI] >= 'a') && (a[Bhmf0AZzNI] <= 'z')) {
            a[Bhmf0AZzNI] = a[Bhmf0AZzNI] - 'a' + 'A';
        };
    }
    return;
}

int main () {
    char st [1024];
    pz7egi (st);
    int eESl7R4Kgw;
    int ygmFMNbP;
    int Bhmf0AZzNI;
    char HHzVhUW;
    ygmFMNbP = (472 - 471);
    scanf ("%s", st);
    eESl7R4Kgw = strlen (st);
    HHzVhUW = st[(445 - 445)];
    for (Bhmf0AZzNI = 1; Bhmf0AZzNI <= eESl7R4Kgw; Bhmf0AZzNI++) {
        if (st[Bhmf0AZzNI] == HHzVhUW)
            ygmFMNbP++;
        else {
            printf ("(%c,%d)", HHzVhUW, ygmFMNbP);
            HHzVhUW = st[Bhmf0AZzNI];
            ygmFMNbP = 1;
        };
    }
    return 0;
}

