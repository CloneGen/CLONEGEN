int main (int zrLlBn, char *GGMl8YP4RENQ []) {
    int QS2r8pY [(1730 - 730)] = {0}, GyVG3Og8sqaK, fvewQI = 0;
    char s1 [(1255 - 255)] = {(961 - 961)}, QAie2rdMZnG [(1555 - 555)] = {0};
    cin.getline (s1, (1131 - 131));
    {
        GyVG3Og8sqaK = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (1000 > GyVG3Og8sqaK) {
            if (!('\0' != s1[GyVG3Og8sqaK]))
                break;
            if (s1[GyVG3Og8sqaK] >= 'a' && s1[GyVG3Og8sqaK] <= 'z')
                s1[GyVG3Og8sqaK] = s1[GyVG3Og8sqaK] - (807 - 775);
            if (s1[GyVG3Og8sqaK] != QAie2rdMZnG[fvewQI]) {
                fvewQI++;
                QAie2rdMZnG[fvewQI] = s1[GyVG3Og8sqaK];
                QS2r8pY[fvewQI]++;
            }
            else
                QS2r8pY[fvewQI]++;
            GyVG3Og8sqaK = GyVG3Og8sqaK +1;
        };
    }
    {
        GyVG3Og8sqaK = 168 - 167;
        while (GyVG3Og8sqaK <= fvewQI) {
            cout << "(" << QAie2rdMZnG[GyVG3Og8sqaK] << "," << QS2r8pY[GyVG3Og8sqaK] << ")";
            GyVG3Og8sqaK++;
        };
    }
    return EXIT_SUCCESS;
}

