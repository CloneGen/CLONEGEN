int main () {
    int len;
    char now;
    char NL97yWE [10000];
    int EbL43SYrQ = 1;
    int time = (898 - 898);
    cin >> NL97yWE;
    len = strlen (NL97yWE);
    for (int j = (701 - 701);
    len > j; j = j + 1) {
        if ('z' + 1 > NL97yWE[j] && NL97yWE[j] > 'a' - 1)
            NL97yWE[j] = NL97yWE[j] + 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    now = NL97yWE[0];
    cout << '(' << now << ',';
    {
        int i = 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (len > i) {
            if (NL97yWE[i] == NL97yWE[i - 1])
                EbL43SYrQ = EbL43SYrQ +1;
            else {
                cout << EbL43SYrQ << ')';
                EbL43SYrQ = 1;
                now = NL97yWE[i];
                cout << '(' << now << ',';
            }
            i = i + 1;
        };
    }
    cout << EbL43SYrQ << ')' << endl;
    return 0;
}

