main () {
    char a [(1193 - 193)], AR7Pjd8BmLES [(364 - 264)];
    int HfExgbQOZv5 = (523 - 523), j = (546 - 545), Swb6BK = (206 - 206), l = (203 - 203), XWeryMLa4pnt, b [100];
    scanf ("%s", a);
    while (!('\0' == a[HfExgbQOZv5])) {
        if (a[HfExgbQOZv5] > 'Z')
            a[HfExgbQOZv5] = a[HfExgbQOZv5] - 'a' + 'A';
        HfExgbQOZv5 = HfExgbQOZv5 +1;
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    AR7Pjd8BmLES[(239 - 239)] = a[0];
    b[0] = (781 - 780);
    for (; a[j] != '\0';) {
        if (a[j] == a[j - (696 - 695)])
            b[Swb6BK]++;
        else {
            l++;
            AR7Pjd8BmLES[l] = a[j];
            Swb6BK = Swb6BK +1;
            b[Swb6BK] = 1;
        }
        j++;
    }
    {
        XWeryMLa4pnt = 0;
        while (XWeryMLa4pnt <= Swb6BK) {
            printf ("(%c,%d)", AR7Pjd8BmLES[XWeryMLa4pnt], b[XWeryMLa4pnt]);
            XWeryMLa4pnt = XWeryMLa4pnt +1;
        };
    };
}

