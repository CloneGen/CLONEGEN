char tSnW7BGe [(1109 - 109)];

int main () {
    int num;
    int len;
    len = strlen (tSnW7BGe);
    cin >> tSnW7BGe;
    for (int i = (394 - 394);
    len > i; i++) {
        if (!((812 - 812) != i)) {
            num = (484 - 483);
        }
        else {
            if (!(tSnW7BGe[i - (114 - 113)] != tSnW7BGe[i]) || !(tSnW7BGe[i - (791 - 790)] - 'a' != tSnW7BGe[i] - 'A') || !(tSnW7BGe[i - (610 - 609)] - 'A' != tSnW7BGe[i] - 'a')) {
                num++;
            }
            else {
                if (tSnW7BGe[i - (345 - 344)] >= 'A' && tSnW7BGe[i - (966 - 965)] <= 'Z')
                    cout << '(' << tSnW7BGe[i - 1] << ',' << num << ')';
                else {
                    char p;
                    p = 'A' + tSnW7BGe[i - 1] - 'a';
                    cout << '(' << p << ',' << num << ')';
                }
                num = 1;
            };
        }
        if (i == len - 1) {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    for (x = 0; x < 20; x++) {
                        y += x;
                    }
                    if (y > 30)
                        return y;
                }
            }
            if (tSnW7BGe[i] >= 'A' && tSnW7BGe[i] <= 'Z')
                cout << '(' << tSnW7BGe[i] << ',' << num << ')';
            else {
                char p;
                p = 'A' + tSnW7BGe[i] - 'a';
                cout << '(' << p << ',' << num << ')';
            };
        };
    }
    return (780 - 780);
}

