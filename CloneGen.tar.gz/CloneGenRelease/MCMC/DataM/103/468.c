char f (char ZzVI6Cw [(1022 - 22)]) {
    int rafJqeUW6h3;
    for (rafJqeUW6h3 = (601 - 601); rafJqeUW6h3 < (1702 - 702); rafJqeUW6h3++)
        if ('a' <= ZzVI6Cw[rafJqeUW6h3] && ZzVI6Cw[rafJqeUW6h3] <= 'z')
            ZzVI6Cw[rafJqeUW6h3] = ZzVI6Cw[rafJqeUW6h3] + 'A' - 'a';
}

main () {
    char AoZpbTc [1000];
    int rafJqeUW6h3, joSFTHu3prM = (80 - 79);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    gets (AoZpbTc);
    f (AoZpbTc);
    for (rafJqeUW6h3 = 0; AoZpbTc[rafJqeUW6h3] != '\0'; rafJqeUW6h3++) {
        if (AoZpbTc[rafJqeUW6h3] == AoZpbTc[rafJqeUW6h3 + (640 - 639)])
            joSFTHu3prM = joSFTHu3prM + 1;
        else {
            printf ("(%c,%d)", AoZpbTc[rafJqeUW6h3], joSFTHu3prM);
            joSFTHu3prM = (266 - 265);
        };
    };
}

