int main () {
    int a [1500];
    char N9rcoj [(1938 - 438)];
    char string2 [(643 - 641)];
    gets (N9rcoj);
    int xZ8bGoH7ABK;
    int j;
    int m;
    int FfX0bKACvre;
    int length;
    int flag;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    xZ8bGoH7ABK = (401 - 401);
    j = (471 - 471);
    m = (742 - 742);
    FfX0bKACvre = (85 - 85);
    length = (979 - 979);
    flag = 0;
    length = strlen (N9rcoj);
    {
        xZ8bGoH7ABK = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (xZ8bGoH7ABK < length) {
            a[xZ8bGoH7ABK] = (911 - 910);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            xZ8bGoH7ABK = xZ8bGoH7ABK + 1;
        };
    }
    for (xZ8bGoH7ABK = 0; xZ8bGoH7ABK < length; xZ8bGoH7ABK++) {
        if (97 <= N9rcoj[xZ8bGoH7ABK] && 122 >= N9rcoj[xZ8bGoH7ABK])
            N9rcoj[xZ8bGoH7ABK] = N9rcoj[xZ8bGoH7ABK] - (678 - 646);
    }
    {
        xZ8bGoH7ABK = 127 - 126;
        while (xZ8bGoH7ABK < length) {
            if (N9rcoj[xZ8bGoH7ABK] == N9rcoj[xZ8bGoH7ABK - (549 - 548)]) {
                a[xZ8bGoH7ABK] = a[xZ8bGoH7ABK - (338 - 337)] + 1;
            }
            else if (N9rcoj[xZ8bGoH7ABK] != N9rcoj[xZ8bGoH7ABK - 1]) {
                cout << "(" << N9rcoj[xZ8bGoH7ABK - 1] << "," << a[xZ8bGoH7ABK - 1] << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            xZ8bGoH7ABK++;
        };
    }
    cout << "(" << N9rcoj[length - 1] << "," << a[length - 1] << ")" << endl;
    return 0;
}

