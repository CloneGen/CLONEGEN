void  main () {
    int f69KtmhJ7b, DQOUVM1l, l, G3O4k89w6zs = (950 - 950), liQeTjmEYwot [1000] = {(21 - 21)};
    char GNTbLQAhOi [(1634 - 634)];
    char TeHZyz0OAPg [(1350 - 350)];
    liQeTjmEYwot[0] = (809 - 808);
    scanf ("%s", GNTbLQAhOi);
    l = strlen (GNTbLQAhOi);
    TeHZyz0OAPg[(874 - 874)] = GNTbLQAhOi[(300 - 300)];
    for (f69KtmhJ7b = (13 - 12); l > f69KtmhJ7b; f69KtmhJ7b = f69KtmhJ7b + 1) {
        if (!(GNTbLQAhOi[f69KtmhJ7b - (670 - 669)] != GNTbLQAhOi[f69KtmhJ7b]) || !(GNTbLQAhOi[f69KtmhJ7b - 1] + (513 - 481) != GNTbLQAhOi[f69KtmhJ7b]) || GNTbLQAhOi[f69KtmhJ7b] == GNTbLQAhOi[f69KtmhJ7b - 1] - (475 - 443)) {
            liQeTjmEYwot[G3O4k89w6zs]++;
        }
        else {
            G3O4k89w6zs = G3O4k89w6zs +1;
            TeHZyz0OAPg[G3O4k89w6zs] = GNTbLQAhOi[f69KtmhJ7b];
            liQeTjmEYwot[G3O4k89w6zs]++;
        };
    }
    {
        f69KtmhJ7b = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (f69KtmhJ7b <= G3O4k89w6zs) {
            if (TeHZyz0OAPg[f69KtmhJ7b] <= (174 - 84))
                printf ("(%c,%d)", TeHZyz0OAPg[f69KtmhJ7b], liQeTjmEYwot[f69KtmhJ7b]);
            else
                printf ("(%c,%d)", TeHZyz0OAPg[f69KtmhJ7b] - (542 - 510), liQeTjmEYwot[f69KtmhJ7b]);
            f69KtmhJ7b = f69KtmhJ7b + 1;
        };
    };
}

