int ss (char a [(1429 - 428)], int n) {
    char d;
    int i;
    int b;
    int c;
    i = 0;
    b = a[n];
    c = a[n];
    while (!('\0' == a[n]) && (b == c || !(c != (b - 32)) || b == (c - 32))) {
        n++;
        i = i + 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        c = a[n];
    }
    if (b >= 97) {
        d = b - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        cout << "(" << d << "," << i << ")";
    }
    else {
        d = b;
        cout << "(" << d << "," << i << ")";
    }
    return i;
}

int main () {
    int i;
    int m;
    int b;
    int o;
    i = 0;
    m = 0;
    {
        int x = 0;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    char a [1001];
    cin >> a;
    while (a[m] != '\0') {
        m++;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        };
    }
    for (; i < m;) {
        o = ss (a, i);
        i = i + o;
    }
    return 0;
}

