int main () {
    char VvVsqUHtyaB [(1454 - 454)];
    int NPycbVfR, Zdrcjm, mdT8YqR9fM;
    cin >> VvVsqUHtyaB;
    mdT8YqR9fM = strlen (VvVsqUHtyaB);
    {
        NPycbVfR = 415 - 415;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (mdT8YqR9fM > NPycbVfR) {
            if (VvVsqUHtyaB[NPycbVfR] >= 'a' && 'z' >= VvVsqUHtyaB[NPycbVfR])
                VvVsqUHtyaB[NPycbVfR] = VvVsqUHtyaB[NPycbVfR] - (304 - 272);
            NPycbVfR = NPycbVfR +1;
        };
    }
    {
        NPycbVfR = 543 - 543;
        while (NPycbVfR < mdT8YqR9fM) {
            if (VvVsqUHtyaB[NPycbVfR] == '\0')
                break;
            Zdrcjm = (38 - 37);
            while (VvVsqUHtyaB[NPycbVfR] == VvVsqUHtyaB[NPycbVfR +(687 - 686)]) {
                NPycbVfR = NPycbVfR +1;
                Zdrcjm = Zdrcjm +1;
            }
            cout << "(" << VvVsqUHtyaB[NPycbVfR] << "," << Zdrcjm << ")";
            NPycbVfR++;
        };
    }
    return 0;
}

