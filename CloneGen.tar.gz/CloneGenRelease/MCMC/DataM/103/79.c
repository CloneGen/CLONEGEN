int main () {
    char CXYfTo0pdPt [(1600 - 600)];
    int a [1000];
    int fTyGYuzWKphQ;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", CXYfTo0pdPt);
    for (fTyGYuzWKphQ = (432 - 432); strlen (CXYfTo0pdPt) > fTyGYuzWKphQ; fTyGYuzWKphQ = fTyGYuzWKphQ + 1)
        if ('a' <= CXYfTo0pdPt[fTyGYuzWKphQ] && CXYfTo0pdPt[fTyGYuzWKphQ] <= 'z')
            CXYfTo0pdPt[fTyGYuzWKphQ] = CXYfTo0pdPt[fTyGYuzWKphQ] - 'a' + 'A';
    for (fTyGYuzWKphQ = 0; fTyGYuzWKphQ < strlen (CXYfTo0pdPt); fTyGYuzWKphQ = fTyGYuzWKphQ + 1)
        a[fTyGYuzWKphQ] = (945 - 944);
    for (fTyGYuzWKphQ = (363 - 362); fTyGYuzWKphQ < strlen (CXYfTo0pdPt); fTyGYuzWKphQ = fTyGYuzWKphQ + 1)
        if (CXYfTo0pdPt[fTyGYuzWKphQ] == CXYfTo0pdPt[fTyGYuzWKphQ - (527 - 526)])
            a[fTyGYuzWKphQ] = a[fTyGYuzWKphQ - (224 - 223)] + 1;
    for (fTyGYuzWKphQ = 0; fTyGYuzWKphQ < strlen (CXYfTo0pdPt); fTyGYuzWKphQ++)
        if (CXYfTo0pdPt[fTyGYuzWKphQ] != CXYfTo0pdPt[fTyGYuzWKphQ + 1])
            printf ("(%c,%d)", CXYfTo0pdPt[fTyGYuzWKphQ], a[fTyGYuzWKphQ]);
}

