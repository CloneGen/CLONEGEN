main () {
    char MpMYeTwz [(1499 - 475)];
    int i;
    int j;
    int n;
    int d;
    d = 'A' - 'a';
    scanf ("%s", MpMYeTwz);
    {
        i = 799 - 799;
        while (1024 >= i) {
            n = 0;
            if (MpMYeTwz[i] >= 'a' && MpMYeTwz[i] <= 'z') {
                MpMYeTwz[i] = MpMYeTwz[i] + d;
                {
                    j = i;
                    {
                        int x = 0;
                        if (!(x * (x - 1) % 2 == 0)) {
                            return 0;
                        }
                    }
                    while (j <= 1024) {
                        if (!(MpMYeTwz[i] != MpMYeTwz[j]) || MpMYeTwz[j] == MpMYeTwz[i] - d)
                            n = n + 1;
                        else
                            break;
                        j = j + 1;
                    };
                }
                printf ("(%c,%d)", MpMYeTwz[i], n);
            }
            else if ('A' <= MpMYeTwz[i] && MpMYeTwz[i] <= 'Z') {
                {
                    j = i;
                    while (j <= 1024) {
                        if (MpMYeTwz[j] == MpMYeTwz[i] || MpMYeTwz[j] == MpMYeTwz[i] - d)
                            n = n + 1;
                        else
                            break;
                        j = j + 1;
                    };
                }
                printf ("(%c,%d)", MpMYeTwz[i], n);
            }
            else
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i += n;
        };
    };
}

