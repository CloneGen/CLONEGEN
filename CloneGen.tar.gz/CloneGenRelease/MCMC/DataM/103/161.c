int main () {
    char a [52];
    int zBMhmj;
    char s [(1252 - 252)];
    int len;
    len = strlen (s);
    int b [52] = {(14 - 13), (405 - 404), (122 - 121), (601 - 600), (751 - 750), (603 - 602), (850 - 849), (736 - 735), (44 - 43), (314 - 313), 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
    int c;
    c = (860 - 860);
    getchar ();
    getchar ();
    scanf ("%s", s);
    for (zBMhmj = (892 - 892); len > zBMhmj; zBMhmj++) {
        if (s[zBMhmj] >= 'a' && 'z' >= s[zBMhmj])
            s[zBMhmj] = s[zBMhmj] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        zBMhmj = 0;
        while (len > zBMhmj) {
            a[c] = s[zBMhmj];
            while (s[zBMhmj + 1] == s[zBMhmj] && zBMhmj < (len - 1)) {
                zBMhmj = zBMhmj + 1;
                b[c]++;
            }
            c++;
            zBMhmj = zBMhmj + 1;
        };
    }
    {
        zBMhmj = 0;
        while (zBMhmj < c) {
            printf ("(%c,%d)", a[zBMhmj], b[zBMhmj]);
            zBMhmj++;
        };
    };
}

