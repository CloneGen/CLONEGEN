int main () {
    int TSMiAkzp57lY, xe3cuxszZW;
    char str [(1117 - 116)];
    char ySzobQe;
    xe3cuxszZW = (656 - 655);
    cin >> str;
    for (TSMiAkzp57lY = (929 - 929); !('\0' == str[TSMiAkzp57lY]); TSMiAkzp57lY++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if ('a' <= str[TSMiAkzp57lY] && str[TSMiAkzp57lY] <= 'z') {
            str[TSMiAkzp57lY] = str[TSMiAkzp57lY] + 'A' - 'a';
        };
    }
    ySzobQe = str[0];
    for (TSMiAkzp57lY = 1; str[TSMiAkzp57lY -1] != '\0'; TSMiAkzp57lY++) {
        if (ySzobQe == str[TSMiAkzp57lY])
            xe3cuxszZW = xe3cuxszZW + 1;
        else {
            cout << '(' << ySzobQe << ',' << xe3cuxszZW << ')';
            ySzobQe = str[TSMiAkzp57lY];
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            xe3cuxszZW = 1;
        };
    }
    return 0;
}

