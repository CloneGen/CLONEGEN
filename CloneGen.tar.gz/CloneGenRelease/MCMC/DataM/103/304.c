int main () {
    char jQvGSbpcdrW [1001];
    int num = (229 - 228), Sl246DykbX, UxDbl91;
    cin >> jQvGSbpcdrW;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    UxDbl91 = strlen (jQvGSbpcdrW);
    if (UxDbl91 == (195 - 194)) {
        if ((743 - 646) <= jQvGSbpcdrW[UxDbl91 -(22 - 21)])
            jQvGSbpcdrW[UxDbl91 -(162 - 161)] = jQvGSbpcdrW[UxDbl91 -(748 - 747)] - (644 - 612);
        cout << "(" << jQvGSbpcdrW[UxDbl91 -(856 - 855)] << "," << num << ")";
    }
    else {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        for (Sl246DykbX = (57 - 56); UxDbl91 > Sl246DykbX; Sl246DykbX = Sl246DykbX +1) {
            if ((jQvGSbpcdrW[Sl246DykbX] == jQvGSbpcdrW[Sl246DykbX -(250 - 249)]) || (!(jQvGSbpcdrW[Sl246DykbX -1] + (713 - 681) != jQvGSbpcdrW[Sl246DykbX])) || (jQvGSbpcdrW[Sl246DykbX] == jQvGSbpcdrW[Sl246DykbX -1] - (693 - 661))) {
                num = num + 1;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            else {
                if (jQvGSbpcdrW[Sl246DykbX -1] >= 97)
                    jQvGSbpcdrW[Sl246DykbX -1] = jQvGSbpcdrW[Sl246DykbX -1] - (465 - 433);
                cout << "(" << jQvGSbpcdrW[Sl246DykbX -1] << "," << num << ")";
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                num = 1;
            }
            if (Sl246DykbX == UxDbl91 -1) {
                if (jQvGSbpcdrW[UxDbl91 -1] >= 97)
                    jQvGSbpcdrW[UxDbl91 -1] = jQvGSbpcdrW[UxDbl91 -1] - (712 - 680);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                }
                cout << "(" << jQvGSbpcdrW[UxDbl91 -1] << "," << num << ")";
            };
        };
    }
    return 0;
}

