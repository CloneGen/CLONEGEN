void  change (char yYMRSZ []) {
    int d;
    d = 'A' - 'a';
    int QCZezbG1AJa6;
    QCZezbG1AJa6 = (916 - 916);
    int kFbOAU5pJD = strlen (yYMRSZ);
    for (QCZezbG1AJa6 = (166 - 166); QCZezbG1AJa6 < kFbOAU5pJD; QCZezbG1AJa6++) {
        if (yYMRSZ[QCZezbG1AJa6] <= 'z' && 'a' <= yYMRSZ[QCZezbG1AJa6]) {
            yYMRSZ[QCZezbG1AJa6] = yYMRSZ[QCZezbG1AJa6] + d;
        };
    };
}

int main () {
    char yYMRSZ [100];
    change (yYMRSZ);
    char hQArjKk0Jg = yYMRSZ[(697 - 697)];
    int VcoxINZLSaVH;
    int kFbOAU5pJD;
    VcoxINZLSaVH = 0;
    kFbOAU5pJD = strlen (yYMRSZ);
    cin >> yYMRSZ;
    for (int QCZezbG1AJa6 = 0;
    QCZezbG1AJa6 < kFbOAU5pJD; QCZezbG1AJa6++) {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (yYMRSZ[QCZezbG1AJa6] == hQArjKk0Jg) {
            VcoxINZLSaVH++;
        }
        else {
            cout << "(" << hQArjKk0Jg << "," << VcoxINZLSaVH << ")";
            hQArjKk0Jg = yYMRSZ[QCZezbG1AJa6];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            VcoxINZLSaVH = 1;
        };
    }
    cout << "(" << hQArjKk0Jg << "," << VcoxINZLSaVH << ")";
    return 0;
}

