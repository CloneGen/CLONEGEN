int main () {
    char RO2b073K, DtsUbjZeBx3;
    int J2ELWk3Vm, iiGS2M9XBjY, k, FWrZgDiGt, m;
    char XC2FWXZ [(1155 - 155)];
    {
        J2ELWk3Vm = 762 - 762;
        while (1) {
            scanf ("%c", &XC2FWXZ[J2ELWk3Vm]);
            if (XC2FWXZ[J2ELWk3Vm] == '\n')
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            J2ELWk3Vm = J2ELWk3Vm +1;
        };
    }
    DtsUbjZeBx3 = XC2FWXZ[(744 - 744)];
    m = DtsUbjZeBx3;
    if (m >= 97) {
        m = m - 32;
        DtsUbjZeBx3 = m;
    }
    FWrZgDiGt = 0;
    for (iiGS2M9XBjY = 0; J2ELWk3Vm > iiGS2M9XBjY; iiGS2M9XBjY = iiGS2M9XBjY + 1) {
        RO2b073K = XC2FWXZ[iiGS2M9XBjY];
        k = RO2b073K;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (k >= 97) {
            k = k - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            RO2b073K = k;
        }
        if (RO2b073K == DtsUbjZeBx3) {
            FWrZgDiGt = FWrZgDiGt +(915 - 914);
        }
        if (RO2b073K != DtsUbjZeBx3) {
            printf ("(%c,%d)", DtsUbjZeBx3, FWrZgDiGt);
            DtsUbjZeBx3 = RO2b073K;
            FWrZgDiGt = 1;
        };
    }
    printf ("(%c,%d)", DtsUbjZeBx3, FWrZgDiGt);
    return 0;
}

