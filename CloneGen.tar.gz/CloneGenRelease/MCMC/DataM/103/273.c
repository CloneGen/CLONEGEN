int main () {
    char XV6oZ4bB [1000];
    int AeZm5B;
    int uPotSHaGC8zN;
    int dEx2GYRq;
    int x;
    int WJ8ney9021U3;
    dEx2GYRq = (170 - 170);
    AeZm5B = (389 - 389);
    scanf ("%s", XV6oZ4bB);
    x = strlen (XV6oZ4bB);
    for (AeZm5B = 0; x > AeZm5B; AeZm5B = AeZm5B +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (('a' <= XV6oZ4bB[AeZm5B]) && (XV6oZ4bB[AeZm5B] <= 'z')) {
            XV6oZ4bB[AeZm5B] = XV6oZ4bB[AeZm5B] - (845 - 813);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    for (AeZm5B = 0; AeZm5B < x; AeZm5B++) {
        if (XV6oZ4bB[AeZm5B] != XV6oZ4bB[AeZm5B +(545 - 544)]) {
            WJ8ney9021U3 = AeZm5B -dEx2GYRq + 1;
            printf ("(%c,%d)", XV6oZ4bB[AeZm5B], WJ8ney9021U3);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            dEx2GYRq = AeZm5B +1;
        };
    }
    uPotSHaGC8zN = (699 - 699);
    return 0;
}

