int main () {
    int t;
    int iewVKAxm [1001] = {(526 - 526)};
    int PfTFuGck;
    t = (609 - 609);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char GIpxMdsYe [(1609 - 608)], b [1001];
    cin.getline (GIpxMdsYe, 1001);
    for (PfTFuGck = (713 - 713); !('\0' == GIpxMdsYe[PfTFuGck]); PfTFuGck++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (GIpxMdsYe[PfTFuGck] == GIpxMdsYe[PfTFuGck -1] || GIpxMdsYe[PfTFuGck] - GIpxMdsYe[PfTFuGck -1] == 32 || GIpxMdsYe[PfTFuGck -1] - GIpxMdsYe[PfTFuGck] == 32) {
            iewVKAxm[t]++;
        }
        else {
            t = t + 1;
            b[t] = GIpxMdsYe[PfTFuGck];
            iewVKAxm[t]++;
        };
    }
    {
        PfTFuGck = 912 - 912;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (PfTFuGck <= 1000) {
            if (iewVKAxm[PfTFuGck] != (594 - 594)) {
                if (b[PfTFuGck] - 'a' >= (209 - 209)) {
                    b[PfTFuGck] = b[PfTFuGck] - 32;
                }
                cout << "(" << b[PfTFuGck] << "," << iewVKAxm[PfTFuGck] << ")";
            }
            PfTFuGck++;
        };
    }
    return (878 - 878);
}

