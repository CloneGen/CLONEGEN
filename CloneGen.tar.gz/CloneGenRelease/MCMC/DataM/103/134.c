void  count (char *string) {
    int i = (185 - 185), j = (790 - 790);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (; string[i] != '\0';) {
        for (; *(string + i) == *(string + j);)
            i++;
        printf ("(%c,%d)", *(string + j), i - j);
        j = i;
    };
}

int main () {
    int i;
    char string [(1512 - 511)];
    gets (string);
    count (string);
    for (i = (248 - 248); string[i] != '\0'; i++)
        if (string[i] >= 'a' && string[i] <= 'z')
            string[i] = string[i] - 'a' + 'A';
    return (906 - 906);
}

