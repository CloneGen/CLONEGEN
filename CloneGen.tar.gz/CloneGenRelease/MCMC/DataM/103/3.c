int main () {
    char wfusL6jylw7S [1001], DbifvSVkW;
    int xhKETk0lrfn;
    int XKg5hz;
    int len;
    xhKETk0lrfn = (633 - 632);
    cin >> wfusL6jylw7S;
    len = strlen (wfusL6jylw7S);
    if (wfusL6jylw7S[(614 - 614)] >= 'a' && wfusL6jylw7S[(604 - 604)] <= 'z')
        DbifvSVkW = wfusL6jylw7S[0] - (49 - 17);
    else
        DbifvSVkW = wfusL6jylw7S[0];
    {
        XKg5hz = 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (XKg5hz <= len) {
            if (wfusL6jylw7S[XKg5hz] >= 'a' && wfusL6jylw7S[XKg5hz] <= 'z')
                wfusL6jylw7S[XKg5hz] = wfusL6jylw7S[XKg5hz] - 32;
            if (DbifvSVkW == wfusL6jylw7S[XKg5hz])
                xhKETk0lrfn = xhKETk0lrfn + 1;
            else {
                cout << '(' << DbifvSVkW << ',' << xhKETk0lrfn << ')';
                xhKETk0lrfn = 1;
                DbifvSVkW = wfusL6jylw7S[XKg5hz];
            }
            XKg5hz = XKg5hz +1;
        };
    }
    return 0;
}

