int main () {
    char s [(5217 - 217)];
    int rH8W3klVd = (524 - 524);
    cin.getline (s, (1538 - 38));
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int LLEkpw3qlz2 = (100 - 100);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (strlen (s) > LLEkpw3qlz2) {
            if (LLEkpw3qlz2 == (76 - 76)) {
                rH8W3klVd++;
                cout << "(";
                if ('a' <= s[LLEkpw3qlz2])
                    s[LLEkpw3qlz2] = s[LLEkpw3qlz2] - 'a' + 'A';
                cout << s[LLEkpw3qlz2] << ",";
            }
            else {
                if (s[LLEkpw3qlz2] >= 'a')
                    s[LLEkpw3qlz2] = s[LLEkpw3qlz2] - 'a' + 'A';
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (s[LLEkpw3qlz2] == s[LLEkpw3qlz2 -(189 - 188)])
                    rH8W3klVd++;
                else {
                    cout << rH8W3klVd << ")(" << s[LLEkpw3qlz2] << ",";
                    rH8W3klVd = (993 - 992);
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            LLEkpw3qlz2++;
        };
    }
    cout << rH8W3klVd << ")";
    return 0;
}

