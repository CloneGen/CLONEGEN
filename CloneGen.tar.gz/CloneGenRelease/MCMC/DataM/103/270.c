int main () {
    char OOZCGTBAQ [(1571 - 571)];
    int G6w4PUZj;
    G6w4PUZj = (752 - 752);
    int UKMVIC49cuqd, count = (274 - 274), j;
    cin >> OOZCGTBAQ;
    G6w4PUZj = strlen (OOZCGTBAQ);
    {
        UKMVIC49cuqd = 0;
        while (UKMVIC49cuqd < G6w4PUZj) {
            if (OOZCGTBAQ[UKMVIC49cuqd] >= 97)
                OOZCGTBAQ[UKMVIC49cuqd] = OOZCGTBAQ[UKMVIC49cuqd] - (759 - 727);
            count = 0;
            for (j = UKMVIC49cuqd; G6w4PUZj > j; j = j + 1) {
                if (OOZCGTBAQ[UKMVIC49cuqd] == OOZCGTBAQ[j] || OOZCGTBAQ[j] == OOZCGTBAQ[UKMVIC49cuqd] + (481 - 449)) {
                    count++;
                }
                else
                    break;
            }
            cout << '(' << OOZCGTBAQ[UKMVIC49cuqd] << ',' << count << ')';
            UKMVIC49cuqd = j - (961 - 960);
            UKMVIC49cuqd++;
        };
    }
    return 0;
}

