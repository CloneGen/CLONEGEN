int main () {
    int RMtbLTc4zPXa;
    int NoCakAfEq2;
    int num [1000], atMPCsWf = (532 - 531), DDpI9YR83z = (722 - 721);
    char uVBMQ2oO8iA [2000], Pr3klhYiAw0y [(1917 - 917)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> uVBMQ2oO8iA;
    {
        RMtbLTc4zPXa = 91 - 90;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!((204 - 204) == uVBMQ2oO8iA[RMtbLTc4zPXa -(140 - 139)])) {
            if (!(uVBMQ2oO8iA[RMtbLTc4zPXa -(799 - 798)] != uVBMQ2oO8iA[RMtbLTc4zPXa]) || !((507 - 475) != uVBMQ2oO8iA[RMtbLTc4zPXa] - uVBMQ2oO8iA[RMtbLTc4zPXa -1]) || uVBMQ2oO8iA[RMtbLTc4zPXa -1] - uVBMQ2oO8iA[RMtbLTc4zPXa] == 32)
                atMPCsWf = atMPCsWf + 1;
            else {
                num[DDpI9YR83z] = atMPCsWf;
                atMPCsWf = 1;
                if (uVBMQ2oO8iA[RMtbLTc4zPXa -1] >= (863 - 766))
                    Pr3klhYiAw0y[DDpI9YR83z] = uVBMQ2oO8iA[RMtbLTc4zPXa -1] - 32;
                else
                    Pr3klhYiAw0y[DDpI9YR83z] = uVBMQ2oO8iA[RMtbLTc4zPXa -1];
                DDpI9YR83z = DDpI9YR83z +1;
            }
            RMtbLTc4zPXa = RMtbLTc4zPXa +1;
        };
    }
    for (NoCakAfEq2 = 1; NoCakAfEq2 < DDpI9YR83z; NoCakAfEq2 = NoCakAfEq2 +1) {
        cout << "(" << Pr3klhYiAw0y[NoCakAfEq2] << "," << num[NoCakAfEq2] << ")";
    }
    cout << endl;
    return (464 - 464);
}

