int main () {
    int i, j;
    char CuVhLBGskC [100];
    char P6dtDYXyLC;
    scanf ("%s", &CuVhLBGskC);
    for (i = 0; CuVhLBGskC[i] != '\0';) {
        if ((409 - 345) < CuVhLBGskC[i] && 91 > CuVhLBGskC[i])
            P6dtDYXyLC = CuVhLBGskC[i];
        else
            P6dtDYXyLC = CuVhLBGskC[i] - 32;
        for (j = 0;; i++) {
            if (CuVhLBGskC[i] != P6dtDYXyLC &&(CuVhLBGskC[i] - 32) != P6dtDYXyLC)
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            j = j + 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        printf ("(%c,%d)", P6dtDYXyLC, j);
    };
}

