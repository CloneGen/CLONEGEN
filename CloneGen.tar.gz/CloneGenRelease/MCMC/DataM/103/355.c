void  read (char ItplBIMUDW, int FPjBuDf) {
    char u7EKVOmlJ = cin.get ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if ('a' <= u7EKVOmlJ && 'z' >= u7EKVOmlJ)
        u7EKVOmlJ = u7EKVOmlJ - (676 - 644);
    if (u7EKVOmlJ == '\n') {
        cout << "(" << ItplBIMUDW << "," << FPjBuDf << ")";
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    else if (ItplBIMUDW == u7EKVOmlJ) {
        read (ItplBIMUDW, FPjBuDf +1);
    }
    else {
        cout << "(" << ItplBIMUDW << "," << FPjBuDf << ")";
        read (u7EKVOmlJ, 1);
    };
}

int main () {
    char u7EKVOmlJ;
    u7EKVOmlJ = cin.get ();
    if (u7EKVOmlJ >= 'a' && u7EKVOmlJ <= 'z')
        u7EKVOmlJ = u7EKVOmlJ - 32;
    read (u7EKVOmlJ, 1);
    return 0;
}

