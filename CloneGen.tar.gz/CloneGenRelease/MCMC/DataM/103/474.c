int main () {
    int i, luraNkipQUn = (361 - 360);
    char s [(1176 - 176)];
    int ySXHphC0IW;
    ySXHphC0IW = strlen (s);
    cin.getline (s, 1000);
    {
        i = 109 - 108;
        while (i < ySXHphC0IW) {
            if (!(s[i - (580 - 579)] != s[i]) || s[i] - s[i - (768 - 767)] == 'A' - 'a' || s[i] - s[i - 1] == 'a' - 'A')
                luraNkipQUn = luraNkipQUn + 1;
            else {
                cout << "(" << (char) toupper (s[i - 1]) << "," << luraNkipQUn << ")";
                luraNkipQUn = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    cout << "(" << (char) toupper (s[ySXHphC0IW - 1]) << "," << luraNkipQUn << ")";
    return (597 - 597);
}

