int main () {
    int plMUJyc7CE5;
    plMUJyc7CE5 = (512 - 511);
    char currChar;
    char lastChar;
    cin >> lastChar;
    if ('z' >= lastChar && 'a' <= lastChar)
        lastChar += 'A' - 'a';
    for (; cin >> currChar;) {
        if (currChar <= 'z' && currChar >= 'a')
            currChar += 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (currChar != lastChar) {
            cout << '(' << lastChar << ',' << plMUJyc7CE5 << ')';
            plMUJyc7CE5 = (589 - 588);
            lastChar = currChar;
        }
        else
            plMUJyc7CE5 = plMUJyc7CE5 + 1;
    }
    cout << '(' << lastChar << ',' << plMUJyc7CE5 << ')';
    return (397 - 397);
}

