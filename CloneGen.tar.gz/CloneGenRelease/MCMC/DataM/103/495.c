int main () {
    int num;
    int x;
    int eAxcqICG5Z;
    int i;
    int len;
    int j;
    num = (377 - 377);
    char SqGJ8uN3F1v5 [1200] = {'\0'};
    char Jwdxs9AINph;
    num = (114 - 113);
    cin >> SqGJ8uN3F1v5;
    len = strlen (SqGJ8uN3F1v5);
    for (i = (892 - 892); len > i; i = i + 1) {
        if ((1044 - 947) <= SqGJ8uN3F1v5[i])
            SqGJ8uN3F1v5[i] = SqGJ8uN3F1v5[i] - 32;
    }
    {
        i = 534 - 534;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (i < len) {
            if (SqGJ8uN3F1v5[i] == SqGJ8uN3F1v5[i + (826 - 825)])
                num++;
            else {
                cout << '(' << SqGJ8uN3F1v5[i] << ',' << num << ')';
                num = (336 - 335);
            }
            i++;
        };
    }
    return 0;
}

