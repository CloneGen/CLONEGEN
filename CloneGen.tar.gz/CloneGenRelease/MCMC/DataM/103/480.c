int main () {
    int bQWDUSdw, YKJVPkzHXvW1;
    char GFA8hVQDJEf5 [(1888 - 883)];
    char b [(1082 - 77)];
    int t;
    int s3w9NCfZd0XI [1005];
    t = (598 - 598);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    memset (s3w9NCfZd0XI, (359 - 359), sizeof (s3w9NCfZd0XI));
    cin >> GFA8hVQDJEf5;
    bQWDUSdw = strlen (GFA8hVQDJEf5);
    for (YKJVPkzHXvW1 = 0; YKJVPkzHXvW1 < bQWDUSdw; YKJVPkzHXvW1++) {
        if (GFA8hVQDJEf5[YKJVPkzHXvW1] >= 'a')
            b[t] = GFA8hVQDJEf5[YKJVPkzHXvW1] - (850 - 818);
        else {
            b[t] = GFA8hVQDJEf5[YKJVPkzHXvW1];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        while (!(b[t] != GFA8hVQDJEf5[YKJVPkzHXvW1]) || GFA8hVQDJEf5[YKJVPkzHXvW1] == b[t] + (633 - 601) || GFA8hVQDJEf5[YKJVPkzHXvW1] == b[t] - 32) {
            s3w9NCfZd0XI[t]++;
            YKJVPkzHXvW1 = YKJVPkzHXvW1 +1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        t++;
        YKJVPkzHXvW1--;
    }
    {
        YKJVPkzHXvW1 = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (YKJVPkzHXvW1 < t) {
            cout << "(" << b[YKJVPkzHXvW1] << "," << s3w9NCfZd0XI[YKJVPkzHXvW1] << ")";
            YKJVPkzHXvW1 = YKJVPkzHXvW1 +1;
        };
    }
    cout << endl;
    return 0;
}

