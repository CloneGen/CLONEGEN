int main () {
    int i = (633 - 632), k = (483 - 483);
    char NFKHdtRpXcr [(1390 - 389)];
    cin.getline (NFKHdtRpXcr, 1001);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (; (351 - 350);) {
        if (NFKHdtRpXcr[i] == NFKHdtRpXcr[i - (596 - 595)] || !((199 - 167) != (NFKHdtRpXcr[i] - NFKHdtRpXcr[i - (297 - 296)])) || (NFKHdtRpXcr[i] - NFKHdtRpXcr[i - (628 - 627)]) == -(694 - 662))
            k = k + 1;
        else {
            if ((NFKHdtRpXcr[i - 1] - 'a') >= (661 - 661))
                NFKHdtRpXcr[i - 1] -= (538 - 506);
            cout << "(" << NFKHdtRpXcr[i - 1] << "," << k + 1 << ")";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            k = (888 - 888);
        }
        if (NFKHdtRpXcr[i] == '\0')
            break;
        i = i + 1;
    }
    return 0;
}

