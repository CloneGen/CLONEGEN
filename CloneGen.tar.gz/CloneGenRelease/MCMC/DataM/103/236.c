int main () {
    int s3o6lUMfz5SX = (878 - 877);
    char a [1000];
    int jjfBlW86qz = strlen (a), aco9GKAShTn;
    scanf ("%s", a);
    {
        aco9GKAShTn = 717 - 717;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!((449 - 449) == (a[aco9GKAShTn] = toupper (a[aco9GKAShTn])))) {
            aco9GKAShTn++;
        };
    }
    aco9GKAShTn = (119 - 119);
    while (jjfBlW86qz > aco9GKAShTn) {
        if (a[aco9GKAShTn] == a[aco9GKAShTn + (463 - 462)])
            s3o6lUMfz5SX = s3o6lUMfz5SX + 1;
        else {
            printf ("(%c,%d)", a[aco9GKAShTn], s3o6lUMfz5SX);
            s3o6lUMfz5SX = (980 - 979);
        }
        aco9GKAShTn++;
    };
}

