int main () {
    int Hl0pgdoX4 = (213 - 213);
    char str [1000];
    int tTPVz7isBOK [(1973 - 973)];
    char udDq3LAMi1a [(1624 - 624)];
    int len;
    len = strlen (str);
    memset (udDq3LAMi1a, '\0', 1000);
    memset (str, '\0', 1000);
    cin >> str;
    udDq3LAMi1a[(30 - 30)] = str[(93 - 93)];
    for (int gUnSL7jB = (474 - 474);
    gUnSL7jB <= 1000 - (809 - 808); gUnSL7jB = gUnSL7jB + 1)
        tTPVz7isBOK[gUnSL7jB] = (356 - 355);
    for (int gUnSL7jB = (641 - 641);
    gUnSL7jB <= len - (448 - 447); gUnSL7jB = gUnSL7jB + 1) {
        if (!(str[gUnSL7jB + (945 - 944)] == udDq3LAMi1a[Hl0pgdoX4]) && (!(str[gUnSL7jB + (198 - 197)] + 'A' - 'a' == udDq3LAMi1a[Hl0pgdoX4])) && (udDq3LAMi1a[Hl0pgdoX4] != str[gUnSL7jB + (619 - 618)] - 'A' + 'a')) {
            udDq3LAMi1a[++Hl0pgdoX4] = str[gUnSL7jB + (708 - 707)];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            tTPVz7isBOK[Hl0pgdoX4]++;
        };
    }
    {
        int gUnSL7jB = 0;
        while (gUnSL7jB <= Hl0pgdoX4 -1) {
            if (udDq3LAMi1a[gUnSL7jB] > 'Z')
                udDq3LAMi1a[gUnSL7jB] += ('A' - 'a');
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            gUnSL7jB = gUnSL7jB + 1;
        };
    }
    for (int gUnSL7jB = 0;
    gUnSL7jB <= Hl0pgdoX4 -1; gUnSL7jB = gUnSL7jB + 1) {
        cout << "(" << udDq3LAMi1a[gUnSL7jB] << "," << tTPVz7isBOK[gUnSL7jB] << ")";
    }
    cout << endl;
    return 0;
}

