int main () {
    int i;
    i = (535 - 535);
    char PRGH21ka [(1808 - 807)] = {'\0'};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin.getline (PRGH21ka, (1737 - 737), '\n');
    for (; (215 - 214);) {
        int m;
        m = 1;
        if (PRGH21ka[i] == '\0')
            break;
        while (PRGH21ka[i] == PRGH21ka[i + 1] || PRGH21ka[i] - 'a' == PRGH21ka[i + 1] - 'A' || PRGH21ka[i] - 'A' == PRGH21ka[i + 1] - 'a') {
            i = i + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            m = m + 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (PRGH21ka[i] - 'a' >= (945 - 945))
            PRGH21ka[i] = 'A' + PRGH21ka[i] - 'a';
        cout << '(' << PRGH21ka[i] << ',' << m << ')';
        m = 1;
        i++;
    }
    return 0;
}

