main () {
    int l;
    char tb5dimSv;
    char lr6PDcau7b;
    char VE2h6ojXz [(1489 - 488)];
    tb5dimSv = (117 - 117);
    lr6PDcau7b = (617 - 616);
    scanf ("%s", VE2h6ojXz);
    l = strlen (VE2h6ojXz);
    while ((631 - 630)) {
        if (l == (455 - 454)) {
            if (VE2h6ojXz[(475 - 475)] >= 'A' && 'Z' >= VE2h6ojXz[(44 - 44)])
                printf ("(%c,%d)", VE2h6ojXz[(127 - 127)], lr6PDcau7b);
            else
                printf ("(%c,%d)", VE2h6ojXz[0] - 'a' + 'A', lr6PDcau7b);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            break;
        }
        else if (VE2h6ojXz[tb5dimSv] == VE2h6ojXz[tb5dimSv + (354 - 353)] || (VE2h6ojXz[tb5dimSv] - VE2h6ojXz[tb5dimSv + 1] == 'a' - 'A') || (VE2h6ojXz[tb5dimSv] - VE2h6ojXz[tb5dimSv + 1] == 'A' - 'a')) {
            tb5dimSv = tb5dimSv + 1;
            lr6PDcau7b = lr6PDcau7b + 1;
        }
        else {
            if (VE2h6ojXz[tb5dimSv] >= 'A' && VE2h6ojXz[tb5dimSv] <= 'Z')
                printf ("(%c,%d)", VE2h6ojXz[tb5dimSv], lr6PDcau7b);
            else
                printf ("(%c,%d)", VE2h6ojXz[tb5dimSv] - 'a' + 'A', lr6PDcau7b);
            tb5dimSv = tb5dimSv + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            lr6PDcau7b = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (tb5dimSv == l)
            break;
    };
}

