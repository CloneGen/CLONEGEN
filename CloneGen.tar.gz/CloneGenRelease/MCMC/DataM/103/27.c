char f [1];

main () {
    char Y1Dfb2SIHo [1000];
    int qQsXEBSanxV;
    qQsXEBSanxV = 0;
    int t;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int uSbAVn;
    t = 0;
    scanf ("%s", Y1Dfb2SIHo);
    uSbAVn = strlen (Y1Dfb2SIHo);
    Y1Dfb2SIHo[uSbAVn] = 'a';
    if (Y1Dfb2SIHo[0] >= 'a' && 'z' >= Y1Dfb2SIHo[0])
        f[0] = Y1Dfb2SIHo[0] + 'A' - 'a';
    else
        f[0] = Y1Dfb2SIHo[0];
    {
        k = 1;
        while (k <= uSbAVn) {
            if (Y1Dfb2SIHo[k - 1] >= 'a' && Y1Dfb2SIHo[k - 1] <= 'z')
                Y1Dfb2SIHo[k - 1] = Y1Dfb2SIHo[k - 1] + 'A' - 'a';
            if (Y1Dfb2SIHo[k - 1] != Y1Dfb2SIHo[qQsXEBSanxV]) {
                printf ("(%s,%d)", f, t);
                f[0] = Y1Dfb2SIHo[k - 1];
                qQsXEBSanxV = k - 1;
                t = 1;
            }
            else
                t++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (k == uSbAVn)
                printf ("(%s,%d)", f, t);
            k++;
        };
    };
}

