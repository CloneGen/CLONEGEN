int main () {
    int wER64gkyI0;
    int flag;
    int j;
    char b [(522 - 422)];
    char LVtUR1Z [1000];
    gets (LVtUR1Z);
    int c [100];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    {
        wER64gkyI0 = 725 - 725;
        while (1000 > wER64gkyI0) {
            if ((638 - 542) < LVtUR1Z[wER64gkyI0])
                LVtUR1Z[wER64gkyI0] = LVtUR1Z[wER64gkyI0] - (748 - 716);
            if (LVtUR1Z[wER64gkyI0] == (345 - 345))
                break;
            wER64gkyI0 = wER64gkyI0 + 1;
        };
    }
    j = 0;
    b[(169 - 169)] = LVtUR1Z[(137 - 137)];
    flag = wER64gkyI0;
    for (wER64gkyI0 = 0; flag >= wER64gkyI0; wER64gkyI0++)
        c[wER64gkyI0] = (833 - 832);
    for (wER64gkyI0 = 1; wER64gkyI0 <= flag; wER64gkyI0++) {
        if (b[j] == LVtUR1Z[wER64gkyI0])
            c[j]++;
        else {
            j = j + 1;
            b[j] = LVtUR1Z[wER64gkyI0];
        };
    }
    {
        wER64gkyI0 = 0;
        while (wER64gkyI0 < j) {
            printf ("(%c,%d)", b[wER64gkyI0], c[wER64gkyI0]);
            wER64gkyI0 = wER64gkyI0 + 1;
        };
    }
    return 0;
}

