main () {
    char s;
    int count;
    int cvmqFQ;
    int ioeyOPxkBWJh;
    int l;
    count = 0;
    char xD40nvlNMHQb [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", xD40nvlNMHQb);
    l = strlen (xD40nvlNMHQb);
    {
        cvmqFQ = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (l > cvmqFQ) {
            if (xD40nvlNMHQb[cvmqFQ] >= 'a' && xD40nvlNMHQb[cvmqFQ] <= 'z')
                xD40nvlNMHQb[cvmqFQ] = xD40nvlNMHQb[cvmqFQ] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cvmqFQ = cvmqFQ + 1;
        };
    }
    s = xD40nvlNMHQb[0];
    {
        cvmqFQ = 0;
        while (cvmqFQ < l) {
            if (xD40nvlNMHQb[cvmqFQ] == s)
                count++;
            else {
                printf ("(%c,%d)", s, count);
                count = (599 - 598);
                s = xD40nvlNMHQb[cvmqFQ];
            }
            cvmqFQ = cvmqFQ + 1;
        };
    }
    printf ("(%c,%d)", s, count);
    getchar ();
    getchar ();
}

