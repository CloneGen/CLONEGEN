main () {
    int a [(1235 - 235)];
    char jPUXmL4g82a [(1635 - 635)];
    int n;
    int aHoCIes43W;
    int ZCEnFvRkeZ91;
    n = (976 - 976);
    char cs [(1809 - 809)];
    scanf ("%s", jPUXmL4g82a);
    {
        aHoCIes43W = 0;
        while (jPUXmL4g82a[aHoCIes43W] != '\0') {
            if ('a' <= jPUXmL4g82a[aHoCIes43W] && 'z' >= jPUXmL4g82a[aHoCIes43W])
                jPUXmL4g82a[aHoCIes43W] = jPUXmL4g82a[aHoCIes43W] - 'a' + 'A';
            a[aHoCIes43W] = (602 - 601);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            aHoCIes43W = aHoCIes43W + 1;
        };
    }
    cs[0] = jPUXmL4g82a[0];
    for (aHoCIes43W = 1; jPUXmL4g82a[aHoCIes43W] != '\0'; aHoCIes43W++) {
        if (jPUXmL4g82a[aHoCIes43W] == cs[n]) {
            a[n]++;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            n++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            cs[n] = jPUXmL4g82a[aHoCIes43W];
        };
    }
    for (aHoCIes43W = 0; aHoCIes43W <= n; aHoCIes43W++) {
        printf ("(%c,%d)", cs[aHoCIes43W], a[aHoCIes43W]);
    };
}

