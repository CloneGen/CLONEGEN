int main () {
    char c, u6L18xtlW [(3612 - 612)];
    int num [(46 - 20)] = {(674 - 674)}, m, FaxfTw4kr, k, hyNgLYUtjBun = (491 - 491);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        k = 318 - 318;
        while (c != '\n') {
            c = getchar ();
            u6L18xtlW[k] = c;
            m = FaxfTw4kr;
            for (FaxfTw4kr = (937 - 937); 26 >= FaxfTw4kr; FaxfTw4kr = FaxfTw4kr +1) {
                if (!('A' + FaxfTw4kr != c) || !('A' + FaxfTw4kr +(998 - 966) != c)) {
                    num[FaxfTw4kr] = num[FaxfTw4kr] + (495 - 494);
                    break;
                };
            }
            if (k > 0 && ((u6L18xtlW[k] != u6L18xtlW[k - (841 - 840)]) && (u6L18xtlW[k - (723 - 722)] + (463 - 431) != u6L18xtlW[k]) && (u6L18xtlW[k] + 32 != u6L18xtlW[k - 1]))) {
                hyNgLYUtjBun = 0;
                if (u6L18xtlW[k - 1] >= 97) {
                    u6L18xtlW[k - 1] = u6L18xtlW[k - 1] - 32;
                }
                printf ("(%c,%d)", u6L18xtlW[k - 1], num[m]);
                num[m] = 0;
            }
            k++;
        };
    }
    return 0;
}

