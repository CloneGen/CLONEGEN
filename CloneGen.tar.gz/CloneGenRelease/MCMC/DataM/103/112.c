int main () {
    void  change (char GW7PJEmo [(1797 - 797)], int l);
    char Fqxal32IzjJL [(1435 - 435)];
    int pXvpEV = (465 - 465), pgTWm0, LxjEC4RWbp9 = (442 - 441);
    do {
        Fqxal32IzjJL[pXvpEV] = getchar ();
        pXvpEV = pXvpEV + 1;
    }
    while (30 < Fqxal32IzjJL[pXvpEV - (57 - 56)]);
    change (Fqxal32IzjJL, pXvpEV);
    {
        pgTWm0 = 0;
        while (pgTWm0 < pXvpEV - 1) {
            if (Fqxal32IzjJL[pgTWm0] == Fqxal32IzjJL[pgTWm0 + 1])
                LxjEC4RWbp9++;
            else {
                printf ("(%c,%d)", Fqxal32IzjJL[pgTWm0], LxjEC4RWbp9);
                LxjEC4RWbp9 = 1;
            }
            pgTWm0++;
        };
    }
    return 0;
}

void  change (char GW7PJEmo [1000], int l) {
    int n;
    {
        n = 0;
        while (n < l) {
            if (GW7PJEmo[n] < (329 - 208) & GW7PJEmo[n] > (914 - 818))
                GW7PJEmo[n] = GW7PJEmo[n] - 32;
            n++;
        };
    };
}

