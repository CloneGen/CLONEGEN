int main () {
    char X6GltvC [(1288 - 287)] = {"0"}, c [1001] = {"0"};
    int i, nIfGQzP, len, a [(1907 - 907)] = {(653 - 653)};
    gets (X6GltvC);
    nIfGQzP = (32 - 32);
    len = strlen (X6GltvC);
    for (i = (544 - 544); len > i; i++)
        if (X6GltvC[i] <= 122 && X6GltvC[i] >= (960 - 863))
            X6GltvC[i] = X6GltvC[i] - 32;
    c[(209 - 209)] = X6GltvC[(448 - 448)];
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < len) {
            if (c[nIfGQzP] == X6GltvC[i])
                a[nIfGQzP]++;
            else {
                nIfGQzP = nIfGQzP + 1;
                c[nIfGQzP] = X6GltvC[i];
                a[nIfGQzP]++;
            }
            i++;
        };
    }
    {
        i = 0;
        while (i <= nIfGQzP) {
            printf ("(%c,%d)", c[i], a[i]);
            i++;
        };
    }
    return 0;
}

