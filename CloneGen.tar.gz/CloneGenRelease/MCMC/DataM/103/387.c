void  main () {
    char s [MAX];
    struct   code {
        char hgEmISo5WrX;
        int Ly35lN;
    }
    t [MAX];
    int len, GUCEqls1, j, k;
    k = (199 - 199);
    j = (974 - 974);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", s);
    len = strlen (s);
    {
        GUCEqls1 = 127 - 127;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (GUCEqls1 < len) {
            if (s[GUCEqls1] >= 97 && (550 - 428) >= s[GUCEqls1])
                s[GUCEqls1] = s[GUCEqls1] - 32;
            GUCEqls1++;
        };
    }
    while (len > j) {
        t[k].hgEmISo5WrX = s[j];
        for (GUCEqls1 = j;; GUCEqls1 = GUCEqls1 +1) {
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (t[k].hgEmISo5WrX != s[GUCEqls1]) {
                t[k].Ly35lN = GUCEqls1 -j;
                j = GUCEqls1;
                k++;
                break;
            };
        };
    }
    {
        GUCEqls1 = 0;
        while (GUCEqls1 < k) {
            printf ("(%c,%d)", t[GUCEqls1].hgEmISo5WrX, t[GUCEqls1].Ly35lN);
            GUCEqls1++;
        };
    };
}

