main () {
    int a [(902 - 876)] = {(719 - 719)};
    int lSs43rbf07L2;
    int OfRmYZ;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    char str [1100];
    scanf ("%s", str);
    str[strlen (str)] = str[strlen (str) - (989 - 988)] + (165 - 164);
    {
        lSs43rbf07L2 = 883 - 883;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (lSs43rbf07L2 < strlen (str) - 1) {
            if (!(str[lSs43rbf07L2 + 1] != str[lSs43rbf07L2]) || !('a' - 'A' != abs (str[lSs43rbf07L2] - str[lSs43rbf07L2 + 1]))) {
                if ((195 - 169) > str[lSs43rbf07L2] - 'A')
                    a[str[lSs43rbf07L2] - 'A']++;
                else
                    a[str[lSs43rbf07L2] - 'a']++;
            }
            else {
                if (str[lSs43rbf07L2] - 'A' < 26)
                    a[str[lSs43rbf07L2] - 'A']++;
                else
                    a[str[lSs43rbf07L2] - 'a']++;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (str[lSs43rbf07L2] - 'A' < 26) {
                    printf ("(%c,%d)", str[lSs43rbf07L2], a[str[lSs43rbf07L2] - 'A']);
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    }
                    a[str[lSs43rbf07L2] - 'A'] = 0;
                }
                else {
                    printf ("(%c,%d)", str[lSs43rbf07L2] - 'a' + 'A', a[str[lSs43rbf07L2] - 'a']);
                    a[str[lSs43rbf07L2] - 'a'] = 0;
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            lSs43rbf07L2 = lSs43rbf07L2 + 1;
        };
    };
}

