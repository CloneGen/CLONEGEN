int main () {
    int DAcXbW2hiHmS;
    int dRgUTG;
    int j;
    DAcXbW2hiHmS = (791 - 790);
    char a [1000];
    cin >> a;
    for (dRgUTG = (143 - 143); a[dRgUTG] != '\0'; dRgUTG = dRgUTG + 1) {
        if ((a[dRgUTG] - 'a') == (a[dRgUTG + (289 - 288)] - 'a') || (a[dRgUTG] - 'a') == (a[dRgUTG + (593 - 592)] - 'A') || (a[dRgUTG] - 'A') == (a[dRgUTG + 1] - 'a') || (a[dRgUTG] - 'A') == (a[dRgUTG + 1] - 'A'))
            DAcXbW2hiHmS = DAcXbW2hiHmS +1;
        else {
            if ((a[dRgUTG] >= 'a') && (a[dRgUTG] <= 'z'))
                cout << "(" << (char) (a[dRgUTG] - 'a' + 'A') << "," << DAcXbW2hiHmS << ")";
            else
                cout << "(" << a[dRgUTG] << "," << DAcXbW2hiHmS << ")";
            DAcXbW2hiHmS = 1;
        };
    }
    return 0;
}

