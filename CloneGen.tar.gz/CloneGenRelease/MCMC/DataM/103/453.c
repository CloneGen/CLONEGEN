main () {
    int lPt9Q3X6AvHS;
    int ZAdtIKrNb0 = (671 - 670);
    char GMl5UdvP [(1082 - 80)];
    gets (GMl5UdvP);
    for (lPt9Q3X6AvHS = (925 - 925); !('\0' == GMl5UdvP[lPt9Q3X6AvHS]); lPt9Q3X6AvHS = lPt9Q3X6AvHS + 1) {
        if (GMl5UdvP[lPt9Q3X6AvHS] >= 'a' && GMl5UdvP[lPt9Q3X6AvHS] <= 'z')
            GMl5UdvP[lPt9Q3X6AvHS] = GMl5UdvP[lPt9Q3X6AvHS] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        lPt9Q3X6AvHS = 602 - 601;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (GMl5UdvP[lPt9Q3X6AvHS] != '\0') {
            if ((GMl5UdvP[lPt9Q3X6AvHS] == GMl5UdvP[lPt9Q3X6AvHS - (825 - 824)]))
                ZAdtIKrNb0 = ZAdtIKrNb0 +(593 - 592);
            else {
                printf ("(%c,%d)", GMl5UdvP[lPt9Q3X6AvHS - (382 - 381)], ZAdtIKrNb0);
                ZAdtIKrNb0 = (749 - 748);
            }
            lPt9Q3X6AvHS = lPt9Q3X6AvHS + 1;
        };
    }
    printf ("(%c,%d)", GMl5UdvP[lPt9Q3X6AvHS - (611 - 610)], ZAdtIKrNb0);
    getchar ();
    getchar ();
}

