int main () {
    char Z9m4rLFnC8 [(1507 - 497)];
    int ezgT56vpQt;
    ezgT56vpQt = 0;
    char mItmZhCsj = '\0';
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> Z9m4rLFnC8;
    {
        int MU7vwTxH5R = (793 - 793);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (MU7vwTxH5R < strlen (Z9m4rLFnC8)) {
            if (Z9m4rLFnC8[MU7vwTxH5R] >= 'a' && 'z' >= Z9m4rLFnC8[MU7vwTxH5R])
                Z9m4rLFnC8[MU7vwTxH5R] = Z9m4rLFnC8[MU7vwTxH5R] + 'A' - 'a';
            MU7vwTxH5R = MU7vwTxH5R +1;
        };
    }
    {
        int MU7vwTxH5R = 0;
        while (MU7vwTxH5R < strlen (Z9m4rLFnC8)) {
            if (Z9m4rLFnC8[MU7vwTxH5R] == mItmZhCsj)
                ezgT56vpQt = ezgT56vpQt + 1;
            else {
                if (mItmZhCsj != '\0')
                    cout << '(' << mItmZhCsj << ',' << ezgT56vpQt << ')';
                ezgT56vpQt = 1;
                mItmZhCsj = Z9m4rLFnC8[MU7vwTxH5R];
            }
            MU7vwTxH5R = MU7vwTxH5R +1;
        };
    }
    cout << '(' << mItmZhCsj << ',' << ezgT56vpQt << ')' << endl;
    return 0;
}

