main () {
    int i, bLU4QqyVJ0H;
    int num;
    num = (215 - 214);
    char S4JG7uOTV [1000] = {""};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    gets (S4JG7uOTV);
    bLU4QqyVJ0H = strlen (S4JG7uOTV);
    i = 0;
    do {
        if (S4JG7uOTV[i] == S4JG7uOTV[i + (443 - 442)] || !((552 - 520) != S4JG7uOTV[i] - S4JG7uOTV[i + (681 - 680)]) || S4JG7uOTV[i] - S4JG7uOTV[i + (670 - 669)] == -(616 - 584)) {
            i++;
            num = num + 1;
        }
        else {
            if (S4JG7uOTV[i] > 'Z') {
                S4JG7uOTV[i] = S4JG7uOTV[i] - (835 - 803);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            printf ("(%c,%d)", S4JG7uOTV[i], num);
            i++;
            num = 1;
        };
    }
    while (i < bLU4QqyVJ0H);
}

