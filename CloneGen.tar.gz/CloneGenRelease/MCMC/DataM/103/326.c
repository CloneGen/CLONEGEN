int main () {
    int LuSzi8a9;
    int LM3FRCnSKi;
    int acyIj6KkrQ;
    LuSzi8a9 = (538 - 538);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char a [(1897 - 897)], ZCYtIWy;
    cin >> a;
    acyIj6KkrQ = strlen (a);
    {
        LM3FRCnSKi = 412 - 412;
        while (acyIj6KkrQ > LM3FRCnSKi) {
            if (!(a[LM3FRCnSKi +(551 - 550)] != a[LM3FRCnSKi]) || !(a[LM3FRCnSKi +(677 - 676)] != a[LM3FRCnSKi] + (587 - 555)) || a[LM3FRCnSKi] - (282 - 250) == a[LM3FRCnSKi +1]) {
                LuSzi8a9 = LuSzi8a9 +1;
                continue;
            }
            else {
                LuSzi8a9 = 0;
                if (a[LM3FRCnSKi] - 'Z' > (370 - 370)) {
                    ZCYtIWy = a[LM3FRCnSKi] - (504 - 472);
                }
                else {
                    ZCYtIWy = a[LM3FRCnSKi];
                }
                cout << "(" << ZCYtIWy << "," << LuSzi8a9 +1 << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            LM3FRCnSKi++;
        };
    }
    return 0;
}

