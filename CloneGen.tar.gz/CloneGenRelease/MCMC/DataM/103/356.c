int main () {
    int count;
    count = 0;
    char y0JxH9tzqN;
    char *IXxUiStO2sT;
    char TSMIOsbp [(417 - 317)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> TSMIOsbp;
    IXxUiStO2sT = TSMIOsbp;
    y0JxH9tzqN = *IXxUiStO2sT;
    while (!('\0' == *IXxUiStO2sT)) {
        if (y0JxH9tzqN > (831 - 741))
            y0JxH9tzqN = y0JxH9tzqN - (701 - 669);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (*IXxUiStO2sT == y0JxH9tzqN || *IXxUiStO2sT == y0JxH9tzqN + 32) {
            count = count + 1;
            IXxUiStO2sT++;
        }
        else {
            cout << "(" << y0JxH9tzqN << "," << count << ")";
            y0JxH9tzqN = *IXxUiStO2sT;
            count = 0;
        };
    }
    cout << "(" << y0JxH9tzqN << "," << count << ")";
    cout << endl;
    return 0;
}

