main () {
    int vbrMV4, DcgQMbJ;
    char a, str [1000];
    gets (str);
    DcgQMbJ = 1;
    a = str[0];
    if (('a' <= a) && ('z' >= a))
        a = a + 'A' - 'a';
    {
        vbrMV4 = 1;
        while (str[vbrMV4] != '\0') {
            if ((str[vbrMV4] == a) || (str[vbrMV4] == a - 'A' + 'a'))
                DcgQMbJ = DcgQMbJ +1;
            else {
                printf ("(%c,%d)", a, DcgQMbJ);
                a = str[vbrMV4];
                if (('a' <= a) && (a <= 'z'))
                    a = a + 'A' - 'a';
                DcgQMbJ = 1;
            }
            vbrMV4++;
        };
    }
    printf ("(%c,%d)", a, DcgQMbJ);
}

