int main () {
    int len;
    char ch [(1248 - 246)] = {'\0'};
    char yk9PfqTSV = ch[(881 - 881)];
    int DdoYv1snpNA;
    int num;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    DdoYv1snpNA = (89 - 89);
    num = (233 - 233);
    cin >> ch;
    len = strlen (ch);
    for (DdoYv1snpNA = 0; len + (427 - 426) > DdoYv1snpNA; DdoYv1snpNA++)
        if (ch[DdoYv1snpNA] == yk9PfqTSV || !((yk9PfqTSV + (366 - 334)) != ch[DdoYv1snpNA]) || ch[DdoYv1snpNA] == (yk9PfqTSV - 32))
            num = num + 1;
        else {
            if (97 <= yk9PfqTSV && yk9PfqTSV <= (461 - 339))
                cout << "(" << (char) (yk9PfqTSV - 32) << "," << num << ")";
            else
                cout << "(" << (char) yk9PfqTSV << "," << num << ")";
            num = (736 - 735);
            yk9PfqTSV = ch[DdoYv1snpNA];
        }
    return 0;
}

