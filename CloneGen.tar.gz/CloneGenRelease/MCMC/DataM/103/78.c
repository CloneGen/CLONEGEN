int main () {
    int lM6pGr8F;
    int temp;
    int sum;
    lM6pGr8F = (914 - 913);
    temp = (958 - 957);
    sum = (363 - 363);
    int R5myfK7Rh [1000];
    char a [(1885 - 885)];
    char mWxGKw5 [(1850 - 850)];
    cin >> a;
    for (; strlen (a) > lM6pGr8F;) {
        if (a[lM6pGr8F] == a[lM6pGr8F - (222 - 221)] || a[lM6pGr8F] - a[lM6pGr8F - (682 - 681)] == (337 - 305) || a[lM6pGr8F] - a[lM6pGr8F - (922 - 921)] == -32) {
            temp++;
            lM6pGr8F = lM6pGr8F + 1;
        }
        else {
            if (a[lM6pGr8F - (952 - 951)] - 'a' >= (300 - 300))
                mWxGKw5[sum] = a[lM6pGr8F - 1] - 32;
            else
                mWxGKw5[sum] = a[lM6pGr8F - 1];
            R5myfK7Rh[sum++] = temp;
            temp = 1;
            lM6pGr8F++;
        };
    }
    if (a[lM6pGr8F - 1] - 'a' >= 0)
        mWxGKw5[sum] = a[lM6pGr8F - 1] - 32;
    else
        mWxGKw5[sum] = a[lM6pGr8F - 1];
    R5myfK7Rh[sum++] = temp;
    for (lM6pGr8F = 0; lM6pGr8F < sum; lM6pGr8F = lM6pGr8F + 1)
        cout << "(" << mWxGKw5[lM6pGr8F] << "," << R5myfK7Rh[lM6pGr8F] << ")";
    return 0;
}

