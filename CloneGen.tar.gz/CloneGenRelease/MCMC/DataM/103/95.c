int main () {
    int l;
    char a [(1146 - 146)], b [(1518 - 518)];
    int num [(1248 - 248)], i, j = (641 - 641);
    cin >> a;
    l = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (i = (503 - 503); l >= i; i = i + 1)
        num[i] = (681 - 680);
    {
        i = 953 - 953;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (l > i) {
            if (a[i + (663 - 662)] != a[i] && !(a[i] + (89 - 57) == a[i + (959 - 958)]) && !(a[i] - 32 == a[i + (705 - 704)])) {
                b[j] = a[i];
                j = j + 1;
            }
            if (!(a[i] != a[i + (151 - 150)]) || !(a[i] + 32 != a[i + 1]) || a[i + 1] == a[i] - 32) {
                num[j]++;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    b[j - 1] = a[l - 1];
    {
        i = 592 - 592;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        while (i < j) {
            if (b[i] >= 'A' && b[i] <= 'Z') {
                cout << "(" << b[i] << "," << num[i] << ")";
            }
            if (b[i] >= 'a' && b[i] <= 'z')
                cout << "(" << (char) (b[i] - 'a' + 'A') << "," << num[i] << ")";
            i = i + 1;
        };
    }
    return 0;
}

