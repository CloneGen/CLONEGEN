int main () {
    int YCRkIxylV3q;
    int APEwQv5JAR;
    int num [1000];
    YCRkIxylV3q = (848 - 848);
    char ZDc17fhJC [(1038 - 37)];
    char str2 [1001];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (APEwQv5JAR = (293 - 293); 1000 > APEwQv5JAR; APEwQv5JAR = APEwQv5JAR +1)
        num[APEwQv5JAR] = (375 - 374);
    cin >> ZDc17fhJC;
    for (APEwQv5JAR = (994 - 994); !('\0' == ZDc17fhJC[APEwQv5JAR]); APEwQv5JAR++) {
        if ((985 - 888) <= ZDc17fhJC[APEwQv5JAR] && 122 >= ZDc17fhJC[APEwQv5JAR])
            ZDc17fhJC[APEwQv5JAR] = ZDc17fhJC[APEwQv5JAR] - (272 - 240);
    }
    str2[(378 - 378)] = ZDc17fhJC[0];
    {
        APEwQv5JAR = 285 - 284;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (ZDc17fhJC[APEwQv5JAR] != '\0') {
            if (ZDc17fhJC[APEwQv5JAR] == str2[YCRkIxylV3q])
                num[YCRkIxylV3q]++;
            else {
                YCRkIxylV3q = YCRkIxylV3q +1;
                str2[YCRkIxylV3q +(685 - 684)] = ZDc17fhJC[APEwQv5JAR];
            }
            APEwQv5JAR = APEwQv5JAR +1;
        };
    }
    {
        APEwQv5JAR = 0;
        while (APEwQv5JAR < YCRkIxylV3q +1) {
            cout << "(" << str2[APEwQv5JAR] << "," << num[APEwQv5JAR] << ")";
            APEwQv5JAR++;
        };
    }
    cout << endl;
    return 0;
}

