int main () {
    char qxYlJ4efL1w [(1769 - 769)];
    int mcVha6tE [(1295 - 295)];
    int PvWZcqMzGA, dWdgcUNhTs2R, tMWIfrSkUvH;
    cin >> qxYlJ4efL1w;
    tMWIfrSkUvH = strlen (qxYlJ4efL1w);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        PvWZcqMzGA = 917 - 917;
        while (PvWZcqMzGA < 1000) {
            mcVha6tE[PvWZcqMzGA] = (551 - 550);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            PvWZcqMzGA = PvWZcqMzGA +1;
        };
    }
    {
        PvWZcqMzGA = 203 - 203;
        while (tMWIfrSkUvH > PvWZcqMzGA) {
            if ('a' <= qxYlJ4efL1w[PvWZcqMzGA]) {
                qxYlJ4efL1w[PvWZcqMzGA] = qxYlJ4efL1w[PvWZcqMzGA] - 'a' + 'A';
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                };
            }
            PvWZcqMzGA++;
        };
    }
    for (PvWZcqMzGA = (687 - 687); tMWIfrSkUvH > PvWZcqMzGA; PvWZcqMzGA = PvWZcqMzGA +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        if (qxYlJ4efL1w[PvWZcqMzGA] == qxYlJ4efL1w[PvWZcqMzGA +(204 - 203)]) {
            {
                dWdgcUNhTs2R = 511 - 510;
                while (dWdgcUNhTs2R < tMWIfrSkUvH) {
                    qxYlJ4efL1w[dWdgcUNhTs2R] = qxYlJ4efL1w[dWdgcUNhTs2R + 1];
                    dWdgcUNhTs2R = dWdgcUNhTs2R + 1;
                };
            }
            tMWIfrSkUvH--;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    for (x = 0; x < 20; x++) {
                        y += x;
                    }
                    if (y > 30)
                        return y;
                }
            }
            mcVha6tE[PvWZcqMzGA]++;
            PvWZcqMzGA = PvWZcqMzGA -1;
        };
    }
    for (PvWZcqMzGA = 0; PvWZcqMzGA < tMWIfrSkUvH; PvWZcqMzGA++) {
        cout << "(" << qxYlJ4efL1w[PvWZcqMzGA] << "," << mcVha6tE[PvWZcqMzGA] << ")";
    }
    return 0;
}

