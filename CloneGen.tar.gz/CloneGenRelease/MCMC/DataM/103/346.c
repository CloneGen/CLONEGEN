int main () {
    char JYZHUn = (813 - 813);
    int i, Sf56xhiqj, n;
    char E0ch71CBldp [(1869 - 864)];
    gets (E0ch71CBldp);
    n = strlen (E0ch71CBldp);
    {
        i = 611 - 611;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (n > i) {
            if (JYZHUn != toupper (E0ch71CBldp[i])) {
                if (JYZHUn) {
                    printf ("(%c,%d)", JYZHUn, Sf56xhiqj);
                }
                JYZHUn = toupper (E0ch71CBldp[i]);
                Sf56xhiqj = 1;
                continue;
            }
            i = i + 1;
            Sf56xhiqj = Sf56xhiqj +1;
        };
    }
    printf ("(%c,%d)\n", JYZHUn, Sf56xhiqj);
    return 0;
}

