int main () {
    char CojK6pOQkv0f [2000];
    gets (CojK6pOQkv0f);
    int j;
    int RLkDF4N;
    int t;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    j = (494 - 494);
    t = strlen (CojK6pOQkv0f);
    for (RLkDF4N = (749 - 749); t > RLkDF4N; RLkDF4N = RLkDF4N +1) {
        if ('Z' < CojK6pOQkv0f[RLkDF4N])
            CojK6pOQkv0f[RLkDF4N] -= 32;
    }
    {
        RLkDF4N = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (RLkDF4N < t) {
            if (!(CojK6pOQkv0f[RLkDF4N -(818 - 817)] == CojK6pOQkv0f[RLkDF4N])) {
                {
                    j = RLkDF4N;
                    while (j < t) {
                        if (CojK6pOQkv0f[j] != CojK6pOQkv0f[RLkDF4N])
                            break;
                        j++;
                    };
                }
                printf ("(%c,%d)", CojK6pOQkv0f[RLkDF4N], j - RLkDF4N);
            }
            RLkDF4N++;
        };
    }
    return 0;
}

