int main () {
    char hK5opqkbfzJB [1000];
    char YPGQNpBV [(1151 - 151)];
    gets (YPGQNpBV);
    int wYC5Ga2;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    wYC5Ga2 = strlen (YPGQNpBV);
    int a [(1590 - 590)] = {(256 - 256)}, p = (513 - 513);
    {
        int ReJgivD = (539 - 539);
        while (wYC5Ga2 > ReJgivD) {
            if (YPGQNpBV[ReJgivD] >= 'a' && 'z' >= YPGQNpBV[ReJgivD])
                YPGQNpBV[ReJgivD] = YPGQNpBV[ReJgivD] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            ReJgivD++;
        };
    }
    for (int qD7phNWunRw = (868 - 868), j;
    wYC5Ga2 > qD7phNWunRw; qD7phNWunRw++) {
        if (qD7phNWunRw > 0 && YPGQNpBV[qD7phNWunRw] == YPGQNpBV[qD7phNWunRw - 1])
            continue;
        else {
            j = qD7phNWunRw;
            while (j < wYC5Ga2) {
                if (YPGQNpBV[qD7phNWunRw] == YPGQNpBV[j]) {
                    a[p]++;
                    hK5opqkbfzJB[p] = YPGQNpBV[qD7phNWunRw];
                }
                else {
                    p++;
                    break;
                }
                j++;
            };
        };
    }
    for (int q = 0;
    q <= p; q = q + 1)
        printf ("(%c,%d)", hK5opqkbfzJB[q], a[q]);
}

