main () {
    char b1pg2T4EaZ [1020];
    int j;
    int len;
    int c40ZSfXEz;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    j = 0;
    scanf ("%s", b1pg2T4EaZ);
    len = strlen (b1pg2T4EaZ);
    for (c40ZSfXEz = 0; c40ZSfXEz < len; c40ZSfXEz++)
        if (b1pg2T4EaZ[c40ZSfXEz] <= 'z' && 'a' <= b1pg2T4EaZ[c40ZSfXEz])
            b1pg2T4EaZ[c40ZSfXEz] = b1pg2T4EaZ[c40ZSfXEz] - 'a' + 'A';
    while (j != len) {
        int le;
        le = (170 - 169);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        {
            c40ZSfXEz = j + 1;
            while (b1pg2T4EaZ[c40ZSfXEz] == b1pg2T4EaZ[j]) {
                c40ZSfXEz++;
                le++, j++;
            };
        }
        printf ("(%c,%d)", b1pg2T4EaZ[j], le);
        j++;
    };
}

