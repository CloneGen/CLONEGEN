main () {
    char ch, SEB9rLcM6 [1001];
    int a, len, i;
    scanf ("%s", SEB9rLcM6);
    len = strlen (SEB9rLcM6);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if ('a' <= SEB9rLcM6[(370 - 370)] && 'z' >= SEB9rLcM6[0])
        ch = 'A' + SEB9rLcM6[0] - 'a';
    else
        ch = SEB9rLcM6[0];
    a = (544 - 543);
    {
        i = 46 - 45;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (len - 1 >= i) {
            if (SEB9rLcM6[i] - ch == 0 || SEB9rLcM6[i] - ch == 'a' - 'A')
                a = a + 1;
            else {
                printf ("(%c,%d)", ch, a);
                if (SEB9rLcM6[i] >= 'a' && SEB9rLcM6[i] <= 'z')
                    ch = 'A' + SEB9rLcM6[i] - 'a';
                else
                    ch = SEB9rLcM6[i];
                a = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    printf ("(%c,%d)", ch, a);
}

