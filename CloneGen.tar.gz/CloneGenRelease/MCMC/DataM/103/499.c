int main () {
    int SS04ye8vZ5;
    int i;
    int RW2faO8;
    SS04ye8vZ5 = (888 - 887);
    char r3ATyfd5XDNo [(1769 - 769)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> r3ATyfd5XDNo;
    RW2faO8 = strlen (r3ATyfd5XDNo);
    for (i = (902 - 902); i < RW2faO8; i = i + 1) {
        if (r3ATyfd5XDNo[i] - 'a' >= (959 - 959) && r3ATyfd5XDNo[i] - 'z' <= (745 - 745))
            r3ATyfd5XDNo[i] = r3ATyfd5XDNo[i] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        i = 824 - 824;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (RW2faO8 -(271 - 270) > i) {
            if (r3ATyfd5XDNo[i] == r3ATyfd5XDNo[i + (37 - 36)])
                SS04ye8vZ5 = SS04ye8vZ5 +1;
            else {
                cout << "(" << r3ATyfd5XDNo[i] << "," << SS04ye8vZ5 << ")";
                SS04ye8vZ5 = (246 - 245);
            }
            i = i + 1;
        };
    }
    if (r3ATyfd5XDNo[RW2faO8 -2] == r3ATyfd5XDNo[RW2faO8 -(434 - 433)])
        cout << "(" << r3ATyfd5XDNo[RW2faO8 -1] << "," << SS04ye8vZ5 << ")";
    else
        cout << "(" << r3ATyfd5XDNo[RW2faO8 -1] << "," << SS04ye8vZ5 << ")";
    return 0;
}

