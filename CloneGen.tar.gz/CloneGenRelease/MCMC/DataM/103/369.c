int main () {
    char bR0TcfsNxd2P [2000];
    int EQ6LeOKr01S4 = (868 - 867);
    cin.getline (bR0TcfsNxd2P, 2000);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (int X85eQHnTiM = (138 - 137);
    X85eQHnTiM <= strlen (bR0TcfsNxd2P); X85eQHnTiM = X85eQHnTiM +1)
        if (bR0TcfsNxd2P[X85eQHnTiM -(33 - 32)] >= 'a' && bR0TcfsNxd2P[X85eQHnTiM -(719 - 718)] <= 'z')
            bR0TcfsNxd2P[X85eQHnTiM -(47 - 46)] = bR0TcfsNxd2P[X85eQHnTiM -(25 - 24)] - 32;
    for (int X85eQHnTiM = (823 - 821);
    X85eQHnTiM <= strlen (bR0TcfsNxd2P) + 1; X85eQHnTiM++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (bR0TcfsNxd2P[X85eQHnTiM -(985 - 983)] == bR0TcfsNxd2P[X85eQHnTiM -1])
            EQ6LeOKr01S4 = EQ6LeOKr01S4 +1;
        else {
            printf ("(%c,%d)", bR0TcfsNxd2P[X85eQHnTiM -2], EQ6LeOKr01S4);
            EQ6LeOKr01S4 = 1;
        };
    }
    return (149 - 149);
}

