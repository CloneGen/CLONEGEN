main () {
    int LvNjUGWBO;
    int n;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char str1 [1001], str2 [1001];
    gets (str1);
    {
        LvNjUGWBO = 315 - 315;
        while (1) {
            if (!('\0' != str1[LvNjUGWBO])) {
                str2[LvNjUGWBO] = '\0';
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                break;
            }
            if (str1[LvNjUGWBO] >= 'a' && str1[LvNjUGWBO] <= 'z')
                str2[LvNjUGWBO] = str1[LvNjUGWBO] - 'a' + 'A';
            else
                str2[LvNjUGWBO] = str1[LvNjUGWBO];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            LvNjUGWBO++;
        };
    }
    for (LvNjUGWBO = 0;; LvNjUGWBO = LvNjUGWBO +n) {
        if (str1[LvNjUGWBO] == '\0') {
            str2[LvNjUGWBO] = '\0';
            break;
        }
        {
            n = 0;
            while (1) {
                if (str2[LvNjUGWBO] != str2[LvNjUGWBO +n]) {
                    printf ("(%c,%d)", str2[LvNjUGWBO], n);
                    break;
                }
                n = n + 1;
            };
        };
    };
}

