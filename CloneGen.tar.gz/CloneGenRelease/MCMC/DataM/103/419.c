int main () {
    int k1hLWcse5gqy;
    k1hLWcse5gqy = (811 - 811);
    int len;
    len = (837 - 837);
    char VliVvAFQxP [(1194 - 194)];
    gets (VliVvAFQxP);
    char bbV1jsuz5dG;
    bbV1jsuz5dG = toupper (VliVvAFQxP[0]);
    int dfPBYgaLxZ = (502 - 502);
    for (; VliVvAFQxP[len];)
        len++;
    for (k1hLWcse5gqy = 0; k1hLWcse5gqy <= len;) {
        if (toupper (VliVvAFQxP[k1hLWcse5gqy]) == bbV1jsuz5dG) {
            k1hLWcse5gqy++;
            dfPBYgaLxZ = dfPBYgaLxZ + 1;
        }
        else {
            printf ("(%c,%d)", bbV1jsuz5dG, dfPBYgaLxZ);
            bbV1jsuz5dG = toupper (VliVvAFQxP[k1hLWcse5gqy]);
            dfPBYgaLxZ = 0;
        };
    }
    return 0;
}

