main () {
    char m;
    int a, b, c, xMebaYKxO37, j, l, FwZfsOM53, n;
    char d [(2340 - 340)];
    int HgdX4aITKEU [(10585 - 585)];
    scanf ("%s", d);
    n = (715 - 715);
    l = strlen (d);
    for (xMebaYKxO37 = (259 - 259); xMebaYKxO37 < l; xMebaYKxO37 = xMebaYKxO37 + 1)
        if (d[xMebaYKxO37] >= 'a' && 'z' >= d[xMebaYKxO37])
            d[xMebaYKxO37] = d[xMebaYKxO37] - 'a' + 'A';
    {
        xMebaYKxO37 = 752 - 752;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (xMebaYKxO37 < (1548 - 548)) {
            HgdX4aITKEU[xMebaYKxO37] = 0;
            xMebaYKxO37++;
        };
    }
    {
        xMebaYKxO37 = 0;
        while (xMebaYKxO37 < l) {
            n = n + 1;
            if (d[xMebaYKxO37 + 1] != d[xMebaYKxO37]) {
                m = d[xMebaYKxO37];
                printf ("(%c,%d)", m, n);
                n = 0;
            }
            xMebaYKxO37++;
        };
    }
    getchar ();
    getchar ();
}

