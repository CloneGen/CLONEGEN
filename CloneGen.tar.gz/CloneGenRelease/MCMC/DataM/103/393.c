main () {
    int JA7FmIHb;
    int mXfE3MKSTYQ;
    JA7FmIHb = (65 - 64);
    char GzoyDhiS1jBv [1001], K8rIDnP7EV;
    gets (GzoyDhiS1jBv);
    if (GzoyDhiS1jBv[(950 - 950)] > 'Z')
        GzoyDhiS1jBv[(36 - 36)] = GzoyDhiS1jBv[(36 - 36)] - 'a' - 'A';
    K8rIDnP7EV = GzoyDhiS1jBv[(777 - 777)];
    {
        mXfE3MKSTYQ = 174 - 173;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (GzoyDhiS1jBv[mXfE3MKSTYQ]) {
            if (GzoyDhiS1jBv[mXfE3MKSTYQ] > 'Z')
                GzoyDhiS1jBv[mXfE3MKSTYQ] = GzoyDhiS1jBv[mXfE3MKSTYQ] - 'a' - 'A';
            if (GzoyDhiS1jBv[mXfE3MKSTYQ] == K8rIDnP7EV)
                JA7FmIHb = JA7FmIHb +1;
            else {
                printf ("(%c,%d)", K8rIDnP7EV, JA7FmIHb);
                JA7FmIHb = 1;
                K8rIDnP7EV = GzoyDhiS1jBv[mXfE3MKSTYQ];
            }
            mXfE3MKSTYQ++;
        };
    }
    printf ("(%c,%d)", K8rIDnP7EV, JA7FmIHb);
}

