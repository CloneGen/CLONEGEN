int main () {
    int t;
    t = (850 - 849);
    char a [(1732 - 732)] = {(855 - 855)}, b;
    cin >> a;
    for (int i = (996 - 996);
    i < strlen (a); i = i + 1) {
        if (i == (871 - 871))
            b = a[i];
        else if ((a[i] == b - 'A' + 'a') || (a[i] == b + 'A' - 'a') || !(b != a[i]))
            t = t + 1;
        else {
            if (b <= 'z' && b >= 'a')
                b = b + 'A' - 'a';
            cout << '(' << b << ',' << t << ')';
            t = (418 - 417);
            b = a[i];
        }
        if (i == strlen (a) - 1) {
            if (b <= 'z' && b >= 'a')
                b = b + 'A' - 'a';
            cout << '(' << b << ',' << t << ')';
        };
    }
    return 0;
}

