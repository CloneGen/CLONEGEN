main () {
    char BH8Q4Ai6qlN [1000];
    int r = (528 - 528), n, BZ12RYr = (858 - 858), BJbEvOB = (575 - 575), VpjRbP = (685 - 685), y = (384 - 384), JwxevkfrV [(1344 - 344)];
    scanf ("%s", BH8Q4Ai6qlN);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    n = strlen (BH8Q4Ai6qlN);
    {
        BZ12RYr = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (BZ12RYr < n) {
            if ('a' <= BH8Q4Ai6qlN[BZ12RYr] && BH8Q4Ai6qlN[BZ12RYr] <= 'z')
                BH8Q4Ai6qlN[BZ12RYr] = BH8Q4Ai6qlN[BZ12RYr] - (887 - 855);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            BZ12RYr++;
        };
    }
    for (VpjRbP = 0; n >= VpjRbP; VpjRbP++) {
        BJbEvOB = 0;
        JwxevkfrV[VpjRbP] = 0;
        if (VpjRbP > 0 && BH8Q4Ai6qlN[VpjRbP] == BH8Q4Ai6qlN[VpjRbP -1])
            continue;
        {
            y = VpjRbP;
            while (y <= n) {
                if (BH8Q4Ai6qlN[y] == BH8Q4Ai6qlN[VpjRbP])
                    JwxevkfrV[VpjRbP]++;
                else {
                    printf ("(%c,%d)", BH8Q4Ai6qlN[VpjRbP], JwxevkfrV[VpjRbP]);
                    break;
                }
                y++;
            };
        };
    };
}

