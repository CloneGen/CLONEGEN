struct   Soe5ilxKaVq {
    char lhviwjZU0Sk;
    int x;
}
Soe5ilxKaVq [1000];

main () {
    char dvtrVTRk;
    char WxpEH1u48o;
    char XGW4bjqz [1100];
    char A16lcze0d;
    char RI5E9Ow;
    char j;
    char cMCj9OLk;
    dvtrVTRk = (954 - 954);
    WxpEH1u48o = (484 - 484);
    scanf ("%s", XGW4bjqz);
    RI5E9Ow = strlen (XGW4bjqz);
    XGW4bjqz[RI5E9Ow] = '\0';
    for (A16lcze0d = (469 - 469); A16lcze0d < RI5E9Ow; A16lcze0d++) {
        if (XGW4bjqz[A16lcze0d] >= 'a' && 'z' >= XGW4bjqz[A16lcze0d])
            XGW4bjqz[A16lcze0d] = XGW4bjqz[A16lcze0d] - 'a' + 'A';
    }
    cMCj9OLk = XGW4bjqz[0];
    for (A16lcze0d = 0; A16lcze0d <= RI5E9Ow; A16lcze0d++) {
        if (!(cMCj9OLk != XGW4bjqz[A16lcze0d])) {
            WxpEH1u48o = WxpEH1u48o +1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (XGW4bjqz[A16lcze0d] != cMCj9OLk && XGW4bjqz[A16lcze0d] != '\0') {
            Soe5ilxKaVq[dvtrVTRk].lhviwjZU0Sk = XGW4bjqz[A16lcze0d -(655 - 654)];
            cMCj9OLk = XGW4bjqz[A16lcze0d];
            Soe5ilxKaVq[dvtrVTRk].x = WxpEH1u48o;
            WxpEH1u48o = (308 - 307);
            dvtrVTRk++;
        }
        if (XGW4bjqz[A16lcze0d] == '\0' && XGW4bjqz[A16lcze0d -(346 - 345)] != '\0' && XGW4bjqz[A16lcze0d] != cMCj9OLk) {
            Soe5ilxKaVq[dvtrVTRk].lhviwjZU0Sk = XGW4bjqz[A16lcze0d -1];
            Soe5ilxKaVq[dvtrVTRk].x = WxpEH1u48o;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            dvtrVTRk++;
            break;
        };
    }
    {
        A16lcze0d = 0;
        while (A16lcze0d < dvtrVTRk) {
            printf ("(%c,%d)", Soe5ilxKaVq[A16lcze0d].lhviwjZU0Sk, Soe5ilxKaVq[A16lcze0d].x);
            A16lcze0d++;
        };
    };
}

