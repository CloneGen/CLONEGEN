int main () {
    int iAq2TL;
    int k1NFsthPR;
    char yd6fl8JStVa [(1037 - 37)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int ugOUMlIL = (667 - 666);
    scanf ("%s", yd6fl8JStVa);
    for (iAq2TL = (853 - 853); !('\0' == yd6fl8JStVa[iAq2TL]); iAq2TL++) {
        if ('a' <= yd6fl8JStVa[iAq2TL] && yd6fl8JStVa[iAq2TL] <= 'z') {
            yd6fl8JStVa[iAq2TL] = yd6fl8JStVa[iAq2TL] + 'A' - 'a';
        };
    }
    {
        k1NFsthPR = 836 - 836;
        while (yd6fl8JStVa[k1NFsthPR] != '\0') {
            if (yd6fl8JStVa[k1NFsthPR] == yd6fl8JStVa[k1NFsthPR + 1]) {
                ugOUMlIL++;
            }
            else {
                printf ("(%c,%d)", yd6fl8JStVa[k1NFsthPR], ugOUMlIL);
                ugOUMlIL = 1;
            }
            k1NFsthPR = k1NFsthPR + 1;
        };
    }
    return 0;
}

