int main () {
    char LD8uhZ7QKes [1001];
    char SZ856QvTM;
    int fMLaRF8Qls;
    int A08GtvLNcuO;
    int j;
    int l;
    fMLaRF8Qls = (528 - 528);
    cin.getline (LD8uhZ7QKes, (1220 - 220));
    l = strlen (LD8uhZ7QKes);
    LD8uhZ7QKes[l] = '.';
    {
        A08GtvLNcuO = 960 - 960;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (A08GtvLNcuO <= l - (832 - 831)) {
            if (LD8uhZ7QKes[A08GtvLNcuO] >= 'a' && LD8uhZ7QKes[A08GtvLNcuO] <= 'z') {
                LD8uhZ7QKes[A08GtvLNcuO] = LD8uhZ7QKes[A08GtvLNcuO] + ('A' - 'a');
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            A08GtvLNcuO = A08GtvLNcuO +1;
        };
    }
    SZ856QvTM = LD8uhZ7QKes[0];
    {
        A08GtvLNcuO = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (A08GtvLNcuO <= l) {
            if (LD8uhZ7QKes[A08GtvLNcuO] == SZ856QvTM) {
                fMLaRF8Qls = fMLaRF8Qls + 1;
            }
            if (LD8uhZ7QKes[A08GtvLNcuO] != SZ856QvTM) {
                cout << "(" << SZ856QvTM << "," << fMLaRF8Qls << ")";
                fMLaRF8Qls = 1;
                SZ856QvTM = LD8uhZ7QKes[A08GtvLNcuO];
            }
            A08GtvLNcuO++;
        };
    }
    cin.get ();
    return 0;
}

