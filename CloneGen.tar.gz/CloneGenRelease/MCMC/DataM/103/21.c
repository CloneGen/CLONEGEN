int main () {
    char a [1000];
    char bo8MEZnz05m;
    int i;
    int roA2fUcad8;
    cin >> a;
    {
        i = 584 - 584;
        while (strlen (a) > i) {
            if (96 < a[i]) {
                a[i] = a[i] - 32;
            }
            i++;
        };
    }
    bo8MEZnz05m = a[0];
    roA2fUcad8 = (968 - 967);
    for (i = (97 - 96); i < strlen (a) + 1; i++) {
        if (a[i] == bo8MEZnz05m) {
            roA2fUcad8 = roA2fUcad8 + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            };
        }
        else {
            cout << "(" << bo8MEZnz05m << "," << roA2fUcad8 << ")";
            bo8MEZnz05m = a[i];
            roA2fUcad8 = 1;
        };
    }
    cout << endl;
    return 0;
}

