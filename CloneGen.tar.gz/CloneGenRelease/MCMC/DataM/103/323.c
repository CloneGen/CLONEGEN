main () {
    char xOG0DIncQH [(1833 - 832)];
    char t [(1398 - 397)];
    int p;
    int uPHcTXQ [(1203 - 202)];
    int rXw4oTP90ADa;
    int msMlBhwQ0;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int h;
    p = (512 - 512);
    scanf ("%s", xOG0DIncQH);
    k = strlen (xOG0DIncQH);
    {
        h = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (h <= k - (882 - 881)) {
            if (xOG0DIncQH[h] >= 'a' && 'z' >= xOG0DIncQH[h])
                xOG0DIncQH[h] = xOG0DIncQH[h] + ('A' - 'a');
            h = h + 1;
        };
    }
    uPHcTXQ[(611 - 611)] = (708 - 707);
    if (k == (791 - 790))
        printf ("(%c,1)", xOG0DIncQH[0]);
    else {
        for (rXw4oTP90ADa = 0; rXw4oTP90ADa <= k - 2; rXw4oTP90ADa++) {
            t[p] = xOG0DIncQH[rXw4oTP90ADa];
            if (xOG0DIncQH[rXw4oTP90ADa] == xOG0DIncQH[rXw4oTP90ADa + 1]) {
                uPHcTXQ[p]++;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                };
            }
            else {
                p = p + 1;
                t[p] = xOG0DIncQH[rXw4oTP90ADa + 1];
                uPHcTXQ[p] = 1;
            };
        }
        {
            msMlBhwQ0 = 0;
            while (msMlBhwQ0 <= p) {
                printf ("(%c,%d)", t[msMlBhwQ0], uPHcTXQ[msMlBhwQ0]);
                msMlBhwQ0 = msMlBhwQ0 + 1;
            };
        };
    };
}

