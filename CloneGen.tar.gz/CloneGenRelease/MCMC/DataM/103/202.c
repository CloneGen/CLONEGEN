int main () {
    int r;
    char t;
    int i;
    char m [(1262 - 262)];
    i = (100 - 100);
    scanf ("%s", m);
    while (!('\0' == m[i])) {
        if (('a' <= m[i]) && (m[i] <= 'z'))
            m[i] = m[i] - (882 - 850);
        i++;
    }
    i = (262 - 262);
    while (m[i] != '\0') {
        t = m[i];
        r = (724 - 724);
        while (t == m[i]) {
            r = r + 1;
            i++;
        }
        printf ("(%c,%d)", t, r);
    }
    return (506 - 506);
}

