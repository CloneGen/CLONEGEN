int main () {
    int GkdRCuGz7gc;
    int bcT5r8Iv;
    GkdRCuGz7gc = 0;
    char eGBA8mUgqzc [(1064 - 63)] = {0};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char F0igUT8Oayqt = toupper (eGBA8mUgqzc[0]);
    cin >> eGBA8mUgqzc;
    for (bcT5r8Iv = 0; strlen (eGBA8mUgqzc) > bcT5r8Iv; bcT5r8Iv = bcT5r8Iv + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(F0igUT8Oayqt != eGBA8mUgqzc[bcT5r8Iv]) || toupper (eGBA8mUgqzc[bcT5r8Iv]) == F0igUT8Oayqt)
            GkdRCuGz7gc = GkdRCuGz7gc +1;
        else {
            cout << '(' << F0igUT8Oayqt << ',' << GkdRCuGz7gc << ')';
            GkdRCuGz7gc = (584 - 583);
            F0igUT8Oayqt = toupper (eGBA8mUgqzc[bcT5r8Iv]);
        };
    }
    cout << '(' << F0igUT8Oayqt << ',' << GkdRCuGz7gc << ')' << endl;
    return 0;
}

