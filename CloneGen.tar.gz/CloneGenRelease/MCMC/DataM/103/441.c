main () {
    int yN9CFvr71 [(1575 - 575)];
    char a [(1691 - 691)];
    int hl2b41;
    int dZNL7yMrd;
    int j;
    scanf ("%s", a);
    dZNL7yMrd = strlen (a);
    {
        hl2b41 = 776 - 776;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (hl2b41 < (1639 - 639)) {
            yN9CFvr71[hl2b41] = (326 - 325);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            hl2b41 = hl2b41 + 1;
        };
    }
    for (hl2b41 = 0; dZNL7yMrd > hl2b41; hl2b41 = hl2b41 + 1) {
        for (j = hl2b41 + 1; j < dZNL7yMrd; j = j + 1) {
            if (a[j] == a[hl2b41] || a[j] == a[hl2b41] - 'a' + 'A' || a[j] == a[hl2b41] - 'A' + 'a')
                yN9CFvr71[hl2b41]++;
            else
                break;
        }
        if (a[hl2b41] >= 'a' && a[hl2b41] <= 'z')
            a[hl2b41] = a[hl2b41] - 'a' + 'A';
        printf ("(%c,%d)", a[hl2b41], yN9CFvr71[hl2b41]);
        hl2b41 = j - 1;
    };
}

