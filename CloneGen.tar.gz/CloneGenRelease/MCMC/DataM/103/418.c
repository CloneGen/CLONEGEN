main () {
    char XTD4FrO02eP [10000];
    char N2ZOPcm0;
    int x;
    int u;
    int i;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    u = (243 - 242);
    scanf ("%s", XTD4FrO02eP);
    x = strlen (XTD4FrO02eP);
    for (i = (178 - 178); i < x; i++) {
        if (XTD4FrO02eP[i] >= 'a' && XTD4FrO02eP[i] <= 'z')
            XTD4FrO02eP[i] = XTD4FrO02eP[i] + 'A' - 'a';
    }
    N2ZOPcm0 = XTD4FrO02eP[0];
    if (!((106 - 105) != x))
        printf ("(%c,%d)", N2ZOPcm0, u);
    else {
        if ((581 - 580) < x) {
            for (i = (894 - 893); i < x; i++) {
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (XTD4FrO02eP[i] == N2ZOPcm0) {
                    u = u + 1;
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    }
                    if (i == x - 1)
                        printf ("(%c,%d)", N2ZOPcm0, u);
                }
                else {
                    printf ("(%c,%d)", N2ZOPcm0, u);
                    N2ZOPcm0 = XTD4FrO02eP[i];
                    u = 1;
                    if (i == x - 1)
                        printf ("(%c,%d)", N2ZOPcm0, u);
                };
            };
        };
    };
}

