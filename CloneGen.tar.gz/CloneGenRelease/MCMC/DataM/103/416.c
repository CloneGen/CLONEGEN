main () {
    int i, HJFqQwDu7, Jc7gsbFRSDX = (505 - 505), l, tem = (414 - 413);
    char a [1000];
    scanf ("%s", &a);
    l = strlen (a);
    {
        i = 0;
        while (l > i) {
            if ('a' <= a[i] && a[i] <= 'z')
                a[i] = a[i] - 32;
            i = i + 1;
        };
    }
    if (!(1 != l))
        printf ("(%c,1)", a[0]);
    else
        do {
            tem = 1;
            {
                HJFqQwDu7 = Jc7gsbFRSDX +1;
                while (HJFqQwDu7 <= l) {
                    if (a[Jc7gsbFRSDX] != a[HJFqQwDu7]) {
                        printf ("(%c,%d)", a[Jc7gsbFRSDX], tem);
                        Jc7gsbFRSDX = HJFqQwDu7;
                        break;
                    }
                    else
                        tem = tem + 1;
                    HJFqQwDu7++;
                };
            };
        }
        while (Jc7gsbFRSDX < l);
}

