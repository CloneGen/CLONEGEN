main () {
    int oBtbOpvUYK, mKBNon = (310 - 309);
    char l [1000];
    scanf ("%s", l);
    {
        oBtbOpvUYK = 295 - 295;
        while (l[oBtbOpvUYK] != '\0') {
            if ((l[oBtbOpvUYK + (1001 - 1000)] == l[oBtbOpvUYK]) || (l[oBtbOpvUYK + (941 - 940)] == l[oBtbOpvUYK] + (986 - 954)) || (l[oBtbOpvUYK + 1] == l[oBtbOpvUYK] - 32))
                mKBNon = mKBNon + 1;
            else if (l[oBtbOpvUYK] >= 'a' && l[oBtbOpvUYK] <= 'z') {
                printf ("(%c,%d)", l[oBtbOpvUYK] - 32, mKBNon);
                mKBNon = 1;
            }
            else {
                printf ("(%c,%d)", l[oBtbOpvUYK], mKBNon);
                mKBNon = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            oBtbOpvUYK = oBtbOpvUYK + 1;
        };
    }
    return 0;
}

