int main () {
    char l6GpoRrxk [1001];
    char s2 [1001];
    int num;
    int JCUnKAcf2pQM;
    int i;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    num = 1;
    cin >> l6GpoRrxk;
    JCUnKAcf2pQM = strlen (l6GpoRrxk);
    for (i = 0; JCUnKAcf2pQM > i; i = i + 1) {
        if (l6GpoRrxk[i] > 90)
            s2[i] = l6GpoRrxk[i] - 32;
        else
            s2[i] = l6GpoRrxk[i];
    }
    if (!(1 != JCUnKAcf2pQM)) {
        cout << '(' << s2[0] << ',' << num << ')';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        return 0;
    }
    for (i = 1; JCUnKAcf2pQM > i; i++) {
        if (!(s2[i - 1] == s2[i]) && !(JCUnKAcf2pQM -1 == i)) {
            cout << '(' << s2[i - 1] << ',' << num << ')';
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            num = 1;
        }
        if (!(s2[i - 1] == s2[i]) && i == JCUnKAcf2pQM -1) {
            cout << '(' << s2[i - 1] << ',' << num << ')';
            num = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            cout << '(' << s2[i] << ',' << num << ')';
        }
        if (s2[i] == s2[i - 1] && i != JCUnKAcf2pQM -1)
            num++;
        if (s2[i] == s2[i - 1] && i == JCUnKAcf2pQM -1) {
            num++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            cout << '(' << s2[i - 1] << ',' << num << ')';
        };
    }
    return 0;
}

