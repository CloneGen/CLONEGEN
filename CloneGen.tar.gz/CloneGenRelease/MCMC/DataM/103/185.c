int main () {
    char mSgel9r6uW [(1319 - 318)];
    int i, vxmFPTBS;
    scanf ("%s", mSgel9r6uW);
    {
        i = 991 - 991;
        while (strlen (mSgel9r6uW) > i) {
            if (mSgel9r6uW[i] >= 'a' && mSgel9r6uW[i] <= 'z') {
                mSgel9r6uW[i] = mSgel9r6uW[i] - 'a' + 'A';
            }
            i = i + 1;
        };
    }
    vxmFPTBS = 1;
    i = 0;
    while (i < strlen (mSgel9r6uW)) {
        if (mSgel9r6uW[i] == mSgel9r6uW[i + 1]) {
            vxmFPTBS = vxmFPTBS + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            };
        }
        else {
            printf ("(%c,%d)", mSgel9r6uW[i], vxmFPTBS);
            vxmFPTBS = 1;
        }
        i = i + 1;
    };
}

