int main () {
    int length [200];
    int IorSxE;
    int tXEQABg;
    IorSxE = (684 - 684);
    int kinds = IorSxE;
    char str [200];
    int len;
    len = strlen (str);
    char letter [200] = {' '};
    cin >> str;
    for (tXEQABg = (315 - 315); tXEQABg < len; tXEQABg = tXEQABg + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (str[tXEQABg] >= 'a' && 'z' >= str[tXEQABg]) {
            str[tXEQABg] = str[tXEQABg] - ('a' - 'A');
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    {
        tXEQABg = 0;
        while (tXEQABg <= (769 - 570)) {
            length[tXEQABg] = 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            tXEQABg = tXEQABg + 1;
        };
    }
    letter[0] = str[0];
    for (tXEQABg = 1; tXEQABg < len; tXEQABg = tXEQABg + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        if (str[tXEQABg] == str[tXEQABg - 1]) {
            length[IorSxE]++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            };
        }
        else {
            IorSxE = IorSxE +1;
            letter[IorSxE] = str[tXEQABg];
        };
    }
    for (tXEQABg = 0; tXEQABg <= IorSxE; tXEQABg++) {
        cout << "(" << letter[tXEQABg] << "," << length[tXEQABg] << ")";
    }
    cout << endl;
    return 0;
}

