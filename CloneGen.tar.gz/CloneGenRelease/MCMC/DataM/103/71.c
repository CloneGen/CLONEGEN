int main () {
    int a;
    char c [1000];
    int BgcBGqUWfo;
    int l;
    gets (c);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    l = strlen (c);
    for (BgcBGqUWfo = (649 - 649); l > BgcBGqUWfo; BgcBGqUWfo++)
        if (97 <= c[BgcBGqUWfo] && (339 - 217) >= c[BgcBGqUWfo])
            c[BgcBGqUWfo] = c[BgcBGqUWfo] - 32;
    a = (659 - 659);
    {
        BgcBGqUWfo = 0;
        while (BgcBGqUWfo < l) {
            if (c[BgcBGqUWfo] == c[BgcBGqUWfo +(71 - 70)])
                a = a + 1;
            else {
                cout << "(" << c[BgcBGqUWfo] << "," << a + (456 - 455) << ")";
                a = 0;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            BgcBGqUWfo++;
        };
    }
    return 0;
}

