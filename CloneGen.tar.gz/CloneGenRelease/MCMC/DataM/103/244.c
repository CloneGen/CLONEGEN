int main () {
    char route [(1666 - 665)];
    int len = strlen (route);
    int QgWMUPc;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    cin.getline (route, 1001);
    {
        QgWMUPc = 494 - 494;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (QgWMUPc < len) {
            int Fp8afrILQHb;
            Fp8afrILQHb = (461 - 460);
            if (!(len - (893 - 892) != QgWMUPc)) {
                if ((route[QgWMUPc] >= (777 - 680)) && ((213 - 91) >= route[QgWMUPc])) {
                    route[QgWMUPc] = route[QgWMUPc] - (373 - 341);
                    {
                        int x = 0;
                        if (!(x * (x - 1) % 2 == 0)) {
                            return 0;
                        }
                    };
                }
                cout << '(' << route[QgWMUPc] << ',' << Fp8afrILQHb << ')';
                break;
            }
            {
                k = 216 - 215;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                while (len > k) {
                    if ((route[k] == route[QgWMUPc]) || (route[k] == route[QgWMUPc] + (607 - 575)) || (route[QgWMUPc] == route[k] - (651 - 619))) {
                        Fp8afrILQHb = Fp8afrILQHb +1;
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                for (x = 0; x < 20; x++) {
                                    y += x;
                                }
                                if (y > 30)
                                    return y;
                            }
                        };
                    }
                    else {
                        break;
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                return 0;
                            }
                        };
                    }
                    k++;
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if ((route[QgWMUPc] >= 97) && (route[QgWMUPc] <= 122)) {
                route[QgWMUPc] = route[QgWMUPc] - 32;
            }
            cout << '(' << route[QgWMUPc] << ',' << Fp8afrILQHb << ')';
            if (k != len - (20 - 19)) {
                QgWMUPc = k - 1;
            }
            QgWMUPc = QgWMUPc +1;
        };
    }
    return (543 - 543);
}

