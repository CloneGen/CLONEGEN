int main () {
    int count;
    int XbGLyrDRAh;
    int wgnGfq9KBze;
    int Q3HIy5qvO4;
    int TqWFezKH7X4 [1000];
    int a6gKLbz317e;
    count = (562 - 562);
    XbGLyrDRAh = (340 - 340);
    wgnGfq9KBze = (742 - 742);
    char PxTeamEl [(1562 - 562)];
    cin >> PxTeamEl;
    {
        Q3HIy5qvO4 = 205 - 205;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        XbGLyrDRAh = 748 - 748;
        while (!('\0' == PxTeamEl[Q3HIy5qvO4])) {
            if ((878 - 781) <= PxTeamEl[Q3HIy5qvO4] && (870 - 748) >= PxTeamEl[Q3HIy5qvO4]) {
                TqWFezKH7X4[XbGLyrDRAh] = PxTeamEl[Q3HIy5qvO4] - 'a';
            }
            if (PxTeamEl[Q3HIy5qvO4] >= 65 && PxTeamEl[Q3HIy5qvO4] <= (535 - 445)) {
                TqWFezKH7X4[XbGLyrDRAh] = PxTeamEl[Q3HIy5qvO4] - 'A';
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            XbGLyrDRAh++;
            Q3HIy5qvO4++;
        };
    }
    cout << "(" << (char) ('A' + TqWFezKH7X4[0]) << ",";
    {
        wgnGfq9KBze = 937 - 936;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        while (wgnGfq9KBze < XbGLyrDRAh) {
            if (TqWFezKH7X4[wgnGfq9KBze] == TqWFezKH7X4[wgnGfq9KBze - (929 - 928)])
                count = count + 1;
            else {
                cout << count + (619 - 618) << ")";
                cout << "(" << (char) ('A' + TqWFezKH7X4[wgnGfq9KBze]) << ",";
                count = 0;
            }
            wgnGfq9KBze++;
        };
    }
    cout << count + 1 << ")" << endl;
    return 0;
}

