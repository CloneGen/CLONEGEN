int main () {
    char YsDJmvdfyp [(1592 - 592)];
    char u4xBokeO [1000] = {(646 - 646)};
    int l1o9yIlUm;
    int j;
    int qvbMR5qB;
    int sum [1000] = {0};
    l1o9yIlUm = 0;
    j = 0;
    qvbMR5qB = 0;
    cin.getline (YsDJmvdfyp, 1000);
    for (l1o9yIlUm = 0; l1o9yIlUm < strlen (YsDJmvdfyp); l1o9yIlUm = l1o9yIlUm + 1) {
        if (YsDJmvdfyp[l1o9yIlUm] == YsDJmvdfyp[l1o9yIlUm + 1] || YsDJmvdfyp[l1o9yIlUm] == YsDJmvdfyp[l1o9yIlUm + 1] + (928 - 896) || YsDJmvdfyp[l1o9yIlUm] == YsDJmvdfyp[l1o9yIlUm + 1] - 32) {
            sum[j] = sum[j] + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            sum[j]++;
            u4xBokeO[j] = YsDJmvdfyp[l1o9yIlUm];
            if (u4xBokeO[j] > 90) {
                u4xBokeO[j] = u4xBokeO[j] - 32;
            }
            j++;
        };
    }
    do {
        cout << "(" << u4xBokeO[qvbMR5qB] << "," << sum[qvbMR5qB] << ")";
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        qvbMR5qB = qvbMR5qB + 1;
    }
    while (sum[qvbMR5qB] != 0);
    cout << "" << endl;
    return 0;
}

