char l (char iZ9K0xUzFQAS) {
    if (iZ9K0xUzFQAS >= 'a' && iZ9K0xUzFQAS <= 'z')
        return iZ9K0xUzFQAS + 'A' - 'a';
    else
        return iZ9K0xUzFQAS;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
}

int main () {
    char KkQwNATsJPY [1001];
    char iZ9K0xUzFQAS = l (KkQwNATsJPY[0]);
    int mHoWCtyUJr = 1;
    cin >> KkQwNATsJPY;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    {
        int q9fRyAkScF46 = 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (q9fRyAkScF46 <= strlen (KkQwNATsJPY)) {
            if (iZ9K0xUzFQAS == l (KkQwNATsJPY[q9fRyAkScF46]))
                mHoWCtyUJr++;
            else {
                cout << '(' << iZ9K0xUzFQAS << ',' << mHoWCtyUJr << ')';
                mHoWCtyUJr = 1;
                iZ9K0xUzFQAS = l (KkQwNATsJPY[q9fRyAkScF46]);
            }
            q9fRyAkScF46++;
        };
    }
    cout << endl;
    return 0;
}

