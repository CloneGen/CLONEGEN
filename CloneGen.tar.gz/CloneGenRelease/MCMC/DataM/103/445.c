int main () {
    char a [(1039 - 39)];
    gets (a);
    int t;
    int i;
    int UEbAzl;
    int s;
    t = (248 - 248);
    UEbAzl = strlen (a);
    s = a[(979 - 979)];
    {
        i = 163 - 163;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < UEbAzl) {
            if (!(a[i] != s) || !(a[i] + (796 - 764) != s) || s == a[i] - (89 - 57))
                t = t + 1;
            else {
                if (s > 'Z')
                    printf ("(%c,%d)", s - (170 - 138), t);
                else
                    printf ("(%c,%d)", s, t);
                t = 1;
                s = a[i];
            }
            i = i + 1;
        };
    }
    if (s > 'Z')
        printf ("(%c,%d)", s - 32, t);
    else
        printf ("(%c,%d)", s, t);
    return (562 - 562);
}

