main () {
    int ZNpU9wLQv34, gg3RBmatLTV, atVviNZ8sU2, p;
    char a [1000];
    char BiTEasA [1000];
    p = (754 - 753);
    gg3RBmatLTV = 'A' - 'a';
    scanf ("%s", a);
    for (ZNpU9wLQv34 = (306 - 306); a[ZNpU9wLQv34] != '\0'; ZNpU9wLQv34 = ZNpU9wLQv34 +1) {
        if (a[ZNpU9wLQv34] >= 'a' && a[ZNpU9wLQv34] <= 'z')
            BiTEasA[ZNpU9wLQv34] = a[ZNpU9wLQv34] + gg3RBmatLTV;
        else
            BiTEasA[ZNpU9wLQv34] = a[ZNpU9wLQv34];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    BiTEasA[ZNpU9wLQv34] = '\0';
    {
        atVviNZ8sU2 = 0;
        while (BiTEasA[atVviNZ8sU2 + (222 - 221)] != '\0') {
            if (BiTEasA[atVviNZ8sU2] == BiTEasA[atVviNZ8sU2 + (592 - 591)]) {
                p = p + (636 - 635);
            }
            else {
                printf ("(%c,%d)", BiTEasA[atVviNZ8sU2], p);
                p = 1;
            }
            atVviNZ8sU2 = atVviNZ8sU2 + 1;
        };
    }
    printf ("(%c,%d)", BiTEasA[atVviNZ8sU2], p);
}

