int main () {
    char ikhyDQG [1001];
    int D9vbVnxR;
    int APgIOlGRus;
    int NMr8doLXIcfx;
    D9vbVnxR = (798 - 797);
    gets (ikhyDQG);
    NMr8doLXIcfx = strlen (ikhyDQG);
    if (NMr8doLXIcfx == (427 - 426))
        printf ("(%c,%d)", ikhyDQG[(162 - 162)] % (103 - 71) + (273 - 209), (942 - 941));
    else
        for (APgIOlGRus = (342 - 341); NMr8doLXIcfx > APgIOlGRus; APgIOlGRus = APgIOlGRus +1) {
            if ((ikhyDQG[APgIOlGRus] % (517 - 485)) == (ikhyDQG[APgIOlGRus -1] % (475 - 443)))
                D9vbVnxR = D9vbVnxR +1;
            else {
                printf ("(%c,%d)", ikhyDQG[APgIOlGRus -1] % (632 - 600) + (575 - 511), D9vbVnxR);
                D9vbVnxR = 1;
            }
            if (APgIOlGRus == NMr8doLXIcfx -1)
                printf ("(%c,%d)", ikhyDQG[APgIOlGRus] % 32 + 64, D9vbVnxR);
        }
    return (241 - 241);
}

