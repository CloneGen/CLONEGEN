void  main () {
    int cmtCdb;
    int k;
    int u4Y2ADNw;
    cmtCdb = (907 - 907);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    k = (527 - 527);
    char QSWEOVNhbY8L [100];
    for (u4Y2ADNw = 0;; u4Y2ADNw = u4Y2ADNw + 1) {
        scanf ("%c", &QSWEOVNhbY8L[u4Y2ADNw]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (QSWEOVNhbY8L[u4Y2ADNw] == '\n')
            break;
    }
    cmtCdb = u4Y2ADNw;
    for (u4Y2ADNw = 0; u4Y2ADNw < cmtCdb; u4Y2ADNw = u4Y2ADNw + 1) {
        if ('Z' < QSWEOVNhbY8L[u4Y2ADNw])
            QSWEOVNhbY8L[u4Y2ADNw] = QSWEOVNhbY8L[u4Y2ADNw] - 32;
    }
    for (u4Y2ADNw = 0; u4Y2ADNw < cmtCdb; u4Y2ADNw++) {
        k += (132 - 131);
        if (QSWEOVNhbY8L[u4Y2ADNw + 1] != QSWEOVNhbY8L[u4Y2ADNw]) {
            printf ("(%c,%d)", QSWEOVNhbY8L[u4Y2ADNw], k);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            k = 0;
        };
    };
}

