int main () {
    char Pwegm5cq;
    Pwegm5cq = (726 - 726);
    char sw2BKb4OdLI [(1254 - 154)];
    gets (sw2BKb4OdLI);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int i, OpwjaCi3, Rf15bTSLAPw, cM5UR8hawl = (618 - 618);
    i = 0;
    while ((999 - 998)) {
        if (i > strlen (sw2BKb4OdLI))
            break;
        if ('z' >= sw2BKb4OdLI[i] && sw2BKb4OdLI[i] >= 'a')
            sw2BKb4OdLI[i] += 'A' - 'a';
        if (Pwegm5cq == 0) {
            cM5UR8hawl = 1;
            Pwegm5cq = sw2BKb4OdLI[i];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
            continue;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (sw2BKb4OdLI[i] == Pwegm5cq)
            cM5UR8hawl++;
        else {
            cout << "(" << Pwegm5cq << "," << cM5UR8hawl << ")";
            Pwegm5cq = sw2BKb4OdLI[i];
            cM5UR8hawl = 1;
        }
        i++;
    }
    return 0;
}

