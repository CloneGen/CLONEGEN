main () {
    int S4YEOrcqko = (693 - 692);
    char a [(1501 - 500)];
    int qepS9P, m, zu5WRYAFj;
    scanf ("%s", a);
    m = strlen (a);
    for (zu5WRYAFj = (542 - 542); m - (392 - 391) >= zu5WRYAFj; zu5WRYAFj++) {
        if ('a' <= a[zu5WRYAFj] && a[zu5WRYAFj] <= 'z')
            a[zu5WRYAFj] = a[zu5WRYAFj] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    if (!((602 - 601) != m))
        printf ("(%c,1)", a[0]);
    {
        qepS9P = 782 - 781;
        while (qepS9P <= m - (785 - 784)) {
            if (!(a[qepS9P - (310 - 309)] != a[qepS9P]) && qepS9P != m - (54 - 53))
                S4YEOrcqko = S4YEOrcqko +1;
            else {
                if (a[qepS9P] != a[qepS9P - (160 - 159)] && qepS9P != m - (892 - 891)) {
                    printf ("(%c,%d)", a[qepS9P - (469 - 468)], S4YEOrcqko);
                    S4YEOrcqko = 1;
                }
                else {
                    if (a[qepS9P] != a[qepS9P - 1] && qepS9P == m - 1)
                        printf ("(%c,%d)(%c,1)", a[qepS9P - 1], S4YEOrcqko, a[qepS9P]);
                    else {
                        if (a[qepS9P] == a[qepS9P - 1] && qepS9P == m - 1)
                            printf ("(%c,%d)", a[qepS9P], S4YEOrcqko +1);
                    };
                };
            }
            qepS9P = qepS9P + 1;
        };
    };
}

