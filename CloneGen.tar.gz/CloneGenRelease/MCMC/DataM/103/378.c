int main () {
    int QTxXeKB, u3zv2ea98R = (350 - 350), b, YeLv4E5Md7g;
    char sOfvCJ0 [1000];
    char bNQFoEUfL;
    QTxXeKB = 0;
    cin >> sOfvCJ0;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    bNQFoEUfL = sOfvCJ0[(877 - 877)];
    if ('a' <= bNQFoEUfL && 'z' >= bNQFoEUfL)
        bNQFoEUfL = bNQFoEUfL + ('A' - 'a');
    YeLv4E5Md7g = strlen (sOfvCJ0);
    for (u3zv2ea98R = 0; YeLv4E5Md7g >= u3zv2ea98R;) {
        b = sOfvCJ0[u3zv2ea98R] - bNQFoEUfL;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (b == 0 || b == ('a' - 'A')) {
            QTxXeKB = QTxXeKB +1;
            u3zv2ea98R = u3zv2ea98R + 1;
        }
        else {
            cout << "(" << bNQFoEUfL << "," << QTxXeKB << ")";
            bNQFoEUfL = sOfvCJ0[u3zv2ea98R];
            if (bNQFoEUfL >= 'a' && bNQFoEUfL <= 'z')
                bNQFoEUfL = 'A' + bNQFoEUfL - 'a';
            QTxXeKB = 0;
        };
    }
    return 0;
}

