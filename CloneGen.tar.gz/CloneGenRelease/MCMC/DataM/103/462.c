int main () {
    char c49YvqZUdbSM;
    char s [(1666 - 666)];
    int HawGZ5kD;
    int nFKQpzd;
    int LWLA0412MS3k;
    cin.getline (s, (1829 - 829));
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    HawGZ5kD = strlen (s);
    {
        nFKQpzd = 732 - 732;
        while (nFKQpzd < HawGZ5kD) {
            if (s[nFKQpzd] >= 'a' && 'z' >= s[nFKQpzd])
                s[nFKQpzd] = s[nFKQpzd] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            nFKQpzd = nFKQpzd + 1;
        };
    }
    c49YvqZUdbSM = s[(249 - 249)];
    nFKQpzd = (228 - 227);
    LWLA0412MS3k = (97 - 96);
    while (nFKQpzd < HawGZ5kD) {
        if (s[nFKQpzd] == c49YvqZUdbSM)
            LWLA0412MS3k = LWLA0412MS3k +1;
        else {
            cout << '(' << c49YvqZUdbSM << ',' << LWLA0412MS3k << ')';
            c49YvqZUdbSM = s[nFKQpzd];
            LWLA0412MS3k = 1;
        }
        nFKQpzd = nFKQpzd + 1;
    }
    cout << '(' << c49YvqZUdbSM << ',' << LWLA0412MS3k << ')';
    return (471 - 471);
}

