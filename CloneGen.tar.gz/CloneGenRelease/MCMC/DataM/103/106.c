int main () {
    char YplQHgRtW [(1352 - 351)];
    int num [(1912 - 911)] = {(382 - 382)};
    int QxRgZ4EL;
    int X4PcUhCA;
    int nlen;
    QxRgZ4EL = (267 - 267);
    cin.getline (YplQHgRtW, 1001);
    nlen = strlen (YplQHgRtW);
    {
        X4PcUhCA = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (nlen > X4PcUhCA) {
            if ((YplQHgRtW[X4PcUhCA] == YplQHgRtW[X4PcUhCA +(951 - 950)]) || (!(('a' - 'A') != (YplQHgRtW[X4PcUhCA] - YplQHgRtW[X4PcUhCA +(455 - 454)]))) || ((YplQHgRtW[X4PcUhCA] - YplQHgRtW[X4PcUhCA +1]) == ('A' - 'a')))
                num[QxRgZ4EL]++;
            else {
                num[QxRgZ4EL]++;
                QxRgZ4EL = QxRgZ4EL +1;
            }
            X4PcUhCA = X4PcUhCA +1;
        };
    }
    for (X4PcUhCA = 0, QxRgZ4EL = 0; 1001 > X4PcUhCA; X4PcUhCA++) {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (num[X4PcUhCA] != 0) {
            QxRgZ4EL = QxRgZ4EL +num[X4PcUhCA];
            cout << '(';
            if (YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]] >= 'A' && YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]] <= 'Z')
                cout << YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]];
            else if (YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]] >= 'a' && YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]] <= 'z')
                cout << (char) (YplQHgRtW[QxRgZ4EL -num[X4PcUhCA]] - 'a' + 'A');
            cout << ',' << num[X4PcUhCA] << ')';
        };
    }
    return 0;
}

