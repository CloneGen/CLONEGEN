main () {
    char b;
    char DaTcMRm [1001] = {'\0'};
    int Jj0aHU = (15 - 15), t7P6qX2nO1c3 = (117 - 117);
    scanf ("%s", DaTcMRm);
    for (; DaTcMRm[Jj0aHU] != '\0'; Jj0aHU = Jj0aHU +1) {
        if ('z' >= DaTcMRm[Jj0aHU] && DaTcMRm[Jj0aHU] >= 'a') {
            DaTcMRm[Jj0aHU] = DaTcMRm[Jj0aHU] + 'A' - 'a';
        };
    }
    Jj0aHU = (359 - 359);
    b = DaTcMRm[(217 - 217)];
    for (; DaTcMRm[Jj0aHU] != '\0'; Jj0aHU = Jj0aHU +1) {
        if (b == DaTcMRm[Jj0aHU])
            t7P6qX2nO1c3++;
        else {
            printf ("(%c,%d)", b, t7P6qX2nO1c3);
            t7P6qX2nO1c3 = (790 - 790);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            b = DaTcMRm[Jj0aHU];
            Jj0aHU = Jj0aHU -1;
        };
    }
    printf ("(%c,%d)", b, t7P6qX2nO1c3);
}

