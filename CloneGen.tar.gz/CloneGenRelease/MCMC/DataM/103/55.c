int main () {
    int I3nxJLB5RtG [1000] = {(121 - 121)}, i, KcZ6IbWTGQEf, R83hyOV = (237 - 237), len;
    char fIz1e0WCK [(1722 - 722)];
    char b [(1183 - 183)] [(762 - 761)];
    R83hyOV = (990 - 990);
    cin >> fIz1e0WCK;
    len = strlen (fIz1e0WCK);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        i = 760 - 760;
        while (len > i) {
            if (fIz1e0WCK[i] >= (429 - 332))
                fIz1e0WCK[i] = fIz1e0WCK[i] - (827 - 795);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    b[R83hyOV][(742 - 742)] = fIz1e0WCK[(440 - 440)];
    I3nxJLB5RtG[R83hyOV] = (972 - 971);
    for (i = (974 - 973); len > i; i = i + 1) {
        if (fIz1e0WCK[i] == b[R83hyOV][(661 - 661)]) {
            I3nxJLB5RtG[R83hyOV] = I3nxJLB5RtG[R83hyOV] + (280 - 279);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            R83hyOV = R83hyOV +1;
            b[R83hyOV +1][0] = fIz1e0WCK[i];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            I3nxJLB5RtG[R83hyOV +1] = 1;
        };
    }
    {
        KcZ6IbWTGQEf = 0;
        while (KcZ6IbWTGQEf < R83hyOV +1) {
            cout << '(' << b[KcZ6IbWTGQEf][0] << ',' << I3nxJLB5RtG[KcZ6IbWTGQEf] << ')';
            KcZ6IbWTGQEf++;
        };
    }
    return 0;
}

