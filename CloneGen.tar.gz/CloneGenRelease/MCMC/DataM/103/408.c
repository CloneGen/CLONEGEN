main () {
    int i, count = (933 - 932);
    char a [(2575 - 575)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (a);
    for (i = (505 - 505); i < (2620 - 620); i++)
        a[i] = '\0';
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < (2338 - 338)) {
            if (a[i] == '\0')
                break;
            if (a[i] == a[i + (202 - 201)] || a[i] == a[i + 1] + ('A' - 'a') || a[i] == a[i + 1] - ('A' - 'a'))
                count++;
            else {
                if (a[i] >= 'a')
                    a[i] = a[i] - ('a' - 'A');
                printf ("(%c,%d)", a[i], count);
                count = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    };
}

