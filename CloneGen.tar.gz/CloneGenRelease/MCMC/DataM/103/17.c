int main () {
    int dZ3Quy9l;
    int SwlLKIOjgkc;
    int yiZmlsDL;
    int qD7txQWnym;
    int B7fqCsPumg;
    dZ3Quy9l = (408 - 408);
    SwlLKIOjgkc = (812 - 812);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char R8v06rOna [(1311 - 311)];
    cin >> R8v06rOna +(242 - 241);
    R8v06rOna[(456 - 456)] = (888 - 888);
    for (yiZmlsDL = (343 - 342); R8v06rOna[yiZmlsDL] != (238 - 238); yiZmlsDL = yiZmlsDL + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (R8v06rOna[yiZmlsDL] > 96 && R8v06rOna[yiZmlsDL] < (695 - 572)) {
            R8v06rOna[yiZmlsDL] = R8v06rOna[yiZmlsDL] - (482 - 450);
        };
    }
    for (yiZmlsDL = (610 - 608); R8v06rOna[yiZmlsDL] != '\0'; yiZmlsDL = yiZmlsDL + 1) {
        if (R8v06rOna[yiZmlsDL] != R8v06rOna[yiZmlsDL - (496 - 495)]) {
            dZ3Quy9l = yiZmlsDL - (449 - 448) - SwlLKIOjgkc;
            SwlLKIOjgkc = yiZmlsDL - (694 - 693);
            cout << "(" << R8v06rOna[yiZmlsDL - (60 - 59)] << "," << dZ3Quy9l << ")";
        };
    }
    cout << "(" << R8v06rOna[yiZmlsDL - (723 - 722)] << "," << yiZmlsDL - (689 - 688) - SwlLKIOjgkc << ")";
    return 0;
}

