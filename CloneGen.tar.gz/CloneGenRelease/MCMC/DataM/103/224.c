main () {
    int G6mZSVlWHka;
    int n;
    char rdQ0qtnWjKlh [1001];
    gets (rdQ0qtnWjKlh);
    for (G6mZSVlWHka = (417 - 417); rdQ0qtnWjKlh[G6mZSVlWHka] != '\0'; G6mZSVlWHka++) {
        if ('a' <= rdQ0qtnWjKlh[G6mZSVlWHka] && rdQ0qtnWjKlh[G6mZSVlWHka] <= 'z')
            rdQ0qtnWjKlh[G6mZSVlWHka] = rdQ0qtnWjKlh[G6mZSVlWHka] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (G6mZSVlWHka = 0; rdQ0qtnWjKlh[G6mZSVlWHka] != '\0';) {
        n = 0;
        for (; rdQ0qtnWjKlh[G6mZSVlWHka +1] == rdQ0qtnWjKlh[G6mZSVlWHka];) {
            n++;
            G6mZSVlWHka++;
        }
        n++;
        printf ("(%c,%d)", rdQ0qtnWjKlh[G6mZSVlWHka], n);
        G6mZSVlWHka++;
    };
}

