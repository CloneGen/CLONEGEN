struct   stu {
    char e1W3zj;
    int count;
};
int main () {
    char *str;
    char *i9up0T764mc;
    char ukDbr2xnMRZ4 [(1636 - 636)];
    gets (ukDbr2xnMRZ4);
    struct   stu opVbra [1001];
    int XPVle2mgKnI;
    int tbOndhaDf;
    str = i9up0T764mc = ukDbr2xnMRZ4;
    while (*i9up0T764mc) {
        if ('a' <= *i9up0T764mc && 'z' >= *i9up0T764mc)
            *i9up0T764mc = *i9up0T764mc + 'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        i9up0T764mc++;
    }
    opVbra[(150 - 150)].e1W3zj = *str;
    opVbra[(237 - 237)].count = (38 - 37);
    str = str + 1;
    tbOndhaDf = 0;
    for (; *str;) {
        if (*str == *(str - 1))
            opVbra[tbOndhaDf].count++;
        else {
            tbOndhaDf = tbOndhaDf + 1;
            opVbra[tbOndhaDf].e1W3zj = *str;
            opVbra[tbOndhaDf].count = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        str++;
    }
    for (XPVle2mgKnI = 0; XPVle2mgKnI <= tbOndhaDf; XPVle2mgKnI = XPVle2mgKnI +1)
        printf ("(%c,%d)", opVbra[XPVle2mgKnI].e1W3zj, opVbra[XPVle2mgKnI].count);
    return 0;
}

