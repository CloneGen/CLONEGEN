int main () {
    char str [1001];
    int FPnBLF2;
    int xQFZEBRNkY;
    int L2xdKbXks0;
    cin >> str;
    xQFZEBRNkY = strlen (str);
    for (FPnBLF2 = (834 - 834); xQFZEBRNkY > FPnBLF2; FPnBLF2++) {
        if ('a' <= str[FPnBLF2] && str[FPnBLF2] <= 'z') {
            str[FPnBLF2] -= 32;
        };
    }
    FPnBLF2 = (682 - 682);
    for (; FPnBLF2 < xQFZEBRNkY;) {
        L2xdKbXks0 = (147 - 146);
        for (; str[FPnBLF2 +1] == str[FPnBLF2] && FPnBLF2 < xQFZEBRNkY;) {
            FPnBLF2++;
            L2xdKbXks0 = L2xdKbXks0 +1;
        }
        cout << "(" << str[FPnBLF2] << "," << L2xdKbXks0 << ")";
        FPnBLF2++;
    }
    return 0;
}

