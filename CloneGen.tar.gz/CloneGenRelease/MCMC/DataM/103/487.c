int main () {
    int rqugXO2bGI9P, EciLYI = (334 - 334), num [(661 - 551)] = {0};
    char uqOUobgdi [(471 - 361)] = {'\0'};
    char out [(789 - 679)] = {'\0'};
    num[0] = 1;
    cin.getline (uqOUobgdi, 110);
    {
        rqugXO2bGI9P = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (strlen (uqOUobgdi) > rqugXO2bGI9P) {
            if (uqOUobgdi[rqugXO2bGI9P] >= 'a' && 'z' >= uqOUobgdi[rqugXO2bGI9P])
                uqOUobgdi[rqugXO2bGI9P] = uqOUobgdi[rqugXO2bGI9P] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            rqugXO2bGI9P = rqugXO2bGI9P + 1;
        };
    }
    out[0] = uqOUobgdi[0];
    for (rqugXO2bGI9P = 1; rqugXO2bGI9P < strlen (uqOUobgdi); rqugXO2bGI9P++) {
        if (out[EciLYI] == uqOUobgdi[rqugXO2bGI9P])
            num[EciLYI]++;
        else {
            EciLYI++;
            out[EciLYI] = uqOUobgdi[rqugXO2bGI9P];
            num[EciLYI]++;
        };
    }
    {
        rqugXO2bGI9P = 0;
        while (rqugXO2bGI9P <= EciLYI) {
            cout << "(" << out[rqugXO2bGI9P] << "," << num[rqugXO2bGI9P] << ")";
            rqugXO2bGI9P = rqugXO2bGI9P + 1;
        };
    }
    return 0;
}

