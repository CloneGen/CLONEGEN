int main () {
    char q, data [1000];
    int length = 1, i, len;
    cin >> data;
    len = strlen (data);
    for (i = 0; i < len;) {
        length = 0;
        q = data[i];
        if (data[i] > 96) {
            q = q - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        do {
            length = length + 1;
        }
        while (data[i + length] == q || data[i + length] == q + 32);
        cout << "(" << q << "," << length << ")";
        i += length;
    }
    cout << endl;
    return 0;
}

