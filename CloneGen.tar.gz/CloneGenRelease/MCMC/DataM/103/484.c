int main () {
    char yeVoAX [1000];
    int DMirA7jEh;
    int FQp3Wj0e4N;
    int j;
    DMirA7jEh = 0;
    FQp3Wj0e4N = strlen (yeVoAX);
    cin >> yeVoAX;
    while (DMirA7jEh < FQp3Wj0e4N) {
        if ('a' <= yeVoAX[DMirA7jEh])
            yeVoAX[DMirA7jEh] = yeVoAX[DMirA7jEh] - (457 - 425);
        j = DMirA7jEh;
        while (true) {
            if (yeVoAX[DMirA7jEh +1] >= 'a')
                yeVoAX[DMirA7jEh +1] = yeVoAX[DMirA7jEh +1] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (yeVoAX[DMirA7jEh +1] == yeVoAX[j])
                DMirA7jEh = DMirA7jEh +1;
            else
                break;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        DMirA7jEh = DMirA7jEh +1;
        cout << "(" << yeVoAX[j] << "," << DMirA7jEh -j + 1 << ")";
    }
    return 0;
}

