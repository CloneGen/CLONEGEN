typedef struct   {
    char a4szOnlvF;
    int q4AZHOpNy;
}
KlQR1ZfyTPo;

int main () {
    char str [MAXLENGTH];
    int fs0WL6Ti, j;
    KlQR1ZfyTPo osp63Qk [MAXLENGTH];
    fgets (str, MAXLENGTH, stdin);
    {
        fs0WL6Ti = 530 - 530;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (MAXLENGTH > fs0WL6Ti) {
            if (str[fs0WL6Ti] == '\n')
                break;
            if (97 <= str[fs0WL6Ti] && 122 >= str[fs0WL6Ti])
                str[fs0WL6Ti] = str[fs0WL6Ti] - (84 - 52);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            fs0WL6Ti = fs0WL6Ti + 1;
        };
    }
    j = (361 - 361);
    osp63Qk[j].a4szOnlvF = str[(744 - 744)];
    osp63Qk[j].q4AZHOpNy = (111 - 110);
    fs0WL6Ti = (649 - 649);
    while (true) {
        if (str[fs0WL6Ti] == str[fs0WL6Ti + 1]) {
            fs0WL6Ti = fs0WL6Ti + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            osp63Qk[j].q4AZHOpNy++;
        }
        else {
            if (str[fs0WL6Ti + 1] == '\n')
                break;
            j = j + 1;
            osp63Qk[j].a4szOnlvF = str[fs0WL6Ti + 1];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            fs0WL6Ti = fs0WL6Ti + 1;
            osp63Qk[j].q4AZHOpNy = 1;
        };
    }
    {
        int fs0WL6Ti = 0;
        while (fs0WL6Ti <= j) {
            printf ("(%c,%d)", osp63Qk[fs0WL6Ti].a4szOnlvF, osp63Qk[fs0WL6Ti].q4AZHOpNy);
            fs0WL6Ti++;
        };
    }
    printf ("\n");
    return 0;
}

