int main () {
    char ekYsFMKr2TL [1000];
    int count = (549 - 548), qwr8Cy;
    gets (ekYsFMKr2TL);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    getchar ();
    getchar ();
    {
        qwr8Cy = 261 - 261;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (strlen (ekYsFMKr2TL) > qwr8Cy) {
            if ((!(ekYsFMKr2TL[qwr8Cy + (30 - 29)] != ekYsFMKr2TL[qwr8Cy])) || (!('a' - 'A' != ekYsFMKr2TL[qwr8Cy] - ekYsFMKr2TL[qwr8Cy + (703 - 702)])) || (ekYsFMKr2TL[qwr8Cy + (394 - 393)] - ekYsFMKr2TL[qwr8Cy] == 'a' - 'A')) {
                count = count + 1;
            }
            else if (ekYsFMKr2TL[qwr8Cy] >= 'a') {
                ekYsFMKr2TL[qwr8Cy] = ekYsFMKr2TL[qwr8Cy] - 'a' + 'A';
                printf ("(%c,%d)", ekYsFMKr2TL[qwr8Cy], count);
                count = 1;
            }
            else {
                printf ("(%c,%d)", ekYsFMKr2TL[qwr8Cy], count);
                count = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            qwr8Cy++;
        };
    };
}

