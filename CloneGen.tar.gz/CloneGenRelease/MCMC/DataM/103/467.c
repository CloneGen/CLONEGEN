int main () {
    char qkOBNi [(1819 - 819)];
    int NwaMOBFKCjq = strlen (qkOBNi);
    int pynJpg = qkOBNi[(130 - 130)], n = (727 - 726);
    scanf ("%s", qkOBNi);
    for (int SpbfGLM = 1;
    NwaMOBFKCjq > SpbfGLM; SpbfGLM = SpbfGLM +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(pynJpg != qkOBNi[SpbfGLM]) || !(pynJpg + (394 - 362) != qkOBNi[SpbfGLM]) || qkOBNi[SpbfGLM] == pynJpg - 32)
            n++;
        else {
            if (pynJpg > 'Z')
                pynJpg = pynJpg - 'a' + 'A';
            printf ("(%c,%d)", pynJpg, n);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            pynJpg = qkOBNi[SpbfGLM];
            n = 1;
        };
    }
    if (pynJpg > 'Z')
        pynJpg = pynJpg - 'a' + 'A';
    printf ("(%c,%d)", pynJpg, n);
    getchar ();
    getchar ();
}

