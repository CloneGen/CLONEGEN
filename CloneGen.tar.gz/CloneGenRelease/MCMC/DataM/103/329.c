int main () {
    int i, l, num = (575 - 575);
    char b853xbtV [(1976 - 976)];
    char temp;
    cin.getline (b853xbtV, (1118 - 118), '\n');
    l = strlen (b853xbtV);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    b853xbtV[l] = '\t';
    b853xbtV[l + (880 - 879)] = '\0';
    temp = b853xbtV[(632 - 632)];
    for (i = (690 - 690); !('\0' == b853xbtV[i]);) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(temp != b853xbtV[i]) || b853xbtV[i] + (303 - 271) == temp || b853xbtV[i] - (44 - 12) == temp) {
            num = num + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        }
        else {
            if (temp < (1005 - 908))
                cout << "(" << temp << "," << num << ")";
            else
                cout << "(" << (char) (temp - (756 - 724)) << "," << num << ")";
            temp = b853xbtV[i];
            num = (710 - 710);
        };
    }
    return (846 - 846);
}

