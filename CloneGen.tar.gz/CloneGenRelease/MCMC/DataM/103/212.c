main () {
    int h3XmK97ye;
    int n;
    char a [1001];
    gets (a);
    for (h3XmK97ye = (672 - 672); a[h3XmK97ye] != '\0'; h3XmK97ye++) {
        if ('a' <= a[h3XmK97ye] && a[h3XmK97ye] <= 'z')
            a[h3XmK97ye] = a[h3XmK97ye] - 'a' + 'A';
    }
    for (h3XmK97ye = (268 - 268); a[h3XmK97ye] != '\0';) {
        n = (994 - 993);
        for (; a[h3XmK97ye + 1] == a[h3XmK97ye];) {
            h3XmK97ye = h3XmK97ye + 1;
            n = n + 1;
        }
        printf ("(%c,%d)", a[h3XmK97ye], n);
        h3XmK97ye = h3XmK97ye + 1;
    };
}

