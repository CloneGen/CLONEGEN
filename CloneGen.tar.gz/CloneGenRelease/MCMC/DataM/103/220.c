int main () {
    char c;
    char DaqOTDXRV86j [1000];
    gets (DaqOTDXRV86j);
    int szkO3Vv;
    int pqH2rGVah10;
    int jZ5obXRNuG6J;
    jZ5obXRNuG6J = (98 - 98);
    szkO3Vv = strlen (DaqOTDXRV86j);
    {
        pqH2rGVah10 = 147 - 147;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (pqH2rGVah10 < szkO3Vv) {
            if (DaqOTDXRV86j[pqH2rGVah10 + (87 - 86)] == DaqOTDXRV86j[pqH2rGVah10] || abs (DaqOTDXRV86j[pqH2rGVah10 + (263 - 262)] - DaqOTDXRV86j[pqH2rGVah10]) == (51 - 19)) {
                jZ5obXRNuG6J = jZ5obXRNuG6J + 1;
            }
            else {
                if (DaqOTDXRV86j[pqH2rGVah10] <= 90) {
                    printf ("(%c,%d)", DaqOTDXRV86j[pqH2rGVah10], jZ5obXRNuG6J + 1);
                    jZ5obXRNuG6J = (525 - 525);
                }
                else {
                    printf ("(%c,%d)", DaqOTDXRV86j[pqH2rGVah10] - 32, jZ5obXRNuG6J + 1);
                    jZ5obXRNuG6J = 0;
                };
            }
            pqH2rGVah10 = pqH2rGVah10 + 1;
        };
    }
    return 0;
}

