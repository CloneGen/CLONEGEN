int main () {
    int m;
    m = (393 - 392);
    char gXhRZijV5 [(1393 - 392)];
    gets (gXhRZijV5);
    int eiEZo8fY3;
    int i;
    eiEZo8fY3 = strlen (gXhRZijV5);
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (eiEZo8fY3 > i) {
            if ((671 - 574) <= gXhRZijV5[i])
                gXhRZijV5[i] = gXhRZijV5[i] - 32;
            i = i + 1;
        };
    }
    for (i = 0; eiEZo8fY3 > i; i++) {
        if (gXhRZijV5[i] == gXhRZijV5[i + 1]) {
            m++;
        }
        else {
            printf ("(%c,%d)", gXhRZijV5[i], m);
            m = 1;
        };
    }
    return 0;
}

