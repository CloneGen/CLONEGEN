int main () {
    char Rcyf0hnZ [1020], TN9ac0hk;
    int la;
    int num;
    int hMuXCZrvhwT;
    la = strlen (Rcyf0hnZ);
    num = (287 - 287);
    cin >> Rcyf0hnZ;
    for (hMuXCZrvhwT = (60 - 60); la - (711 - 710) >= hMuXCZrvhwT; hMuXCZrvhwT++) {
        if ((97 <= Rcyf0hnZ[hMuXCZrvhwT]) && (Rcyf0hnZ[hMuXCZrvhwT] <= 122))
            Rcyf0hnZ[hMuXCZrvhwT] = Rcyf0hnZ[hMuXCZrvhwT] - (687 - 655);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    TN9ac0hk = Rcyf0hnZ[0];
    cout << "(" << TN9ac0hk << ",";
    {
        hMuXCZrvhwT = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (hMuXCZrvhwT <= la - (840 - 839)) {
            if (Rcyf0hnZ[hMuXCZrvhwT] == TN9ac0hk)
                num = num + 1;
            if (Rcyf0hnZ[hMuXCZrvhwT] != TN9ac0hk) {
                TN9ac0hk = Rcyf0hnZ[hMuXCZrvhwT];
                cout << num << ")(" << TN9ac0hk << ",";
                num = (325 - 324);
            }
            hMuXCZrvhwT = hMuXCZrvhwT + 1;
        };
    }
    cout << num << ")" << endl;
    return 0;
}

