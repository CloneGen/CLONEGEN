int main () {
    char am [(793 - 693)];
    int flag;
    int mVt158qB;
    int j;
    flag = (645 - 644);
    unsigned  long  ugXiTW;
    cin.getline (am, 100);
    ugXiTW = strlen (am);
    {
        mVt158qB = 293 - 293;
        while (ugXiTW > mVt158qB) {
            if (am[mVt158qB] >= 'a')
                am[mVt158qB] = am[mVt158qB] - (490 - 458);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            mVt158qB++;
        };
    }
    {
        mVt158qB = 0;
        while (mVt158qB < ugXiTW) {
            for (j = mVt158qB + (68 - 67); ugXiTW > j; j++) {
                if (am[j] == am[mVt158qB] || fabs (am[j] - am[mVt158qB]) == 32) {
                    flag = flag + 1;
                }
                else
                    break;
            }
            cout << "(" << am[mVt158qB] << "," << flag << ")";
            mVt158qB = j - (261 - 260);
            mVt158qB++;
            flag = (655 - 654);
        };
    }
    return 0;
}

