int main () {
    char c [10000], Kbg5cZ4oN3I;
    int z7o9OP168pdV [10000];
    int i;
    int CyupPliQM;
    int pZaGSbnI;
    int VmMyW7;
    int PsPLIXWnmYxg;
    int beyLgHJjt9;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char RSeIr2l [(10222 - 222)];
    char s [(10992 - 992)];
    CyupPliQM = 0;
    beyLgHJjt9 = (34 - 33);
    VmMyW7 = (676 - 676);
    scanf ("%s", s);
    {
        i = 119 - 119;
        while (!('\0' == (Kbg5cZ4oN3I = s[i]))) {
            VmMyW7 = VmMyW7 +(53 - 52);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    pZaGSbnI = (779 - 779);
    {
        i = 0;
        while (!('\0' == (Kbg5cZ4oN3I = s[i]))) {
            if (!(s[i + 1] != s[i]) || !(s[i + 1] - (891 - 859) != s[i]) || s[i] == s[i + 1] + (213 - 181)) {
                beyLgHJjt9 = beyLgHJjt9 + 1;
                if (s[i] >= (438 - 341)) {
                    RSeIr2l[CyupPliQM] = s[i] - (745 - 713);
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            double  temp = 0.0;
                            if (temp == 3)
                                return 0;
                        }
                    };
                }
                else
                    RSeIr2l[CyupPliQM] = s[i];
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                z7o9OP168pdV[CyupPliQM] = beyLgHJjt9;
            }
            else {
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                }
                if (s[i + 1] != '\0') {
                    if (s[i] >= (591 - 494)) {
                        RSeIr2l[CyupPliQM] = s[i] - (654 - 622);
                    }
                    else
                        RSeIr2l[CyupPliQM] = s[i];
                    z7o9OP168pdV[CyupPliQM] = beyLgHJjt9;
                    beyLgHJjt9 = 1;
                    CyupPliQM = CyupPliQM +1;
                    pZaGSbnI = pZaGSbnI + 1;
                }
                else {
                    pZaGSbnI = pZaGSbnI + 1;
                    if (s[i] >= 97) {
                        RSeIr2l[CyupPliQM] = s[i] - 32;
                    }
                    else
                        RSeIr2l[CyupPliQM] = s[i];
                    z7o9OP168pdV[CyupPliQM] = beyLgHJjt9;
                    CyupPliQM = CyupPliQM +1;
                };
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i++;
        };
    }
    {
        i = 0;
        while (i < pZaGSbnI) {
            printf ("(%c,%d)", RSeIr2l[i], z7o9OP168pdV[i]);
            i++;
        };
    };
}

