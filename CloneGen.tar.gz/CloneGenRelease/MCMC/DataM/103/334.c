int main () {
    int i;
    int j;
    int DxTeCP7imXyt;
    int IQRIGTprdNz;
    int f [1002] = {(284 - 284)};
    int s6TCob5fxXU0;
    i = (376 - 376);
    j = (485 - 485);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    DxTeCP7imXyt = (627 - 627);
    char s [1002];
    char iVnNEHy [1002];
    gets (s);
    IQRIGTprdNz = strlen (s);
    if (!((686 - 685) != IQRIGTprdNz)) {
        if (65 <= s[(11 - 11)] && s[(60 - 60)] <= 90)
            printf ("(%c,%d)", s[0], (797 - 796));
        else
            printf ("(%c,%d)", s[0] - (894 - 862), (26 - 25));
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    else {
        {
            i = 313 - 312;
            while (i <= IQRIGTprdNz) {
                DxTeCP7imXyt = i - 1;
                f[DxTeCP7imXyt] = 1;
                for (; i < IQRIGTprdNz; i++) {
                    if (s[i] == s[DxTeCP7imXyt] || abs (s[i] - s[DxTeCP7imXyt]) == 32)
                        f[DxTeCP7imXyt]++;
                    else
                        break;
                }
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (s[DxTeCP7imXyt] >= 65 && s[DxTeCP7imXyt] <= 90)
                    printf ("(%c,%d)", s[DxTeCP7imXyt], f[DxTeCP7imXyt]);
                else
                    printf ("(%c,%d)", s[DxTeCP7imXyt] - 32, f[DxTeCP7imXyt]);
                i = i + 1;
            };
        };
    }
    return 0;
}

