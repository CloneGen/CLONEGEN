int main () {
    char JiHpesPRMS [1100];
    int num = 0;
    cin >> JiHpesPRMS;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int i = 0;
        while (i < strlen (JiHpesPRMS)) {
            if ('a' <= JiHpesPRMS[i] && JiHpesPRMS[i] <= 'z')
                JiHpesPRMS[i] = JiHpesPRMS[i] + 'A' - 'a';
            i = i + 1;
        };
    }
    {
        int i = 0;
        while (i < strlen (JiHpesPRMS)) {
            if (JiHpesPRMS[i] == JiHpesPRMS[i + 1]) {
                num = num + 1;
            }
            else {
                cout << "(" << JiHpesPRMS[i] << "," << num + 1 << ")";
                num = 0;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i = i + 1;
        };
    }
    return 0;
}

