int main () {
    int thi4geIuz8ly;
    int sejhaSmZpc;
    int ql74VKmOtu5;
    char t;
    char bQtmsVrM [(1123 - 123)];
    gets (bQtmsVrM);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    ql74VKmOtu5 = (133 - 132);
    sejhaSmZpc = strlen (bQtmsVrM);
    {
        thi4geIuz8ly = 170 - 170;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (sejhaSmZpc > thi4geIuz8ly) {
            if ('a' <= bQtmsVrM[thi4geIuz8ly] && 'z' >= bQtmsVrM[thi4geIuz8ly])
                bQtmsVrM[thi4geIuz8ly] = bQtmsVrM[thi4geIuz8ly] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            thi4geIuz8ly = thi4geIuz8ly + 1;
        };
    }
    t = bQtmsVrM[0];
    {
        thi4geIuz8ly = 679 - 678;
        while (thi4geIuz8ly < sejhaSmZpc) {
            if (bQtmsVrM[thi4geIuz8ly] == t)
                ql74VKmOtu5++;
            else {
                printf ("(%c,%d)", t, ql74VKmOtu5);
                t = bQtmsVrM[thi4geIuz8ly];
                ql74VKmOtu5 = 1;
            }
            thi4geIuz8ly = thi4geIuz8ly + 1;
        };
    }
    t = bQtmsVrM[sejhaSmZpc - 1];
    printf ("(%c,%d)\n", t, ql74VKmOtu5);
}

