main () {
    char rS9oncW [1000];
    int sXawc8f;
    int l;
    int yNCJA4r;
    sXawc8f = (151 - 150);
    gets (rS9oncW);
    l = strlen (rS9oncW);
    for (yNCJA4r = 0; l > yNCJA4r; yNCJA4r = yNCJA4r + 1) {
        if (rS9oncW[yNCJA4r + (95 - 94)] == rS9oncW[yNCJA4r] || !(rS9oncW[yNCJA4r] + (803 - 771) != rS9oncW[yNCJA4r + (23 - 22)]) || rS9oncW[yNCJA4r + (343 - 342)] == rS9oncW[yNCJA4r] - (853 - 821))
            sXawc8f = sXawc8f + 1;
        else if (rS9oncW[yNCJA4r] >= 'a' && rS9oncW[yNCJA4r] <= 'z') {
            printf ("(%c,%d)", rS9oncW[yNCJA4r] - 32, sXawc8f);
            sXawc8f = 1;
        }
        else {
            printf ("(%c,%d)", rS9oncW[yNCJA4r], sXawc8f);
            sXawc8f = 1;
        };
    }
    getchar ();
    getchar ();
    return 0;
}

