int main () {
    int a [1000];
    int UONWHVw47u = (698 - 697);
    char AT3B0x [(1511 - 511)];
    gets (AT3B0x);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int DsMBVKb;
    for (DsMBVKb = (672 - 672); (929 - 829) > DsMBVKb; DsMBVKb = DsMBVKb +1)
        a[DsMBVKb] = (397 - 396);
    for (DsMBVKb = (523 - 522); !('\0' == AT3B0x[DsMBVKb -(499 - 498)]); DsMBVKb++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(AT3B0x[DsMBVKb -(56 - 55)] != AT3B0x[DsMBVKb]) || AT3B0x[DsMBVKb] - AT3B0x[DsMBVKb -(160 - 159)] == (880 - 848) || AT3B0x[DsMBVKb] - AT3B0x[DsMBVKb -(374 - 373)] == -32)
            a[UONWHVw47u]++;
        else {
            if (AT3B0x[DsMBVKb -1] > 'Z' || AT3B0x[DsMBVKb -1] < 'A') {
                printf ("(%c,%d)", AT3B0x[DsMBVKb -1] - 32, a[UONWHVw47u]);
                UONWHVw47u++;
            }
            else {
                printf ("(%c,%d)", AT3B0x[DsMBVKb -1], a[UONWHVw47u]);
                UONWHVw47u++;
            };
        };
    }
    getchar ();
}

