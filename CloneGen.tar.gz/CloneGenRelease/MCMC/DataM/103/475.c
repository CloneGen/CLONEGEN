int main () {
    char NOK423W [(1384 - 379)];
    char temp;
    int pLbUW1;
    int count;
    int eXnTqxzkHIKc;
    pLbUW1 = strlen (NOK423W);
    count = (854 - 854);
    cin.getline (NOK423W, (1703 - 698));
    {
        eXnTqxzkHIKc = 36 - 36;
        while (pLbUW1 > eXnTqxzkHIKc) {
            if ('a' <= NOK423W[eXnTqxzkHIKc] && 'z' >= NOK423W[eXnTqxzkHIKc])
                NOK423W[eXnTqxzkHIKc] = NOK423W[eXnTqxzkHIKc] + ('A' - 'a');
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            eXnTqxzkHIKc = eXnTqxzkHIKc + 1;
        };
    }
    for (eXnTqxzkHIKc = 0; pLbUW1 > eXnTqxzkHIKc;) {
        temp = NOK423W[eXnTqxzkHIKc];
        count = (377 - 376);
        eXnTqxzkHIKc++;
        while (NOK423W[eXnTqxzkHIKc] == NOK423W[eXnTqxzkHIKc - 1]) {
            if (eXnTqxzkHIKc == pLbUW1)
                break;
            eXnTqxzkHIKc++;
            count = count + 1;
        }
        cout << '(' << temp << ',' << count << ')';
    }
    return 0;
}

