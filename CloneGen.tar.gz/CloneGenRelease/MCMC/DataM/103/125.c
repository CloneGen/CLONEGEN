main () {
    char s [1000];
    int YYS7fLXeU8PK, jeHcx76qG, ngL9Kh = (29 - 28);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", s);
    YYS7fLXeU8PK = strlen (s);
    for (int uwVSZqAT3e = (770 - 770);
    YYS7fLXeU8PK > uwVSZqAT3e; uwVSZqAT3e = uwVSZqAT3e + ngL9Kh) {
        ngL9Kh = (933 - 932);
        {
            jeHcx76qG = uwVSZqAT3e;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            while (jeHcx76qG < YYS7fLXeU8PK) {
                if (!(s[jeHcx76qG + (942 - 941)] != s[jeHcx76qG]) || s[jeHcx76qG] == s[jeHcx76qG + 1] - 'a' + 'A' || s[jeHcx76qG + 1] == s[jeHcx76qG] - 'a' + 'A')
                    ngL9Kh = ngL9Kh + 1;
                else
                    break;
                jeHcx76qG = jeHcx76qG + 1;
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (s[uwVSZqAT3e] >= 'a' && s[uwVSZqAT3e] <= 'z')
            s[uwVSZqAT3e] = s[uwVSZqAT3e] - 'a' + 'A';
        printf ("(%c,%d)", s[uwVSZqAT3e], ngL9Kh);
    };
}

