int main () {
    char kNPgry [(1232 - 231)];
    int num [(350 - 323)], OEmURMSlGJYA, MKZt5m, bs87Qk;
    {
        bs87Qk = 774 - 774;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (27 >= bs87Qk) {
            num[bs87Qk] = (842 - 841);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            bs87Qk++;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", kNPgry);
    {
        MKZt5m = 542 - 542;
        while (strlen (kNPgry) >= MKZt5m) {
            if (kNPgry[MKZt5m] >= 'a' && kNPgry[MKZt5m] <= 'z')
                kNPgry[MKZt5m] = kNPgry[MKZt5m] - 'a' + 'A';
            MKZt5m++;
        };
    }
    {
        MKZt5m = 101 - 100;
        while (MKZt5m <= strlen (kNPgry)) {
            if (kNPgry[MKZt5m] == kNPgry[MKZt5m -1]) {
                num[kNPgry[MKZt5m] - 'A']++;
            }
            else {
                printf ("(%c,%d)", kNPgry[MKZt5m -1], num[kNPgry[MKZt5m -1] - 'A']);
                num[kNPgry[MKZt5m -1] - 'A'] = 1;
            }
            MKZt5m++;
        };
    }
    return 0;
}

