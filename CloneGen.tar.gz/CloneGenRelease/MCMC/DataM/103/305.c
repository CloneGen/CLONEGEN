int main () {
    int ObiMzeaVrlBp, FrE7Hy = (802 - 802), CvL7W0B, BsjMC1 = (616 - 615);
    char F4jVipIKB [(1286 - 286)] = {" "};
    gets (F4jVipIKB);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    ObiMzeaVrlBp = strlen (F4jVipIKB);
    while (FrE7Hy < ObiMzeaVrlBp) {
        if (F4jVipIKB[FrE7Hy +(887 - 886)] == F4jVipIKB[FrE7Hy] || F4jVipIKB[FrE7Hy +1] == F4jVipIKB[FrE7Hy] - (786 - 754) || F4jVipIKB[FrE7Hy +1] == F4jVipIKB[FrE7Hy] + 32) {
            FrE7Hy = FrE7Hy +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            BsjMC1 = BsjMC1 +1;
        }
        else {
            if (F4jVipIKB[FrE7Hy] >= 'a' && F4jVipIKB[FrE7Hy] <= 'z')
                F4jVipIKB[FrE7Hy] = F4jVipIKB[FrE7Hy] - 32;
            printf ("(%c,%d)", F4jVipIKB[FrE7Hy], BsjMC1);
            BsjMC1 = 1;
            FrE7Hy = FrE7Hy +1;
        };
    }
    return 0;
}

