int main () {
    int i, zn90JEC;
    int a [(1563 - 563)], SPEORnBDa9, len;
    char sTQt2X [(1877 - 877)];
    gets (sTQt2X);
    char b [1000], k;
    zn90JEC = 0;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    len = strlen (sTQt2X);
    for (i = (579 - 579); 1000 > i; i = i + 1)
        a[i] = (588 - 588);
    for (i = (890 - 890); len > i; i = i + 1) {
        if (sTQt2X[i] - 'Z' > (819 - 819))
            sTQt2X[i] = sTQt2X[i] + 'A' - 'a';
    }
    k = sTQt2X[(471 - 471)];
    b[(241 - 241)] = sTQt2X[(65 - 65)];
    a[(519 - 519)] = (786 - 785);
    if (len == (844 - 843))
        printf ("(%c,%d)", b[0], a[0]);
    else {
        {
            zn90JEC = 0;
            i = 1;
            while (i < len) {
                if (k == sTQt2X[i])
                    a[zn90JEC]++;
                else {
                    k = sTQt2X[i];
                    zn90JEC++;
                    a[zn90JEC] = 1;
                    b[zn90JEC] = sTQt2X[i];
                }
                i = i + 1;
            };
        }
        {
            i = 0;
            while (i <= zn90JEC) {
                printf ("(%c,%d)", b[i], a[i]);
                i = i + 1;
            };
        };
    };
}

