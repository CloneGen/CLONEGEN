int main () {
    int U1tuEG8s;
    U1tuEG8s = (947 - 947);
    char GSlhWnBaV;
    GSlhWnBaV = getchar ();
    char UipLFwZKbgy [(1098 - 88)] = {'\0'};
    int i;
    i = (698 - 698);
    while (GSlhWnBaV != '\n') {
        if ((903 - 806) <= GSlhWnBaV &&GSlhWnBaV <= 122) {
            UipLFwZKbgy[U1tuEG8s] = GSlhWnBaV -(74 - 42);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            U1tuEG8s = U1tuEG8s +1;
        }
        else {
            UipLFwZKbgy[U1tuEG8s] = GSlhWnBaV;
            U1tuEG8s = U1tuEG8s +1;
        }
        GSlhWnBaV = getchar ();
    }
    U1tuEG8s = (695 - 694);
    UipLFwZKbgy[strlen (UipLFwZKbgy)] = '1';
    for (i = 0; i < strlen (UipLFwZKbgy) - (958 - 957); i = i + 1) {
        if (UipLFwZKbgy[i] == UipLFwZKbgy[i + (437 - 436)])
            U1tuEG8s++;
        else {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            if (UipLFwZKbgy[i] != UipLFwZKbgy[i + 1]) {
                cout << "(" << UipLFwZKbgy[i] << "," << U1tuEG8s << ")";
                U1tuEG8s = 1;
            };
        };
    }
    return 0;
}

