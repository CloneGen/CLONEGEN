int main () {
    int IgMaqpFYXQdk;
    int ln;
    int m;
    int t7e89WK34ycp;
    char aSPlyJUMsv [(1082 - 81)];
    char Rgv0mF;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> aSPlyJUMsv;
    ln = strlen (aSPlyJUMsv);
    for (IgMaqpFYXQdk = (476 - 476); IgMaqpFYXQdk < ln; IgMaqpFYXQdk++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (aSPlyJUMsv[IgMaqpFYXQdk] >= 96) {
            aSPlyJUMsv[IgMaqpFYXQdk] = aSPlyJUMsv[IgMaqpFYXQdk] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    m = 0;
    t7e89WK34ycp = (331 - 330);
    for (IgMaqpFYXQdk = 0; IgMaqpFYXQdk < ln; IgMaqpFYXQdk++) {
        Rgv0mF = aSPlyJUMsv[IgMaqpFYXQdk];
        if (aSPlyJUMsv[IgMaqpFYXQdk +1] == Rgv0mF)
            t7e89WK34ycp++;
        else {
            cout << "(" << Rgv0mF << "," << t7e89WK34ycp << ")";
            t7e89WK34ycp = 1;
            m = IgMaqpFYXQdk;
        };
    }
    return 0;
}

