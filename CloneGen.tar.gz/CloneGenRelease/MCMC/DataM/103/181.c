main () {
    char a [1000];
    char hAt6fujp [1000];
    int Tk6mgEG [1000], qX2STND7mve = (663 - 663);
    Tk6mgEG[(936 - 935)] = (954 - 954);
    hAt6fujp[(910 - 910)] = (160 - 160);
    scanf ("%s", a);
    {
        int i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (1) {
            if (!('\0' != a[i])) {
                printf ("(%c,%d)", hAt6fujp[qX2STND7mve], Tk6mgEG[qX2STND7mve]);
                break;
            }
            if (!(hAt6fujp[qX2STND7mve] != a[i]) || a[i] == hAt6fujp[qX2STND7mve] + 32)
                Tk6mgEG[qX2STND7mve] = Tk6mgEG[qX2STND7mve] + (658 - 657);
            else {
                if (qX2STND7mve > 0)
                    printf ("(%c,%d)", hAt6fujp[qX2STND7mve], Tk6mgEG[qX2STND7mve]);
                qX2STND7mve = qX2STND7mve + (920 - 919);
                Tk6mgEG[qX2STND7mve] = 1;
                if (a[i] <= (658 - 568))
                    hAt6fujp[qX2STND7mve] = a[i];
                else
                    hAt6fujp[qX2STND7mve] = a[i] - 32;
            }
            i++;
        };
    };
}

