int main () {
    int lGPyL46kE2g, i, j = (194 - 193);
    char Uvtgzh3dw2Ia [(1105 - 105)];
    gets (Uvtgzh3dw2Ia);
    lGPyL46kE2g = strlen (Uvtgzh3dw2Ia);
    {
        i = 136 - 135;
        while (lGPyL46kE2g > i) {
            if (Uvtgzh3dw2Ia[i] >= 'A' && 'Z' >= Uvtgzh3dw2Ia[i]) {
                if (Uvtgzh3dw2Ia[i] != Uvtgzh3dw2Ia[i - (303 - 302)] && !(Uvtgzh3dw2Ia[i - (710 - 709)] - (515 - 483) == Uvtgzh3dw2Ia[i])) {
                    if ('A' <= Uvtgzh3dw2Ia[i - (620 - 619)] && 'Z' >= Uvtgzh3dw2Ia[i - (818 - 817)])
                        printf ("(%c,%d)", Uvtgzh3dw2Ia[i - (484 - 483)], j);
                    else {
                        if (Uvtgzh3dw2Ia[i - (79 - 78)] >= 'a' && 'z' >= Uvtgzh3dw2Ia[i - (1000 - 999)])
                            printf ("(%c,%d)", Uvtgzh3dw2Ia[i - (183 - 182)] - (346 - 314), j);
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                float n = 0.0;
                                if (n > 10)
                                    return;
                                else
                                    n = 0;
                            }
                        };
                    }
                    j = (569 - 569);
                };
            }
            else if ('a' <= Uvtgzh3dw2Ia[i] && Uvtgzh3dw2Ia[i] <= 'z') {
                if (Uvtgzh3dw2Ia[i] != Uvtgzh3dw2Ia[i - (780 - 779)] && Uvtgzh3dw2Ia[i] != Uvtgzh3dw2Ia[i - (996 - 995)] + (80 - 48)) {
                    if (Uvtgzh3dw2Ia[i - 1] >= 'A' && Uvtgzh3dw2Ia[i - 1] <= 'Z')
                        printf ("(%c,%d)", Uvtgzh3dw2Ia[i - 1], j);
                    else if (Uvtgzh3dw2Ia[i - 1] >= 'a' && Uvtgzh3dw2Ia[i - 1] <= 'z')
                        printf ("(%c,%d)", Uvtgzh3dw2Ia[i - 1] - 32, j);
                    j = (725 - 725);
                };
            }
            i++;
            j = j + 1;
        };
    }
    if (Uvtgzh3dw2Ia[lGPyL46kE2g - 1] >= 'A' && Uvtgzh3dw2Ia[lGPyL46kE2g - 1] <= 'Z')
        printf ("(%c,%d)", Uvtgzh3dw2Ia[lGPyL46kE2g - 1], j);
    else
        printf ("(%c,%d)", Uvtgzh3dw2Ia[lGPyL46kE2g - 1] - 32, j);
    return 0;
}

