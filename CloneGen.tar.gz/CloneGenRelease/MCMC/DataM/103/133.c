int main () {
    char AVGwczFSyQ [1000];
    char temp;
    int hi4y8LIz, maGkYKBj = strlen (AVGwczFSyQ);
    int g4OiIc9K1sp, Jdfc5ov = (889 - 889);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", AVGwczFSyQ);
    for (hi4y8LIz = (460 - 460); hi4y8LIz < maGkYKBj; hi4y8LIz = hi4y8LIz + 1)
        if (AVGwczFSyQ[hi4y8LIz] >= 'a' && 'z' >= AVGwczFSyQ[hi4y8LIz])
            AVGwczFSyQ[hi4y8LIz] = AVGwczFSyQ[hi4y8LIz] - 'a' + 'A';
    {
        hi4y8LIz = 0;
        while (Jdfc5ov < maGkYKBj) {
            temp = AVGwczFSyQ[Jdfc5ov];
            for (g4OiIc9K1sp = 0;; g4OiIc9K1sp = g4OiIc9K1sp + 1) {
                if (AVGwczFSyQ[Jdfc5ov +g4OiIc9K1sp] != AVGwczFSyQ[Jdfc5ov +g4OiIc9K1sp + (81 - 80)])
                    break;
            }
            hi4y8LIz++;
            printf ("(%c,%d)", AVGwczFSyQ[Jdfc5ov], g4OiIc9K1sp + (714 - 713));
            Jdfc5ov = Jdfc5ov +g4OiIc9K1sp + 1;
        };
    }
    return 0;
}

