main () {
    char XjiuQhfw [1001];
    int v2mdh5S;
    int a [(1469 - 469)];
    int x;
    scanf ("%s", XjiuQhfw);
    x = strlen (XjiuQhfw);
    for (v2mdh5S = (253 - 253); v2mdh5S < (1171 - 171); v2mdh5S = v2mdh5S + 1)
        a[v2mdh5S] = (423 - 422);
    for (v2mdh5S = (726 - 725); x >= v2mdh5S; v2mdh5S++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!((XjiuQhfw[v2mdh5S - (47 - 46)] - 'A' - (521 - 489)) != (XjiuQhfw[v2mdh5S] - 'A')))
            a[XjiuQhfw[v2mdh5S] - 'A']++;
        else {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if ((XjiuQhfw[v2mdh5S] - 'A' - (617 - 585)) == (XjiuQhfw[v2mdh5S - (733 - 732)] - 'A'))
                a[XjiuQhfw[v2mdh5S] - 'A' - (299 - 267)]++;
            else {
                if ((XjiuQhfw[v2mdh5S] - '0') == (XjiuQhfw[v2mdh5S - (513 - 512)] - '0')) {
                    if ((XjiuQhfw[v2mdh5S] - '0') < (589 - 546))
                        a[XjiuQhfw[v2mdh5S] - 'A']++;
                    else
                        a[XjiuQhfw[v2mdh5S] - 'A' - (103 - 71)]++;
                }
                else if ((XjiuQhfw[v2mdh5S - (223 - 222)] - '0') < 43) {
                    printf ("(%c,%d)", XjiuQhfw[v2mdh5S - (920 - 919)], a[XjiuQhfw[v2mdh5S - (915 - 914)] - 'A']);
                    a[XjiuQhfw[v2mdh5S - 1] - 'A'] = 1;
                }
                else {
                    printf ("(%c,%d)", XjiuQhfw[v2mdh5S - 1] - 'A' - 32 + 'A', a[XjiuQhfw[v2mdh5S - 1] - 'A' - 32]);
                    a[XjiuQhfw[v2mdh5S - 1] - 'A' - 32] = 1;
                };
            };
        };
    };
}

