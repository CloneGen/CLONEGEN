main () {
    int i;
    int j;
    int k;
    int qargJjCpiY;
    int TQg1y4drb [(1676 - 676)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    char LJGSEyuH [1000];
    gets (LJGSEyuH);
    i = j = k = (543 - 543);
    while (k < (1439 - 439)) {
        TQg1y4drb[k] = (770 - 769);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        k = k + 1;
    }
    {
        k = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (k < 1000) {
            if (LJGSEyuH[k] > 'Z') {
                LJGSEyuH[k] = LJGSEyuH[k] - (925 - 893);
            }
            k++;
        };
    }
    while (1000 > i) {
        j = i;
        if (LJGSEyuH[j] == '\0')
            break;
        while (LJGSEyuH[j] == LJGSEyuH[j + (799 - 798)]) {
            TQg1y4drb[j + 1] = TQg1y4drb[j] + 1;
            j++;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        printf ("(%c,%d)", LJGSEyuH[j], TQg1y4drb[j]);
        i = j + 1;
    };
}

