void  main () {
    char rHma0K6rF [(1208 - 207)];
    gets (rHma0K6rF);
    int B4BSzfb8xN;
    int j;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int OjEsQ9Kut5;
    for (B4BSzfb8xN = (817 - 817); rHma0K6rF[B4BSzfb8xN] != '\0'; B4BSzfb8xN = B4BSzfb8xN +1) {
        if (90 < rHma0K6rF[B4BSzfb8xN])
            rHma0K6rF[B4BSzfb8xN] = rHma0K6rF[B4BSzfb8xN] - (320 - 288);
    }
    for (B4BSzfb8xN = (296 - 296); rHma0K6rF[B4BSzfb8xN] != '\0';) {
        {
            j = 151 - 151;
            while (1) {
                if (rHma0K6rF[B4BSzfb8xN +j] != rHma0K6rF[B4BSzfb8xN])
                    break;
                j = j + 1;
            };
        }
        printf ("(%c,%d)", rHma0K6rF[B4BSzfb8xN], j);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        B4BSzfb8xN = B4BSzfb8xN +j;
    };
}

