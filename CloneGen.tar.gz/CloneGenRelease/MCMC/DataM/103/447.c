main () {
    int tCTIjYq4ZvV;
    int GxQbR51ltvkf;
    char z89SDJ;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char yvtH0B6Yhb4K [(1800 - 790)];
    z89SDJ = (367 - 367);
    scanf ("%s", yvtH0B6Yhb4K);
    for (tCTIjYq4ZvV = (738 - 738); 999 > tCTIjYq4ZvV;) {
        {
            GxQbR51ltvkf = tCTIjYq4ZvV;
            while (GxQbR51ltvkf < 999) {
                if (!(yvtH0B6Yhb4K[GxQbR51ltvkf] != yvtH0B6Yhb4K[tCTIjYq4ZvV]) || yvtH0B6Yhb4K[tCTIjYq4ZvV] == yvtH0B6Yhb4K[GxQbR51ltvkf] + 'A' - 'a' || !(yvtH0B6Yhb4K[GxQbR51ltvkf] - 'A' + 'a' != yvtH0B6Yhb4K[tCTIjYq4ZvV]))
                    z89SDJ = z89SDJ + 1;
                else
                    break;
                GxQbR51ltvkf++;
            };
        }
        if (yvtH0B6Yhb4K[tCTIjYq4ZvV] >= 'a' && yvtH0B6Yhb4K[tCTIjYq4ZvV] <= 'z')
            yvtH0B6Yhb4K[tCTIjYq4ZvV] = yvtH0B6Yhb4K[tCTIjYq4ZvV] + 'A' - 'a';
        printf ("(%c,%d)", yvtH0B6Yhb4K[tCTIjYq4ZvV], z89SDJ);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        tCTIjYq4ZvV = tCTIjYq4ZvV + z89SDJ;
        if (yvtH0B6Yhb4K[tCTIjYq4ZvV] == 0)
            break;
        z89SDJ = 0;
    };
}

