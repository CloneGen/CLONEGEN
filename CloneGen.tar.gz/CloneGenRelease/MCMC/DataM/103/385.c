int main () {
    char arr [(1926 - 925)];
    int Kuv50E, BwIT1o, iREuiM = (115 - 115);
    cin >> arr;
    BwIT1o = strlen (arr);
    for (Kuv50E = (797 - 797); Kuv50E < BwIT1o; Kuv50E = Kuv50E +1) {
        if ((int) arr[Kuv50E] > (506 - 414))
            arr[Kuv50E] = (char) ((int) arr[Kuv50E] - (874 - 842));
    }
    for (Kuv50E = (753 - 752); Kuv50E < BwIT1o; Kuv50E++) {
        if (arr[Kuv50E] != arr[Kuv50E -(106 - 105)]) {
            cout << '(' << arr[Kuv50E -(955 - 954)] << ',' << Kuv50E -iREuiM << ')';
            iREuiM = Kuv50E;
        };
    }
    cout << '(' << arr[BwIT1o -1] << ',' << BwIT1o -iREuiM << ')' << endl;
    return 0;
}

