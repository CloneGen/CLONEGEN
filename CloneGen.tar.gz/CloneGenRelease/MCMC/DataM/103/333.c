char tLcCsp47Q [(1589 - 589)];
int SXRAEDx [(1862 - 862)];
int a5LehzSTrvml, bM09L6dX;

main () {
    scanf ("%s", tLcCsp47Q);
    for (a5LehzSTrvml = (850 - 850); !('\0' == tLcCsp47Q[a5LehzSTrvml]); a5LehzSTrvml = a5LehzSTrvml + 1) {
        if (tLcCsp47Q[a5LehzSTrvml] >= 'a' && 'z' >= tLcCsp47Q[a5LehzSTrvml])
            tLcCsp47Q[a5LehzSTrvml] = tLcCsp47Q[a5LehzSTrvml] - 'a' + 'A';
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (a5LehzSTrvml = (545 - 545); tLcCsp47Q[a5LehzSTrvml] != '\0';) {
        {
            bM09L6dX = a5LehzSTrvml;
            while (1) {
                if (tLcCsp47Q[bM09L6dX] == tLcCsp47Q[a5LehzSTrvml])
                    SXRAEDx[a5LehzSTrvml]++;
                if (tLcCsp47Q[bM09L6dX] != tLcCsp47Q[a5LehzSTrvml])
                    break;
                bM09L6dX = bM09L6dX + 1;
            };
        }
        printf ("(%c,%d)", tLcCsp47Q[a5LehzSTrvml], SXRAEDx[a5LehzSTrvml]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        a5LehzSTrvml = a5LehzSTrvml + SXRAEDx[a5LehzSTrvml];
    }
    return (693 - 693);
}

