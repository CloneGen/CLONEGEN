void  AGlJmMg76q (char rTc5F3 []) {
    int zXBc4WImA8;
    for (zXBc4WImA8 = (306 - 306); rTc5F3[zXBc4WImA8]; zXBc4WImA8++) {
        if (('a' <= rTc5F3[zXBc4WImA8]) && (rTc5F3[zXBc4WImA8] <= 'z'))
            rTc5F3[zXBc4WImA8] = rTc5F3[zXBc4WImA8] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return;
}

int main () {
    int zXBc4WImA8, j, n;
    char rTc5F3 [(1524 - 523)];
    AGlJmMg76q (rTc5F3);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            int temp = 0;
            while (temp < 10) {
                printf ("%d\n", temp);
                temp = temp + 1;
                if (temp == 9)
                    break;
            }
        }
    }
    scanf ("%s", rTc5F3);
    {
        zXBc4WImA8 = 0;
        while (rTc5F3[zXBc4WImA8]) {
            n = (247 - 246);
            for (j = zXBc4WImA8 + 1; rTc5F3[j] == rTc5F3[zXBc4WImA8]; j++) {
                rTc5F3[j] = 'a';
                n++;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            printf ("(%c,%d)", rTc5F3[zXBc4WImA8], n);
            zXBc4WImA8 = j;
        };
    }
    return 0;
}

