main () {
    char a [1009];
    int wpbLETRYcaOI;
    int j;
    int m;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", a);
    m = strlen (a);
    for (wpbLETRYcaOI = (828 - 828); m > wpbLETRYcaOI;) {
        int cCINA1n0f8 = 0;
        {
            j = wpbLETRYcaOI;
            while (m > j) {
                if (a[wpbLETRYcaOI] == a[j] || a[wpbLETRYcaOI] == (a[j] + 'A' - 'a') || a[wpbLETRYcaOI] == (a[j] - 'A' + 'a'))
                    cCINA1n0f8 = cCINA1n0f8 + 1;
                else
                    break;
                j++;
            };
        }
        if (a[wpbLETRYcaOI] <= 'Z' && a[wpbLETRYcaOI] >= 'A')
            printf ("(%c,%d)", a[wpbLETRYcaOI], cCINA1n0f8);
        else
            printf ("(%c,%d)", a[wpbLETRYcaOI] + 'A' - 'a', cCINA1n0f8);
        wpbLETRYcaOI = wpbLETRYcaOI + cCINA1n0f8;
    };
}

