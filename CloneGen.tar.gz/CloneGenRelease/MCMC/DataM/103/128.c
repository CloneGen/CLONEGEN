int main () {
    char K5m89ZNa [1002] = {(447 - 447)};
    char Gu7J3VNaMGy4;
    int sum;
    int n;
    int m;
    int ZmG15f;
    sum = 0;
    n = strlen (K5m89ZNa);
    m = 'A' - 'a';
    scanf ("%s", K5m89ZNa);
    {
        ZmG15f = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (n > ZmG15f) {
            if ('a' <= K5m89ZNa[ZmG15f] && 'z' >= K5m89ZNa[ZmG15f]) {
                K5m89ZNa[ZmG15f] += m;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            ZmG15f++;
        };
    }
    Gu7J3VNaMGy4 = K5m89ZNa[0];
    for (ZmG15f = 0; ZmG15f <= n; ZmG15f = ZmG15f +1) {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (K5m89ZNa[ZmG15f] != Gu7J3VNaMGy4) {
            printf ("(%c,%d)", Gu7J3VNaMGy4, sum);
            sum = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            Gu7J3VNaMGy4 = K5m89ZNa[ZmG15f];
        }
        else {
            sum = sum + 1;
        };
    }
    return 0;
}

