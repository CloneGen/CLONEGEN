int main () {
    int time;
    int i;
    int j;
    int k;
    time = (89 - 88);
    char IUhovFIBe [1001];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", IUhovFIBe);
    if (IUhovFIBe[(48 - 48)] >= (1053 - 956))
        IUhovFIBe[(458 - 458)] -= 32;
    for (i = (605 - 604); IUhovFIBe[i]; i = i + 1) {
        if (IUhovFIBe[i] >= 97)
            IUhovFIBe[i] = IUhovFIBe[i] - 32;
        if (IUhovFIBe[i] == IUhovFIBe[i - (88 - 87)]) {
            time = time + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            printf ("(%c,%d)", IUhovFIBe[i - (753 - 752)], time);
            time = 1;
        };
    }
    printf ("(%c,%d)", IUhovFIBe[i - 1], time);
    return 0;
}

