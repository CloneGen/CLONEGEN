int main () {
    char n9kvRp26ZKjo;
    char nsoj2nfHZV [1000] = {0};
    gets (nsoj2nfHZV);
    int jIdlLAg;
    int ClFwDkx;
    int WVyIo7BM0c69;
    WVyIo7BM0c69 = 0;
    ClFwDkx = strlen (nsoj2nfHZV);
    {
        jIdlLAg = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (ClFwDkx > jIdlLAg) {
            if (97 <= nsoj2nfHZV[jIdlLAg])
                nsoj2nfHZV[jIdlLAg] = nsoj2nfHZV[jIdlLAg] - 32;
            jIdlLAg++;
        };
    }
    n9kvRp26ZKjo = nsoj2nfHZV[0];
    for (jIdlLAg = 1; jIdlLAg < ClFwDkx; jIdlLAg++) {
        if (nsoj2nfHZV[jIdlLAg] != n9kvRp26ZKjo) {
            WVyIo7BM0c69 = 0;
            printf ("(%c,%d)", nsoj2nfHZV[jIdlLAg - 1], WVyIo7BM0c69 +1);
            n9kvRp26ZKjo = nsoj2nfHZV[jIdlLAg];
        }
        else
            WVyIo7BM0c69 = WVyIo7BM0c69 +1;
    }
    printf ("(%c,%d)", n9kvRp26ZKjo, WVyIo7BM0c69 +1);
    return 0;
}

