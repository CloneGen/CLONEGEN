int main () {
    char temp;
    temp = '*';
    char MCGv5F;
    int d2GxiuOCs;
    d2GxiuOCs = (992 - 992);
    int ocGobjIMz91;
    ocGobjIMz91 = (294 - 293);
    int ssxLP3C;
    ssxLP3C = (305 - 304);
    for (; ssxLP3C;) {
        ++d2GxiuOCs;
        scanf ("%c", &MCGv5F);
        if ((878 - 781) <= MCGv5F &&122 >= MCGv5F)
            MCGv5F = MCGv5F -(258 - 226);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (MCGv5F == temp)
            ocGobjIMz91 = ocGobjIMz91 + 1;
        else if (temp == '*')
            ;
        else {
            printf ("(%c,%d)", temp, ocGobjIMz91);
            ocGobjIMz91 = 1;
        }
        temp = MCGv5F;
        if (MCGv5F == '\n')
            break;
    }
    return 0;
}

