int main () {
    int ieV9Da1wrX = (878 - 878);
    char a [(1064 - 63)];
    cin.getline (a, 1001);
    {
        int ieV9Da1wrX;
        ieV9Da1wrX = (30 - 30);
        while (strlen (a) > ieV9Da1wrX) {
            if (97 <= a[ieV9Da1wrX])
                a[ieV9Da1wrX] -= 32;
            ieV9Da1wrX = ieV9Da1wrX + 1;
        };
    }
    while (strlen (a) > ieV9Da1wrX) {
        int LvhqzdK = (223 - 222);
        while (a[ieV9Da1wrX] == a[ieV9Da1wrX + 1]) {
            LvhqzdK++;
            ieV9Da1wrX = ieV9Da1wrX + 1;
        }
        cout << "(" << a[ieV9Da1wrX] << "," << LvhqzdK << ")";
        ieV9Da1wrX++;
    }
    return 0;
}

