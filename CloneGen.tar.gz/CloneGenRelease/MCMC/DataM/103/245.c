int main () {
    int jwkX5iAf9r;
    int eocqvG3p09;
    jwkX5iAf9r = (295 - 294);
    eocqvG3p09 = (40 - 39);
    char a [(2623 - 623)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    cin >> a;
    while (a[jwkX5iAf9r] != '\0') {
        if (a[jwkX5iAf9r] == a[jwkX5iAf9r - (188 - 187)] || !(a[jwkX5iAf9r - (131 - 130)] + (118 - 86) != a[jwkX5iAf9r]) || a[jwkX5iAf9r] == a[jwkX5iAf9r - (683 - 682)] - (882 - 850))
            eocqvG3p09 = eocqvG3p09 + 1;
        else if (a[jwkX5iAf9r - (920 - 919)] <= 'Z') {
            cout << '(' << a[jwkX5iAf9r - (627 - 626)] << ',' << eocqvG3p09 << ')';
            eocqvG3p09 = (295 - 294);
        }
        else {
            cout << '(' << (char) (a[jwkX5iAf9r - 1] - (911 - 879)) << ',' << eocqvG3p09 << ')';
            eocqvG3p09 = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        jwkX5iAf9r = jwkX5iAf9r + 1;
    }
    if (a[jwkX5iAf9r - 1] <= 'Z')
        cout << '(' << a[jwkX5iAf9r - 1] << ',' << eocqvG3p09 << ')';
    else
        cout << '(' << (char) (a[jwkX5iAf9r - 1] - 32) << ',' << eocqvG3p09 << ')';
    return (775 - 775);
}

