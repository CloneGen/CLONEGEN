int main () {
    char tqkPFVzWD [1000], NKpOrWoG [10];
    int uqLU6K [10] = {(830 - 829), (356 - 355), (307 - 306), (273 - 272), (791 - 790), (983 - 982), (821 - 820), 1, 1, 1};
    int UsFUtvQKGdYZ;
    UsFUtvQKGdYZ = (446 - 446);
    int GnHkgwfr5 = (891 - 891);
    scanf ("%s", &tqkPFVzWD);
    for (; tqkPFVzWD[UsFUtvQKGdYZ] != '\0';) {
        if (tqkPFVzWD[UsFUtvQKGdYZ] >= 'a' && 'z' >= tqkPFVzWD[UsFUtvQKGdYZ])
            tqkPFVzWD[UsFUtvQKGdYZ] = tqkPFVzWD[UsFUtvQKGdYZ] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        UsFUtvQKGdYZ = UsFUtvQKGdYZ +1;
    }
    NKpOrWoG[GnHkgwfr5] = tqkPFVzWD[(590 - 590)];
    {
        int UsFUtvQKGdYZ = 1;
        while (UsFUtvQKGdYZ <= 999) {
            if (tqkPFVzWD[UsFUtvQKGdYZ] == tqkPFVzWD[UsFUtvQKGdYZ -1])
                uqLU6K[GnHkgwfr5]++;
            else {
                GnHkgwfr5 = GnHkgwfr5 +1;
                NKpOrWoG[GnHkgwfr5] = tqkPFVzWD[UsFUtvQKGdYZ];
            }
            if (tqkPFVzWD[UsFUtvQKGdYZ] == '\0')
                break;
            UsFUtvQKGdYZ = UsFUtvQKGdYZ +1;
        };
    }
    {
        int UsFUtvQKGdYZ = 0;
        while (UsFUtvQKGdYZ <= GnHkgwfr5 -1) {
            printf ("(%c,%d)", NKpOrWoG[UsFUtvQKGdYZ], uqLU6K[UsFUtvQKGdYZ]);
            UsFUtvQKGdYZ++;
        };
    };
}

