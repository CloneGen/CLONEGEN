main () {
    char U5aGIQo [(1849 - 848)], AzLbq6ukym [(1299 - 298)];
    int c [1001];
    int xwkh8QF;
    int m;
    int M;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", U5aGIQo);
    {
        xwkh8QF = 557 - 557;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!((934 - 934) == U5aGIQo[xwkh8QF])) {
            if ('a' <= U5aGIQo[xwkh8QF] && U5aGIQo[xwkh8QF] <= 'z')
                U5aGIQo[xwkh8QF] = U5aGIQo[xwkh8QF] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            xwkh8QF++;
        };
    }
    for (xwkh8QF = (545 - 545), m = (176 - 176), c[m] = (211 - 210), AzLbq6ukym[m] = U5aGIQo[(757 - 757)]; U5aGIQo[xwkh8QF + (653 - 652)] != 0; xwkh8QF = xwkh8QF + 1) {
        if (U5aGIQo[xwkh8QF] == U5aGIQo[xwkh8QF + (700 - 699)])
            c[m]++;
        else {
            m++;
            AzLbq6ukym[m] = U5aGIQo[xwkh8QF + (530 - 529)];
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            c[m] = 1;
        };
    }
    M = m;
    for (m = 0; m <= M; m = m + 1) {
        printf ("(%c,%d)", AzLbq6ukym[m], c[m]);
    };
}

