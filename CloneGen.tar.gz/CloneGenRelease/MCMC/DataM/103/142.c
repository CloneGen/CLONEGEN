main () {
    char RFeZVNL5AfX [(1259 - 259)];
    gets (RFeZVNL5AfX);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int gwhNCZKUp, BrmLAK, j, ZBvzUrA, lJHG9q7cX, a9xNR8sl;
    a9xNR8sl = strlen (RFeZVNL5AfX);
    {
        BrmLAK = 708 - 708;
        while (a9xNR8sl > BrmLAK) {
            RFeZVNL5AfX[BrmLAK] = toupper (RFeZVNL5AfX[BrmLAK]);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            BrmLAK = BrmLAK +1;
        };
    }
    {
        BrmLAK = 808 - 808;
        while (a9xNR8sl > BrmLAK) {
            lJHG9q7cX = (48 - 47);
            {
                j = BrmLAK;
                while (j < a9xNR8sl) {
                    if (!(RFeZVNL5AfX[j + 1] != RFeZVNL5AfX[j]))
                        lJHG9q7cX++;
                    else
                        break;
                    j = j + 1;
                };
            }
            if (RFeZVNL5AfX[BrmLAK] != RFeZVNL5AfX[BrmLAK -1])
                printf ("(%c,%d)", RFeZVNL5AfX[BrmLAK], lJHG9q7cX);
            BrmLAK = BrmLAK +1;
        };
    };
}

