int main () {
    int BYjMNHTQ, j, max;
    char P93RjWf6Piv [(2080 - 980)] = {'\0'};
    cin >> P93RjWf6Piv;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        BYjMNHTQ = 598 - 598;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (BYjMNHTQ < strlen (P93RjWf6Piv)) {
            if (P93RjWf6Piv[BYjMNHTQ] >= 'a' && 'z' >= P93RjWf6Piv[BYjMNHTQ])
                P93RjWf6Piv[BYjMNHTQ] = P93RjWf6Piv[BYjMNHTQ] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            BYjMNHTQ++;
        };
    }
    for (BYjMNHTQ = (575 - 575); BYjMNHTQ < strlen (P93RjWf6Piv); BYjMNHTQ = BYjMNHTQ +1) {
        {
            j = 593 - 593;
            while (j < strlen (P93RjWf6Piv) - BYjMNHTQ) {
                if (P93RjWf6Piv[BYjMNHTQ] == P93RjWf6Piv[BYjMNHTQ +j])
                    max = j + (622 - 621);
                else
                    break;
                j = j + 1;
            };
        }
        cout << "(" << P93RjWf6Piv[BYjMNHTQ] << ',' << max << ")";
        BYjMNHTQ = BYjMNHTQ +max - 1;
    }
    return 0;
}

