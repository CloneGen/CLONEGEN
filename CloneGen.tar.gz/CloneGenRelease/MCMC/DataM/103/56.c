int main () {
    int Ql01OBFzvE = (67 - 67), jsP05lJhk = (827 - 827), VCciPolY [(1643 - 643)] [2] = {(303 - 303)};
    char str [(1847 - 747)] = {(890 - 890)};
    cin.getline (str, 1100, '\n');
    if ('A' <= str[(944 - 944)] && 'Z' >= str[(349 - 349)])
        VCciPolY[(468 - 468)][(37 - 37)] = str[(906 - 906)];
    else
        VCciPolY[(574 - 574)][(349 - 349)] = str[(559 - 559)] + 'A' - 'a';
    VCciPolY[(799 - 799)][(247 - 246)]++;
    for (Ql01OBFzvE = (93 - 92); !((464 - 464) == str[Ql01OBFzvE]); Ql01OBFzvE++) {
        if (str[Ql01OBFzvE] >= 'A' && 'Z' >= str[Ql01OBFzvE] && str[Ql01OBFzvE] == VCciPolY[jsP05lJhk][(693 - 693)] || str[Ql01OBFzvE] + 'A' - 'a' == VCciPolY[jsP05lJhk][(468 - 468)])
            VCciPolY[jsP05lJhk][1]++;
        else {
            jsP05lJhk++;
            if (str[Ql01OBFzvE] >= 'A' && str[0] <= 'Z')
                VCciPolY[jsP05lJhk][0] = str[Ql01OBFzvE];
            else
                VCciPolY[jsP05lJhk][0] = str[Ql01OBFzvE] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            VCciPolY[jsP05lJhk][1]++;
        };
    }
    for (Ql01OBFzvE = 0; Ql01OBFzvE <= jsP05lJhk; Ql01OBFzvE++)
        cout << '(' << (char) VCciPolY[Ql01OBFzvE][0] << ',' << VCciPolY[Ql01OBFzvE][1] << ')';
    return 0;
}

