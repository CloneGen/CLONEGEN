int main () {
    int jTEzH3tA, UP206gaLJ3;
    int vlCcYmzjo;
    vlCcYmzjo = 0;
    char a [(1106 - 106)];
    gets (a);
    getchar ();
    getchar ();
    getchar ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    jTEzH3tA = strlen (a);
    for (; jTEzH3tA > vlCcYmzjo;) {
        int k = (826 - 825);
        UP206gaLJ3 = vlCcYmzjo + (689 - 688);
        for (; (a[vlCcYmzjo] == a[UP206gaLJ3] || a[vlCcYmzjo] == a[UP206gaLJ3] - 'a' + 'A' || a[vlCcYmzjo] == a[UP206gaLJ3] + 'a' - 'A');) {
            UP206gaLJ3++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            k++;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (a[vlCcYmzjo] >= 'a' && a[vlCcYmzjo] <= 'z')
            a[vlCcYmzjo] = a[vlCcYmzjo] - 'a' + 'A';
        printf ("(%c,%d)", a[vlCcYmzjo], k);
        vlCcYmzjo = UP206gaLJ3;
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

