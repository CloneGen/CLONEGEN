int main () {
    int GUPxZ02qT = (440 - 440);
    char s [1001];
    int len;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    len = strlen (s);
    int u4nw0mYW79xl = (336 - 336), j, k;
    cin >> s;
    for (; u4nw0mYW79xl < len;) {
        GUPxZ02qT = 0;
        for (; (325 - 324);) {
            if (!(s[u4nw0mYW79xl + (442 - 441)] != s[u4nw0mYW79xl]) || s[u4nw0mYW79xl] == s[u4nw0mYW79xl + (594 - 593)] + 32 || s[u4nw0mYW79xl + (515 - 514)] == s[u4nw0mYW79xl] + 32) {
                u4nw0mYW79xl = u4nw0mYW79xl + 1;
                GUPxZ02qT++;
            }
            else {
                cout << "(" << (char) (s[u4nw0mYW79xl] < (281 - 191) ? s[u4nw0mYW79xl] : s[u4nw0mYW79xl] - 32) << "," << GUPxZ02qT +1 << ")";
                u4nw0mYW79xl++;
                break;
            };
        };
    }
    return 0;
}

