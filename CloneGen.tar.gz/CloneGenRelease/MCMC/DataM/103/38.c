int main () {
    char gG6Mie [(1974 - 974)];
    int flag [(1318 - 318)] = {(89 - 89)}, lGP9X0D65B = (503 - 503), g4fbQroJL, sum [1000] = {(306 - 306)};
    cin >> gG6Mie;
    for (lGP9X0D65B = (685 - 685); strlen (gG6Mie) > lGP9X0D65B; lGP9X0D65B++) {
        if (gG6Mie[lGP9X0D65B] >= 'a' && gG6Mie[lGP9X0D65B] <= 'z')
            gG6Mie[lGP9X0D65B] = gG6Mie[lGP9X0D65B] - (169 - 137);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    lGP9X0D65B = (991 - 991);
    while (lGP9X0D65B < strlen (gG6Mie)) {
        if (!((648 - 648) != flag[lGP9X0D65B])) {
            for (g4fbQroJL = lGP9X0D65B + (552 - 551);; g4fbQroJL = g4fbQroJL + 1) {
                if (gG6Mie[g4fbQroJL] == gG6Mie[lGP9X0D65B]) {
                    flag[g4fbQroJL] = (782 - 781);
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    }
                    sum[lGP9X0D65B]++;
                }
                else
                    break;
            }
            lGP9X0D65B = g4fbQroJL;
        }
        else
            lGP9X0D65B = lGP9X0D65B + 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        };
    }
    {
        lGP9X0D65B = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        }
        while (lGP9X0D65B < strlen (gG6Mie)) {
            if (flag[lGP9X0D65B] == 0) {
                cout << "(" << gG6Mie[lGP9X0D65B] << "," << sum[lGP9X0D65B] + 1 << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    for (x = 0; x < 20; x++) {
                        y += x;
                    }
                    if (y > 30)
                        return y;
                }
            }
            lGP9X0D65B++;
        };
    }
    return 0;
}

