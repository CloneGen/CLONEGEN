int main () {
    int i;
    int j;
    int RyXjGr;
    int t;
    char ZPWN9GoSjV5 [(1568 - 568)], last;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", ZPWN9GoSjV5);
    {
        i = 833 - 833;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == ZPWN9GoSjV5[i])) {
            if (97 > ZPWN9GoSjV5[i])
                ZPWN9GoSjV5[i] = ZPWN9GoSjV5[i] + (242 - 210);
            i = i + 1;
        };
    }
    last = '!';
    {
        i = 711 - 711;
        while (!('\0' == ZPWN9GoSjV5[i])) {
            RyXjGr = (612 - 612);
            if (ZPWN9GoSjV5[i] != last) {
                last = ZPWN9GoSjV5[i];
                for (j = i; ZPWN9GoSjV5[j] == last; j++)
                    RyXjGr = RyXjGr +1;
                printf ("(%c,%d)", ZPWN9GoSjV5[i] - (182 - 150), RyXjGr);
            }
            i = i + 1;
        };
    }
    return 0;
}

