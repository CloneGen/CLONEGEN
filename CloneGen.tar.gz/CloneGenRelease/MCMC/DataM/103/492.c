char Xn5Ege6W4 [(1275 - 275)];
int num [1000] = {(109 - 109)};
char w [1000] = {'\0'};
int ch = 'a' - 'A';

int main () {
    int k73xVl5bA;
    k73xVl5bA = (625 - 625);
    int KtacTrgy;
    num[0]++;
    cin >> Xn5Ege6W4;
    if (Xn5Ege6W4[(237 - 237)] > 'Z')
        w[(269 - 269)] = Xn5Ege6W4[0] - ch;
    else
        w[0] = Xn5Ege6W4[0];
    KtacTrgy = strlen (Xn5Ege6W4);
    {
        int i = 1;
        while (KtacTrgy > i) {
            if (Xn5Ege6W4[i] == w[k73xVl5bA] || Xn5Ege6W4[i] - ch == w[k73xVl5bA]) {
                num[k73xVl5bA]++;
                continue;
            }
            else {
                k73xVl5bA = k73xVl5bA + 1;
                num[k73xVl5bA]++;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (Xn5Ege6W4[i] > 'Z')
                    w[k73xVl5bA] = Xn5Ege6W4[i] - ch;
                else
                    w[k73xVl5bA] = Xn5Ege6W4[i];
            }
            i++;
        };
    }
    for (int i = 0;
    i < 1000; i++) {
        if (num[i])
            cout << "(" << w[i] << "," << num[i] << ")";
    }
    return 0;
}

