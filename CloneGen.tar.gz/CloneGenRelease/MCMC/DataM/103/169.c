main () {
    char nQqryVhbDN [1000];
    int j;
    int gZtvPe;
    j = (606 - 605);
    scanf ("%s", nQqryVhbDN);
    {
        gZtvPe = 678 - 678;
        while (nQqryVhbDN[gZtvPe] != '\0') {
            if (nQqryVhbDN[gZtvPe] >= (351 - 254))
                nQqryVhbDN[gZtvPe] = nQqryVhbDN[gZtvPe] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            gZtvPe = gZtvPe + 1;
        };
    }
    {
        gZtvPe = 0;
        while (nQqryVhbDN[gZtvPe] != '\0') {
            if (nQqryVhbDN[gZtvPe + 1] == nQqryVhbDN[gZtvPe])
                j = j + 1;
            else {
                printf ("(%c,%d)", nQqryVhbDN[gZtvPe], j);
                j = 1;
            }
            gZtvPe++;
        };
    };
}

