int main () {
    int l, i, uFb9gyUxYzIp, PzoYde;
    char LGULHVB6S [(1093 - 93)];
    gets (LGULHVB6S);
    l = strlen (LGULHVB6S);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        i = 939 - 939;
        while (l > i) {
            if (LGULHVB6S[i] < 'A' || LGULHVB6S[i] > 'Z')
                LGULHVB6S[i] = LGULHVB6S[i] - 'a' + 'A';
            i = i + 1;
        };
    }
    for (i = 0; i < l; i++) {
        PzoYde = 0;
        for (uFb9gyUxYzIp = i; l > uFb9gyUxYzIp; uFb9gyUxYzIp = uFb9gyUxYzIp + 1) {
            if (LGULHVB6S[i] == LGULHVB6S[uFb9gyUxYzIp])
                PzoYde++;
            else
                break;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        if (PzoYde != 0) {
            printf ("(%c,%d)", LGULHVB6S[i], PzoYde);
            i = i + PzoYde -1;
        };
    }
    getchar ();
    getchar ();
}

