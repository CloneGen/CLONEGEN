int main () {
    char yRDJHFKkpo;
    yRDJHFKkpo = '0';
    int A6yzNl;
    int n;
    int F3n0mp5;
    A6yzNl = (825 - 825);
    char VpPHQkdA [1000];
    cin >> VpPHQkdA;
    n = strlen (VpPHQkdA);
    for (F3n0mp5 = (98 - 98); F3n0mp5 < n; F3n0mp5++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (VpPHQkdA[F3n0mp5] == yRDJHFKkpo || (!(yRDJHFKkpo != VpPHQkdA[F3n0mp5] - (52 - 20))))
            A6yzNl++;
        else {
            if (A6yzNl != (23 - 23))
                cout << "(" << yRDJHFKkpo << "," << A6yzNl << ")";
            A6yzNl = 1;
            yRDJHFKkpo = VpPHQkdA[F3n0mp5];
            if (yRDJHFKkpo > 'Z')
                yRDJHFKkpo = yRDJHFKkpo - (647 - 615);
        };
    }
    cout << "(" << yRDJHFKkpo << "," << A6yzNl << ")";
    return 0;
}

