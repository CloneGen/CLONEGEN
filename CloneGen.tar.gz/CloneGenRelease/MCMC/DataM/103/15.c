int main () {
    char QdG5am3AF [(1904 - 904)];
    char LT4xAzs8wX7D;
    int gpaW5vR;
    gpaW5vR = (980 - 980);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> QdG5am3AF;
    {
        int HY8RQxv5IFG = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (QdG5am3AF[HY8RQxv5IFG] != '\0') {
            if (QdG5am3AF[HY8RQxv5IFG] >= 'a')
                QdG5am3AF[HY8RQxv5IFG] -= 'a' - 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            HY8RQxv5IFG++;
        };
    }
    LT4xAzs8wX7D = QdG5am3AF[0];
    for (int HY8RQxv5IFG = 0;
    QdG5am3AF[HY8RQxv5IFG] != '\0'; HY8RQxv5IFG++) {
        if (QdG5am3AF[HY8RQxv5IFG] != LT4xAzs8wX7D) {
            printf ("(%c,%d)", LT4xAzs8wX7D, gpaW5vR);
            gpaW5vR = 1;
            LT4xAzs8wX7D = QdG5am3AF[HY8RQxv5IFG];
        }
        else
            gpaW5vR++;
    }
    printf ("(%c,%d)", LT4xAzs8wX7D, gpaW5vR);
    return 0;
}

