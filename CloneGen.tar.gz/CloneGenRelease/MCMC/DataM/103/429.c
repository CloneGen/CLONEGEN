int main () {
    char lC35vd8x2Ra [(1953 - 948)];
    gets (lC35vd8x2Ra);
    int B9nY7RWw8;
    int XlawoVzq;
    int NHaA4r1mx;
    B9nY7RWw8 = (185 - 185);
    XlawoVzq = (300 - 299);
    while (!('\0' == lC35vd8x2Ra[B9nY7RWw8])) {
        if ((938 - 938) <= lC35vd8x2Ra[B9nY7RWw8] - 'a' && lC35vd8x2Ra[B9nY7RWw8] - 'z' <= (968 - 968))
            lC35vd8x2Ra[B9nY7RWw8] = lC35vd8x2Ra[B9nY7RWw8] - 'a' + 'A';
        B9nY7RWw8 = B9nY7RWw8 +1;
    }
    B9nY7RWw8 = (281 - 281);
    for (; lC35vd8x2Ra[B9nY7RWw8] != '\0';) {
        if ((lC35vd8x2Ra[B9nY7RWw8]) != (lC35vd8x2Ra[B9nY7RWw8 +1])) {
            printf ("(%c,%d)", lC35vd8x2Ra[B9nY7RWw8], XlawoVzq);
            XlawoVzq = 1;
        }
        else
            XlawoVzq = XlawoVzq +1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        B9nY7RWw8++;
    };
}

