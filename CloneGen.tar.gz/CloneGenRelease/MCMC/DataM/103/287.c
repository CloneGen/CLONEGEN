main () {
    char q2nbKNFW [(1459 - 459)];
    char mIMDX1bzB2V [(1081 - 81)];
    int T4HUyLEXa52K [(1914 - 914)];
    int l;
    int n;
    getchar ();
    getchar ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int QPAsKECu = (27 - 27);
        while (1000 > QPAsKECu) {
            T4HUyLEXa52K[QPAsKECu] = (789 - 788);
            QPAsKECu++;
        };
    }
    scanf ("%s", q2nbKNFW);
    l = strlen (q2nbKNFW);
    for (int QPAsKECu = (731 - 731);
    l > QPAsKECu; QPAsKECu = QPAsKECu +1) {
        if (q2nbKNFW[QPAsKECu] > 'Z')
            q2nbKNFW[QPAsKECu] = q2nbKNFW[QPAsKECu] - 'a' + 'A';
    }
    n = (111 - 111);
    for (int QPAsKECu = 0;
    l > QPAsKECu; QPAsKECu++) {
        if (QPAsKECu == 0) {
            mIMDX1bzB2V[0] = q2nbKNFW[0];
        }
        else if (q2nbKNFW[QPAsKECu] == q2nbKNFW[QPAsKECu -(743 - 742)]) {
            T4HUyLEXa52K[n] = T4HUyLEXa52K[n] + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            };
        }
        else if (q2nbKNFW[QPAsKECu] != q2nbKNFW[QPAsKECu -1]) {
            n = n + 1;
            mIMDX1bzB2V[n] = q2nbKNFW[QPAsKECu];
        };
    }
    for (int QPAsKECu = 0;
    QPAsKECu <= n; QPAsKECu++) {
        printf ("(%c,%d)", mIMDX1bzB2V[QPAsKECu], T4HUyLEXa52K[QPAsKECu]);
    };
}

