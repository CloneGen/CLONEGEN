main () {
    char jTxHEhN4jQ [maxl + 1], t;
    int ans;
    int lawXQ7xBzMO;
    ans = (437 - 437);
    t = (446 - 446);
    scanf ("%s", jTxHEhN4jQ);
    {
        lawXQ7xBzMO = 0;
        while (!('\0' == jTxHEhN4jQ[lawXQ7xBzMO])) {
            if ((!(t != jTxHEhN4jQ[lawXQ7xBzMO])) || (!(t - 'A' + 'a' != jTxHEhN4jQ[lawXQ7xBzMO])))
                ans = ans + 1;
            else {
                if (lawXQ7xBzMO == 0)
                    ans++;
                else {
                    printf ("%d)", ans);
                    ans = 1;
                }
                if ((jTxHEhN4jQ[lawXQ7xBzMO] <= 'z') && (jTxHEhN4jQ[lawXQ7xBzMO] >= 'a'))
                    t = jTxHEhN4jQ[lawXQ7xBzMO] - 'a' + 'A';
                else
                    t = jTxHEhN4jQ[lawXQ7xBzMO];
                printf ("(%c,", t);
            }
            lawXQ7xBzMO = lawXQ7xBzMO + 1;
        };
    }
    printf ("%d)", ans);
}

