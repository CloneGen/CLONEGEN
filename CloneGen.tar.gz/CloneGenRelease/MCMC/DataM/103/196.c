int main () {
    int a = (923 - 922), S2bRH9y6pL, c;
    char jdptiBOhLc2I [(1081 - 81)];
    scanf ("%s", jdptiBOhLc2I);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int jJF9WNmHZpP = (983 - 983);
        while (!('\0' == jdptiBOhLc2I[jJF9WNmHZpP])) {
            if ('a' <= jdptiBOhLc2I[jJF9WNmHZpP])
                jdptiBOhLc2I[jJF9WNmHZpP] = jdptiBOhLc2I[jJF9WNmHZpP] - 'a' + 'A';
            else
                jdptiBOhLc2I[jJF9WNmHZpP] = jdptiBOhLc2I[jJF9WNmHZpP];
            jJF9WNmHZpP = jJF9WNmHZpP + 1;
        };
    }
    for (int jJF9WNmHZpP = (962 - 962);
    jdptiBOhLc2I[jJF9WNmHZpP] != '\0'; jJF9WNmHZpP = jJF9WNmHZpP + 1)
        if (jdptiBOhLc2I[jJF9WNmHZpP] == jdptiBOhLc2I[jJF9WNmHZpP + (38 - 37)]) {
            a++;
            continue;
        }
        else {
            printf ("(%c,%d)", jdptiBOhLc2I[jJF9WNmHZpP], a);
            a = (687 - 686);
        }
    return 0;
}

