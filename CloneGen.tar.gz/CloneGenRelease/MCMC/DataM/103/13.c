main () {
    char VZyGY9XifmD [1000];
    int i;
    int j;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", VZyGY9XifmD);
    for (i = 0; VZyGY9XifmD[i] != '\0';) {
        int kk;
        kk = i;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        int ws;
        {
            ws = i;
            while (!('\0' == VZyGY9XifmD[ws])) {
                if (!(VZyGY9XifmD[ws + (177 - 176)] == VZyGY9XifmD[ws]) && VZyGY9XifmD[ws] != VZyGY9XifmD[ws + (757 - 756)] + (1006 - 974) && VZyGY9XifmD[ws] != VZyGY9XifmD[ws + (129 - 128)] - 32)
                    break;
                ws = ws + 1;
            };
        }
        if (kk < ws) {
            if (VZyGY9XifmD[ws] >= 97)
                VZyGY9XifmD[ws] = VZyGY9XifmD[ws] - 32;
            printf ("(%c,%d)", VZyGY9XifmD[ws], ws - kk + 1);
            i = ws + 1;
        }
        else {
            if (VZyGY9XifmD[ws] >= 97)
                VZyGY9XifmD[ws] = VZyGY9XifmD[ws] - 32;
            printf ("(%c,1)", VZyGY9XifmD[ws]);
            i++;
        };
    }
    getchar ();
    getchar ();
}

