int main () {
    struct   {
        char gdMLJD7s1P;
        int d;
    }
    BkCXmy9ou2jJ [27];
    char aWlGKA [1010];
    int m;
    int A;
    int l;
    m = (376 - 375);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    A = 0;
    cin >> aWlGKA;
    l = strlen (aWlGKA);
    for (int YbvXk2 = 0;
    l > YbvXk2; YbvXk2 = YbvXk2 +1) {
        if (aWlGKA[YbvXk2] >= 97)
            aWlGKA[YbvXk2] -= (540 - 508);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    BkCXmy9ou2jJ[(942 - 941)].gdMLJD7s1P = aWlGKA[0], BkCXmy9ou2jJ[(530 - 529)].d = 1;
    {
        int YbvXk2 = 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (YbvXk2 < l) {
            if (aWlGKA[YbvXk2] == aWlGKA[YbvXk2 -1])
                BkCXmy9ou2jJ[m].d++;
            else {
                BkCXmy9ou2jJ[++m].gdMLJD7s1P = aWlGKA[YbvXk2];
                BkCXmy9ou2jJ[m].d = 1;
            }
            YbvXk2 = YbvXk2 +1;
        };
    }
    for (int YbvXk2 = 1;
    YbvXk2 <= m; YbvXk2 = YbvXk2 +1)
        cout << "(" << BkCXmy9ou2jJ[YbvXk2].gdMLJD7s1P << "," << BkCXmy9ou2jJ[YbvXk2].d << ")";
    return 0;
}

