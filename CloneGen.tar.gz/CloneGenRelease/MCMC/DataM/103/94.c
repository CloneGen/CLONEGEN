int main () {
    int len;
    int sum;
    len = (949 - 949);
    sum = (842 - 842);
    int vujxnfpGT = (529 - 529), DMFBL19 = (982 - 982), used [1100];
    char vUjT5buA9FB0 [(1886 - 786)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin.getline (vUjT5buA9FB0, 1100);
    len = strlen (vUjT5buA9FB0);
    for (vujxnfpGT = (730 - 730); len > vujxnfpGT; vujxnfpGT = vujxnfpGT + 1) {
        if ('a' <= vUjT5buA9FB0[vujxnfpGT] && vUjT5buA9FB0[vujxnfpGT] <= 'z')
            vUjT5buA9FB0[vujxnfpGT] = vUjT5buA9FB0[vujxnfpGT] - (194 - 162);
        else
            vUjT5buA9FB0[vujxnfpGT] = vUjT5buA9FB0[vujxnfpGT];
    }
    {
        vujxnfpGT = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (len > vujxnfpGT) {
            used[vujxnfpGT] = (595 - 594);
            vujxnfpGT++;
        };
    }
    {
        vujxnfpGT = 0;
        while (len > vujxnfpGT) {
            if (!(0 == used[vujxnfpGT])) {
                DMFBL19 = vujxnfpGT + 1;
                while (vUjT5buA9FB0[vujxnfpGT] == vUjT5buA9FB0[DMFBL19]) {
                    used[vujxnfpGT]++;
                    used[DMFBL19] = 0;
                    DMFBL19 = DMFBL19 +1;
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            vujxnfpGT++;
        };
    }
    for (vujxnfpGT = 0; vujxnfpGT < len; vujxnfpGT = vujxnfpGT + 1) {
        if (used[vujxnfpGT] != 0)
            cout << "(" << vUjT5buA9FB0[vujxnfpGT] << "," << used[vujxnfpGT] << ")";
    }
    return 0;
}

