int main () {
    int x [1000], a, M2sjzcCTrO, Dq9FfxN7Ll84, IyMUF2SfG, Rf6umFKQLA1a, k, t = (328 - 328);
    char n [(1803 - 803)];
    scanf ("%s", n);
    IyMUF2SfG = (318 - 318);
    for (Rf6umFKQLA1a = (442 - 442); Rf6umFKQLA1a < 1000; Rf6umFKQLA1a++) {
        x[Rf6umFKQLA1a] = (25 - 25);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(0 == n[Rf6umFKQLA1a]))
            IyMUF2SfG = IyMUF2SfG +1;
        else
            break;
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (Rf6umFKQLA1a = 0; IyMUF2SfG > Rf6umFKQLA1a; Rf6umFKQLA1a++) {
        if (('a' <= n[Rf6umFKQLA1a]) && ('z' >= n[Rf6umFKQLA1a]))
            n[Rf6umFKQLA1a] = n[Rf6umFKQLA1a] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        };
    }
    Rf6umFKQLA1a = 0;
    for (Rf6umFKQLA1a = 0; IyMUF2SfG > Rf6umFKQLA1a; Rf6umFKQLA1a++) {
        for (; n[Rf6umFKQLA1a] == n[Rf6umFKQLA1a +1];) {
            for (k = Rf6umFKQLA1a; k < IyMUF2SfG; k = k + 1)
                n[k] = n[k + 1];
            IyMUF2SfG = IyMUF2SfG -1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            x[t]++;
        }
        t++;
    }
    for (Rf6umFKQLA1a = 0; Rf6umFKQLA1a < t; Rf6umFKQLA1a++)
        printf ("(%c,%d)", n[Rf6umFKQLA1a], x[Rf6umFKQLA1a] + 1);
}

