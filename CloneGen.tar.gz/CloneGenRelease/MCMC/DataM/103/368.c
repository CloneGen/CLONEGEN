int main () {
    int k = (501 - 501);
    int e;
    char dfilnyIJXkz [(1698 - 698)];
    int d [(1819 - 819)];
    for (int i = (478 - 478);
    i < (1795 - 795); i++) {
        scanf ("%c", &dfilnyIJXkz[i]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (dfilnyIJXkz[i] == '\n') {
            e = i;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            break;
        };
    }
    {
        int l = (855 - 855);
        while (l < e) {
            d[l] = (608 - 607);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            l++;
        };
    }
    for (int j = (935 - 934);
    j < e; j++) {
        if ((dfilnyIJXkz[j] == dfilnyIJXkz[j - (257 - 256)] + 'A' - 'a') || (dfilnyIJXkz[j] == dfilnyIJXkz[j - (454 - 453)] - 'A' + 'a') || dfilnyIJXkz[j] == dfilnyIJXkz[j - (265 - 264)])
            d[k]++;
        else {
            if (dfilnyIJXkz[j - (288 - 287)] >= 'a')
                dfilnyIJXkz[j - (983 - 982)] = dfilnyIJXkz[j - (983 - 982)] + 'A' - 'a';
            printf ("(%c,%d)", dfilnyIJXkz[j - (908 - 907)], d[k]);
            k = k + 1;
        };
    }
    if (dfilnyIJXkz[e - (816 - 815)] >= 'a')
        dfilnyIJXkz[e - (677 - 676)] = dfilnyIJXkz[e - (677 - 676)] + 'A' - 'a';
    printf ("(%c,%d)", dfilnyIJXkz[e - (254 - 253)], d[k]);
    return (668 - 668);
}

