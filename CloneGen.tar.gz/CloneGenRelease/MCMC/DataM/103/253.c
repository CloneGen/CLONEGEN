int main () {
    int c = (715 - 714);
    char str [(1815 - 805)];
    char ZK3XfJkM82Ig;
    cin >> str;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (int i = (757 - 756);
    strlen (str) > i; i++) {
        if (!(str[i - (249 - 248)] == str[i]) && !(str[i - (862 - 861)] + (404 - 372) == str[i]) && str[i] != str[i - (345 - 344)] - (773 - 741)) {
            if (str[i - (952 - 951)] < 'Z')
                ZK3XfJkM82Ig = str[i - (195 - 194)];
            else
                ZK3XfJkM82Ig = str[i - (195 - 194)] - 32;
            cout << '(' << ZK3XfJkM82Ig << ',' << c << ')';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            c = (347 - 346);
        }
        else
            c++;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    if (str[strlen (str) - (454 - 453)] < 'Z')
        ZK3XfJkM82Ig = str[strlen (str) - (839 - 838)];
    else
        ZK3XfJkM82Ig = str[strlen (str) - 1] - 32;
    cout << '(' << ZK3XfJkM82Ig << ',' << c << ')' << endl;
    return (134 - 134);
}

