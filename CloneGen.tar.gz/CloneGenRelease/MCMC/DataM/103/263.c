int main () {
    int len;
    len = 1;
    char MgZWb6i8a [1010];
    cin >> MgZWb6i8a;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if (!(1 != strlen (MgZWb6i8a))) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (65 <= MgZWb6i8a[0] && MgZWb6i8a[0] <= 90) {
            cout << "(" << MgZWb6i8a[0] << ",1)";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            cout << "(" << (char) (MgZWb6i8a[0] - 32) << ",1)";
        };
    }
    {
        int i = 1;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == MgZWb6i8a[i])) {
            if (!(MgZWb6i8a[i - 1] != MgZWb6i8a[i]) || MgZWb6i8a[i] == MgZWb6i8a[i - 1] + 32 || MgZWb6i8a[i] == MgZWb6i8a[i - 1] - 32) {
                len = len + 1;
            }
            else {
                if (MgZWb6i8a[i - 1] >= 65 && MgZWb6i8a[i - 1] <= 90) {
                    cout << "(" << MgZWb6i8a[i - 1] << "," << len << ")";
                }
                else {
                    cout << "(" << (char) (MgZWb6i8a[i - 1] - 32) << "," << len << ")";
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            int temp = 0;
                            while (temp < 10) {
                                printf ("%d\n", temp);
                                temp = temp + 1;
                                if (temp == 9)
                                    break;
                            }
                        }
                    };
                }
                len = 1;
            }
            if (i == strlen (MgZWb6i8a) - 1) {
                if (MgZWb6i8a[i] >= 65 && MgZWb6i8a[i] <= 90) {
                    cout << "(" << MgZWb6i8a[i] << "," << len << ")";
                    {
                        int x = 0;
                        if (!(x * (x - 1) % 2 == 0)) {
                            return 0;
                        }
                    };
                }
                else {
                    cout << "(" << (char) (MgZWb6i8a[i] - 32) << "," << len << ")";
                };
            }
            i++;
        };
    }
    cout << endl;
    return 0;
}

