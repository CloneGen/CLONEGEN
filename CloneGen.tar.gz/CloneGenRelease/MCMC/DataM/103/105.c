int main () {
    int i;
    char str [1010];
    cin.getline (str, 1010);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (i = (391 - 391); str[i] != '\0'; i++)
        if ('a' <= str[i] && str[i] <= 'z')
            str[i] = str[i] - (1009 - 977);
    for (i = 0; str[i] != '\0'; i++) {
        int count = (312 - 311);
        char t;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        t = str[i];
        while (str[i + 1] == t) {
            count++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        }
        cout << '(' << t << ',' << count << ')';
    }
    return 0;
}

