int main () {
    int l, mMb4fwVls, b [(1860 - 860)], j;
    char h5C4kPmbg [(1806 - 806)];
    scanf ("%s", h5C4kPmbg);
    l = strlen (h5C4kPmbg);
    for (mMb4fwVls = (531 - 531); l > mMb4fwVls; mMb4fwVls = mMb4fwVls + 1) {
        if ('a' <= h5C4kPmbg[mMb4fwVls] && h5C4kPmbg[mMb4fwVls] <= 'z')
            h5C4kPmbg[mMb4fwVls] = h5C4kPmbg[mMb4fwVls] - 'a' + 'A';
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (mMb4fwVls = (445 - 445); mMb4fwVls < (1230 - 230); mMb4fwVls++)
        b[mMb4fwVls] = 0;
    {
        mMb4fwVls = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (mMb4fwVls < l) {
            {
                j = 842 - 841;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                while (j < l) {
                    if (h5C4kPmbg[j] == h5C4kPmbg[mMb4fwVls])
                        b[mMb4fwVls]++;
                    else {
                        break;
                    }
                    j++;
                };
            }
            b[mMb4fwVls]++;
            mMb4fwVls = j - 1;
            mMb4fwVls++;
        };
    }
    {
        mMb4fwVls = 0;
        while (mMb4fwVls < 1000) {
            if (b[mMb4fwVls] != 0)
                printf ("(%c,%d)", h5C4kPmbg[mMb4fwVls], b[mMb4fwVls]);
            mMb4fwVls++;
        };
    }
    getchar ();
    getchar ();
}

