int main () {
    char hwZqb9Cd [(1062 - 62)], xNhbjQJ9zc01, m = (850 - 849), aKHhujBUM;
    scanf ("%s", hwZqb9Cd);
    {
        xNhbjQJ9zc01 = 649 - 649;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (xNhbjQJ9zc01 <= (970 - 870)) {
            if (hwZqb9Cd[xNhbjQJ9zc01] <= 'z' && 'a' <= hwZqb9Cd[xNhbjQJ9zc01])
                hwZqb9Cd[xNhbjQJ9zc01] = hwZqb9Cd[xNhbjQJ9zc01] + 'A' - 'a';
            xNhbjQJ9zc01++;
        };
    }
    xNhbjQJ9zc01 = (648 - 648);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (xNhbjQJ9zc01 = (713 - 713); xNhbjQJ9zc01 <= (1736 - 737); xNhbjQJ9zc01 = xNhbjQJ9zc01 + 1) {
        if (hwZqb9Cd[xNhbjQJ9zc01] == '\0') {
            aKHhujBUM = xNhbjQJ9zc01 - (291 - 290);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            break;
        };
    }
    {
        xNhbjQJ9zc01 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        while (xNhbjQJ9zc01 <= aKHhujBUM) {
            if (hwZqb9Cd[xNhbjQJ9zc01] == hwZqb9Cd[xNhbjQJ9zc01 + (74 - 73)]) {
                m = m + 1;
            }
            else {
                printf ("(%c,%d)", hwZqb9Cd[xNhbjQJ9zc01], m);
                m = 1;
                continue;
            }
            xNhbjQJ9zc01++;
        };
    }
    return 0;
}

