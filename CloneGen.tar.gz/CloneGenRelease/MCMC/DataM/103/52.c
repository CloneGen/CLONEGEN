int main () {
    int t;
    int i;
    int Pru4V3i;
    t = (987 - 987);
    char a [(510 - 10)], c;
    t = (137 - 136);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> a;
    Pru4V3i = strlen (a);
    c = a[(774 - 774)];
    if (c >= 'a' && c <= 'z') {
        c = c - (970 - 938);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (i = (926 - 925); i <= Pru4V3i -1; i++) {
        if (c >= 'a' && c <= 'z') {
            c = c - (817 - 785);
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (a[i] == c || a[i] == c + (855 - 823)) {
            t = t + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            cout << '(' << c << ',' << t << ')';
            t = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            c = a[i];
        };
    }
    cout << '(' << c << ',' << t << ')';
    return (847 - 847);
}

