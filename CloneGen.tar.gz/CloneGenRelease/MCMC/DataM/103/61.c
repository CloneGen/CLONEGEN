int main () {
    int ZbkjIe4s;
    int UiDhy6c9TXzL;
    int VtKaU61 [100] = {(320 - 320)};
    ZbkjIe4s = (776 - 776);
    UiDhy6c9TXzL = (815 - 815);
    char EYHKQhuByWe [100];
    int sum;
    sum = 0;
    cin >> EYHKQhuByWe;
    {
        ZbkjIe4s = 0;
        while (!('\0' == EYHKQhuByWe[ZbkjIe4s])) {
            if (VtKaU61[UiDhy6c9TXzL] == 0)
                VtKaU61[UiDhy6c9TXzL]++;
            else {
                if (EYHKQhuByWe[ZbkjIe4s] == EYHKQhuByWe[ZbkjIe4s -(500 - 499)] || !('A' - 'a' != EYHKQhuByWe[ZbkjIe4s] - EYHKQhuByWe[ZbkjIe4s -(578 - 577)]) || EYHKQhuByWe[ZbkjIe4s] - EYHKQhuByWe[ZbkjIe4s -(902 - 901)] == 'a' - 'A')
                    VtKaU61[UiDhy6c9TXzL]++;
                else {
                    UiDhy6c9TXzL++;
                    VtKaU61[UiDhy6c9TXzL] = (314 - 313);
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            ZbkjIe4s = ZbkjIe4s +1;
        };
    }
    for (ZbkjIe4s = 0; ZbkjIe4s <= UiDhy6c9TXzL; ZbkjIe4s++) {
        sum = sum + VtKaU61[ZbkjIe4s];
        if (EYHKQhuByWe[VtKaU61[ZbkjIe4s] - (369 - 368)] >= 'A' && EYHKQhuByWe[VtKaU61[ZbkjIe4s] - 1] <= 'Z')
            ;
        else
            EYHKQhuByWe[VtKaU61[ZbkjIe4s] - 1] += 'A' - 'a';
        cout << '(' << EYHKQhuByWe[sum - 1] << ',' << VtKaU61[ZbkjIe4s] << ')';
    }
    cout << endl;
    return 0;
}

