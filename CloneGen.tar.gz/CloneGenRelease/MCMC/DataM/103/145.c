char rqVPgJ [(1310 - 310)];

main () {
    int Zwfo2TJO5Pn;
    int lW0wgNzT7X1;
    int OL8iYh;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    Zwfo2TJO5Pn = (340 - 339);
    cin >> rqVPgJ;
    OL8iYh = strlen (rqVPgJ);
    for (lW0wgNzT7X1 = (965 - 965); OL8iYh > lW0wgNzT7X1; lW0wgNzT7X1 = lW0wgNzT7X1 + 1)
        if (rqVPgJ[lW0wgNzT7X1] > (276 - 180))
            rqVPgJ[lW0wgNzT7X1] -= (191 - 159);
    for (lW0wgNzT7X1 = (977 - 976); lW0wgNzT7X1 <= OL8iYh; lW0wgNzT7X1 = lW0wgNzT7X1 + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (rqVPgJ[lW0wgNzT7X1] == rqVPgJ[lW0wgNzT7X1 - 1])
            Zwfo2TJO5Pn = Zwfo2TJO5Pn +1;
        else {
            cout << '(' << rqVPgJ[lW0wgNzT7X1 - 1] << ',' << Zwfo2TJO5Pn << ')';
            Zwfo2TJO5Pn = 1;
        };
    };
}

