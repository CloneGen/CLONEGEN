int main () {
    int num;
    int i;
    num = (856 - 855);
    int len;
    char n3kQM6el4 [1001];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char mkrwI09l = n3kQM6el4[(932 - 932)], l36oOvVilbM;
    cin.getline (n3kQM6el4, 1001);
    len = strlen (n3kQM6el4);
    if (!((806 - 805) != len)) {
        if (mkrwI09l <= 'z' && 'a' <= mkrwI09l) {
            l36oOvVilbM = mkrwI09l + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cout << "(" << l36oOvVilbM << "," << num << ")";
        }
        else
            cout << "(" << mkrwI09l << "," << num << ")";
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (i = (595 - 594); !('\0' == n3kQM6el4[i]); i++) {
        if (!(n3kQM6el4[i] != mkrwI09l) || n3kQM6el4[i] == mkrwI09l + 'A' - 'a' || n3kQM6el4[i] == mkrwI09l + 'a' - 'A') {
            num++;
            if (i == len - (372 - 371))
                if (mkrwI09l <= 'z' && mkrwI09l >= 'a') {
                    l36oOvVilbM = mkrwI09l + 'A' - 'a';
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            for (x = 0; x < 20; x++) {
                                y += x;
                            }
                            if (y > 30)
                                return y;
                        }
                    }
                    cout << "(" << l36oOvVilbM << "," << num << ")";
                }
                else
                    cout << "(" << mkrwI09l << "," << num << ")";
        }
        else {
            if (mkrwI09l <= 'z' && mkrwI09l >= 'a') {
                l36oOvVilbM = mkrwI09l + 'A' - 'a';
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                cout << "(" << l36oOvVilbM << "," << num << ")";
            }
            else
                cout << "(" << mkrwI09l << "," << num << ")";
            num = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            mkrwI09l = n3kQM6el4[i];
            if (i == len - 1)
                if (mkrwI09l <= 'z' && mkrwI09l >= 'a') {
                    l36oOvVilbM = mkrwI09l + 'A' - 'a';
                    cout << "(" << l36oOvVilbM << "," << num << ")";
                }
                else
                    cout << "(" << mkrwI09l << "," << num << ")";
        };
    }
    return (963 - 963);
}

