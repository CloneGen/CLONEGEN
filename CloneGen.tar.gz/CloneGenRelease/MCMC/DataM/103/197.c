int main () {
    int a = (378 - 377);
    int i;
    char A5iohEr2 [(1236 - 236)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (A5iohEr2);
    {
        i = 134 - 134;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < strlen (A5iohEr2)) {
            if ('a' > A5iohEr2[i])
                A5iohEr2[i] = tolower (A5iohEr2[i]);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    {
        i = 0;
        while (i < strlen (A5iohEr2)) {
            if (A5iohEr2[i] != A5iohEr2[i + (106 - 105)]) {
                printf ("(%c,%d)", A5iohEr2[i] - 'a' + 'A', a);
                a = 1;
            }
            else
                a = a + 1;
            i++;
        };
    };
}

