int main () {
    int ZcgaADz;
    ZcgaADz = 1;
    int zDeNqO4T;
    int mMuLo7PI;
    zDeNqO4T = 1;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    mMuLo7PI = 0;
    char a [(1271 - 171)];
    int fMkA72TR0Oh;
    fMkA72TR0Oh = strlen (a);
    scanf ("%s", a);
    for (; fMkA72TR0Oh > mMuLo7PI;) {
        if (toupper (a[zDeNqO4T]) == toupper (a[mMuLo7PI]))
            ZcgaADz = ZcgaADz +1;
        else {
            printf ("(%c,%d)", toupper (a[mMuLo7PI]), ZcgaADz);
            mMuLo7PI += ZcgaADz;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            ZcgaADz = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        zDeNqO4T = zDeNqO4T + 1;
    };
}

