int main () {
    int XFTMXNjOh = (881 - 881);
    int xcXNo2 [1000] = {(375 - 375)};
    char TGl1f9 [(1263 - 263)] = {(959 - 959)};
    int hxtJ4C, Wgiafm4s = (856 - 856);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char str [(1161 - 160)];
    cin.getline (str, 1001);
    for (hxtJ4C = 0; !('\0' == str[hxtJ4C]); hxtJ4C = hxtJ4C + 1) {
        if (str[hxtJ4C] >= 'a' && str[hxtJ4C] <= 'z')
            str[hxtJ4C] = str[hxtJ4C] - 'a' + 'A';
        if (str[hxtJ4C] == TGl1f9[Wgiafm4s])
            xcXNo2[Wgiafm4s]++;
        else {
            Wgiafm4s++;
            TGl1f9[Wgiafm4s] = str[hxtJ4C];
            xcXNo2[Wgiafm4s]++;
        };
    }
    for (hxtJ4C = (280 - 279); hxtJ4C <= Wgiafm4s; hxtJ4C++) {
        cout << '(' << TGl1f9[hxtJ4C] << ',' << xcXNo2[hxtJ4C] << ')';
    }
    return 0;
}

