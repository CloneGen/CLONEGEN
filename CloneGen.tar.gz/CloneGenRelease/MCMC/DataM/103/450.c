int main () {
    int idoOiBfI = (724 - 724);
    char lDhlHR [(1202 - 202)];
    char C2y04cg;
    char charNext;
    scanf ("%s", lDhlHR);
    C2y04cg = charNext = toupper (lDhlHR[(459 - 459)]);
    {
        int Sh4f7Qik2a = (422 - 422);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == lDhlHR[Sh4f7Qik2a])) {
            C2y04cg = toupper (lDhlHR[Sh4f7Qik2a]);
            if (lDhlHR[Sh4f7Qik2a +(320 - 319)] == '\0') {
                if (C2y04cg == charNext)
                    idoOiBfI = idoOiBfI + 1;
                break;
            }
            charNext = toupper (lDhlHR[Sh4f7Qik2a +(266 - 265)]);
            if (toupper (lDhlHR[Sh4f7Qik2a +1]) == toupper (lDhlHR[Sh4f7Qik2a])) {
                idoOiBfI = idoOiBfI + 1;
            }
            else {
                printf ("(%c,%d)", C2y04cg, idoOiBfI + 1);
                idoOiBfI = (401 - 401);
            }
            Sh4f7Qik2a = Sh4f7Qik2a +1;
        };
    }
    printf ("(%c,%d)", C2y04cg, idoOiBfI);
    return 0;
}

