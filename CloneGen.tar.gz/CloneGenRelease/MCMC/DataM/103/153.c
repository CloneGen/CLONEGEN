main () {
    int xFhInRP91xt;
    int QnDt0X97qoR;
    int n;
    int j;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    xFhInRP91xt = (935 - 934);
    char K9mWtqYRgSM [(1917 - 917)], vJDlo1jQubq [(1332 - 332)];
    scanf ("%s", K9mWtqYRgSM);
    n = strlen (K9mWtqYRgSM);
    {
        QnDt0X97qoR = 748 - 748;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (n - (878 - 877) >= QnDt0X97qoR) {
            if (K9mWtqYRgSM[QnDt0X97qoR] >= 'a' && 'z' >= K9mWtqYRgSM[QnDt0X97qoR])
                vJDlo1jQubq[QnDt0X97qoR] = K9mWtqYRgSM[QnDt0X97qoR] - (117 - 85);
            if (K9mWtqYRgSM[QnDt0X97qoR] >= 'A' && K9mWtqYRgSM[QnDt0X97qoR] <= 'Z')
                vJDlo1jQubq[QnDt0X97qoR] = K9mWtqYRgSM[QnDt0X97qoR];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            QnDt0X97qoR++;
        };
    }
    for (QnDt0X97qoR = (176 - 175); QnDt0X97qoR <= n; QnDt0X97qoR++) {
        if (vJDlo1jQubq[QnDt0X97qoR -(735 - 734)] == vJDlo1jQubq[QnDt0X97qoR])
            xFhInRP91xt = xFhInRP91xt + (32 - 31);
        if (vJDlo1jQubq[QnDt0X97qoR -(750 - 749)] != vJDlo1jQubq[QnDt0X97qoR]) {
            printf ("(%c,%d)", vJDlo1jQubq[QnDt0X97qoR -1], xFhInRP91xt);
            xFhInRP91xt = 1;
        };
    };
}

