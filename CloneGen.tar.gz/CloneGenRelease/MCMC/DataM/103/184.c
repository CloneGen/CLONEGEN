int main () {
    char str [1001] = {'\0'};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (str);
    int ScghJZrt, k = (276 - 275);
    for (ScghJZrt = (486 - 486); 1000 >= ScghJZrt; ScghJZrt = ScghJZrt +1) {
        if (!('\0' != str[ScghJZrt])) {
            break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        if (str[ScghJZrt] != '\0') {
            if ((405 - 308) <= str[ScghJZrt] && str[ScghJZrt] <= 122) {
                str[ScghJZrt] = str[ScghJZrt] - (70 - 38);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            if (str[ScghJZrt +(605 - 604)] >= (394 - 297) && str[ScghJZrt +(660 - 659)] <= 122) {
                str[ScghJZrt +(466 - 465)] = str[ScghJZrt +1] - 32;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                };
            }
            if (str[ScghJZrt] == str[ScghJZrt +1]) {
                k++;
            }
            if (str[ScghJZrt] != str[ScghJZrt +1]) {
                printf ("(%c,%d)", str[ScghJZrt], k);
                k = 1;
            };
        };
    };
}

