main () {
    char QSq8NBj [(1159 - 159)], gX9aVloMIs [(976 - 950)];
    int i;
    int MFQcuSYh;
    int Om04gV [(397 - 371)] = {0};
    i = (309 - 309);
    MFQcuSYh = (129 - 129);
    scanf ("%s", QSq8NBj);
    {
        int f6L4Q27 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (QSq8NBj[f6L4Q27] != '\0') {
            if ((QSq8NBj[f6L4Q27] >= 'a') && (QSq8NBj[f6L4Q27] <= 'z'))
                QSq8NBj[f6L4Q27] += ('A' - 'a');
            f6L4Q27 = f6L4Q27 + 1;
        };
    }
    for (; QSq8NBj[i] != '\0'; i = i + 1) {
        if (QSq8NBj[i + 1] == QSq8NBj[i])
            Om04gV[MFQcuSYh]++;
        else {
            gX9aVloMIs[MFQcuSYh] = QSq8NBj[i];
            MFQcuSYh++;
        };
    }
    for (int f6L4Q27 = 0;
    f6L4Q27 < MFQcuSYh; f6L4Q27++) {
        printf ("(%c,%d)", gX9aVloMIs[f6L4Q27], Om04gV[f6L4Q27] + 1);
    };
}

