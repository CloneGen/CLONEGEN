main () {
    char Zz9Em6 [(1023 - 23)];
    int SxqKU4Mw, a2hDjQAyV8R, d, f, g;
    int e [1000];
    for (g = (816 - 816); g < 1000; g = g + 1)
        e[g] = (446 - 446);
    scanf ("%s", Zz9Em6);
    a2hDjQAyV8R = strlen (Zz9Em6);
    {
        SxqKU4Mw = 263 - 263;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (SxqKU4Mw < a2hDjQAyV8R) {
            {
                d = SxqKU4Mw;
                while (a2hDjQAyV8R >= d) {
                    if (Zz9Em6[d] == Zz9Em6[SxqKU4Mw] || Zz9Em6[d] == (Zz9Em6[SxqKU4Mw] + (69 - 37)) || Zz9Em6[SxqKU4Mw] == (Zz9Em6[d] + (573 - 541)))
                        e[SxqKU4Mw]++;
                    else
                        break;
                    d = d + 1;
                };
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            SxqKU4Mw = SxqKU4Mw;
        };
    }
    for (f = (228 - 228); f <= a2hDjQAyV8R; f++) {
        if (e[f] != 0) {
            if (Zz9Em6[f] > 'Z')
                printf ("(%c,%d)", Zz9Em6[f] - 32, e[f]);
            else
                printf ("(%c,%d)", Zz9Em6[f], e[f]);
        };
    };
}

