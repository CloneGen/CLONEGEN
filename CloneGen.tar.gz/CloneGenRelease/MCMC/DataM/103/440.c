main () {
    char a [1002];
    int i;
    int l = (998 - 997);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", a);
    {
        i = 302 - 302;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (!('\0' == a[i])) {
            if ('Z' < a[i])
                a[i] = a[i] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        i = 1;
        while (a[i] != '\0') {
            if (a[i] == a[i - 1])
                l = l + 1;
            else {
                printf ("(%c,%d)", a[i - 1], l);
                l = 1;
            }
            i = i + 1;
        };
    }
    printf ("(%c,%d)", a[i - 1], l);
}

