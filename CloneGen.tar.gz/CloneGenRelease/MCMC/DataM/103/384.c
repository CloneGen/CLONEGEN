int main () {
    char p1VNsG [(1739 - 738)];
    gets (p1VNsG);
    int uHl9E5wuP;
    int time;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    time = (355 - 355);
    {
        uHl9E5wuP = 0;
        while (p1VNsG[uHl9E5wuP] != '\0') {
            if (!(p1VNsG[uHl9E5wuP + (643 - 642)] == p1VNsG[uHl9E5wuP]) && (p1VNsG[uHl9E5wuP] - p1VNsG[uHl9E5wuP + (442 - 441)] != 'A' - 'a' && p1VNsG[uHl9E5wuP] - p1VNsG[uHl9E5wuP + (172 - 171)] != -'A' + 'a')) {
                if (p1VNsG[uHl9E5wuP] >= 'a') {
                    printf ("(%c,%d)", p1VNsG[uHl9E5wuP] - 'a' + 'A', time + (709 - 708));
                }
                else {
                    printf ("(%c,%d)", p1VNsG[uHl9E5wuP], time + 1);
                }
                time = 0;
            }
            else {
                time = time + 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            uHl9E5wuP++;
        };
    }
    return 0;
}

