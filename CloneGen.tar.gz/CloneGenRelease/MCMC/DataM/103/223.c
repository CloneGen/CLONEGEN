int main () {
    int c;
    c = (291 - 291);
    char b;
    char a [(1733 - 731)];
    gets (a);
    int EAsN97fmo2Zg;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int i;
    EAsN97fmo2Zg = strlen (a);
    {
        i = 237 - 237;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < EAsN97fmo2Zg) {
            if (a[i] >= 'a' && 'z' >= a[i]) {
                a[i] = a[i] - 'a' + 'A';
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    b = a[(996 - 996)];
    {
        i = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < EAsN97fmo2Zg) {
            if (a[i] == b) {
                c = c + 1;
            }
            else {
                printf ("(%c,%d)", b, c);
                c = (344 - 343);
                b = a[i];
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            i = i + 1;
        };
    }
    printf ("(%c,%d)", b, c);
}

