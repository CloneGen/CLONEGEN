int main () {
    int i, j, l, y;
    char a [(1217 - 216)];
    int x [(875 - 775)] = {(364 - 364)};
    scanf ("%s", a);
    l = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        i = 662 - 662;
        while (i < l) {
            if (a[i] >= 'a' && a[i] <= 'z')
                a[i] = a[i] - 'a' + 'A';
            i = i + 1;
        };
    }
    for (i = (531 - 531); i < l; i++) {
        y = a[i] - 'A';
        x[y]++;
        if (a[i] == a[i + 1])
            continue;
        else {
            printf ("(%c,%d)", a[i], x[y]);
            x[y] = (903 - 903);
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

