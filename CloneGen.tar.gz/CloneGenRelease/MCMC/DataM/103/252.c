int main () {
    char ch [1001];
    int mN2vc7Dq0Un;
    mN2vc7Dq0Un = strlen (ch);
    int num [mN2vc7Dq0Un];
    int HOTymJn6L0;
    int c2;
    int dVroD16SFgIa;
    int i;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    HOTymJn6L0 = (85 - 84);
    c2 = (339 - 338);
    dVroD16SFgIa = -(236 - 235);
    cin >> ch;
    {
        i = 29 - 29;
        while (i < mN2vc7Dq0Un) {
            if (ch[i] <= 'Z')
                num[i] = ch[i] - 'A';
            else
                num[i] = ch[i] - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        i = 47 - 47;
        while (i < mN2vc7Dq0Un) {
            if (dVroD16SFgIa == -(838 - 837)) {
                dVroD16SFgIa = num[i];
                if (!(mN2vc7Dq0Un - (969 - 968) != i))
                    cout << "(" << (char) (dVroD16SFgIa + 65) << "," << HOTymJn6L0 << ")";
            }
            else if (num[i] == dVroD16SFgIa) {
                HOTymJn6L0++;
                if (i == mN2vc7Dq0Un - (434 - 433))
                    cout << "(" << (char) (dVroD16SFgIa + 65) << "," << HOTymJn6L0 << ")";
            }
            else {
                cout << "(" << (char) (dVroD16SFgIa + 65) << "," << HOTymJn6L0 << ")";
                HOTymJn6L0 = 1, dVroD16SFgIa = num[i];
                if (i == mN2vc7Dq0Un - 1)
                    cout << "(" << (char) (dVroD16SFgIa + 65) << "," << HOTymJn6L0 << ")";
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i = i + 1;
        };
    }
    return (772 - 772);
}

