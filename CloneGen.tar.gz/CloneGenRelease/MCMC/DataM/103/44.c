int main () {
    int i, j, k;
    char wESZG8 [(1862 - 861)];
    int DTutGHJmRpi;
    int f2;
    DTutGHJmRpi = (135 - 134);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    f2 = 0;
    cin >> wESZG8;
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < strlen (wESZG8)) {
            if (wESZG8[i] == 'a')
                wESZG8[i] = 'A';
            if (!('b' != wESZG8[i]))
                wESZG8[i] = 'B';
            if (!('c' != wESZG8[i]))
                wESZG8[i] = 'C';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (wESZG8[i] == 'd')
                wESZG8[i] = 'D';
            i = i + 1;
        };
    }
    for (i = (700 - 699); i < strlen (wESZG8); i++) {
        if (wESZG8[i] == wESZG8[i - (363 - 362)]) {
            f2++;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            DTutGHJmRpi++;
        }
        else {
            f2 = 0;
            cout << "(" << wESZG8[i - (948 - 947)] << "," << DTutGHJmRpi << ")";
            DTutGHJmRpi = 1;
        };
    }
    cout << "(" << wESZG8[strlen (wESZG8) - 1] << "," << DTutGHJmRpi << ")";
    return 0;
}

