main () {
    int bHGWkdb15m;
    char c;
    char s [(1417 - 416)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (s);
    int n = (964 - 963);
    for (bHGWkdb15m = (525 - 525); !('\0' == (s[bHGWkdb15m])); bHGWkdb15m = bHGWkdb15m + 1) {
        if (s[bHGWkdb15m] >= 'a' && s[bHGWkdb15m] <= 'z')
            s[bHGWkdb15m] = s[bHGWkdb15m] - 'a' + 'A';
    }
    for (bHGWkdb15m = 0; (s[bHGWkdb15m]) != '\0'; bHGWkdb15m = bHGWkdb15m + 1) {
        if (s[bHGWkdb15m] == s[bHGWkdb15m + (403 - 402)])
            n = n + 1;
        else {
            printf ("(%c,%d)", s[bHGWkdb15m], n);
            n = 1;
        };
    };
}

