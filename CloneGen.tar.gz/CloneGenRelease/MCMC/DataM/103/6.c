char str [(1089 - 89)];

int main () {
    int aln = (881 - 881);
    char als;
    int Sq2T1zpJX = strlen (str);
    cin >> str;
    {
        int Av0NQF = (339 - 339);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (Sq2T1zpJX > Av0NQF) {
            if (str[Av0NQF] >= 'a' && 'z' >= str[Av0NQF])
                str[Av0NQF] = (char) (str[Av0NQF] + 'A' - 'a');
            Av0NQF = Av0NQF +1;
        };
    }
    als = str[(969 - 969)];
    {
        int Av0NQF = (164 - 164);
        while (Av0NQF < Sq2T1zpJX) {
            if (str[Av0NQF] == als)
                aln = aln + 1;
            else {
                cout << "(" << als << "," << aln << ")";
                aln = (352 - 351);
                als = str[Av0NQF];
            }
            Av0NQF++;
        };
    }
    cout << "(" << als << "," << aln << ")" << endl;
    return (291 - 291);
}

