char shift (char y) {
    char NB40QP;
    if ('a' <= y)
        NB40QP = y - 'a' + 'A';
    else
        NB40QP = y;
    return NB40QP;
}

main () {
    char m6LbP1fqvXK [(494 - 393)];
    int p3pSyJ1FgQ4, sum = (829 - 828);
    scanf ("%s", m6LbP1fqvXK);
    printf ("(%c,", shift (m6LbP1fqvXK[(335 - 335)]));
    for (p3pSyJ1FgQ4 = (246 - 245);; p3pSyJ1FgQ4++) {
        if (shift (m6LbP1fqvXK[p3pSyJ1FgQ4]) == shift (m6LbP1fqvXK[p3pSyJ1FgQ4 - (715 - 714)])) {
            sum = sum + 1;
        }
        if ((shift (m6LbP1fqvXK[p3pSyJ1FgQ4]) != shift (m6LbP1fqvXK[p3pSyJ1FgQ4 - (930 - 929)])) && (m6LbP1fqvXK[p3pSyJ1FgQ4] != '\0')) {
            printf ("%d)(%c,", sum, shift (m6LbP1fqvXK[p3pSyJ1FgQ4]));
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            sum = 1;
        }
        if (m6LbP1fqvXK[p3pSyJ1FgQ4] == '\0') {
            printf ("%d)", sum);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            break;
        };
    };
}

