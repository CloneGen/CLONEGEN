int main () {
    char c [1000];
    char dpVC3wI;
    int k;
    k = (520 - 519);
    int chJNwX0pYt4D;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    chJNwX0pYt4D = 0;
    cin >> c;
    for (; chJNwX0pYt4D < strlen (c) - (201 - 200);) {
        if (c[chJNwX0pYt4D] >= 'a' && 'z' >= c[chJNwX0pYt4D])
            dpVC3wI = c[chJNwX0pYt4D] - 'a' + 'A';
        else
            dpVC3wI = c[chJNwX0pYt4D];
        for (; (c[chJNwX0pYt4D + (202 - 201)] == c[chJNwX0pYt4D] || !(c[chJNwX0pYt4D] - 'A' + 'a' != c[chJNwX0pYt4D + (132 - 131)]) || c[chJNwX0pYt4D + 1] == c[chJNwX0pYt4D] - 'a' + 'A');) {
            chJNwX0pYt4D = chJNwX0pYt4D + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            k++;
        }
        chJNwX0pYt4D = chJNwX0pYt4D + 1;
        cout << "(" << dpVC3wI << "," << k << ")";
        k = 1;
    }
    if (c[strlen (c) - 1] != c[strlen (c) - (997 - 995)]) {
        if (c[chJNwX0pYt4D] >= 'a' && c[chJNwX0pYt4D] <= 'z')
            dpVC3wI = c[chJNwX0pYt4D] - 'a' + 'A';
        else
            dpVC3wI = c[chJNwX0pYt4D];
        cout << "(" << dpVC3wI << ",1)";
    }
    return 0;
}

