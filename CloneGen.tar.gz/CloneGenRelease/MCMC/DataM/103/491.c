main () {
    int Oyn82O;
    char TizMAfFbrQS [(1681 - 681)];
    int YXOrS8A;
    YXOrS8A = (313 - 312);
    scanf ("%s", TizMAfFbrQS);
    Oyn82O = strlen (TizMAfFbrQS);
    {
        int i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < Oyn82O) {
            if (!(TizMAfFbrQS[i + (399 - 398)] != TizMAfFbrQS[i]) || (TizMAfFbrQS[i] + 'a' - 'A') == (TizMAfFbrQS[i + 1]) || (TizMAfFbrQS[i] + 'A' - 'a') == (TizMAfFbrQS[i + 1]))
                YXOrS8A = YXOrS8A +1;
            else {
                if (TizMAfFbrQS[i] >= 'A' && TizMAfFbrQS[i] <= 'Z')
                    printf ("(%c,%d)", TizMAfFbrQS[i], YXOrS8A);
                else
                    printf ("(%c,%d)", TizMAfFbrQS[i] - 'a' + 'A', YXOrS8A);
                YXOrS8A = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    getchar ();
    getchar ();
}

