main () {
    char LXqQlSN6GA [1000];
    int UoMhD1LYV, num = (271 - 270), a, EnQzx9bLaNj;
    scanf ("%s", LXqQlSN6GA);
    {
        UoMhD1LYV = 890 - 890;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (LXqQlSN6GA[UoMhD1LYV] != '\0') {
            a = LXqQlSN6GA[UoMhD1LYV];
            EnQzx9bLaNj = LXqQlSN6GA[UoMhD1LYV +1];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (a == EnQzx9bLaNj || a - EnQzx9bLaNj == (70 - 38) || a - EnQzx9bLaNj == -(420 - 388))
                num++;
            else {
                if (LXqQlSN6GA[UoMhD1LYV] < 91)
                    printf ("(%c,%d)", LXqQlSN6GA[UoMhD1LYV], num);
                else
                    printf ("(%c,%d)", LXqQlSN6GA[UoMhD1LYV] - (1026 - 994), num);
                num = 1;
            }
            UoMhD1LYV++;
        };
    };
}

