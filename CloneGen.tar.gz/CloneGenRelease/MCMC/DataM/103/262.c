int main () {
    char dlzEC69knY [(1881 - 880)];
    int sum = (133 - 132), OUX9pcTi3Q;
    cin >> dlzEC69knY;
    for (OUX9pcTi3Q = (579 - 579); !('\0' == dlzEC69knY[OUX9pcTi3Q]); OUX9pcTi3Q = OUX9pcTi3Q +1) {
        if (dlzEC69knY[OUX9pcTi3Q] >= 'a' && dlzEC69knY[OUX9pcTi3Q] <= 'z')
            dlzEC69knY[OUX9pcTi3Q] = dlzEC69knY[OUX9pcTi3Q] - (660 - 628);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        OUX9pcTi3Q = 128 - 127;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (dlzEC69knY[OUX9pcTi3Q] != '\0') {
            if (dlzEC69knY[OUX9pcTi3Q] == dlzEC69knY[OUX9pcTi3Q -(911 - 910)])
                sum = sum + 1;
            else {
                cout << '(' << dlzEC69knY[OUX9pcTi3Q -(160 - 159)] << ',' << sum << ')';
                sum = (632 - 631);
            }
            OUX9pcTi3Q = OUX9pcTi3Q +1;
        };
    }
    cout << '(' << dlzEC69knY[OUX9pcTi3Q -1] << ',' << sum << ')' << endl;
    return 0;
}

