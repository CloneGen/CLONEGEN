void  ch (char z1aqPGi5 [(1565 - 565)]) {
    int Hyv6QDptaCX3;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        Hyv6QDptaCX3 = 201 - 201;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while ((1581 - 581) > Hyv6QDptaCX3) {
            if (z1aqPGi5[Hyv6QDptaCX3] >= 'a' && z1aqPGi5[Hyv6QDptaCX3] <= 'z')
                z1aqPGi5[Hyv6QDptaCX3] = 'A' - 'a' + z1aqPGi5[Hyv6QDptaCX3];
            else {
                if (z1aqPGi5[Hyv6QDptaCX3] == (407 - 407))
                    break;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            Hyv6QDptaCX3++;
        };
    };
}

main () {
    char z1aqPGi5 [1000];
    ch (z1aqPGi5);
    int Hyv6QDptaCX3, jhMrO9, xvHcXalF1 = (48 - 47), evTjkZJy3OR;
    scanf ("%s", z1aqPGi5);
    {
        int x = 0;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    evTjkZJy3OR = strlen (z1aqPGi5);
    for (Hyv6QDptaCX3 = 0; Hyv6QDptaCX3 < evTjkZJy3OR; Hyv6QDptaCX3 = Hyv6QDptaCX3 +1) {
        if (z1aqPGi5[Hyv6QDptaCX3] == z1aqPGi5[Hyv6QDptaCX3 +1])
            xvHcXalF1++;
        else {
            printf ("(%c,%d)", z1aqPGi5[Hyv6QDptaCX3], xvHcXalF1);
            xvHcXalF1 = 1;
        };
    }
    getchar ();
    getchar ();
}

