int main () {
    char Ec7MRvYEga [1005] = {'\0'};
    int b [1005] = {(54 - 54)}, zizOsFeC86 = (376 - 375);
    cin >> Ec7MRvYEga;
    for (int ICUhok1dv = (618 - 618);
    strlen (Ec7MRvYEga) - (151 - 150) > ICUhok1dv; ICUhok1dv = ICUhok1dv +1) {
        if (0 <= Ec7MRvYEga[ICUhok1dv] - 'a' && 0 >= Ec7MRvYEga[ICUhok1dv] - 'z')
            Ec7MRvYEga[ICUhok1dv] = Ec7MRvYEga[ICUhok1dv] + 'A' - 'a';
        if (!(Ec7MRvYEga[ICUhok1dv +(439 - 438)] == Ec7MRvYEga[ICUhok1dv]) && Ec7MRvYEga[ICUhok1dv] - Ec7MRvYEga[ICUhok1dv +(803 - 802)] != 'A' - 'a' && Ec7MRvYEga[ICUhok1dv] - Ec7MRvYEga[ICUhok1dv +(60 - 59)] != 'a' - 'A') {
            b[zizOsFeC86] = ICUhok1dv +1;
            zizOsFeC86++;
        };
    }
    if (Ec7MRvYEga[strlen (Ec7MRvYEga) - 1] - 'a' >= 0 && Ec7MRvYEga[strlen (Ec7MRvYEga) - 1] - 'z' <= 0)
        Ec7MRvYEga[strlen (Ec7MRvYEga) - 1] = Ec7MRvYEga[strlen (Ec7MRvYEga) - 1] + 'A' - 'a';
    b[zizOsFeC86] = strlen (Ec7MRvYEga);
    for (int ICUhok1dv = 1;
    ICUhok1dv <= zizOsFeC86; ICUhok1dv++) {
        cout << "(" << Ec7MRvYEga[b[ICUhok1dv -1]] << "," << b[ICUhok1dv] - b[ICUhok1dv -1] << ")";
    }
    return 0;
}

