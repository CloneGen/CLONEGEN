int f (char WZPIMaWvcD, char pBpOUTxD5) {
    char c;
    char RA9GsYnOK;
    c = pBpOUTxD5 + 'A' - 'a';
    RA9GsYnOK = pBpOUTxD5 - 'A' + 'a';
    if ((!(pBpOUTxD5 != WZPIMaWvcD)) || (!(c != WZPIMaWvcD)) || (WZPIMaWvcD == RA9GsYnOK))
        return (711 - 710);
    else
        return (931 - 931);
}

int vCBKJby3nh5d (char WZPIMaWvcD) {
    int c, RA9GsYnOK;
    char pBpOUTxD5;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    c = WZPIMaWvcD -'A';
    RA9GsYnOK = 'a' - 'A';
    if (c < RA9GsYnOK)
        return WZPIMaWvcD;
    else {
        pBpOUTxD5 = WZPIMaWvcD +'A' - 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        return pBpOUTxD5;
    };
}

int h (int WZPIMaWvcD, int pBpOUTxD5) {
    int c;
    c = (67 - 66);
    int RdPpfK8So;
    {
        RdPpfK8So = 748 - 747;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (RdPpfK8So <= pBpOUTxD5) {
            RdPpfK8So++;
            c = c * WZPIMaWvcD;
        };
    }
    return c;
}

int main () {
    char c;
    char RA9GsYnOK;
    char pBpOUTxD5 [5001];
    char WZPIMaWvcD [(1803 - 802)];
    int RdPpfK8So;
    int lK4cfRMki2;
    int k;
    int l;
    int m;
    int n;
    int p;
    int q;
    int ykiz1gX;
    RdPpfK8So = lK4cfRMki2 = n = (346 - 346);
    scanf ("%s", WZPIMaWvcD);
    ykiz1gX = (978 - 977);
    while (WZPIMaWvcD[RdPpfK8So]) {
        n = n + (829 - 828);
        RdPpfK8So = RdPpfK8So +(285 - 284);
    }
    RdPpfK8So = (315 - 315);
    {
        RdPpfK8So = 557 - 556;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (RdPpfK8So <= n) {
            c = vCBKJby3nh5d (WZPIMaWvcD[RdPpfK8So -1]);
            RA9GsYnOK = vCBKJby3nh5d (WZPIMaWvcD[RdPpfK8So]);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            RdPpfK8So++;
            q = c - RA9GsYnOK;
            if (q == (196 - 196))
                ykiz1gX = ykiz1gX + 1;
            else {
                p = 1;
                for (k = 1; k <= (1406 - 406); k = k + 1) {
                    l = h ((958 - 948), k);
                    m = ykiz1gX / l;
                    if (m != 0)
                        p = p + 1;
                    else
                        k = (1464 - 463);
                }
                pBpOUTxD5[lK4cfRMki2] = '(';
                lK4cfRMki2 = lK4cfRMki2 + 1;
                pBpOUTxD5[lK4cfRMki2] = vCBKJby3nh5d (WZPIMaWvcD[RdPpfK8So -1]);
                lK4cfRMki2 = lK4cfRMki2 + 1;
                pBpOUTxD5[lK4cfRMki2] = ',';
                lK4cfRMki2 = lK4cfRMki2 + 1;
                {
                    k = 1;
                    while (k <= p) {
                        pBpOUTxD5[lK4cfRMki2] = (ykiz1gX / h ((819 - 809), p - k)) % 10 + '0';
                        k++;
                        lK4cfRMki2 = lK4cfRMki2 + 1;
                    };
                }
                ykiz1gX = 1;
                pBpOUTxD5[lK4cfRMki2] = ')';
                lK4cfRMki2++;
            };
        };
    }
    pBpOUTxD5[lK4cfRMki2] = '\0';
    printf ("%s", pBpOUTxD5);
    return 0;
}

