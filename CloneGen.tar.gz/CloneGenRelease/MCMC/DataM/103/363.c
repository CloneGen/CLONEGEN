int main () {
    int U8UXTK;
    U8UXTK = 0;
    char c;
    char t;
    c = cin.get ();
    if ((729 - 632) <= c)
        c -= (690 - 658);
    t = c;
    while (c != '\n') {
        if (c >= 97)
            c = c - 32;
        if (t == c)
            U8UXTK++;
        else {
            cout << "(" << t << "," << U8UXTK << ")";
            t = c;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            U8UXTK = (713 - 712);
        }
        c = cin.get ();
    }
    cout << "(" << t << "," << U8UXTK << ")" << endl;
    return 0;
}

