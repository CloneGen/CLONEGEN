char a [1001] = {(364 - 364)};

void  f () {
    int l, P47EFs08reY;
    l = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (P47EFs08reY = (874 - 874); P47EFs08reY < l; P47EFs08reY++)
        if ('a' <= a[P47EFs08reY] && 'z' >= a[P47EFs08reY])
            a[P47EFs08reY] = a[P47EFs08reY] - 'a' + 'A';
}

int main () {
    int b [1000] = {(277 - 277)};
    int l;
    int P47EFs08reY;
    int DSfMC4PWz6LK;
    P47EFs08reY = (170 - 170);
    cin >> a;
    f ();
    l = strlen (a);
    for (; P47EFs08reY < l;) {
        for (DSfMC4PWz6LK = (495 - 495); DSfMC4PWz6LK < l - P47EFs08reY; DSfMC4PWz6LK++) {
            if (a[P47EFs08reY +DSfMC4PWz6LK] == a[P47EFs08reY])
                b[P47EFs08reY]++;
            else
                break;
        }
        P47EFs08reY = P47EFs08reY +DSfMC4PWz6LK;
    }
    for (P47EFs08reY = (975 - 975); P47EFs08reY < l; P47EFs08reY++) {
        if (b[P47EFs08reY] != 0)
            cout << "(" << a[P47EFs08reY] << "," << b[P47EFs08reY] << ")";
    }
    return 0;
}

