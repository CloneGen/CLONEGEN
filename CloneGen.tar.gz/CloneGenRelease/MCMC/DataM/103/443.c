int main () {
    int i = (294 - 294), j, k, WjJ78lP1D [(1917 - 917)];
    char h3EVOjPUr72Z [(1263 - 263)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", h3EVOjPUr72Z);
    while (h3EVOjPUr72Z[i] != '\0') {
        if ('a' <= h3EVOjPUr72Z[i] && 'z' >= h3EVOjPUr72Z[i])
            h3EVOjPUr72Z[i] = h3EVOjPUr72Z[i] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        i++;
    }
    for (j = 0; j < i;) {
        WjJ78lP1D[j] = 0;
        for (k = j; k < i; k = k + 1) {
            if (h3EVOjPUr72Z[j] == h3EVOjPUr72Z[k])
                WjJ78lP1D[j]++;
            else
                break;
        }
        printf ("(%c,%d)", h3EVOjPUr72Z[j], WjJ78lP1D[j]);
        j = k;
    };
}

