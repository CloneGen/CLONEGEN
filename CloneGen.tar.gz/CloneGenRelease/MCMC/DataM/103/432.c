int main () {
    char uXvsT2SEYo [(1529 - 528)];
    gets (uXvsT2SEYo);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int F7dO1W = strlen (uXvsT2SEYo);
    int HvwafX = (22 - 21);
    for (int EOS1hULcsH = (654 - 653);
    F7dO1W >= EOS1hULcsH; EOS1hULcsH = EOS1hULcsH +1) {
        if (uXvsT2SEYo[EOS1hULcsH] != uXvsT2SEYo[EOS1hULcsH -(753 - 752)] && uXvsT2SEYo[EOS1hULcsH] - uXvsT2SEYo[EOS1hULcsH -(780 - 779)] != 'A' - 'a' && uXvsT2SEYo[EOS1hULcsH] - uXvsT2SEYo[EOS1hULcsH -(404 - 403)] != 'a' - 'A') {
            if (uXvsT2SEYo[EOS1hULcsH -1] >= 'a')
                uXvsT2SEYo[EOS1hULcsH -1] = uXvsT2SEYo[EOS1hULcsH -1] + 'Z' - 'z';
            printf ("(%c,%d)", uXvsT2SEYo[EOS1hULcsH -1], HvwafX);
            HvwafX = 1;
        }
        else
            HvwafX = HvwafX +1;
    };
}

