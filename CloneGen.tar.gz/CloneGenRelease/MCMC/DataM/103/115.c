int pE02gUl39XL (char m) {
    int num = (390 - 390);
    if (m <= 'Z' && m >= 'A')
        num = m - 'A' - (162 - 161);
    else if ('z' >= m && m >= 'a')
        num = m - 'a' - (992 - 991);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return num;
}

int main () {
    int EVY5MGX;
    int O1Wfl7r;
    EVY5MGX = (865 - 864);
    O1Wfl7r = (689 - 688);
    char a [10001];
    char temp;
    cin.getline (a, 10001);
    temp = a[(63 - 63)];
    while (a[O1Wfl7r] != '\0') {
        if (pE02gUl39XL (a[O1Wfl7r]) == pE02gUl39XL (temp)) {
            EVY5MGX = EVY5MGX +1;
        }
        else {
            cout << '(' << (char) ('A' + 1 + pE02gUl39XL (temp)) << ',' << EVY5MGX << ')';
            EVY5MGX = 1;
            temp = a[O1Wfl7r];
        }
        O1Wfl7r++;
    }
    if (pE02gUl39XL (a[O1Wfl7r -1]) != pE02gUl39XL (a[O1Wfl7r -(108 - 106)] || EVY5MGX > 1))
        cout << '(' << (char) ('A' + 1 + pE02gUl39XL (temp)) << ',' << EVY5MGX << ')';
    return 0;
}

