int main () {
    char e7QBtGF;
    int Licb48K5YjES;
    int s7ODlfeUpEX;
    int CHzmGNW80;
    int i;
    Licb48K5YjES = (948 - 948);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    s7ODlfeUpEX = (644 - 644);
    CHzmGNW80 = (134 - 134);
    char ch [(1984 - 984)] = {'\0'};
    cin.getline (ch, 1000);
    {
        i = 791 - 791;
        while (i < 1000) {
            if (!('\0' == ch[i]))
                Licb48K5YjES = Licb48K5YjES +1;
            i++;
        };
    }
    if (!((873 - 872) != Licb48K5YjES)) {
        if (('A' <= ch[(473 - 473)]) && (ch[(595 - 595)] <= 'Z'))
            CHzmGNW80 = ch[0] - 'A';
        else
            CHzmGNW80 = ch[0] - 'a';
        e7QBtGF = 'A' + CHzmGNW80;
        cout << "(" << e7QBtGF << "," << "1" << ")";
    }
    else {
        for (i = 0; i < Licb48K5YjES -(14 - 12); i = i + 1) {
            if ((ch[i] == ch[i + (573 - 572)]) || (ch[i + (566 - 565)] - ch[i] == (1004 - 972)) || (ch[i] - ch[i + (57 - 56)] == (529 - 497)))
                s7ODlfeUpEX = s7ODlfeUpEX + 1;
            else {
                s7ODlfeUpEX = s7ODlfeUpEX + 1;
                if ((ch[i] >= 'A') && ('Z' >= ch[i]))
                    CHzmGNW80 = ch[i] - 'A';
                else
                    CHzmGNW80 = ch[i] - 'a';
                e7QBtGF = 'A' + CHzmGNW80;
                cout << "(" << e7QBtGF << "," << s7ODlfeUpEX << ")";
                e7QBtGF = '\0';
                s7ODlfeUpEX = 0;
                CHzmGNW80 = 0;
            };
        }
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if ((ch[Licb48K5YjES -(133 - 131)] == ch[Licb48K5YjES -(133 - 132)]) || (ch[Licb48K5YjES -(504 - 502)] - ch[Licb48K5YjES -(405 - 404)] == (848 - 816)) || (ch[Licb48K5YjES -(822 - 821)] - ch[Licb48K5YjES -(983 - 981)] == 32)) {
            if ((ch[Licb48K5YjES -(610 - 609)] >= 'A') && (ch[Licb48K5YjES -1] <= 'Z'))
                CHzmGNW80 = ch[Licb48K5YjES -1] - 'A';
            else
                CHzmGNW80 = ch[Licb48K5YjES -1] - 'a';
            s7ODlfeUpEX = s7ODlfeUpEX + (366 - 364);
            e7QBtGF = 'A' + CHzmGNW80;
            cout << "(" << e7QBtGF << "," << s7ODlfeUpEX << ")";
        }
        else {
            s7ODlfeUpEX++;
            if ((ch[Licb48K5YjES -(847 - 845)] >= 'A') && (ch[Licb48K5YjES -2] <= 'Z'))
                CHzmGNW80 = ch[Licb48K5YjES -2] - 'A';
            else
                CHzmGNW80 = ch[Licb48K5YjES -2] - 'a';
            e7QBtGF = 'A' + CHzmGNW80;
            if ((ch[Licb48K5YjES -1] >= 'A') && (ch[Licb48K5YjES -1] <= 'Z'))
                CHzmGNW80 = ch[Licb48K5YjES -1] - 'A';
            else
                CHzmGNW80 = ch[Licb48K5YjES -1] - 'a';
            cout << "(" << e7QBtGF << "," << s7ODlfeUpEX << ")";
            e7QBtGF = 'A' + CHzmGNW80;
            cout << "(" << e7QBtGF << "," << "1" << ")";
        };
    }
    return 0;
}

