char lhlpudI0f [1000];

int main (int Rv5D3GNxRo, char *argv []) {
    char frlAW0HNi6B;
    int SXdTDI4;
    SXdTDI4 = (54 - 54);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin.getline (lhlpudI0f, 1000, '\n');
    frlAW0HNi6B = (278 - 182) <= lhlpudI0f[(212 - 212)] ? lhlpudI0f[(536 - 536)] - 'a' + 'A' : lhlpudI0f[0];
    {
        int wiu95IEhmyJ0 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (wiu95IEhmyJ0 < strlen (lhlpudI0f) + (587 - 586)) {
            if (lhlpudI0f[wiu95IEhmyJ0] >= (285 - 189))
                lhlpudI0f[wiu95IEhmyJ0] -= 'a' - 'A';
            if (lhlpudI0f[wiu95IEhmyJ0] == frlAW0HNi6B) {
                SXdTDI4++;
            }
            else {
                cout << "(" << frlAW0HNi6B << "," << SXdTDI4 << ")";
                SXdTDI4 = 1;
                frlAW0HNi6B = lhlpudI0f[wiu95IEhmyJ0];
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            wiu95IEhmyJ0 = wiu95IEhmyJ0 + 1;
        };
    }
    return EXIT_SUCCESS;
}

