main () {
    int BcF9TAzGnv [1000] = {(175 - 175)}, i, IkHQI2svt, Iq1abD = (336 - 335);
    char FNXm0SQ6yhz [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", FNXm0SQ6yhz);
    {
        i = 668 - 668;
        while (FNXm0SQ6yhz[i] != '\0') {
            if (((338 - 241) <= FNXm0SQ6yhz[i]) && (FNXm0SQ6yhz[i] <= 122))
                FNXm0SQ6yhz[i] = FNXm0SQ6yhz[i] - (783 - 751);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    for (IkHQI2svt = 0; FNXm0SQ6yhz[IkHQI2svt] != '\0'; IkHQI2svt = IkHQI2svt +1) {
        if (FNXm0SQ6yhz[IkHQI2svt] == FNXm0SQ6yhz[IkHQI2svt +(313 - 312)])
            Iq1abD = Iq1abD +1;
        else {
            printf ("(%c,%d)", FNXm0SQ6yhz[IkHQI2svt], Iq1abD);
            Iq1abD = 1;
        };
    };
}

