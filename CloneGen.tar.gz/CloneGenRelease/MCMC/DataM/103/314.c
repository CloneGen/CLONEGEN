int main () {
    char rKT35P1nxsQz [1001];
    gets (rKT35P1nxsQz);
    int oByhA5XRW;
    int fOlkGpxqr;
    int LY3FKiDgWBq;
    oByhA5XRW = (753 - 752);
    fOlkGpxqr = strlen (rKT35P1nxsQz);
    {
        LY3FKiDgWBq = 962 - 962;
        while (LY3FKiDgWBq < fOlkGpxqr) {
            if (rKT35P1nxsQz[LY3FKiDgWBq] >= 'a' && 'z' >= rKT35P1nxsQz[LY3FKiDgWBq])
                rKT35P1nxsQz[LY3FKiDgWBq] = rKT35P1nxsQz[LY3FKiDgWBq] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            LY3FKiDgWBq++;
        };
    }
    {
        LY3FKiDgWBq = 0;
        while (LY3FKiDgWBq < fOlkGpxqr) {
            if (rKT35P1nxsQz[LY3FKiDgWBq] == rKT35P1nxsQz[LY3FKiDgWBq +1]) {
                oByhA5XRW++;
            }
            else {
                cout << "(" << rKT35P1nxsQz[LY3FKiDgWBq] << "," << oByhA5XRW << ")";
                oByhA5XRW = 1;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            LY3FKiDgWBq++;
        };
    };
}

