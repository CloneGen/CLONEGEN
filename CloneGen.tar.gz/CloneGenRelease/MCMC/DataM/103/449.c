main () {
    int mxEr4H;
    int j;
    char oh4O3kB [2000];
    int n3p7ScVvmr = (163 - 162);
    getchar ();
    getchar ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", oh4O3kB);
    {
        mxEr4H = 965 - 965;
        while (oh4O3kB[mxEr4H] != '\0') {
            if (oh4O3kB[mxEr4H] >= 'a' && oh4O3kB[mxEr4H] <= 'z')
                oh4O3kB[mxEr4H] = oh4O3kB[mxEr4H] - (854 - 822);
            mxEr4H = mxEr4H + 1;
        };
    }
    {
        j = 0;
        while (oh4O3kB[j] != '\0') {
            if (oh4O3kB[j] == oh4O3kB[j + 1])
                n3p7ScVvmr = n3p7ScVvmr + 1;
            else {
                printf ("(%c,%d)", oh4O3kB[j], n3p7ScVvmr);
                n3p7ScVvmr = 1;
            }
            j++;
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

