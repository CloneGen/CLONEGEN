char f (char DbEDMepUjd05) {
    if ('a' <= DbEDMepUjd05)
        return DbEDMepUjd05 -'a' + 'A';
    else
        return DbEDMepUjd05;
}

int main () {
    int j8usEIzC, ZqbkuT5, i;
    char str [(1871 - 871)];
    ZqbkuT5 = (348 - 347);
    scanf ("%s", str);
    j8usEIzC = f (str[0]);
    {
        i = 199 - 198;
        while (i < strlen (str)) {
            if (j8usEIzC == f (str[i]))
                ZqbkuT5++;
            else {
                printf ("(%c,%d)", j8usEIzC, ZqbkuT5);
                j8usEIzC = f (str[i]);
                ZqbkuT5 = 1;
            }
            i++;
        };
    }
    printf ("(%c,%d)", j8usEIzC, ZqbkuT5);
}

