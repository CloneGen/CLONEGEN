int main () {
    char bJkuI6KnhV [1001];
    int SEDtRWYj1VX;
    int FoHw5VmfN1e;
    int a;
    int dKGtJe;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    SEDtRWYj1VX = (994 - 993);
    scanf ("%s", bJkuI6KnhV);
    dKGtJe = strlen (bJkuI6KnhV);
    {
        FoHw5VmfN1e = 911 - 911;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while ((dKGtJe - (903 - 902)) >= FoHw5VmfN1e) {
            if ((935 - 838) <= bJkuI6KnhV[FoHw5VmfN1e])
                bJkuI6KnhV[FoHw5VmfN1e] = bJkuI6KnhV[FoHw5VmfN1e] - (519 - 487);
            FoHw5VmfN1e++;
        };
    }
    for (FoHw5VmfN1e = 0; FoHw5VmfN1e <= (dKGtJe - (532 - 531)); FoHw5VmfN1e++) {
        if (bJkuI6KnhV[FoHw5VmfN1e] == bJkuI6KnhV[FoHw5VmfN1e +1])
            SEDtRWYj1VX = SEDtRWYj1VX +1;
        else {
            printf ("(%c,%d)", bJkuI6KnhV[FoHw5VmfN1e], SEDtRWYj1VX);
            SEDtRWYj1VX = 1;
        };
    };
}

