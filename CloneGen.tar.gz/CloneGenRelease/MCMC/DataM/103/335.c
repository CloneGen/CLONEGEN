int main () {
    int fYbuegiy6;
    char a [(1693 - 692)];
    int k = (774 - 773);
    scanf ("%s", a);
    for (fYbuegiy6 = (467 - 467); a[fYbuegiy6] != '\0'; fYbuegiy6++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (('a' <= a[fYbuegiy6]) && (a[fYbuegiy6] <= 'z')) {
            a[fYbuegiy6] = a[fYbuegiy6] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    for (fYbuegiy6 = 0; a[fYbuegiy6] != '\0'; fYbuegiy6++) {
        if (a[fYbuegiy6] == a[fYbuegiy6 + (850 - 849)]) {
            k = k + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            continue;
        }
        else {
            printf ("(%c,%d)", a[fYbuegiy6], k);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            k = 1;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

