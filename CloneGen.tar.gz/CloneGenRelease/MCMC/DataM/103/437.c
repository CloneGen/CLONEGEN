main () {
    char s [1000];
    int r9Ig4pqQ1, DeNb9I6wj, c;
    c = (115 - 115);
    scanf ("%s", &s);
    DeNb9I6wj = strlen (s);
    {
        r9Ig4pqQ1 = 585 - 585;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (DeNb9I6wj -(549 - 548) >= r9Ig4pqQ1) {
            if ((s[r9Ig4pqQ1] >= 'a') && ('z' >= s[r9Ig4pqQ1]))
                s[r9Ig4pqQ1] = s[r9Ig4pqQ1] - 'a' + 'A';
            r9Ig4pqQ1 = r9Ig4pqQ1 + 1;
        };
    }
    {
        r9Ig4pqQ1 = 307 - 307;
        while (DeNb9I6wj -(535 - 534) >= r9Ig4pqQ1) {
            if ((s[r9Ig4pqQ1] == s[r9Ig4pqQ1 + 1]) && (r9Ig4pqQ1 < DeNb9I6wj)) {
                c = c + 1;
            }
            else {
                if ((s[r9Ig4pqQ1] == s[r9Ig4pqQ1 + 1]) && (s[r9Ig4pqQ1 + (442 - 440)] == '\0'))
                    printf ("(%c,%d)", s[r9Ig4pqQ1], c);
                else {
                    printf ("(%c,%d)", s[r9Ig4pqQ1], c + 1);
                    c = (481 - 481);
                };
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            r9Ig4pqQ1 = r9Ig4pqQ1 + 1;
        };
    }
    getchar ();
    getchar ();
}

