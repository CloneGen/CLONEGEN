int main () {
    char t0OMHcT [2000];
    int t;
    int i;
    t = (135 - 135);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> t0OMHcT;
    for (i = 0; !('\0' == t0OMHcT[i]); i++) {
        if (t0OMHcT[i] >= 'a' && t0OMHcT[i] <= 'z') {
            t0OMHcT[i] = t0OMHcT[i] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        };
    }
    for (i = 0; t0OMHcT[i] != '\0'; i++) {
        if (t0OMHcT[i] == t0OMHcT[i + 1]) {
            t++;
        }
        else {
            t++;
            cout << "(" << t0OMHcT[i] << "," << t << ")";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            t = 0;
        };
    }
    cout << endl;
    return 0;
}

