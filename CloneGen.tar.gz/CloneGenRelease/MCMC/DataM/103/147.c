int main () {
    char PXq4nmy;
    char T8DwadRhXrBV [1000];
    int a;
    int Q1hpMHBQci;
    Q1hpMHBQci = (45 - 44);
    a = (564 - 564);
    scanf ("%s", T8DwadRhXrBV);
    for (; !('\0' == T8DwadRhXrBV[a]);) {
        T8DwadRhXrBV[a] = toupper (T8DwadRhXrBV[a]);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        a++;
    }
    a = 0;
    while (T8DwadRhXrBV[a] != '\0') {
        PXq4nmy = T8DwadRhXrBV[a];
        if (PXq4nmy == T8DwadRhXrBV[a + 1])
            Q1hpMHBQci = Q1hpMHBQci +1;
        else {
            printf ("(%c,%d)", PXq4nmy, Q1hpMHBQci);
            Q1hpMHBQci = 1;
        }
        a++;
    };
}

