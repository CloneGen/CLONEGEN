int main () {
    int count;
    int Ivpr6FWB8Ca;
    int fjKYcS2;
    count = 1;
    char pl3S0tnFkDiE [1005];
    char szFikWrb5no;
    cin >> pl3S0tnFkDiE;
    {
        Ivpr6FWB8Ca = 984 - 984;
        while (strlen (pl3S0tnFkDiE) > Ivpr6FWB8Ca) {
            if ((390 - 294) < pl3S0tnFkDiE[Ivpr6FWB8Ca] && (807 - 684) > pl3S0tnFkDiE[Ivpr6FWB8Ca])
                pl3S0tnFkDiE[Ivpr6FWB8Ca] = pl3S0tnFkDiE[Ivpr6FWB8Ca] - (286 - 254);
            Ivpr6FWB8Ca++;
        };
    }
    for (Ivpr6FWB8Ca = (839 - 839); Ivpr6FWB8Ca < strlen (pl3S0tnFkDiE);) {
        szFikWrb5no = pl3S0tnFkDiE[Ivpr6FWB8Ca];
        for (fjKYcS2 = Ivpr6FWB8Ca +1; fjKYcS2 < strlen (pl3S0tnFkDiE); fjKYcS2++) {
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (szFikWrb5no != pl3S0tnFkDiE[fjKYcS2]) {
                cout << "(" << pl3S0tnFkDiE[Ivpr6FWB8Ca] << "," << fjKYcS2 - Ivpr6FWB8Ca << ")";
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                break;
            };
        }
        if (fjKYcS2 == strlen (pl3S0tnFkDiE)) {
            cout << "(" << pl3S0tnFkDiE[Ivpr6FWB8Ca] << "," << fjKYcS2 - Ivpr6FWB8Ca << ")";
        }
        Ivpr6FWB8Ca = fjKYcS2;
    }
    return (280 - 280);
}

