main () {
    char eJRnI8lkYt4 [1000];
    gets (eJRnI8lkYt4);
    int mc60LkHPy8BT;
    int u1RcEL6i0dj4;
    u1RcEL6i0dj4 = (639 - 638);
    mc60LkHPy8BT = (629 - 629);
    while (!('\0' == eJRnI8lkYt4[mc60LkHPy8BT])) {
        if ('a' <= eJRnI8lkYt4[mc60LkHPy8BT] && eJRnI8lkYt4[mc60LkHPy8BT] <= 'z') {
            eJRnI8lkYt4[mc60LkHPy8BT] = eJRnI8lkYt4[mc60LkHPy8BT] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        mc60LkHPy8BT++;
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    mc60LkHPy8BT = (229 - 229);
    while (eJRnI8lkYt4[mc60LkHPy8BT + (661 - 660)] != '\0') {
        if (eJRnI8lkYt4[mc60LkHPy8BT] == eJRnI8lkYt4[mc60LkHPy8BT + (802 - 801)]) {
            u1RcEL6i0dj4 = u1RcEL6i0dj4 + (809 - 808);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            printf ("(%c,%d)", eJRnI8lkYt4[mc60LkHPy8BT], u1RcEL6i0dj4);
            u1RcEL6i0dj4 = (910 - 909);
        }
        if (eJRnI8lkYt4[mc60LkHPy8BT + 2] == '\0') {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    double  temp = 0.0;
                    if (temp == 3)
                        return 0;
                }
            }
            if (eJRnI8lkYt4[mc60LkHPy8BT] == eJRnI8lkYt4[mc60LkHPy8BT + 1]) {
                printf ("(%c,%d)", eJRnI8lkYt4[mc60LkHPy8BT], u1RcEL6i0dj4);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                };
            }
            else {
                printf ("(%c,%d)", eJRnI8lkYt4[mc60LkHPy8BT + 1], u1RcEL6i0dj4);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            };
        }
        mc60LkHPy8BT++;
    }
    if (eJRnI8lkYt4[1] == '\0') {
        if (eJRnI8lkYt4[(679 - 679)] >= 'a' && eJRnI8lkYt4[(643 - 643)] <= 'z') {
            eJRnI8lkYt4[0] = eJRnI8lkYt4[0] + 'A' - 'a';
            printf ("(%c,%d)", eJRnI8lkYt4[0], 1);
        }
        else {
            printf ("(%c,%d)", eJRnI8lkYt4[0], 1);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        };
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

