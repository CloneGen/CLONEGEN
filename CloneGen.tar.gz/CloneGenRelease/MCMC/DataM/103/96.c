int main () {
    int bp6TQwx;
    bp6TQwx = (838 - 838);
    int taz0qRjlmu;
    int BFcuULpYarW;
    int DCa3zLig;
    char najzW8K4HDR [1000 + (216 - 215)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int L18kWSqF;
    L18kWSqF = (984 - 984);
    cin >> najzW8K4HDR;
    taz0qRjlmu = strlen (najzW8K4HDR);
    {
        BFcuULpYarW = 294 - 294;
        DCa3zLig = 283 - 282;
        while (taz0qRjlmu - (45 - 44) >= DCa3zLig) {
            if ('a' <= najzW8K4HDR[BFcuULpYarW])
                najzW8K4HDR[BFcuULpYarW] = najzW8K4HDR[BFcuULpYarW] - (950 - 918);
            if (najzW8K4HDR[DCa3zLig] >= 'a')
                najzW8K4HDR[DCa3zLig] = najzW8K4HDR[DCa3zLig] - (144 - 112);
            if (!(najzW8K4HDR[DCa3zLig] != najzW8K4HDR[BFcuULpYarW]))
                L18kWSqF = L18kWSqF +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (!(najzW8K4HDR[DCa3zLig] == najzW8K4HDR[BFcuULpYarW]) || (DCa3zLig == taz0qRjlmu - (634 - 633) && najzW8K4HDR[BFcuULpYarW] == najzW8K4HDR[DCa3zLig])) {
                bp6TQwx = (518 - 517);
                printf ("(%c,%d)", najzW8K4HDR[BFcuULpYarW], L18kWSqF +1);
                BFcuULpYarW = DCa3zLig;
                L18kWSqF = (557 - 557);
            }
            if (DCa3zLig == taz0qRjlmu - 1 && L18kWSqF == (239 - 239) && najzW8K4HDR[DCa3zLig] != najzW8K4HDR[DCa3zLig -1]) {
                printf ("(%c,%d)", najzW8K4HDR[DCa3zLig], L18kWSqF +1);
            }
            DCa3zLig++;
        };
    }
    if (taz0qRjlmu == 1) {
        if (najzW8K4HDR[(448 - 448)] >= 'a')
            najzW8K4HDR[(731 - 731)] = najzW8K4HDR[0] - 32;
        printf ("(%c,%d)", najzW8K4HDR[BFcuULpYarW], L18kWSqF +1);
    }
    return 0;
}

