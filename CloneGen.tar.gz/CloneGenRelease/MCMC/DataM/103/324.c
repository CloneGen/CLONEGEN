int main () {
    char a [1010];
    int QQtBgSW74dC = (730 - 730);
    int IYMGreKI9 = (510 - 509);
    cin >> a;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    while (a[QQtBgSW74dC] != '\0') {
        if (!(a[QQtBgSW74dC] != a[QQtBgSW74dC +(813 - 812)]) || !(a[QQtBgSW74dC] - 'A' != a[QQtBgSW74dC +(624 - 623)] - 'a') || a[QQtBgSW74dC +1] - 'A' == a[QQtBgSW74dC] - 'a') {
            IYMGreKI9 = IYMGreKI9 +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            if (a[QQtBgSW74dC] >= 'a' && a[QQtBgSW74dC] <= 'z') {
                cout << '(';
                cout << (char) ('A' + a[QQtBgSW74dC] - 'a') << ',';
                cout << IYMGreKI9;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                IYMGreKI9 = 1;
                cout << ')';
            }
            else {
                cout << '(';
                cout << a[QQtBgSW74dC] << ',';
                cout << IYMGreKI9;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                IYMGreKI9 = 1;
                cout << ')';
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        QQtBgSW74dC = QQtBgSW74dC +1;
    }
    cout << endl;
    return (494 - 494);
}

