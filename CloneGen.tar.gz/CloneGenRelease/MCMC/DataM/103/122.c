int main () {
    char Hf3hCjdLq [(1571 - 571)];
    int m1kJZR;
    int WzZly2rh8TQ;
    int HuX0iq4WEM9;
    int p;
    int q;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    m1kJZR = (652 - 652);
    cin.getline (Hf3hCjdLq, 1000);
    {
        WzZly2rh8TQ = 564 - 564;
        while (WzZly2rh8TQ < 1000) {
            if (Hf3hCjdLq[WzZly2rh8TQ] >= 'a' && Hf3hCjdLq[WzZly2rh8TQ] <= 'z')
                Hf3hCjdLq[WzZly2rh8TQ] = Hf3hCjdLq[WzZly2rh8TQ] - 'a' + 'A';
            WzZly2rh8TQ = WzZly2rh8TQ +1;
        };
    }
    for (p = 0; p < strlen (Hf3hCjdLq); p = p + 1) {
        if (Hf3hCjdLq[p] == '\0')
            break;
        if (Hf3hCjdLq[p] == '0')
            continue;
        {
            q = 369 - 368;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            while (q < strlen (Hf3hCjdLq)) {
                if (Hf3hCjdLq[q] == Hf3hCjdLq[p]) {
                    Hf3hCjdLq[q] = '0';
                    m1kJZR++;
                }
                else {
                    break;
                }
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                q++;
            };
        }
        cout << "(" << Hf3hCjdLq[p] << "," << m1kJZR + 1 << ")";
        m1kJZR = 0;
        Hf3hCjdLq[p] = '0';
    }
    return 0;
}

