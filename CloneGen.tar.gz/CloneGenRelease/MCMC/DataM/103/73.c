int main () {
    int uh7VBNl;
    int UUEgtuI [1000];
    int d8IGhKv6N;
    char a [(1487 - 487)];
    int x2T3c9rBVdH;
    char JV5Jzn [(1560 - 560)];
    UUEgtuI[0] = (863 - 862);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> a;
    x2T3c9rBVdH = strlen (a);
    uh7VBNl = (475 - 475);
    {
        d8IGhKv6N = 483 - 483;
        while (x2T3c9rBVdH > d8IGhKv6N) {
            if ('a' <= a[d8IGhKv6N] && 'z' >= a[d8IGhKv6N])
                a[d8IGhKv6N] = a[d8IGhKv6N] - (788 - 756);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            d8IGhKv6N = d8IGhKv6N + 1;
        };
    }
    JV5Jzn[(853 - 853)] = a[0];
    for (d8IGhKv6N = 1; d8IGhKv6N < x2T3c9rBVdH; d8IGhKv6N++) {
        if (a[d8IGhKv6N] == a[d8IGhKv6N - 1]) {
            JV5Jzn[uh7VBNl] = a[d8IGhKv6N];
            UUEgtuI[uh7VBNl]++;
        }
        else {
            uh7VBNl++;
            JV5Jzn[uh7VBNl] = a[d8IGhKv6N];
            UUEgtuI[uh7VBNl] = 1;
        };
    }
    {
        d8IGhKv6N = 0;
        while (d8IGhKv6N <= uh7VBNl) {
            cout << '(' << JV5Jzn[d8IGhKv6N] << ',' << UUEgtuI[d8IGhKv6N] << ')';
            d8IGhKv6N++;
        };
    }
    cout << endl;
    return 0;
}

