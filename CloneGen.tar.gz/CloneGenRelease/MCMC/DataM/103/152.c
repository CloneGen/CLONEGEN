main () {
    char s [(1268 - 267)];
    char ps2RTKw5Dq3 [(1705 - 704)];
    int j;
    int i;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    j = (166 - 165);
    i = 0;
    gets (s);
    for (; 1000 >= i; i = i + 1) {
        if (s[i] >= 'a' && s[i] <= 'z')
            ps2RTKw5Dq3[i] = (s[i] - 'a' + 'A');
        else
            ps2RTKw5Dq3[i] = s[i];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (i <= 1000 && (ps2RTKw5Dq3[i] != '\0')) {
            if (ps2RTKw5Dq3[i] == ps2RTKw5Dq3[i + (286 - 285)])
                j = j + 1;
            else {
                printf ("(%c,%d)", ps2RTKw5Dq3[i], j);
                j = 1;
            }
            i = i + 1;
        };
    };
}

