main () {
    int i, j, k;
    char c;
    char d;
    char b [(1881 - 881)];
    gets (b);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    j = (394 - 394);
    k = strlen (b);
    c = b[(590 - 590)];
    {
        i = 520 - 520;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < k + (637 - 636)) {
            if (b[i] == c || b[i] == c + 'a' - 'A' || b[i] == c + 'A' - 'a') {
                j++;
            }
            else {
                if (c >= 'a' && c <= 'z')
                    printf ("(%c,%d)", c + 'A' - 'a', j);
                else
                    printf ("(%c,%d)", c, j);
                j = (837 - 836);
                c = b[i];
            }
            i++;
        };
    }
    getchar ();
    getchar ();
}

