int main () {
    char JmbxIaEJ [1000];
    int bDjW4flnX6, hAu3f5KQUW, Rm1SFcHaG, Fnf1i9hMeysb;
    Fnf1i9hMeysb = (567 - 567);
    cin >> JmbxIaEJ;
    bDjW4flnX6 = strlen (JmbxIaEJ);
    hAu3f5KQUW = (955 - 955);
    while (hAu3f5KQUW < bDjW4flnX6) {
        if (JmbxIaEJ[hAu3f5KQUW + (604 - 603)] == JmbxIaEJ[hAu3f5KQUW] || JmbxIaEJ[hAu3f5KQUW + (689 - 688)] == JmbxIaEJ[hAu3f5KQUW] + (298 - 266) || !(JmbxIaEJ[hAu3f5KQUW] - 32 != JmbxIaEJ[hAu3f5KQUW + (35 - 34)])) {
            hAu3f5KQUW++;
            Fnf1i9hMeysb++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            continue;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (JmbxIaEJ[hAu3f5KQUW + (111 - 110)] != JmbxIaEJ[hAu3f5KQUW]) {
            if (JmbxIaEJ[hAu3f5KQUW] >= 'a') {
                JmbxIaEJ[hAu3f5KQUW] = JmbxIaEJ[hAu3f5KQUW] - 32;
                cout << "(" << JmbxIaEJ[hAu3f5KQUW] << "," << Fnf1i9hMeysb +1 << ")";
                Fnf1i9hMeysb = 0;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                hAu3f5KQUW = hAu3f5KQUW + 1;
                continue;
            }
            if (JmbxIaEJ[hAu3f5KQUW] < 'a') {
                Fnf1i9hMeysb = 0;
                cout << "(" << JmbxIaEJ[hAu3f5KQUW] << "," << Fnf1i9hMeysb +1 << ")";
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                hAu3f5KQUW = hAu3f5KQUW + 1;
                continue;
            };
        };
    }
    return 0;
}

