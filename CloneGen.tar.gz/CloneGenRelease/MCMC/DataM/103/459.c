int main () {
    int RigQd4RaB;
    int GTnFJRh5Lf9;
    int LKtkVCEozGN;
    char xckBWw [(1048 - 48)];
    char fGPV6Wxdkz;
    cin.getline (xckBWw, 1000);
    GTnFJRh5Lf9 = strlen (xckBWw);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        RigQd4RaB = 891 - 891;
        while (RigQd4RaB <= GTnFJRh5Lf9 -(981 - 980)) {
            if (xckBWw[RigQd4RaB] >= 'a' && xckBWw[RigQd4RaB] <= 'z') {
                xckBWw[RigQd4RaB] = xckBWw[RigQd4RaB] - 32;
            }
            RigQd4RaB = RigQd4RaB +1;
        };
    }
    xckBWw[GTnFJRh5Lf9] = '0';
    fGPV6Wxdkz = xckBWw[(157 - 157)];
    LKtkVCEozGN = (74 - 73);
    if ((874 - 873) < GTnFJRh5Lf9) {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        for (RigQd4RaB = (992 - 991); RigQd4RaB <= GTnFJRh5Lf9; RigQd4RaB++) {
            if (xckBWw[RigQd4RaB] == fGPV6Wxdkz) {
                LKtkVCEozGN++;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                };
            }
            if (xckBWw[RigQd4RaB] != fGPV6Wxdkz) {
                cout << "(" << fGPV6Wxdkz << "," << LKtkVCEozGN << ")";
                LKtkVCEozGN = 1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                }
                fGPV6Wxdkz = xckBWw[RigQd4RaB];
            };
        };
    }
    if (GTnFJRh5Lf9 == 1) {
        cout << "(" << xckBWw[0] << "," << 1 << ")";
    }
    cin.get ();
    return 0;
}

