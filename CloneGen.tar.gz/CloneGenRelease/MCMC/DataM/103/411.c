int main () {
    char mwTHxVoIMnG [1010] = {(774 - 774)};
    gets (mwTHxVoIMnG);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int Jkrx0I = strlen (mwTHxVoIMnG);
    for (int i = 0;
    Jkrx0I > i; i++)
        mwTHxVoIMnG[i] = toupper (mwTHxVoIMnG[i]);
    {
        int i;
        i = 0;
        while (i < Jkrx0I) {
            int QStjZmDFW = (931 - 930);
            {
                int j = i + 1;
                while (j < Jkrx0I) {
                    if (mwTHxVoIMnG[j] != mwTHxVoIMnG[i])
                        break;
                    else
                        QStjZmDFW++;
                    j = j + 1;
                };
            }
            printf ("(%c,%d)", mwTHxVoIMnG[i], QStjZmDFW);
            i = i + QStjZmDFW -1;
            i++;
        };
    };
}

