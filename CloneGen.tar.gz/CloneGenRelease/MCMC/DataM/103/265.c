int main () {
    int vrw2IC7i, gpg4HTsq, DNys8De4wtc = (24 - 23), Y4qQ6Zdi8IW = (977 - 976);
    char X0P1o9 [(1059 - 48)] = {(403 - 403)};
    cin >> X0P1o9;
    gpg4HTsq = strlen (X0P1o9);
    for (vrw2IC7i = (437 - 437); gpg4HTsq - (627 - 626) >= vrw2IC7i; vrw2IC7i = vrw2IC7i + 1)
        if (X0P1o9[vrw2IC7i] >= 'a' && X0P1o9[vrw2IC7i] <= 'z')
            X0P1o9[vrw2IC7i] = X0P1o9[vrw2IC7i] - 'a' + 'A';
    cout << "(" << X0P1o9[0] << ",";
    for (vrw2IC7i = (983 - 982); vrw2IC7i <= gpg4HTsq - (126 - 125); vrw2IC7i++) {
        if (X0P1o9[vrw2IC7i] == X0P1o9[vrw2IC7i - (426 - 425)])
            DNys8De4wtc = DNys8De4wtc +1;
        else {
            cout << DNys8De4wtc << ")";
            cout << "(" << X0P1o9[vrw2IC7i] << ",";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            DNys8De4wtc = 1;
        };
    }
    cout << DNys8De4wtc << ")" << endl;
    return 0;
}

