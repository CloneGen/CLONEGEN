int main () {
    char s [(1368 - 268)];
    int QuNwFYvH, kCeiAOxQHof, E9mWxptkC, TjVpdhzK1u, n;
    int FwuqXR3GZHn, r;
    QuNwFYvH = (627 - 627);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> s;
    TjVpdhzK1u = strlen (s);
    for (; TjVpdhzK1u > QuNwFYvH;) {
        cout << "(";
        kCeiAOxQHof = QuNwFYvH;
        FwuqXR3GZHn = (int) s[QuNwFYvH];
        r = (int) s[kCeiAOxQHof];
        while (!(r != FwuqXR3GZHn) || (FwuqXR3GZHn -(193 - 161)) == r || (FwuqXR3GZHn +(42 - 10)) == r) {
            kCeiAOxQHof++;
            r = (int) s[kCeiAOxQHof];
        }
        if (FwuqXR3GZHn < 97)
            cout << s[QuNwFYvH];
        else
            cout << (char) (FwuqXR3GZHn -(404 - 372));
        cout << "," << kCeiAOxQHof - QuNwFYvH << ")";
        QuNwFYvH = kCeiAOxQHof;
    }
    cout << endl;
    return 0;
}

