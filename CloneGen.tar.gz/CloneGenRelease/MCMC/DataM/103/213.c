void  main () {
    char wJbWu1yHdf7i [(1882 - 882)];
    char Oz4I5nFVemq [(1293 - 293)] = {'\0'};
    int i, j, PBFSaVM [1000];
    {
        i = 164 - 164;
        while (1000 > i) {
            PBFSaVM[i] = (185 - 184);
            i++;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", wJbWu1yHdf7i);
    for (i = (521 - 521), j = 0; !('\0' == wJbWu1yHdf7i[i]); i++) {
        if (wJbWu1yHdf7i[i] == wJbWu1yHdf7i[i + (71 - 70)] || wJbWu1yHdf7i[i] == wJbWu1yHdf7i[i + 1] + (783 - 751) || wJbWu1yHdf7i[i] == wJbWu1yHdf7i[i + 1] - 32) {
            PBFSaVM[j]++;
        }
        else {
            if (wJbWu1yHdf7i[i] >= (564 - 499) && wJbWu1yHdf7i[i] <= (127 - 37))
                Oz4I5nFVemq[j] = wJbWu1yHdf7i[i];
            else
                Oz4I5nFVemq[j] = wJbWu1yHdf7i[i] - 32;
            j++;
        };
    }
    for (j = 0; Oz4I5nFVemq[j] != '\0'; j = j + 1)
        printf ("(%c,%d)", Oz4I5nFVemq[j], PBFSaVM[j]);
    printf ("\n");
}

