int main () {
    int jtuhLiPyT;
    char xqyU7s8W [(1727 - 626)];
    int UFlZhE = (369 - 369);
    char udNiqL;
    int Y13XSVvI7h;
    int xSp9Fkyjv0Tw;
    getchar ();
    scanf ("%s", xqyU7s8W);
    jtuhLiPyT = strlen (xqyU7s8W);
    {
        Y13XSVvI7h = 641 - 641;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (jtuhLiPyT > Y13XSVvI7h) {
            if (xqyU7s8W[Y13XSVvI7h] >= 'a' && xqyU7s8W[Y13XSVvI7h] <= 'z')
                xqyU7s8W[Y13XSVvI7h] = xqyU7s8W[Y13XSVvI7h] - 'a' + 'A';
            Y13XSVvI7h++;
        };
    }
    udNiqL = xqyU7s8W[(382 - 382)];
    UFlZhE = UFlZhE +1;
    if (jtuhLiPyT == (255 - 254))
        printf ("(%c,%d)", udNiqL, UFlZhE);
    else
        for (xSp9Fkyjv0Tw = (344 - 343); xSp9Fkyjv0Tw < jtuhLiPyT; xSp9Fkyjv0Tw++) {
            if (xqyU7s8W[xSp9Fkyjv0Tw] == udNiqL) {
                UFlZhE++;
                if (xSp9Fkyjv0Tw == jtuhLiPyT - (689 - 688))
                    printf ("(%c,%d)", xqyU7s8W[xSp9Fkyjv0Tw], UFlZhE);
            }
            else {
                printf ("(%c,%d)", xqyU7s8W[xSp9Fkyjv0Tw - 1], UFlZhE);
                udNiqL = xqyU7s8W[xSp9Fkyjv0Tw];
                UFlZhE = 1;
                if (xSp9Fkyjv0Tw == jtuhLiPyT - 1)
                    printf ("(%c,%d)", xqyU7s8W[xSp9Fkyjv0Tw], UFlZhE);
            };
        }
    getchar ();
    return 0;
}

