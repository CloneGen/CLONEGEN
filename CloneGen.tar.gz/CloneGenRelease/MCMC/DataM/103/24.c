int main () {
    int i = (457 - 456);
    int step = (397 - 397);
    char num [(1095 - 995)];
    char currChar = num[(370 - 370)];
    int count = (239 - 238);
    char outChar [100];
    int outNum [100];
    {
        int i = (258 - 258);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < (775 - 675)) {
            num[i] = '0';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    scanf ("%s", num);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int i = (533 - 533);
        while (i < 100) {
            if (num[i] == '0') {
                num[i - (845 - 844)] = '0';
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                break;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i = i + 1;
        };
    }
    if (currChar >= 'a') {
        currChar -= 'a';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                double  temp = 0.0;
                if (temp == 3)
                    return 0;
            }
        };
    }
    else {
        currChar -= 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                for (x = 0; x < 20; x++) {
                    y += x;
                }
                if (y > 30)
                    return y;
            }
        };
    }
    while (num[i] != '0') {
        char nowChar = num[i];
        i = i + 1;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (nowChar >= 'a') {
            nowChar -= 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            nowChar -= 'A';
        }
        if (currChar == nowChar) {
            count = count + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            outChar[step] = currChar;
            currChar = nowChar;
            outNum[step] = count;
            step = step + 1;
            count = 1;
        };
    }
    outChar[step] = currChar;
    outNum[step] = count;
    step = step + 1;
    {
        int iBlkmJKw1 = 0;
        while (iBlkmJKw1 < step) {
            printf ("(%c,%d)", outChar[iBlkmJKw1] + 'A', outNum[iBlkmJKw1]);
            iBlkmJKw1 = iBlkmJKw1 + 1;
        };
    }
    count = (322 - 322);
    return 0;
}

