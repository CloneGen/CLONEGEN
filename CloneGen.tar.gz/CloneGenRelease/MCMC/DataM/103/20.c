int main () {
    char a [(804 - 704)] = {(20 - 20)};
    char wRkqcuINg6Af;
    int Qu1MUzt8a0;
    int j;
    int n;
    int k;
    int counter;
    cin >> a;
    {
        Qu1MUzt8a0 = 126 - 126;
        while (a[Qu1MUzt8a0] != (297 - 297)) {
            if (97 <= a[Qu1MUzt8a0])
                a[Qu1MUzt8a0] = a[Qu1MUzt8a0] - 32;
            Qu1MUzt8a0 = Qu1MUzt8a0 +1;
        };
    }
    for (Qu1MUzt8a0 = (112 - 112); a[Qu1MUzt8a0] != (756 - 756);) {
        wRkqcuINg6Af = a[Qu1MUzt8a0];
        {
            k = 0;
            j = Qu1MUzt8a0;
            while (a[j] == wRkqcuINg6Af) {
                j = j + 1;
                k = k + 1;
            };
        }
        Qu1MUzt8a0 = j;
        cout << "(" << wRkqcuINg6Af << "," << k << ")";
    }
    return 0;
}

