main () {
    int t6cpw9T;
    int k;
    int gzBZocre9;
    int n1o2kEIeK [(201 - 101)];
    char Ufjicb [(449 - 349)];
    scanf ("%s", Ufjicb);
    for (t6cpw9T = 0; Ufjicb[t6cpw9T] != '\0'; t6cpw9T++) {
        if ('a' <= Ufjicb[t6cpw9T] && Ufjicb[t6cpw9T] <= 'z')
            Ufjicb[t6cpw9T] = Ufjicb[t6cpw9T] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    t6cpw9T = 0;
    while (Ufjicb[t6cpw9T] != '\0') {
        {
            k = t6cpw9T;
            while (1) {
                if (Ufjicb[k] != Ufjicb[t6cpw9T])
                    break;
                k = k + 1;
            };
        }
        printf ("(%c,%d)", Ufjicb[t6cpw9T], k - t6cpw9T);
        t6cpw9T = k;
    };
}

