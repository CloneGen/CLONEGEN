int main () {
    char jftIMia [1001];
    int lts8Bz6kIfmL;
    lts8Bz6kIfmL = strlen (jftIMia);
    int number;
    number = (102 - 101);
    cin >> jftIMia;
    jftIMia[lts8Bz6kIfmL] = '2';
    for (int DfvJZ2DFK = (394 - 394);
    lts8Bz6kIfmL > DfvJZ2DFK; DfvJZ2DFK++) {
        if (!(jftIMia[DfvJZ2DFK] != jftIMia[DfvJZ2DFK +1]) || !('A' - 'a' != jftIMia[DfvJZ2DFK +1] - jftIMia[DfvJZ2DFK]) || jftIMia[DfvJZ2DFK] - jftIMia[DfvJZ2DFK +1] == 'A' - 'a') {
            number++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            if (jftIMia[DfvJZ2DFK] >= 97)
                jftIMia[DfvJZ2DFK] = jftIMia[DfvJZ2DFK] - 32;
            cout << "(" << jftIMia[DfvJZ2DFK] << "," << number << ")";
            number = 1;
        };
    }
    return 0;
}

