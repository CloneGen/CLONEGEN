int main () {
    char vOaGfYvz4 [(1186 - 186)];
    char fEYzQMjvoI;
    int i = (602 - 602), count = (756 - 755);
    memset (vOaGfYvz4, '%', (1365 - 365));
    cin >> vOaGfYvz4;
    for (; !('%' == vOaGfYvz4[i]);) {
        if ('a' <= vOaGfYvz4[i] && vOaGfYvz4[i] <= 'z')
            vOaGfYvz4[i] = vOaGfYvz4[i] + 'A' - 'a';
        i = i + 1;
    }
    fEYzQMjvoI = vOaGfYvz4[0];
    i = (754 - 753);
    while (vOaGfYvz4[i] != '%') {
        if (vOaGfYvz4[i] == fEYzQMjvoI)
            count = count + 1;
        else {
            cout << "(" << fEYzQMjvoI << "," << count << ")";
            count = 1;
            fEYzQMjvoI = vOaGfYvz4[i];
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        i++;
    }
    return 0;
}

