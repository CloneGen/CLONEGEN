int main () {
    char MTCnzrmeGsZD = (582 - 582);
    char s [1002];
    int m7oWC240m;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    m7oWC240m = 0;
    cin >> s;
    {
        int AE6meA3k;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        AE6meA3k = 0;
        while (strlen (s) > AE6meA3k) {
            char ecqwJRaHGr = s[AE6meA3k];
            AE6meA3k = AE6meA3k +1;
            if (ecqwJRaHGr >= 'a')
                ecqwJRaHGr -= (536 - 504);
            if (ecqwJRaHGr == MTCnzrmeGsZD) {
                m7oWC240m = m7oWC240m + 1;
            }
            else {
                if (MTCnzrmeGsZD != 0) {
                    cout << "(" << MTCnzrmeGsZD << "," << m7oWC240m << ")";
                }
                m7oWC240m = (571 - 570);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                MTCnzrmeGsZD = ecqwJRaHGr;
            };
        };
    }
    cout << "(" << MTCnzrmeGsZD << "," << m7oWC240m << ")";
    return 0;
}

