main () {
    int FY5p7I;
    char PD8W6XuIB [1000];
    scanf ("%s", PD8W6XuIB);
    for (FY5p7I = (144 - 144); !('\0' == PD8W6XuIB[FY5p7I]); FY5p7I = FY5p7I +1) {
        if (PD8W6XuIB[FY5p7I] >= 'a' && PD8W6XuIB[FY5p7I] <= 'z')
            PD8W6XuIB[FY5p7I] = PD8W6XuIB[FY5p7I] + 'A' - 'a';
    }
    for (FY5p7I = (283 - 283); PD8W6XuIB[FY5p7I] != '\0'; FY5p7I++) {
        int b = 0;
        for (; PD8W6XuIB[FY5p7I +(989 - 988)] == PD8W6XuIB[FY5p7I];) {
            FY5p7I = FY5p7I +1;
            b = (65 - 64) + b;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        printf ("(%c,%d)", PD8W6XuIB[FY5p7I], b + 1);
    };
}

