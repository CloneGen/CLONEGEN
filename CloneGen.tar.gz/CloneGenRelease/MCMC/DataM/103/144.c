main () {
    int nlWMFV1;
    int FEzBmLqv;
    int flg;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char t2zbDfA [MAX];
    char id8fmGXpv;
    flg = (277 - 277);
    scanf ("%s", t2zbDfA);
    for (nlWMFV1 = (715 - 715);; nlWMFV1 = nlWMFV1 + 1) {
        if ((!(0 == nlWMFV1)) && (!(t2zbDfA[nlWMFV1 - (653 - 652)] != t2zbDfA[nlWMFV1]) || t2zbDfA[nlWMFV1] == t2zbDfA[nlWMFV1 - (481 - 480)] - (460 - 428) || t2zbDfA[nlWMFV1] == t2zbDfA[nlWMFV1 - 1] + 32)) {
            FEzBmLqv = FEzBmLqv +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else if (t2zbDfA[nlWMFV1] >= 'A' && t2zbDfA[nlWMFV1] <= 'Z') {
            if (flg)
                printf ("(%c,%d)", id8fmGXpv, FEzBmLqv);
            FEzBmLqv = 1;
            flg = 1;
            id8fmGXpv = t2zbDfA[nlWMFV1];
        }
        else {
            if (flg)
                printf ("(%c,%d)", id8fmGXpv, FEzBmLqv);
            FEzBmLqv = 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            id8fmGXpv = t2zbDfA[nlWMFV1] - 32;
            flg = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (t2zbDfA[nlWMFV1] == '\0')
            break;
    };
}

