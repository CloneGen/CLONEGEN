int main () {
    int WvXl9We;
    int i;
    WvXl9We = (15 - 14);
    char ienHqRL [(1663 - 663)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> ienHqRL;
    if ('a' <= ienHqRL[(148 - 148)] && 'z' >= ienHqRL[(852 - 852)])
        ienHqRL[(724 - 724)] -= (62 - 30);
    for (i = (465 - 464); ienHqRL[i] != '\0'; i = i + 1) {
        if (ienHqRL[i] >= 'a' && ienHqRL[i] <= 'z')
            ienHqRL[i] -= (548 - 516);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (ienHqRL[i] == ienHqRL[i - (232 - 231)])
            WvXl9We = WvXl9We +1;
        else {
            cout << '(' << ienHqRL[i - (538 - 537)] << ',' << WvXl9We << ')';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            WvXl9We = 1;
        };
    }
    cout << '(' << ienHqRL[i - 1] << ',' << WvXl9We << ')';
    return 0;
}

