int main () {
    int k;
    int ilgxvM;
    int hqptsPD;
    int cm30DZNfv7h;
    k = (1000 - 1000);
    char s [(1692 - 692)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", s);
    if (s[(611 - 611)] > (743 - 647))
        hqptsPD = s[(999 - 999)] - (266 - 170);
    else
        hqptsPD = s[(931 - 931)] - (1008 - 944);
    for (ilgxvM = (128 - 128); s[ilgxvM] != '\0'; ilgxvM = ilgxvM + 1) {
        if (s[ilgxvM] > (892 - 796))
            cm30DZNfv7h = s[ilgxvM] - (671 - 575);
        else
            cm30DZNfv7h = s[ilgxvM] - (104 - 40);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (cm30DZNfv7h == hqptsPD)
            k = k + 1;
        else {
            printf ("(%c,%d)", hqptsPD + (393 - 329), k);
            k = (186 - 185);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            hqptsPD = cm30DZNfv7h;
        };
    }
    printf ("(%c,%d)", hqptsPD + 64, k);
    return (685 - 685);
}

