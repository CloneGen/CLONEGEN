int main () {
    char temp;
    int i, PWQMTde, k;
    char nyzAm31uCB5 [1001];
    int LiEpJOt6No [(1147 - 947)];
    gets (nyzAm31uCB5);
    for (i = (380 - 380); i <= (417 - 218); i++)
        LiEpJOt6No[i] = (413 - 413);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    i = (913 - 912);
    if (nyzAm31uCB5[(794 - 794)] >= 'a' && 'z' >= nyzAm31uCB5[(957 - 957)])
        nyzAm31uCB5[(439 - 439)] = nyzAm31uCB5[(364 - 364)] - 'a' + 'A';
    temp = nyzAm31uCB5[(635 - 635)];
    LiEpJOt6No[nyzAm31uCB5[(901 - 901)]] = 1;
    while (!(0 == nyzAm31uCB5[i])) {
        if (nyzAm31uCB5[i] >= 'a' && nyzAm31uCB5[i] <= 'z')
            nyzAm31uCB5[i] = nyzAm31uCB5[i] - 'a' + 'A';
        if (LiEpJOt6No[nyzAm31uCB5[i]] == 0) {
            cout << '(' << temp << ',' << LiEpJOt6No[temp] << ')';
            LiEpJOt6No[temp] = 0;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            temp = nyzAm31uCB5[i];
            LiEpJOt6No[nyzAm31uCB5[i]] = 1;
        }
        else {
            LiEpJOt6No[nyzAm31uCB5[i]]++;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        i++;
    }
    if (LiEpJOt6No[nyzAm31uCB5[i - 1]] != 0)
        cout << '(' << temp << ',' << LiEpJOt6No[temp] << ')';
    return 0;
}

