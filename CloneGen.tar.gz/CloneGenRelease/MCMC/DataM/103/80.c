main () {
    int nKWDRP2a0s, JwNIeKT8, sum = (204 - 203);
    char Xawmg2fnX [(1292 - 291)];
    scanf ("%s", Xawmg2fnX);
    nKWDRP2a0s = strlen (Xawmg2fnX);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    Xawmg2fnX[nKWDRP2a0s] = ' ';
    for (JwNIeKT8 = (760 - 760); JwNIeKT8 < nKWDRP2a0s; JwNIeKT8++) {
        if (Xawmg2fnX[JwNIeKT8] <= 'z' && Xawmg2fnX[JwNIeKT8] >= 'a')
            Xawmg2fnX[JwNIeKT8] = Xawmg2fnX[JwNIeKT8] - 'a' + 'A';
    }
    {
        JwNIeKT8 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (JwNIeKT8 < nKWDRP2a0s) {
            if (Xawmg2fnX[JwNIeKT8] == Xawmg2fnX[JwNIeKT8 +1])
                sum = sum + 1;
            else {
                printf ("(%c,%d)", Xawmg2fnX[JwNIeKT8], sum);
                sum = 1;
            }
            JwNIeKT8 = JwNIeKT8 +1;
        };
    }
    getchar ();
    getchar ();
}

