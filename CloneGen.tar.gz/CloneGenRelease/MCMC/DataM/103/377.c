int main () {
    char word [1000];
    int length;
    length = strlen (word);
    char LtRgoZv9HG;
    LtRgoZv9HG = word[0];
    int KD8y1We;
    KD8y1We = (541 - 540);
    cin >> word;
    for (int i = 0;
    i < length; i++) {
        if (word[i] >= 'a' && word[i] <= 'z')
            word[i] += ('A' - 'a');
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (int i = 1;
    i < length; i++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (word[i] != LtRgoZv9HG) {
            printf ("(%c,%d)", LtRgoZv9HG, KD8y1We);
            LtRgoZv9HG = word[i];
            KD8y1We = 1;
        }
        else {
            KD8y1We++;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        };
    }
    printf ("(%c,%d)", LtRgoZv9HG, KD8y1We);
    return 0;
}

