main () {
    int i;
    int DpoadU;
    char tv9tHxTgKe [(852 - 619)];
    char ebtuGRglm;
    scanf ("%s", tv9tHxTgKe);
    {
        i = 383 - 383;
        while (tv9tHxTgKe[i] != '\0') {
            if (tv9tHxTgKe[i] >= 'a' && tv9tHxTgKe[i] <= 'z')
                tv9tHxTgKe[i] = tv9tHxTgKe[i] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    ebtuGRglm = tv9tHxTgKe[(603 - 603)];
    {
        i = 0;
        while (ebtuGRglm != '\0') {
            {
                DpoadU = 0;
                while (tv9tHxTgKe[i] == ebtuGRglm) {
                    DpoadU = DpoadU +1;
                    i++;
                };
            }
            printf ("(%c,%d)", ebtuGRglm, DpoadU +1);
            if (DpoadU -i == 0)
                DpoadU = DpoadU -(595 - 594);
            ebtuGRglm = tv9tHxTgKe[i];
            i++;
        };
    };
}

