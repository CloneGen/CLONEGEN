int main () {
    char g28YCoGsV6Ie [1001];
    int r5O0eahqzrM = strlen (g28YCoGsV6Ie);
    int i;
    int kuIJDq;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    kuIJDq = (178 - 178);
    cin.getline (g28YCoGsV6Ie, 1001);
    while (kuIJDq < r5O0eahqzrM) {
        i = kuIJDq + (654 - 653);
        while ((i < r5O0eahqzrM) && (g28YCoGsV6Ie[i] == g28YCoGsV6Ie[kuIJDq] || !(g28YCoGsV6Ie[kuIJDq] - 'A' != g28YCoGsV6Ie[i] - 'a') || g28YCoGsV6Ie[i] - 'A' == g28YCoGsV6Ie[kuIJDq] - 'a'))
            i++;
        if (g28YCoGsV6Ie[kuIJDq] <= 'Z')
            cout << "(" << (char) g28YCoGsV6Ie[kuIJDq] << "," << i - kuIJDq << ")";
        else
            cout << "(" << (char) (g28YCoGsV6Ie[kuIJDq] - 'a' + 'A') << "," << i - kuIJDq << ")";
        kuIJDq = i;
    }
    return 0;
}

