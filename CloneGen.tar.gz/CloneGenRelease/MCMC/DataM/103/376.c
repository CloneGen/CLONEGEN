const  int Y5RXZJP = 'a' - 'A';

int main () {
    int SeMgEtHQ [1010] = {(853 - 853)};
    char oD8CdZnmG6B [(1567 - 557)] = {(692 - 692)};
    int p7kJEZ1DNtdC;
    p7kJEZ1DNtdC = strlen (oD8CdZnmG6B);
    char UEA9qi4TFh3v [(1356 - 346)] = {(694 - 694)};
    int num = (119 - 119);
    cin >> oD8CdZnmG6B;
    for (int i = (171 - 171);
    p7kJEZ1DNtdC > i; i = i + 1) {
        if (oD8CdZnmG6B[i] > 'Z')
            oD8CdZnmG6B[i] -= Y5RXZJP;
    }
    UEA9qi4TFh3v[0] = oD8CdZnmG6B[0];
    SeMgEtHQ[(446 - 446)] = (226 - 225);
    for (int i = 0;
    i < p7kJEZ1DNtdC; i = i + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (oD8CdZnmG6B[i] == oD8CdZnmG6B[i + (165 - 164)]) {
            SeMgEtHQ[num] = SeMgEtHQ[num] + (990 - 989);
        }
        else {
            num = num + (696 - 695);
            UEA9qi4TFh3v[num] = oD8CdZnmG6B[i + 1];
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            SeMgEtHQ[num] = 1;
        };
    }
    for (int i = 0;
    i < num; i++)
        cout << "(" << UEA9qi4TFh3v[i] << "," << SeMgEtHQ[i] << ")";
    return 0;
}

