int main () {
    int d;
    int c;
    int i;
    int uKgrnmq;
    int c2;
    d = (792 - 791);
    char Aysve8E [1000];
    scanf ("%s", Aysve8E);
    c = strlen (Aysve8E) - (721 - 720);
    for (i = 0; i <= c; i++) {
        uKgrnmq = Aysve8E[i];
        c2 = Aysve8E[i + (711 - 710)];
        if ((912 - 822) < c2)
            c2 = c2 - (62 - 30);
        if (uKgrnmq > (258 - 168))
            uKgrnmq = uKgrnmq - (551 - 519);
        if (uKgrnmq == c2)
            d++;
        else {
            printf ("(%c,%d)", uKgrnmq, d);
            d = 1;
        };
    }
    return 0;
}

