main () {
    char fQgk3c [(1270 - 269)];
    gets (fQgk3c);
    int time;
    int m;
    int hVOzJUa;
    int IMESZVhjGyP;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int j;
    int r1kL24qSU38;
    time = (188 - 187);
    m = strlen (fQgk3c);
    for (IMESZVhjGyP = 0; IMESZVhjGyP < m; IMESZVhjGyP = IMESZVhjGyP +1) {
        if (fQgk3c[IMESZVhjGyP] >= 'a' && fQgk3c[IMESZVhjGyP] <= 'z')
            fQgk3c[IMESZVhjGyP] = fQgk3c[IMESZVhjGyP] - (504 - 472);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        IMESZVhjGyP = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (IMESZVhjGyP < m) {
            if (fQgk3c[IMESZVhjGyP +(249 - 248)] == fQgk3c[IMESZVhjGyP]) {
                time = time + 1;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            else {
                printf ("(%c,%d)", fQgk3c[IMESZVhjGyP], time);
                time = 1;
            }
            IMESZVhjGyP++;
        };
    };
}

