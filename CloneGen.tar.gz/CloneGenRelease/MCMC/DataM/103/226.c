int main () {
    char str [1000];
    int JNQKoZDX9j;
    int q8yUF4u1;
    int s;
    int E31wGsrB;
    char HxPuZebyFlqm;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", str);
    q8yUF4u1 = strlen (str);
    if (str[(16 - 16)] < 97)
        HxPuZebyFlqm = str[0];
    else
        HxPuZebyFlqm = str[0] - (810 - 778);
    E31wGsrB = (493 - 492);
    for (JNQKoZDX9j = 1; JNQKoZDX9j < q8yUF4u1; JNQKoZDX9j = JNQKoZDX9j +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(HxPuZebyFlqm != str[JNQKoZDX9j]) || str[JNQKoZDX9j] - (918 - 886) == HxPuZebyFlqm) {
            E31wGsrB = E31wGsrB +1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            printf ("(%c,%d)", HxPuZebyFlqm, E31wGsrB);
            if (str[JNQKoZDX9j] < 97)
                HxPuZebyFlqm = str[JNQKoZDX9j];
            else
                HxPuZebyFlqm = str[JNQKoZDX9j] - (240 - 208);
            E31wGsrB = 1;
        };
    }
    printf ("(%c,%d)", HxPuZebyFlqm, E31wGsrB);
    return 0;
}

