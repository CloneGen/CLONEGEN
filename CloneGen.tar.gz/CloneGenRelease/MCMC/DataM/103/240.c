void  main () {
    int D2qTahYk0l, j, Ij8iXNs4gM, d = (80 - 79);
    char a [(10645 - 645)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", a);
    Ij8iXNs4gM = strlen (a);
    for (D2qTahYk0l = (661 - 661); Ij8iXNs4gM > D2qTahYk0l; D2qTahYk0l = D2qTahYk0l +1)
        if (a[D2qTahYk0l] > (148 - 52) && a[D2qTahYk0l] < (841 - 718))
            a[D2qTahYk0l] = a[D2qTahYk0l] - (1016 - 984);
    {
        D2qTahYk0l = 339 - 339;
        while (Ij8iXNs4gM > D2qTahYk0l) {
            if (a[D2qTahYk0l] == a[D2qTahYk0l +1])
                d = d + 1;
            else
                printf ("(%c,%d)", a[D2qTahYk0l], d), d = 1;
            D2qTahYk0l++;
        };
    };
}

