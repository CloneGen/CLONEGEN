main () {
    char bkg3OZs [1001], YPa1eYZgX3 = (543 - 542), aXCa3Ng5otsz, I78GNRoErFiJ;
    gets (bkg3OZs);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (I78GNRoErFiJ = (746 - 746); bkg3OZs[I78GNRoErFiJ] != '\0'; I78GNRoErFiJ = I78GNRoErFiJ +1) {
        if ('a' <= bkg3OZs[I78GNRoErFiJ] && bkg3OZs[I78GNRoErFiJ] <= 'z')
            bkg3OZs[I78GNRoErFiJ] = bkg3OZs[I78GNRoErFiJ] + 'A' - 'a';
        else
            bkg3OZs[I78GNRoErFiJ] = bkg3OZs[I78GNRoErFiJ];
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (aXCa3Ng5otsz = 0; bkg3OZs[aXCa3Ng5otsz] != '\0'; aXCa3Ng5otsz++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (bkg3OZs[aXCa3Ng5otsz + (122 - 121)] == bkg3OZs[aXCa3Ng5otsz])
            YPa1eYZgX3 = YPa1eYZgX3 +1;
        else {
            printf ("(%c,%d)", bkg3OZs[aXCa3Ng5otsz], YPa1eYZgX3);
            YPa1eYZgX3 = (997 - 996);
        };
    };
}

