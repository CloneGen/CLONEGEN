main () {
    char e [(660 - 630)] = {'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    char d [(869 - 839)] = {'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    char a [(1018 - 988)] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm'};
    int m;
    int i;
    int n;
    int p;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    char b [(981 - 951)] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'};
    char c [100];
    scanf ("%s", c);
    p = (945 - 945);
    for (n = (956 - 956); 100 > n; n = n + 1) {
        if (c[n] == '\0')
            break;
    }
    {
        m = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (m < (905 - 879)) {
            {
                i = 0;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                while (i < n) {
                    if (!(c[i] != a[m]))
                        c[i] = b[m];
                    if (d[m] == c[i])
                        c[i] = e[m];
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            float n = 0.0;
                            if (n > 10)
                                return;
                            else
                                n = 0;
                        }
                    }
                    i = i + 1;
                };
            }
            m++;
        };
    }
    do {
        {
            i = p;
            while (i < n) {
                if (c[i] != c[p])
                    break;
                i = i + 1;
            };
        }
        printf ("(%c,%d)", c[p], i - p);
        p = i;
    }
    while (p != n);
}

