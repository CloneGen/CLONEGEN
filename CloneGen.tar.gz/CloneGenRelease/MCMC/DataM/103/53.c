main () {
    char zm [1000];
    int a [(1201 - 201)] = {(905 - 905)}, aIAaVyCR7 [1000], l, ez1QPclu6SIY, p = (509 - 509);
    scanf ("%s", zm);
    l = strlen (zm);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    aIAaVyCR7[0] = zm[0];
    {
        ez1QPclu6SIY = 420 - 419;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (ez1QPclu6SIY < l) {
            if (!(zm[ez1QPclu6SIY - (766 - 765)] != zm[ez1QPclu6SIY]) || !(zm[ez1QPclu6SIY - 1] - 'a' + 'A' != zm[ez1QPclu6SIY]) || zm[ez1QPclu6SIY] == zm[ez1QPclu6SIY - 1] - 'A' + 'a')
                a[p] = a[p] + 1;
            else {
                p = p + 1;
                aIAaVyCR7[p] = zm[ez1QPclu6SIY];
            }
            ez1QPclu6SIY = ez1QPclu6SIY + 1;
        };
    }
    {
        ez1QPclu6SIY = 0;
        while (ez1QPclu6SIY <= p) {
            if (aIAaVyCR7[ez1QPclu6SIY] <= 'z' && aIAaVyCR7[ez1QPclu6SIY] >= 'a')
                aIAaVyCR7[ez1QPclu6SIY] = aIAaVyCR7[ez1QPclu6SIY] - 'a' + 'A';
            ez1QPclu6SIY = ez1QPclu6SIY + 1;
        };
    }
    for (ez1QPclu6SIY = 0; ez1QPclu6SIY <= p; ez1QPclu6SIY = ez1QPclu6SIY + 1) {
        printf ("(%c,%d)", aIAaVyCR7[ez1QPclu6SIY], a[ez1QPclu6SIY] + 1);
    };
}

