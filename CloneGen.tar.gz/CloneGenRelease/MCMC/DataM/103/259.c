char jX3z8bp (char FpLJU9OjyD) {
    if ('A' <= FpLJU9OjyD &&'Z' >= FpLJU9OjyD)
        return FpLJU9OjyD;
    else {
        if (FpLJU9OjyD >= 'a' && FpLJU9OjyD <= 'z')
            return FpLJU9OjyD -'a' + 'A';
        else
            cout << "errer,not ??" << FpLJU9OjyD << endl;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    return FpLJU9OjyD;
}

int main () {
    int same;
    same = (568 - 567);
    char iLyoU9c8HlhD [(1253 - 253)];
    int length;
    length = strlen (iLyoU9c8HlhD);
    char ldIzxC = jX3z8bp (iLyoU9c8HlhD[(227 - 227)]);
    cin >> iLyoU9c8HlhD;
    for (int i = 1;
    i < length; i++) {
        if (jX3z8bp (iLyoU9c8HlhD[i]) == ldIzxC) {
            same = same + 1;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            };
        }
        else {
            cout << "(" << ldIzxC << "," << same << ")";
            ldIzxC = jX3z8bp (iLyoU9c8HlhD[i]);
            same = 1;
        };
    }
    cout << "(" << ldIzxC << "," << same << ")";
    return 0;
}

