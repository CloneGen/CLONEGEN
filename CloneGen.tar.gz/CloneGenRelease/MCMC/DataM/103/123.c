int main () {
    int yN1MJRYtf8, j, count = (637 - 637), dRlZ04X;
    char ch [(544 - 444)];
    cin >> ch;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        yN1MJRYtf8 = 502 - 502;
        while (strlen (ch) > yN1MJRYtf8) {
            if (ch[yN1MJRYtf8] >= 'a' && ch[yN1MJRYtf8] <= 'z')
                ch[yN1MJRYtf8] = ch[yN1MJRYtf8] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            yN1MJRYtf8 = yN1MJRYtf8 + 1;
        };
    }
    j = 0;
    while (1) {
        dRlZ04X = 'A';
        for (yN1MJRYtf8 = dRlZ04X; 'Z' >= yN1MJRYtf8; yN1MJRYtf8 = yN1MJRYtf8 + 1) {
            if (yN1MJRYtf8 == ch[j]) {
                while (yN1MJRYtf8 == ch[j]) {
                    j = j + 1;
                    count++;
                }
                cout << '(' << (char) yN1MJRYtf8 << ',' << count << ')';
                count = 0;
                dRlZ04X = 'A';
            };
        }
        if (j == strlen (ch))
            break;
    }
    return 0;
}

