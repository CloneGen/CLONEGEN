struct   letters {
    char Zm7qMkfQr;
    int time;
};
void  main () {
    char t;
    int k;
    int l;
    int i;
    k = (66 - 66);
    char AFomdSfA7z [1001] = {(23 - 23)};
    gets (AFomdSfA7z);
    struct   letters g7cQ12EwPx [(263 - 163)] = {(274 - 274)};
    l = strlen (AFomdSfA7z);
    g7cQ12EwPx[(170 - 170)].Zm7qMkfQr = ((1062 - 972) < AFomdSfA7z[(700 - 700)]) ? AFomdSfA7z[0] - (624 - 592) : AFomdSfA7z[0];
    g7cQ12EwPx[0].time++;
    for (i = (808 - 807); l > i; i = i + 1) {
        t = AFomdSfA7z[i];
        if (t > 90)
            t -= 32;
        if (t == AFomdSfA7z[i - 1] || t == AFomdSfA7z[i - 1] - 32)
            g7cQ12EwPx[k].time++;
        else {
            k++;
            g7cQ12EwPx[k].Zm7qMkfQr = t;
            g7cQ12EwPx[k].time++;
        };
    }
    {
        i = 0;
        while (i <= k) {
            printf ("(%c,%d)", g7cQ12EwPx[i].Zm7qMkfQr, g7cQ12EwPx[i].time);
            i++;
        };
    };
}

