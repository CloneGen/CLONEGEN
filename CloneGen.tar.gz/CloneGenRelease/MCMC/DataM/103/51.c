int main () {
    int kbJgZT = (443 - 442);
    int BKgRGyqN [(159 - 132)];
    char sTguIqkd8Q2 [(1869 - 868)];
    gets (sTguIqkd8Q2);
    int xLRc24, SZTqDbz157Qo, VFH16fbZ;
    int gX4aCkghPJ = strlen (sTguIqkd8Q2);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (xLRc24 = 0; xLRc24 < gX4aCkghPJ; xLRc24 = xLRc24 + 1) {
        if (sTguIqkd8Q2[xLRc24] <= 'z' && 'a' <= sTguIqkd8Q2[xLRc24])
            sTguIqkd8Q2[xLRc24] = sTguIqkd8Q2[xLRc24] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (xLRc24 = (916 - 915); xLRc24 < gX4aCkghPJ; xLRc24++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (sTguIqkd8Q2[xLRc24] == sTguIqkd8Q2[xLRc24 - 1]) {
            kbJgZT = kbJgZT + 1;
        }
        else {
            printf ("(%c,%d)", sTguIqkd8Q2[xLRc24 - 1], kbJgZT);
            kbJgZT = 1;
        };
    }
    printf ("(%c,%d)", sTguIqkd8Q2[gX4aCkghPJ - 1], kbJgZT);
    getchar ();
    getchar ();
}

