int main () {
    int UbGCqPLDAgV3, gUkvcLoqx = (999 - 999), j, ibo98ghq [(802 - 702)] = {(817 - 817)};
    char a [(565 - 465)];
    char *F5oby3;
    char *q;
    char RpwGit [(553 - 453)];
    cin.getline (a, 100);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    UbGCqPLDAgV3 = strlen (a);
    for (gUkvcLoqx = (362 - 362); 100 > gUkvcLoqx; gUkvcLoqx = gUkvcLoqx + 1) {
        ibo98ghq[gUkvcLoqx] = (189 - 188);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    gUkvcLoqx = (102 - 102);
    {
        F5oby3 = a;
        while (UbGCqPLDAgV3 +a >= F5oby3) {
            {
                q = 480 - 479;
                while (!(*F5oby3 != *q) || fabs (*F5oby3-*q) == (248 - 216)) {
                    RpwGit[gUkvcLoqx] = *F5oby3;
                    ibo98ghq[gUkvcLoqx]++;
                    q = q + 1;
                };
            }
            if (ibo98ghq[gUkvcLoqx] != (612 - 611)) {
                gUkvcLoqx = gUkvcLoqx + 1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                }
                F5oby3 = q - (724 - 723);
            }
            else {
                RpwGit[gUkvcLoqx] = *F5oby3;
                gUkvcLoqx++;
            }
            F5oby3++;
        };
    }
    for (j = (242 - 242); j < gUkvcLoqx; j = j + 1) {
        if (RpwGit[j] >= 'a' && RpwGit[j] <= 'z') {
            RpwGit[j] = RpwGit[j] - 32;
        };
    }
    for (j = 0; j < gUkvcLoqx - 1; j++) {
        cout << "(" << RpwGit[j] << "," << ibo98ghq[j] << ")";
    }
    return 0;
}

