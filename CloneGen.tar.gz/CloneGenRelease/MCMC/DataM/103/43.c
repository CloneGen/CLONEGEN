int main () {
    char TMVi345Frc;
    char kaUD8Jd [1000];
    int dbgYqs;
    int len;
    int DGtC7epiVl;
    dbgYqs = (583 - 583);
    cin >> kaUD8Jd;
    len = strlen (kaUD8Jd);
    if (kaUD8Jd[(925 - 925)] >= (1005 - 940) && kaUD8Jd[(338 - 338)] <= 90)
        TMVi345Frc = kaUD8Jd[0];
    else
        TMVi345Frc = kaUD8Jd[0] - (909 - 877);
    cout << '(' << TMVi345Frc << ',';
    for (DGtC7epiVl = 0; len > DGtC7epiVl; DGtC7epiVl++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(TMVi345Frc != kaUD8Jd[DGtC7epiVl]) || kaUD8Jd[DGtC7epiVl] - 32 == TMVi345Frc)
            dbgYqs = dbgYqs + 1;
        else {
            if (kaUD8Jd[DGtC7epiVl] >= 65 && kaUD8Jd[DGtC7epiVl] <= 90)
                TMVi345Frc = kaUD8Jd[DGtC7epiVl];
            else
                TMVi345Frc = kaUD8Jd[DGtC7epiVl] - 32;
            cout << dbgYqs << ')';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cout << '(' << TMVi345Frc << ',';
            dbgYqs = (510 - 509);
        };
    }
    cout << dbgYqs << ')';
    return 0;
}

