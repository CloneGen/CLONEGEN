int main () {
    char a [(1833 - 833)];
    int AyHruhjlNg, abOW50DyaYEc, j = (653 - 653);
    struct   comp {
        char NJLVubsa;
        int TrmX40;
    }
    com [1000];
    scanf ("%s", a);
    AyHruhjlNg = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (abOW50DyaYEc = (861 - 861); AyHruhjlNg > abOW50DyaYEc; abOW50DyaYEc = abOW50DyaYEc + 1) {
        com[abOW50DyaYEc].TrmX40 = (386 - 386);
    }
    {
        abOW50DyaYEc = 913 - 913;
        while (abOW50DyaYEc < AyHruhjlNg) {
            if (a[abOW50DyaYEc] >= (787 - 690) && 122 >= a[abOW50DyaYEc])
                a[abOW50DyaYEc] = a[abOW50DyaYEc] - (529 - 497);
            abOW50DyaYEc = abOW50DyaYEc + 1;
        };
    }
    {
        abOW50DyaYEc = 0;
        while (abOW50DyaYEc < AyHruhjlNg) {
            if (a[abOW50DyaYEc] == com[j].NJLVubsa) {
                com[j].TrmX40++;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                };
            }
            else {
                j = j + 1;
                com[j].NJLVubsa = a[abOW50DyaYEc];
                com[j].TrmX40++;
            }
            abOW50DyaYEc++;
        };
    }
    for (abOW50DyaYEc = (466 - 465); abOW50DyaYEc <= j; abOW50DyaYEc = abOW50DyaYEc + 1) {
        printf ("(%c,%d)", com[abOW50DyaYEc].NJLVubsa, com[abOW50DyaYEc].TrmX40);
    }
    return 0;
}

