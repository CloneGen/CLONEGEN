int main () {
    int k4pNHl;
    k4pNHl = (520 - 520);
    int vfzM9E7g [100] = {(573 - 573)};
    char a [(651 - 451)];
    int e0iLYsIJ [100] = {(517 - 517)};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int qnCmOwWS;
    cin >> a;
    {
        qnCmOwWS = 527 - 527;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (strlen (a) > qnCmOwWS) {
            if (a[qnCmOwWS] >= 'a' && a[qnCmOwWS] <= 'z')
                a[qnCmOwWS] = a[qnCmOwWS] - (543 - 511);
            qnCmOwWS = qnCmOwWS + 1;
        };
    }
    {
        qnCmOwWS = 0;
        while (qnCmOwWS < strlen (a)) {
            if (a[qnCmOwWS] == a[qnCmOwWS + (122 - 121)]) {
                e0iLYsIJ[k4pNHl]++;
            }
            else {
                e0iLYsIJ[k4pNHl]++;
                k4pNHl++;
                vfzM9E7g[k4pNHl] = qnCmOwWS + (515 - 514);
            }
            qnCmOwWS = qnCmOwWS + 1;
        };
    }
    for (qnCmOwWS = 0; qnCmOwWS < k4pNHl; qnCmOwWS = qnCmOwWS + 1)
        cout << '(' << a[vfzM9E7g[qnCmOwWS]] << ',' << e0iLYsIJ[qnCmOwWS] << ')';
    return 0;
}

