main () {
    char ozTS8lZt [1010];
    int l;
    int qxJMrvg;
    int JGaCF0t9c;
    int k;
    int x;
    char c;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (ozTS8lZt);
    getchar ();
    l = strlen (ozTS8lZt);
    {
        qxJMrvg = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (l > qxJMrvg) {
            ozTS8lZt[qxJMrvg] = toupper (ozTS8lZt[qxJMrvg]);
            qxJMrvg = qxJMrvg + 1;
        };
    }
    qxJMrvg = 0;
    for (; qxJMrvg < l;) {
        c = ozTS8lZt[qxJMrvg];
        JGaCF0t9c = qxJMrvg + (936 - 935);
        x = JGaCF0t9c -qxJMrvg;
        while (JGaCF0t9c < l && ozTS8lZt[JGaCF0t9c] == c)
            JGaCF0t9c++;
        qxJMrvg = JGaCF0t9c;
        printf ("(%c,%d)", c, x);
    }
    getchar ();
    printf ("\n");
}

