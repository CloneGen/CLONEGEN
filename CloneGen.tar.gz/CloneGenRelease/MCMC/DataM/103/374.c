int main () {
    char words [(2174 - 174)];
    char *p = NULL;
    char *q = NULL;
    cin.getline (words, sizeof (words));
    p = words;
    q = words;
    while ((540 - 539)) {
        if (!('\0' != *q)) {
            if ((807 - 710) <= *p)
                *p = *p - (835 - 803);
            cout << "(" << *p << ',' << (q - p) << ")";
            cout << endl;
            break;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (*p == *q || fabs (*p - *q) == (751 - 719))
            q++;
        else {
            if (*p >= 97)
                *p = *p - (702 - 670);
            cout << "(" << *p << ',' << (q - p) << ")";
            p = q;
        };
    }
    return (413 - 413);
}

