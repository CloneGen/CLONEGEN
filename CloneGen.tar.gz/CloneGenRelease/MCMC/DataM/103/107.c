int main () {
    char QnIQPOq [2000] = {(726 - 726)};
    char a [(2929 - 929)] = {(695 - 695)};
    char G8kxTvQPgz;
    int b [2000] = {(596 - 596)};
    int pOZydegDpb;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int tcMJuz5;
    int IENOlMe;
    pOZydegDpb = (125 - 125);
    tcMJuz5 = (116 - 116);
    for (; cin.getline (a, 2000);) {
        tcMJuz5 = 0;
        pOZydegDpb = 0;
        memset (b, (797 - 797), sizeof (b));
        memset (QnIQPOq, (219 - 219), sizeof (QnIQPOq));
        G8kxTvQPgz = (256 - 256);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        G8kxTvQPgz = a[0];
        for (IENOlMe = 0; !('\0' == a[IENOlMe]); IENOlMe++) {
            if (!(G8kxTvQPgz != a[IENOlMe]) || a[IENOlMe] + (609 - 577) == G8kxTvQPgz || !(G8kxTvQPgz != a[IENOlMe] - (704 - 672))) {
                b[tcMJuz5]++;
                if (a[IENOlMe] >= 'a' && a[IENOlMe] <= 'z')
                    QnIQPOq[tcMJuz5] = a[IENOlMe] - 32;
                QnIQPOq[tcMJuz5] = a[IENOlMe];
            }
            else {
                tcMJuz5 = tcMJuz5 + 1;
                b[tcMJuz5] = 1;
                G8kxTvQPgz = a[IENOlMe];
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                QnIQPOq[tcMJuz5] = G8kxTvQPgz;
                continue;
            };
        }
        for (IENOlMe = 0; QnIQPOq[IENOlMe] != '\0'; IENOlMe++) {
            if (QnIQPOq[IENOlMe] >= 'a' && QnIQPOq[IENOlMe] <= 'z')
                QnIQPOq[IENOlMe] = QnIQPOq[IENOlMe] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            cout << "(" << QnIQPOq[IENOlMe] << "," << b[IENOlMe] << ")";
        }
        cout << endl;
    }
    return 0;
}

