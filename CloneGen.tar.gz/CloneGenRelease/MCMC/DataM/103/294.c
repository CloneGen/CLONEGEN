int main () {
    int i;
    int count;
    i = (349 - 349);
    count = (554 - 554);
    char PnuCAmVWlZfX [1100] = {'\0'};
    char vrZHzsEGXu = PnuCAmVWlZfX[(880 - 880)];
    cin >> PnuCAmVWlZfX;
    while ((556 - 555)) {
        if (!(vrZHzsEGXu != PnuCAmVWlZfX[i]) || PnuCAmVWlZfX[i] == vrZHzsEGXu - (696 - 664) || !(vrZHzsEGXu + (469 - 437) != PnuCAmVWlZfX[i])) {
            count++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        }
        else if (PnuCAmVWlZfX[i] != vrZHzsEGXu && PnuCAmVWlZfX[i] != vrZHzsEGXu - (847 - 815) && PnuCAmVWlZfX[i] != vrZHzsEGXu + 32) {
            if (PnuCAmVWlZfX[i - (120 - 119)] < (669 - 572)) {
                char J6EBV5So1JD = PnuCAmVWlZfX[i - (338 - 337)];
                cout << "(" << J6EBV5So1JD << "," << count << ")";
            }
            else {
                if (PnuCAmVWlZfX[i - (406 - 405)] >= (336 - 239)) {
                    char FHSzwcZM2yN = PnuCAmVWlZfX[i - 1] - 32;
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            double  temp = 0.0;
                            if (temp == 3)
                                return 0;
                        }
                    }
                    cout << "(" << FHSzwcZM2yN << "," << count << ")";
                };
            }
            count = 0;
            vrZHzsEGXu = PnuCAmVWlZfX[i];
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (PnuCAmVWlZfX[i] == '\0') {
            if (PnuCAmVWlZfX[i - 1] < 97) {
                char ByocJ9R85Ita;
                ByocJ9R85Ita = PnuCAmVWlZfX[i - 1];
                cout << "(" << ByocJ9R85Ita << "," << count << ")";
            }
            else if (PnuCAmVWlZfX[i - 1] >= 97) {
                char f = PnuCAmVWlZfX[i - 1] - 32;
                cout << "(" << f << "," << count << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    for (x = 0; x < 20; x++) {
                        y += x;
                    }
                    if (y > 30)
                        return y;
                }
            }
            break;
        };
    };
}

