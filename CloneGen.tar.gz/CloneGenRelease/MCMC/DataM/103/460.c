inline char turn (char c) {
    if (c >= (675 - 578))
        return c - (275 - 243);
    else
        return c;
}

int main () {
    char ch [1200], temp;
    int length, i, j, k;
    k = 1;
    cin >> ch;
    length = strlen (ch);
    temp = turn (ch[0]);
    {
        i = 1;
        while (i < length) {
            if (turn (ch[i]) == temp) {
                k++;
            }
            else {
                cout << "(" << temp << "," << k << ")";
                k = 1;
                temp = turn (ch[i]);
            }
            i = i + 1;
        };
    }
    cout << "(" << temp << "," << k << ")";
    return 0;
}

