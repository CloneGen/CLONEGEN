int main (int SzR56MZsQ, char *argv []) {
    char RFg3mSZjbY [(1794 - 794)] = {'\0'};
    int wlVhaBJ48s, j, TK190l8ZrD = (755 - 755);
    gets (RFg3mSZjbY);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (wlVhaBJ48s = (614 - 614); (1868 - 868) > wlVhaBJ48s; wlVhaBJ48s = wlVhaBJ48s + 1) {
        if (RFg3mSZjbY[wlVhaBJ48s] == '\0')
            break;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (RFg3mSZjbY[wlVhaBJ48s] >= 'a' && RFg3mSZjbY[wlVhaBJ48s] <= 'z')
            RFg3mSZjbY[wlVhaBJ48s] = RFg3mSZjbY[wlVhaBJ48s] - 'a' + 'A';
    }
    {
        wlVhaBJ48s = 847 - 847;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (1000 > wlVhaBJ48s) {
            if (RFg3mSZjbY[wlVhaBJ48s] == '\0')
                break;
            if (RFg3mSZjbY[wlVhaBJ48s] != RFg3mSZjbY[wlVhaBJ48s + 1]) {
                TK190l8ZrD = (784 - 784);
                for (j = wlVhaBJ48s; RFg3mSZjbY[j] == RFg3mSZjbY[wlVhaBJ48s]; j = j - 1)
                    TK190l8ZrD++;
                printf ("(%c,%d)", RFg3mSZjbY[wlVhaBJ48s], TK190l8ZrD);
            }
            wlVhaBJ48s++;
        };
    }
    return 0;
}

