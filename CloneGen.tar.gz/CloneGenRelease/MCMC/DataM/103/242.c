int main () {
    char shuru [2000];
    int pytX7LB;
    int bC4VgAWP;
    int q94T3IMwJvqS;
    int MBb4czk;
    int s;
    int TvPOtm;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", shuru);
    bC4VgAWP = strlen (shuru);
    {
        q94T3IMwJvqS = 0;
        while (q94T3IMwJvqS < bC4VgAWP) {
            if (shuru[q94T3IMwJvqS] > (933 - 843))
                shuru[q94T3IMwJvqS] = shuru[q94T3IMwJvqS] - (916 - 884);
            else
                ;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            q94T3IMwJvqS = q94T3IMwJvqS + 1;
        };
    }
    MBb4czk = 0;
    TvPOtm = 0;
    if (bC4VgAWP == (942 - 941)) {
        printf ("(%c,1)", shuru[MBb4czk]);
    }
    else {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (MBb4czk < bC4VgAWP - (673 - 672)) {
            if (shuru[MBb4czk] == shuru[MBb4czk +1]) {
                s = 1;
                do {
                    s = s + 1;
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            for (x = 0; x < 20; x++) {
                                y += x;
                            }
                            if (y > 30)
                                return y;
                        }
                    };
                }
                while (shuru[MBb4czk] == shuru[MBb4czk +s]);
                printf ("(%c,%d)", shuru[MBb4czk], s);
                MBb4czk = MBb4czk +s;
            }
            else {
                printf ("(%c,1)", shuru[MBb4czk]);
                MBb4czk = MBb4czk +1;
                TvPOtm++;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            if (MBb4czk == bC4VgAWP - 1)
                printf ("(%c,1)", shuru[MBb4czk]);
            else
                ;
        };
    }
    getchar ();
    getchar ();
}

