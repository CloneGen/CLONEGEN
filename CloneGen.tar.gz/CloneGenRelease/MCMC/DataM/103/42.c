int main () {
    char hMgLdxHj [1100] = {(441 - 441)};
    int b [1100] = {(324 - 324)};
    char a [(1965 - 865)];
    char J2Pg1wvLXqn = a[(630 - 630)];
    int W210gvnVzu, j = (301 - 301), cDkPCWRx = (973 - 973), l;
    cin.getline (a, (1165 - 65));
    l = strlen (a);
    hMgLdxHj[(747 - 747)] = a[(569 - 569)];
    b[(899 - 899)] = (684 - 683);
    {
        W210gvnVzu = 1;
        while (W210gvnVzu < l) {
            if ((!(J2Pg1wvLXqn != a[W210gvnVzu])) || ((a[W210gvnVzu] - 'a') == (J2Pg1wvLXqn -'A')) || ((a[W210gvnVzu] - 'A') == (J2Pg1wvLXqn -'a'))) {
                b[cDkPCWRx]++;
            }
            else {
                cDkPCWRx++;
                b[cDkPCWRx] = 1;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                hMgLdxHj[cDkPCWRx] = a[W210gvnVzu];
                J2Pg1wvLXqn = a[W210gvnVzu];
            }
            W210gvnVzu = W210gvnVzu +1;
        };
    }
    for (W210gvnVzu = 0; W210gvnVzu <= cDkPCWRx; W210gvnVzu = W210gvnVzu +1) {
        cout << "(";
        if (hMgLdxHj[W210gvnVzu] > (993 - 897)) {
            int rcsR6wyC5 = hMgLdxHj[W210gvnVzu] - 'a';
            char J2Pg1wvLXqn = rcsR6wyC5 + 'A';
            cout << J2Pg1wvLXqn << ",";
        }
        else {
            cout << hMgLdxHj[W210gvnVzu] << ",";
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        cout << b[W210gvnVzu] << ")";
    }
    cin.get ();
    cin.get ();
    cin.get ();
    return 0;
}

