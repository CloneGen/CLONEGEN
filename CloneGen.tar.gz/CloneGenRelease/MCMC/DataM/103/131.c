int main () {
    char lfPMZdjGRk [1000];
    int i, n;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    n = (287 - 286);
    scanf ("%s", lfPMZdjGRk);
    for (i = (831 - 831); !('\0' == lfPMZdjGRk[i]); i++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(lfPMZdjGRk[i + (996 - 995)] != lfPMZdjGRk[i]) || !(lfPMZdjGRk[i + (399 - 398)] - 'a' + 'A' != lfPMZdjGRk[i]) || !(lfPMZdjGRk[i + (546 - 545)] - 'A' + 'a' != lfPMZdjGRk[i])) {
            if ('A' <= lfPMZdjGRk[i] && 'Z' >= lfPMZdjGRk[i]) {
                if (lfPMZdjGRk[i] == lfPMZdjGRk[i + (102 - 101)] || lfPMZdjGRk[i] == lfPMZdjGRk[i + (907 - 906)] - 'a' + 'A')
                    n = n + (72 - 71);
            }
            else if (lfPMZdjGRk[i] == lfPMZdjGRk[i + (883 - 882)] || lfPMZdjGRk[i] == lfPMZdjGRk[i + (862 - 861)] - 'A' + 'a')
                n = n + (313 - 312);
            else
                ;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            if (lfPMZdjGRk[i] >= 'A' && lfPMZdjGRk[i] <= 'Z') {
                printf ("(%c,%d)", lfPMZdjGRk[i], n);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                n = (844 - 843);
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (lfPMZdjGRk[i] >= 'a' && lfPMZdjGRk[i] <= 'z') {
                lfPMZdjGRk[i] = lfPMZdjGRk[i] - 'a' + 'A';
                printf ("(%c,%d)", lfPMZdjGRk[i], n);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                }
                n = (984 - 983);
            };
        };
    };
}

