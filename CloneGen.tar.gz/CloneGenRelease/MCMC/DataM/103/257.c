main () {
    int OA4c0a7EYG, WPNLOM8tI92l;
    char GAdo7Vrc1U [1000];
    OA4c0a7EYG = (357 - 357);
    scanf ("%s", GAdo7Vrc1U);
    for (int k = 0;
    !('\0' == GAdo7Vrc1U[k]); k++) {
        if (GAdo7Vrc1U[k] >= 'a' && GAdo7Vrc1U[k] <= 'z')
            GAdo7Vrc1U[k] = GAdo7Vrc1U[k] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    while (GAdo7Vrc1U[OA4c0a7EYG] != '\0') {
        for (WPNLOM8tI92l = OA4c0a7EYG;; WPNLOM8tI92l = WPNLOM8tI92l +1) {
            if (GAdo7Vrc1U[WPNLOM8tI92l] != GAdo7Vrc1U[OA4c0a7EYG])
                break;
        }
        printf ("(%c,%d)", GAdo7Vrc1U[OA4c0a7EYG], (WPNLOM8tI92l -OA4c0a7EYG));
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        OA4c0a7EYG = WPNLOM8tI92l;
    };
}

