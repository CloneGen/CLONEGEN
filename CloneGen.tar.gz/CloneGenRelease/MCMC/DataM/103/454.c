main () {
    int k = (151 - 150);
    int YxwpILqC1kz;
    char a [(1232 - 231)], c;
    gets (a);
    {
        YxwpILqC1kz = 0;
        while (a[YxwpILqC1kz] != '\0') {
            if ((!(a[YxwpILqC1kz] != a[YxwpILqC1kz +(932 - 931)])) || (a[YxwpILqC1kz +(750 - 749)] == a[YxwpILqC1kz] + 'A' - 'a') || a[YxwpILqC1kz +1] == (a[YxwpILqC1kz] - 'A' + 'a'))
                k++;
            else {
                if (a[YxwpILqC1kz] < 'a')
                    printf ("(%c,%d)", a[YxwpILqC1kz], k);
                else {
                    c = a[YxwpILqC1kz] + 'A' - 'a';
                    printf ("(%c,%d)", c, k);
                }
                k = 1;
            }
            YxwpILqC1kz = YxwpILqC1kz +1;
        };
    };
}

