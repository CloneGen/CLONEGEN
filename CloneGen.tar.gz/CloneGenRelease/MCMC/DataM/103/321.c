main () {
    char a [(1685 - 685)], b [(1199 - 199)], e [1000];
    int c [(1775 - 775)] = {(801 - 801)};
    int i;
    int m;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (a);
    k = (740 - 740);
    m = strlen (a);
    {
        i = 168 - 168;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (m >= i) {
            if ('a' > a[i])
                b[i] = a[i];
            else
                b[i] = a[i] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    e[(539 - 539)] = b[(724 - 724)];
    c[(195 - 195)] = (613 - 612);
    {
        i = 209 - 208;
        while (m >= i) {
            if (b[i] == b[i - (89 - 88)])
                c[k] = c[k] + (356 - 355);
            else {
                k = k + (642 - 641);
                e[k] = b[i];
                c[k] = c[k] + (79 - 78);
            }
            i = i + 1;
        };
    }
    {
        i = 201 - 201;
        while (i <= k - 1) {
            printf ("(%c,%d)", e[i], c[i]);
            i++;
        };
    };
}

