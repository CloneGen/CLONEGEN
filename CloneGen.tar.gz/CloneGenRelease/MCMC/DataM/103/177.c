int main () {
    int unpxTR5PM4L1, xOYe1Tdpf, j;
    char a [(5709 - 709)], t;
    scanf ("%s", a);
    unpxTR5PM4L1 = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (xOYe1Tdpf = 0; xOYe1Tdpf < unpxTR5PM4L1; xOYe1Tdpf++)
        if (a[xOYe1Tdpf] >= 'a' && a[xOYe1Tdpf] <= 'z')
            a[xOYe1Tdpf] = a[xOYe1Tdpf] - 'a' + 'A';
    for (xOYe1Tdpf = 0; xOYe1Tdpf < unpxTR5PM4L1;) {
        t = a[xOYe1Tdpf++], j = 1;
        for (; a[xOYe1Tdpf] == t; xOYe1Tdpf++, j = j + 1)
            ;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        printf ("(%c,%d)", t, j);
    }
    return 0;
}

