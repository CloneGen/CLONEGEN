char AObmuMht5Q [1001], d1TUCt;
int wvK6Z5E1;

void  display (int tXpx3jgCe) {
    if (!AObmuMht5Q[tXpx3jgCe])
        return;
    if (wvK6Z5E1 == (986 - 985)) {
        if ('A' <= AObmuMht5Q[tXpx3jgCe] && AObmuMht5Q[tXpx3jgCe] <= 'Z')
            d1TUCt = AObmuMht5Q[tXpx3jgCe];
        else
            d1TUCt = AObmuMht5Q[tXpx3jgCe] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if (AObmuMht5Q[tXpx3jgCe] != AObmuMht5Q[tXpx3jgCe + (476 - 475)] && abs (AObmuMht5Q[tXpx3jgCe] - AObmuMht5Q[tXpx3jgCe + (172 - 171)]) != 32) {
        cout << '(' << d1TUCt << ',' << wvK6Z5E1 << ')';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        wvK6Z5E1 = 1;
    }
    else
        wvK6Z5E1 = wvK6Z5E1 + 1;
    display (tXpx3jgCe + 1);
}

int main () {
    cin >> AObmuMht5Q;
    wvK6Z5E1 = 1;
    display ((302 - 302));
}

