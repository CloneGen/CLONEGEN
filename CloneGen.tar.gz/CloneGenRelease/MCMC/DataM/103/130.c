main () {
    int tas7SEJbTr [1001];
    char GOo4azEZ [(1869 - 868)], xnYOMs3rhi [1001];
    int AMpchyjW = (399 - 399);
    scanf ("%s", GOo4azEZ);
    xnYOMs3rhi[(660 - 660)] = GOo4azEZ[(70 - 70)];
    for (int wZxSj6cizJ = 0;
    1000 >= wZxSj6cizJ; wZxSj6cizJ++) {
        tas7SEJbTr[wZxSj6cizJ] = (287 - 286);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        xnYOMs3rhi[wZxSj6cizJ] = 0;
    }
    for (int ttiTpKI8FPu = 0;
    strlen (GOo4azEZ) >= ttiTpKI8FPu; ttiTpKI8FPu = ttiTpKI8FPu + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (!(GOo4azEZ[ttiTpKI8FPu + (217 - 216)] != GOo4azEZ[ttiTpKI8FPu]) || GOo4azEZ[ttiTpKI8FPu] == GOo4azEZ[ttiTpKI8FPu + (879 - 878)] + 32 || GOo4azEZ[ttiTpKI8FPu] == GOo4azEZ[ttiTpKI8FPu + 1] - 32)
            tas7SEJbTr[AMpchyjW]++;
        else {
            xnYOMs3rhi[AMpchyjW] = GOo4azEZ[ttiTpKI8FPu];
            AMpchyjW = AMpchyjW +1;
        };
    }
    for (int sLo7NVbEarcs = 0;
    sLo7NVbEarcs < strlen (xnYOMs3rhi); sLo7NVbEarcs++) {
        if (xnYOMs3rhi[sLo7NVbEarcs] > 95)
            xnYOMs3rhi[sLo7NVbEarcs] = xnYOMs3rhi[sLo7NVbEarcs] - 32;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        printf ("(%c,%d)", xnYOMs3rhi[sLo7NVbEarcs], tas7SEJbTr[sLo7NVbEarcs]);
    };
}

