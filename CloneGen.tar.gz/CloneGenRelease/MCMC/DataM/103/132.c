int main () {
    int i;
    int j;
    int LguHkEnZm;
    int hDkc0TGWV;
    int l;
    char s [1050];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    char i9bJ3uakqjEB;
    scanf ("%s", s);
    l = strlen (s);
    hDkc0TGWV = (218 - 218);
    for (i = 0; l > i; i = i + 1)
        if (!(0 != hDkc0TGWV)) {
            hDkc0TGWV = 1;
            i9bJ3uakqjEB = s[i];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (i9bJ3uakqjEB >= 97)
                i9bJ3uakqjEB = i9bJ3uakqjEB - 32;
        }
        else if ((s[i] == i9bJ3uakqjEB) || (s[i] - 32 == i9bJ3uakqjEB))
            hDkc0TGWV++;
        else {
            printf ("(%c,%d)", i9bJ3uakqjEB, hDkc0TGWV);
            i9bJ3uakqjEB = s[i];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (i9bJ3uakqjEB >= 97)
                i9bJ3uakqjEB = i9bJ3uakqjEB - 32;
            hDkc0TGWV = 1;
        }
    printf ("(%c,%d)", i9bJ3uakqjEB, hDkc0TGWV);
}

