int main () {
    int jpEqLFw7;
    int DSEHAKqIm;
    char str [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    jpEqLFw7 = (446 - 445);
    scanf ("%s", str);
    {
        DSEHAKqIm = 43 - 42;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (DSEHAKqIm <= strlen (str)) {
            if (str[DSEHAKqIm] == str[DSEHAKqIm -(468 - 467)] || (str[DSEHAKqIm] - 'a') == (str[DSEHAKqIm -(152 - 151)] - 'A') || (str[DSEHAKqIm] - 'A') == (str[DSEHAKqIm -(994 - 993)] - 'a'))
                jpEqLFw7++;
            else {
                if (str[DSEHAKqIm -(884 - 883)] >= 'a')
                    printf ("(%c,%d)", str[DSEHAKqIm -(796 - 795)] - 32, jpEqLFw7);
                else
                    printf ("(%c,%d)", str[DSEHAKqIm -1], jpEqLFw7);
                jpEqLFw7 = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            DSEHAKqIm++;
        };
    };
}

