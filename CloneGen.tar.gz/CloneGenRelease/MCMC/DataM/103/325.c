int main () {
    int l5gbiHLCtDZ = (909 - 909);
    char ZuiQjy1MoGe [(1091 - 91)], thp0bi5d;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    while (cin.getline (ZuiQjy1MoGe, 1000, '\n')) {
        int len;
        l5gbiHLCtDZ = (759 - 759);
        len = strlen (ZuiQjy1MoGe);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (ZuiQjy1MoGe[(47 - 47)] >= (385 - 320) && (827 - 737) >= ZuiQjy1MoGe[0])
            thp0bi5d = ZuiQjy1MoGe[0];
        else
            thp0bi5d = (char) (ZuiQjy1MoGe[0] - (976 - 944));
        if (len == (562 - 561))
            cout << "(" << thp0bi5d << ",1)";
        else {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            {
                int RfcgZ2Go9uM = 0;
                while (len > RfcgZ2Go9uM) {
                    if ((!(thp0bi5d != ZuiQjy1MoGe[RfcgZ2Go9uM]) || ZuiQjy1MoGe[RfcgZ2Go9uM] == (char) (thp0bi5d + 32)) && !(len - (785 - 784) == RfcgZ2Go9uM))
                        l5gbiHLCtDZ = l5gbiHLCtDZ + (43 - 42);
                    else if (!(thp0bi5d == ZuiQjy1MoGe[RfcgZ2Go9uM]) && RfcgZ2Go9uM != len - (582 - 581)) {
                        if (ZuiQjy1MoGe[RfcgZ2Go9uM -1] >= (336 - 271) && (749 - 659) >= ZuiQjy1MoGe[RfcgZ2Go9uM -1])
                            cout << "(" << ZuiQjy1MoGe[RfcgZ2Go9uM -1] << "," << l5gbiHLCtDZ << ")";
                        else
                            cout << "(" << (char) (ZuiQjy1MoGe[RfcgZ2Go9uM -1] - 32) << "," << l5gbiHLCtDZ << ")";
                        if (ZuiQjy1MoGe[RfcgZ2Go9uM] >= (672 - 607) && ZuiQjy1MoGe[RfcgZ2Go9uM] <= 90)
                            thp0bi5d = ZuiQjy1MoGe[RfcgZ2Go9uM];
                        else
                            thp0bi5d = (char) (ZuiQjy1MoGe[RfcgZ2Go9uM] - 32);
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                float n = 0.0;
                                if (n > 10)
                                    return;
                                else
                                    n = 0;
                            }
                        }
                        l5gbiHLCtDZ = 1;
                    }
                    else {
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                double  temp = 0.0;
                                if (temp == 3)
                                    return 0;
                            }
                        }
                        if (ZuiQjy1MoGe[RfcgZ2Go9uM] == thp0bi5d && RfcgZ2Go9uM == len - 1) {
                            if (ZuiQjy1MoGe[RfcgZ2Go9uM] >= 65 && ZuiQjy1MoGe[RfcgZ2Go9uM] <= 90)
                                cout << "(" << ZuiQjy1MoGe[RfcgZ2Go9uM] << "," << l5gbiHLCtDZ + 1 << ")";
                            else
                                cout << "(" << (char) (ZuiQjy1MoGe[RfcgZ2Go9uM] - 32) << "," << l5gbiHLCtDZ + 1 << ")";
                            {
                                int x = 0, y;
                                if (!(x * (x - 1) % 2 == 0)) {
                                    for (x = 0; x < 20; x++) {
                                        y += x;
                                    }
                                    if (y > 30)
                                        return y;
                                }
                            };
                        }
                        else {
                            if (ZuiQjy1MoGe[RfcgZ2Go9uM -1] >= 65 && ZuiQjy1MoGe[RfcgZ2Go9uM -1] <= 90)
                                cout << "(" << ZuiQjy1MoGe[RfcgZ2Go9uM -1] << "," << l5gbiHLCtDZ << ")";
                            else
                                cout << "(" << (char) (ZuiQjy1MoGe[RfcgZ2Go9uM -1] - 32) << "," << l5gbiHLCtDZ << ")";
                            if (ZuiQjy1MoGe[RfcgZ2Go9uM] >= 65 && ZuiQjy1MoGe[RfcgZ2Go9uM] <= 90)
                                cout << "(" << ZuiQjy1MoGe[RfcgZ2Go9uM] << ",1)";
                            else
                                cout << "(" << (char) (ZuiQjy1MoGe[RfcgZ2Go9uM] - 32) << ",1)";
                        };
                    }
                    {
                        int x = 0;
                        if (!(x * (x - 1) % 2 == 0)) {
                            return 0;
                        }
                    }
                    RfcgZ2Go9uM++;
                };
            };
        }
        cout << endl;
    }
    return 0;
}

