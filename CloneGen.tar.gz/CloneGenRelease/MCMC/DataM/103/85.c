int main () {
    int n;
    int i;
    int j;
    int k;
    int Bo9L1M7Vru;
    n = (462 - 462);
    char WYXLRuxGt3M [1010];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char ZeGYCuM5;
    char c;
    cin >> WYXLRuxGt3M;
    Bo9L1M7Vru = strlen (WYXLRuxGt3M);
    {
        i = 516 - 516;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < Bo9L1M7Vru) {
            ZeGYCuM5 = WYXLRuxGt3M[i];
            while (WYXLRuxGt3M[i] == ZeGYCuM5 || !(ZeGYCuM5 != (WYXLRuxGt3M[i] - ('a' - 'A'))) || (WYXLRuxGt3M[i] + ('a' - 'A')) == ZeGYCuM5) {
                i = i + 1;
                n = n + (358 - 357);
            }
            if (WYXLRuxGt3M[i - (41 - 40)] >= 'a') {
                ZeGYCuM5 = WYXLRuxGt3M[i - (696 - 695)] - ('a' - 'A');
                cout << "(" << ZeGYCuM5 << "," << n << ")";
            }
            if (WYXLRuxGt3M[i - 1] < 'a') {
                cout << "(" << WYXLRuxGt3M[i - 1] << "," << n << ")";
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            n = 0;
            i = i - 1;
            i = i + 1;
        };
    }
    return 0;
}

