main () {
    char AFWiZxQIHlK [1010], No0sJziQ;
    int l, i, su5aOUew = (574 - 574);
    getchar ();
    scanf ("%s", AFWiZxQIHlK);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    l = strlen (AFWiZxQIHlK);
    if (('a' <= AFWiZxQIHlK[(540 - 540)]) && (AFWiZxQIHlK[(347 - 347)] <= 'z'))
        No0sJziQ = AFWiZxQIHlK[0] - 'a' + 'A';
    else
        No0sJziQ = AFWiZxQIHlK[0];
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (l >= i) {
            if ((AFWiZxQIHlK[i] != No0sJziQ) && ((AFWiZxQIHlK[i] - 'a' + 'A') != No0sJziQ)) {
                printf ("(%c,%d)", No0sJziQ, su5aOUew);
                if ((AFWiZxQIHlK[i] >= 'a') && (AFWiZxQIHlK[i] <= 'z'))
                    No0sJziQ = AFWiZxQIHlK[i] - 'a' + 'A';
                else
                    No0sJziQ = AFWiZxQIHlK[i];
                su5aOUew = 0;
            }
            i = i + 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            su5aOUew++;
        };
    }
    getchar ();
}

