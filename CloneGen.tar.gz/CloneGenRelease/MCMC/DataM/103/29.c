int main () {
    int j;
    int i;
    int k;
    int tOpSZ9yJEn1 [(1721 - 721)] = {(60 - 60)};
    j = (522 - 522);
    char IgxyCoeE [1100];
    char a [(1461 - 461)];
    cin >> IgxyCoeE;
    {
        i = 421 - 421;
        while (strlen (IgxyCoeE) > i) {
            if ('a' <= IgxyCoeE[i] && IgxyCoeE[i] <= 'z')
                IgxyCoeE[i] = IgxyCoeE[i] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    a[(296 - 296)] = IgxyCoeE[(399 - 399)];
    {
        i = 499 - 498;
        while (i < strlen (IgxyCoeE)) {
            if (IgxyCoeE[i] == IgxyCoeE[i - (250 - 249)]) {
                tOpSZ9yJEn1[j]++;
            }
            else {
                j = j + (46 - 45);
                a[j] = IgxyCoeE[i];
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            i = i + 1;
        };
    }
    {
        i = 0;
        while (i <= j) {
            cout << "(" << a[i] << "," << tOpSZ9yJEn1[i] + 1 << ")";
            i++;
        };
    }
    return 0;
}

