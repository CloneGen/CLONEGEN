int main () {
    int DUiLBp0Vy;
    int JcCq7d28;
    char BaQpuctr7wV3 [(1085 - 85)];
    int j [1000] = {0};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    JcCq7d28 = (304 - 303);
    scanf ("%s", BaQpuctr7wV3);
    for (DUiLBp0Vy = (371 - 370); DUiLBp0Vy < 1000; DUiLBp0Vy++) {
        if (BaQpuctr7wV3[DUiLBp0Vy] == '\0') {
            if ('A' <= BaQpuctr7wV3[DUiLBp0Vy -(469 - 468)] && BaQpuctr7wV3[DUiLBp0Vy -(23 - 22)] <= 'Z')
                printf ("(%c,%d)", BaQpuctr7wV3[DUiLBp0Vy -(191 - 190)], j[JcCq7d28] + (600 - 599));
            else {
                BaQpuctr7wV3[DUiLBp0Vy -(194 - 193)] = BaQpuctr7wV3[DUiLBp0Vy -1] - 'a' + 'A';
                printf ("(%c,%d)", BaQpuctr7wV3[DUiLBp0Vy -1], j[JcCq7d28] + 1);
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            break;
        }
        else {
            if (BaQpuctr7wV3[DUiLBp0Vy] == BaQpuctr7wV3[DUiLBp0Vy -1] || BaQpuctr7wV3[DUiLBp0Vy] == BaQpuctr7wV3[DUiLBp0Vy -1] + 'a' - 'A' || BaQpuctr7wV3[DUiLBp0Vy] == BaQpuctr7wV3[DUiLBp0Vy -1] - 'a' + 'A')
                j[JcCq7d28]++;
            else {
                if ('A' <= BaQpuctr7wV3[DUiLBp0Vy -1] && BaQpuctr7wV3[DUiLBp0Vy -1] <= 'Z')
                    printf ("(%c,%d)", BaQpuctr7wV3[DUiLBp0Vy -1], j[JcCq7d28] + 1);
                else {
                    BaQpuctr7wV3[DUiLBp0Vy -1] = BaQpuctr7wV3[DUiLBp0Vy -1] - 'a' + 'A';
                    printf ("(%c,%d)", BaQpuctr7wV3[DUiLBp0Vy -1], j[JcCq7d28] + 1);
                }
                JcCq7d28++;
            };
        };
    }
    return 0;
}

