int main () {
    int ans;
    int Ucu7r8nfKd;
    ans = (31 - 30);
    char Em2xI7Ek0F [1100] = {(373 - 373)};
    cin >> Em2xI7Ek0F;
    {
        Ucu7r8nfKd = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while ((int) strlen (Em2xI7Ek0F) > Ucu7r8nfKd) {
            if (('a' <= Em2xI7Ek0F[Ucu7r8nfKd]) && ('z' >= Em2xI7Ek0F[Ucu7r8nfKd]))
                Em2xI7Ek0F[Ucu7r8nfKd] = Em2xI7Ek0F[Ucu7r8nfKd] - 'a' + 'A';
            Ucu7r8nfKd = Ucu7r8nfKd +1;
        };
    }
    cout << '(' << Em2xI7Ek0F[0] << ',';
    {
        Ucu7r8nfKd = 1;
        while (Ucu7r8nfKd < (int) strlen (Em2xI7Ek0F)) {
            if (Em2xI7Ek0F[Ucu7r8nfKd] == Em2xI7Ek0F[Ucu7r8nfKd -1])
                ans++;
            else {
                cout << ans << ")(" << Em2xI7Ek0F[Ucu7r8nfKd] << ',';
                ans = 1;
            }
            Ucu7r8nfKd++;
        };
    }
    cout << ans << ')' << endl;
    return 0;
}

