int main () {
    char a [1001];
    int i;
    int j;
    gets (a);
    j = 1;
    i = 0;
    do {
        if ('Z' < a[i]) {
            a[i] = a[i] - ('a' - 'A');
        }
        i = i + 1;
    }
    while (!('\0' == a[i]));
    i = 0;
    do {
        if (a[i] == a[i + 1]) {
            j = j + 1;
        }
        else {
            printf ("(%c,%d)", a[i], j);
            j = 1;
        }
        i = i + 1;
    }
    while (i < 1001 && a[i] != '\0');
    return 0;
}

