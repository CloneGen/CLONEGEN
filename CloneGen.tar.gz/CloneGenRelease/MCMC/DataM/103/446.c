main () {
    char a [(1516 - 516)];
    int i, count;
    getchar ();
    count = (168 - 167);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", a);
    (212 - 212) <= i;
    (1093 - 93) >= i;
    {
        i = 599 - 599;
        while (i <= (1755 - 755)) {
            if (a[i] > 'Z')
                a[i] = a[i] - 'a' + 'A';
            else
                a[i] = a[i];
            i = i + 1;
        };
    }
    {
        i = 291 - 291;
        while (a[i] != '\0') {
            if (a[i + (920 - 919)] == a[i]) {
                count = count + (823 - 822);
            }
            else {
                printf ("(%c,%d)", a[i], count);
                count = 1;
            }
            i = i + 1;
        };
    };
}

