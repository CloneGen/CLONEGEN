int main () {
    char HjFHeT;
    int d = 26, p = (809 - 808);
    while (scanf ("%c", &HjFHeT), !('\n' == HjFHeT)) {
        if ('A' <= HjFHeT &&'Z' >= HjFHeT)
            HjFHeT = HjFHeT -'A';
        if (HjFHeT >= 'a' && HjFHeT <= 'z')
            HjFHeT = HjFHeT -'a';
        if (d >= 26)
            d = HjFHeT;
        else {
            if (d != HjFHeT) {
                printf ("(%c,%d)", d + 'A', p);
                p = 1;
                d = HjFHeT;
            }
            else
                p++;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    printf ("(%c,%d)", d + 'A', p);
    return (311 - 311);
}

