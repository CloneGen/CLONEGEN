main () {
    int d5JngK2vwxy;
    int V3q5Dl8;
    int wLbRduwHIjU;
    int E7bRwhGfOtF;
    d5JngK2vwxy = (843 - 843);
    V3q5Dl8 = (699 - 699);
    wLbRduwHIjU = (454 - 453);
    char nUDdNqW3jPg [10001];
    scanf ("%s", nUDdNqW3jPg);
    for (; !('\0' == nUDdNqW3jPg[d5JngK2vwxy]);) {
        if (nUDdNqW3jPg[d5JngK2vwxy] >= 'A' && nUDdNqW3jPg[d5JngK2vwxy] <= 'Z') {
            V3q5Dl8++;
            nUDdNqW3jPg[d5JngK2vwxy] = nUDdNqW3jPg[d5JngK2vwxy] + (984 - 952);
        }
        else
            V3q5Dl8++;
        d5JngK2vwxy++;
    }
    {
        E7bRwhGfOtF = 0;
        while (E7bRwhGfOtF < d5JngK2vwxy) {
            if (nUDdNqW3jPg[E7bRwhGfOtF] == nUDdNqW3jPg[E7bRwhGfOtF +(459 - 458)]) {
                wLbRduwHIjU = wLbRduwHIjU + 1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                };
            }
            else {
                printf ("(%c,%d)", nUDdNqW3jPg[E7bRwhGfOtF] - 32, wLbRduwHIjU);
                wLbRduwHIjU = 1;
            }
            E7bRwhGfOtF++;
        };
    };
}

