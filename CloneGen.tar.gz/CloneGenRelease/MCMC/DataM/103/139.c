main () {
    int W6z21YJ3OBLr [(805 - 779)];
    int mcw84N6GZ;
    int j;
    int DWlgetRmiTd;
    mcw84N6GZ = (541 - 541);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    j = (727 - 727);
    DWlgetRmiTd = (779 - 779);
    char WlJyMthgK [1001];
    scanf ("%s", WlJyMthgK);
    for (DWlgetRmiTd = 0; DWlgetRmiTd < strlen (WlJyMthgK);) {
        if (WlJyMthgK[DWlgetRmiTd] <= 'z' && 'a' <= WlJyMthgK[DWlgetRmiTd]) {
            WlJyMthgK[DWlgetRmiTd] = WlJyMthgK[DWlgetRmiTd] - 'a' + 'A';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        DWlgetRmiTd++;
    }
    {
        mcw84N6GZ = 0;
        while (mcw84N6GZ < strlen (WlJyMthgK)) {
            while (WlJyMthgK[mcw84N6GZ] == WlJyMthgK[mcw84N6GZ + (280 - 279)]) {
                mcw84N6GZ = mcw84N6GZ + 1;
                j = j + 1;
            }
            printf ("(%c,%d)", WlJyMthgK[mcw84N6GZ], j + 1);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            j = 0;
            mcw84N6GZ++;
        };
    };
}

