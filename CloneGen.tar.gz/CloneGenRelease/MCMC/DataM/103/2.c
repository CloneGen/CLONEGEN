main () {
    int j;
    j = (318 - 317);
    char k [2];
    char a [(1232 - 231)];
    int QPKDFJA;
    scanf ("%s", a);
    k[(25 - 24)] = '\0';
    for (QPKDFJA = (344 - 344); a[QPKDFJA] != '\0'; QPKDFJA++) {
        if (('a' <= a[QPKDFJA]) && (a[QPKDFJA] <= 'z'))
            a[QPKDFJA] = a[QPKDFJA] + 'A' - 'a';
        else
            continue;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    QPKDFJA = (679 - 679);
    while (a[QPKDFJA] != '\0') {
        if (a[QPKDFJA] == a[QPKDFJA +1]) {
            QPKDFJA = QPKDFJA +1;
            j = j + 1;
        }
        else {
            k[0] = a[QPKDFJA];
            printf ("(%s,%d)", k, j);
            j = 1;
            QPKDFJA++;
        };
    };
}

