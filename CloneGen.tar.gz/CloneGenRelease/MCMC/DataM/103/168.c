int main () {
    int vIhdHNsRkM;
    int fKZg5o9cl0M;
    vIhdHNsRkM = (144 - 144);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char str [(1463 - 462)];
    scanf ("%s", str);
    for (fKZg5o9cl0M = (423 - 423); str[fKZg5o9cl0M] != '\0'; fKZg5o9cl0M = fKZg5o9cl0M + 1) {
        if ((!(str[fKZg5o9cl0M + (763 - 762)] != str[fKZg5o9cl0M])) || (str[fKZg5o9cl0M] == str[fKZg5o9cl0M + (648 - 647)] - 'a' + 'A') || (str[fKZg5o9cl0M] == str[fKZg5o9cl0M + (83 - 82)] + 'a' - 'A'))
            vIhdHNsRkM++;
        else {
            if (str[fKZg5o9cl0M] >= 'Z')
                printf ("(%c,%d)", (str[fKZg5o9cl0M] - 'a' + 'A'), vIhdHNsRkM + (782 - 781));
            else
                printf ("(%c,%d)", str[fKZg5o9cl0M], vIhdHNsRkM + 1);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            vIhdHNsRkM = 0;
        };
    }
    return 0;
}

