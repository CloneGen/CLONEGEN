int main () {
    char JioGL9BK1hC [1000];
    int Zkl6BFN, yEf3HTpk, WhV8UEjYnk5;
    gets (JioGL9BK1hC);
    {
        Zkl6BFN = 997 - 997;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (JioGL9BK1hC[Zkl6BFN] != '\0') {
            if (JioGL9BK1hC[Zkl6BFN] >= 'a' && JioGL9BK1hC[Zkl6BFN] <= 'z')
                JioGL9BK1hC[Zkl6BFN] = JioGL9BK1hC[Zkl6BFN] - 'a' + 'A';
            Zkl6BFN++;
        };
    }
    for (Zkl6BFN = (38 - 38); JioGL9BK1hC[Zkl6BFN] != '\0'; Zkl6BFN++) {
        WhV8UEjYnk5 = 0;
        {
            yEf3HTpk = Zkl6BFN;
            while (JioGL9BK1hC[yEf3HTpk] == JioGL9BK1hC[Zkl6BFN]) {
                yEf3HTpk++;
                WhV8UEjYnk5++;
            };
        }
        Zkl6BFN = yEf3HTpk - (410 - 409);
        printf ("(%c,%d)", JioGL9BK1hC[Zkl6BFN], WhV8UEjYnk5);
    };
}

