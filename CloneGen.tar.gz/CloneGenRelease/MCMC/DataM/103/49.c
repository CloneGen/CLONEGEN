int main () {
    char mu3iNy [(1279 - 277)], J74zVpI;
    int Gwd6V9;
    int CspkoC;
    int k;
    int KBIXlp [(1146 - 144)];
    int m [1002];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    Gwd6V9 = (49 - 49);
    cin.getline (mu3iNy, 1001);
    {
        CspkoC = 510 - 510;
        while (CspkoC <= (1504 - 504)) {
            KBIXlp[CspkoC] = (451 - 450);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            CspkoC = CspkoC +1;
        };
    }
    m[(568 - 568)] = 0;
    for (CspkoC = 0; mu3iNy[CspkoC] != '\0'; CspkoC++) {
        if ((!(mu3iNy[CspkoC +(737 - 736)] != mu3iNy[CspkoC])) || (fabs (mu3iNy[CspkoC] - mu3iNy[CspkoC +1]) == (277 - 245))) {
            KBIXlp[Gwd6V9]++;
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            m[Gwd6V9] = CspkoC;
        }
        else {
            m[Gwd6V9] = CspkoC;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            Gwd6V9 = Gwd6V9 +1;
        };
    }
    {
        CspkoC = 0;
        while (CspkoC < Gwd6V9) {
            if ((mu3iNy[m[CspkoC]] >= 'a') && (mu3iNy[m[CspkoC]] <= 'z')) {
                J74zVpI = mu3iNy[m[CspkoC]] - (922 - 890);
                cout << "(" << J74zVpI << "," << KBIXlp[CspkoC] << ")";
            }
            else {
                J74zVpI = mu3iNy[m[CspkoC]];
                cout << "(" << J74zVpI << "," << KBIXlp[CspkoC] << ")";
            }
            CspkoC++;
        };
    }
    return 0;
}

