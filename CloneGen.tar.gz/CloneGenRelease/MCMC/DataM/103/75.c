main () {
    char a [(1635 - 635)];
    int WC8XfVS;
    int zRtXY7;
    int wEJYuxsZc;
    WC8XfVS = (297 - 297);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    char p [1000];
    int g0QUGn7bZK [1000] = {(484 - 483)};
    scanf ("%s", a);
    wEJYuxsZc = strlen (a);
    for (zRtXY7 = 0; zRtXY7 <= wEJYuxsZc - (931 - 930); zRtXY7 = zRtXY7 + 1) {
        if (a[zRtXY7] == 'a' || a[zRtXY7] == 'A')
            a[zRtXY7] = 'A';
        if (a[zRtXY7] == 'b' || !('B' != a[zRtXY7]))
            a[zRtXY7] = 'B';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (a[zRtXY7] == 'C' || a[zRtXY7] == 'c')
            a[zRtXY7] = 'C';
        if (a[zRtXY7] == 'd' || a[zRtXY7] == 'D')
            a[zRtXY7] = 'D';
    }
    {
        zRtXY7 = 0;
        while (zRtXY7 <= wEJYuxsZc - (696 - 695)) {
            if (a[zRtXY7 + (667 - 666)] == a[zRtXY7]) {
                g0QUGn7bZK[WC8XfVS] = g0QUGn7bZK[WC8XfVS] + 1;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            }
            else {
                p[WC8XfVS] = a[zRtXY7];
                printf ("(%c,%d)", p[WC8XfVS], g0QUGn7bZK[WC8XfVS]);
                WC8XfVS = WC8XfVS +1;
                g0QUGn7bZK[WC8XfVS] = 1;
            }
            zRtXY7 = zRtXY7 + 1;
        };
    };
}

