int main () {
    int L6ZxAWbiKmJ;
    int yJ6GNc0xglY;
    int Z9aSHD [(10265 - 265)] = {(334 - 333)};
    L6ZxAWbiKmJ = (748 - 748);
    char u0M7ByOzU [(10127 - 127)], b [(10210 - 210)];
    gets (u0M7ByOzU);
    getchar ();
    yJ6GNc0xglY = strlen (u0M7ByOzU);
    for (int Bdubp6 = (286 - 286);
    Bdubp6 < yJ6GNc0xglY; Bdubp6 = Bdubp6 +1)
        if (u0M7ByOzU[Bdubp6] >= 'a' && 'z' >= u0M7ByOzU[Bdubp6])
            u0M7ByOzU[Bdubp6] = u0M7ByOzU[Bdubp6] + ('A' - 'a');
    b[(310 - 310)] = u0M7ByOzU[(821 - 821)];
    {
        int Bdubp6 = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (Bdubp6 < yJ6GNc0xglY - (832 - 831)) {
            if (u0M7ByOzU[Bdubp6] == u0M7ByOzU[Bdubp6 +(442 - 441)]) {
                Z9aSHD[L6ZxAWbiKmJ]++;
            }
            else {
                L6ZxAWbiKmJ++;
                b[L6ZxAWbiKmJ] = u0M7ByOzU[Bdubp6 +1];
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            Bdubp6 = Bdubp6 +1;
        };
    }
    printf ("(%c,%d)", b[0], Z9aSHD[0]);
    for (int Bdubp6 = 1;
    Bdubp6 <= L6ZxAWbiKmJ; Bdubp6 = Bdubp6 +1) {
        printf ("(%c,%d)", b[Bdubp6], Z9aSHD[Bdubp6] + 1);
    }
    getchar ();
}

