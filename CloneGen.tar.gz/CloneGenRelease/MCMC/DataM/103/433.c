main () {
    char c [1001];
    int s1ShG6rJ;
    s1ShG6rJ = (53 - 52);
    int lDPBGHT;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int Hd0J4Y;
    int k;
    int N2fEpI;
    scanf ("%s", c);
    for (lDPBGHT = (979 - 978); 1000 >= lDPBGHT; lDPBGHT = lDPBGHT + 1) {
        if (65 <= c[lDPBGHT] && 97 > c[lDPBGHT]) {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (!(c[lDPBGHT - (948 - 947)] == c[lDPBGHT]) && (c[lDPBGHT] != c[lDPBGHT - 1] - 32)) {
                if (c[lDPBGHT - 1] < 97)
                    printf ("(%c,%d)", c[lDPBGHT - 1], s1ShG6rJ);
                else
                    printf ("(%c,%d)", c[lDPBGHT - 1] - 32, s1ShG6rJ);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                }
                s1ShG6rJ = 1;
            }
            else {
                s1ShG6rJ = s1ShG6rJ + 1;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                };
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (97 <= c[lDPBGHT] && c[lDPBGHT] <= 122) {
            if (c[lDPBGHT] != c[lDPBGHT - 1] && c[lDPBGHT] != (c[lDPBGHT - 1] + 32)) {
                if (c[lDPBGHT - 1] < 97)
                    printf ("(%c,%d)", c[lDPBGHT - 1], s1ShG6rJ);
                else
                    printf ("(%c,%d)", c[lDPBGHT - 1] - 32, s1ShG6rJ);
                s1ShG6rJ = 1;
            }
            else {
                s1ShG6rJ = s1ShG6rJ + 1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                };
            };
        }
        if (c[lDPBGHT] == '\0') {
            if (c[lDPBGHT - 1] < 97)
                printf ("(%c,%d)", c[lDPBGHT - 1], s1ShG6rJ);
            else
                printf ("(%c,%d)", c[lDPBGHT - 1] - 32, s1ShG6rJ);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            break;
        };
    };
}

