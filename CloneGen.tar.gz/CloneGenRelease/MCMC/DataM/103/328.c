int main () {
    char FqzpA3xi [1005];
    gets (FqzpA3xi);
    char Wmegu3P = FqzpA3xi[0];
    int SPwZ9JKSAghl, v9jpEdorm;
    int j8Lv1AGCNkz = (19 - 18);
    SPwZ9JKSAghl = strlen (FqzpA3xi);
    if (FqzpA3xi[(473 - 473)] >= 'a' && FqzpA3xi[(671 - 671)] <= 'z')
        FqzpA3xi[(721 - 721)] = FqzpA3xi[(465 - 465)] - 'a' + 'A';
    {
        v9jpEdorm = 1;
        while (v9jpEdorm <= SPwZ9JKSAghl) {
            if (FqzpA3xi[v9jpEdorm] >= 'a' && FqzpA3xi[v9jpEdorm] <= 'z')
                FqzpA3xi[v9jpEdorm] = FqzpA3xi[v9jpEdorm] - 'a' + 'A';
            if (FqzpA3xi[v9jpEdorm] != Wmegu3P) {
                printf ("(%c,%d)", Wmegu3P, j8Lv1AGCNkz);
                Wmegu3P = FqzpA3xi[v9jpEdorm];
                j8Lv1AGCNkz = 1;
            }
            else
                j8Lv1AGCNkz = j8Lv1AGCNkz + 1;
            v9jpEdorm++;
        };
    }
    return 0;
}

