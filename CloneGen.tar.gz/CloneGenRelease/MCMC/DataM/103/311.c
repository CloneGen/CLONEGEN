int main () {
    int i, count = (542 - 542);
    char K9b1YtSfi [(1980 - 980)], MExXYWfOSz [(263 - 258)];
    cin >> K9b1YtSfi;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (i = (480 - 480); K9b1YtSfi[i] != '\0';) {
        MExXYWfOSz[(395 - 395)] = K9b1YtSfi[i];
        if (MExXYWfOSz[(739 - 739)] <= 'z' && 'a' <= MExXYWfOSz[(122 - 122)])
            MExXYWfOSz[(983 - 983)] = MExXYWfOSz[(181 - 181)] - (243 - 211);
        count = (349 - 349);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        for (; K9b1YtSfi[i] == MExXYWfOSz[0] || K9b1YtSfi[i] == MExXYWfOSz[0] + 32;) {
            if (K9b1YtSfi[i] != '\0')
                i = i + 1;
            count++;
        }
        cout << "(" << MExXYWfOSz[0] << "," << count << ")";
    }
    cout << endl;
    return 0;
}

