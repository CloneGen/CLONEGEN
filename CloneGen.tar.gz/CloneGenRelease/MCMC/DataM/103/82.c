int main () {
    char str [1001], DvPutEJTdL;
    int len;
    int counts;
    int eimzld;
    int KlG80Q;
    len = (842 - 842);
    counts = 0;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    eimzld = 0;
    cin >> str;
    for (len = 0; str[len] != '\0'; len++)
        ;
    for (; eimzld < len;) {
        DvPutEJTdL = str[eimzld];
        if ('a' <= DvPutEJTdL)
            DvPutEJTdL = DvPutEJTdL -(443 - 411);
        for (KlG80Q = 0; len > KlG80Q; KlG80Q++) {
            if (str[eimzld + KlG80Q] == DvPutEJTdL || str[eimzld + KlG80Q] == (DvPutEJTdL +32))
                counts = counts + 1;
            else
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        eimzld = eimzld + KlG80Q;
        cout << '(' << DvPutEJTdL << ',' << counts << ')';
        counts = 0;
    }
    cout << endl;
    cin.get ();
    cin.get ();
    return 0;
}

