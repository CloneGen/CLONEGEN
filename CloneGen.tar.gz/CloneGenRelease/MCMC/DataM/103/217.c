int main () {
    char YSM4s60 [100];
    gets (YSM4s60);
    int Dmej7KtLxc;
    int n;
    int j;
    int i;
    Dmej7KtLxc = (207 - 206);
    n = strlen (YSM4s60);
    for (i = (669 - 669); i < n; i++) {
        if ('A' <= YSM4s60[i] && YSM4s60[i] <= 'Z') {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (YSM4s60[i + (344 - 343)] == YSM4s60[i] || !(YSM4s60[i] + 32 != YSM4s60[i + 1])) {
                Dmej7KtLxc = Dmej7KtLxc +1;
                continue;
            }
            else {
                printf ("(%c,%d)", YSM4s60[i], Dmej7KtLxc);
                Dmej7KtLxc = 1;
                continue;
            };
        }
        else {
            if (YSM4s60[i] >= 'a' && YSM4s60[i] <= 'z') {
                if (YSM4s60[i + 1] == YSM4s60[i] || YSM4s60[i + 1] == YSM4s60[i] - 32) {
                    Dmej7KtLxc++;
                    {
                        int x = 0, y;
                        if (!(x * (x - 1) % 2 == 0)) {
                            for (x = 0; x < 20; x++) {
                                y += x;
                            }
                            if (y > 30)
                                return y;
                        }
                    }
                    continue;
                }
                else {
                    printf ("(%c,%d)", YSM4s60[i] - 32, Dmej7KtLxc);
                    Dmej7KtLxc = 1;
                    continue;
                };
            };
        };
    }
    return (538 - 538);
}

