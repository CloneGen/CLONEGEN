int main () {
    int b [1000] = {0}, j, RDlYxmyWBc6Q = 0, m;
    int VxdyYzwFnIu, n = 0;
    char a [1000];
    scanf ("%s", a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (VxdyYzwFnIu = 0; VxdyYzwFnIu < 1000; VxdyYzwFnIu++) {
        if (a[VxdyYzwFnIu] != 0)
            n++;
        else
            break;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (j = 0; n > j; j++) {
        if (a[j + 1] == a[j] || a[j + 1] == a[j] - 'a' + 'A' || a[j] == a[j + 1] - 'a' + 'A')
            b[RDlYxmyWBc6Q]++;
        else {
            b[RDlYxmyWBc6Q] = b[RDlYxmyWBc6Q] + 1;
            if (a[RDlYxmyWBc6Q] >= 'a' && a[RDlYxmyWBc6Q] <= 'z')
                m = a[RDlYxmyWBc6Q] - 'a' + 'A';
            else
                m = a[RDlYxmyWBc6Q];
            printf ("(%c,%d)", m, b[RDlYxmyWBc6Q]);
            RDlYxmyWBc6Q = j + 1;
        };
    }
    return 0;
}

