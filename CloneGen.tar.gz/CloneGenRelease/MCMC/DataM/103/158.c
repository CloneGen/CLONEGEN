int main () {
    char fVhxlMn [(1749 - 749)];
    char b;
    gets (fVhxlMn);
    int d3K4GkuZP;
    int wO5adjtkqr;
    int TvQAF7JE2T;
    int i;
    TvQAF7JE2T = strlen (fVhxlMn);
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (TvQAF7JE2T > i) {
            if (fVhxlMn[i] >= 'a' && 'z' >= fVhxlMn[i])
                fVhxlMn[i] = fVhxlMn[i] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    for (i = 0; i < TvQAF7JE2T; i = i + 1) {
        wO5adjtkqr = (869 - 868);
        b = fVhxlMn[i];
    loop :
        if (fVhxlMn[i] == fVhxlMn[i + 1]) {
            goto loop;
            i++;
            wO5adjtkqr = wO5adjtkqr + 1;
        }
        else
            printf ("(%c,%d)", b, wO5adjtkqr);
    }
    getchar ();
    getchar ();
}

