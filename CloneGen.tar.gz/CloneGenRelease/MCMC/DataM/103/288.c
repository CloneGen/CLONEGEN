int main () {
    int len, PR9jDeghipVF, sum = (61 - 60);
    char a [(1327 - 327)] = {(377 - 377)};
    cin >> a;
    len = strlen (a);
    {
        PR9jDeghipVF = 0;
        while (PR9jDeghipVF < len) {
            if (a[PR9jDeghipVF] >= 'a' && 'z' >= a[PR9jDeghipVF])
                a[PR9jDeghipVF] = a[PR9jDeghipVF] + ('A' - 'a');
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            PR9jDeghipVF++;
        };
    }
    for (PR9jDeghipVF = (378 - 377); PR9jDeghipVF <= len; PR9jDeghipVF = PR9jDeghipVF +1) {
        if (a[PR9jDeghipVF] == a[PR9jDeghipVF -(329 - 328)])
            sum = sum + 1;
        else {
            cout << "(" << a[PR9jDeghipVF -1] << "," << sum << ")";
            sum = 1;
        };
    }
    return 0;
}

