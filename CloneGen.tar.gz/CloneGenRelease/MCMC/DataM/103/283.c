struct   letter {
    char E25cQGlsd;
    int res;
}
number [(1363 - 363)];

int main () {
    char Qa0Fhn [1100] = {(363 - 363)};
    int z3vTyWLIxN = 0;
    {
        int m1q0CK = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while ((1999 - 999) > m1q0CK) {
            number[m1q0CK].res = 0;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            m1q0CK = m1q0CK + 1;
        };
    }
    cin >> Qa0Fhn;
    {
        int m1q0CK = 0;
        while (m1q0CK < strlen (Qa0Fhn)) {
            if ('z' >= Qa0Fhn[m1q0CK] && 'a' <= Qa0Fhn[m1q0CK]) {
                Qa0Fhn[m1q0CK] = Qa0Fhn[m1q0CK] + 'A' - 'a';
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            m1q0CK = m1q0CK + 1;
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (int m1q0CK = 0;
    strlen (Qa0Fhn) - (226 - 225) > m1q0CK; m1q0CK = m1q0CK + 1) {
        number[z3vTyWLIxN].E25cQGlsd = Qa0Fhn[m1q0CK];
        number[z3vTyWLIxN].res++;
        if (Qa0Fhn[m1q0CK] != Qa0Fhn[m1q0CK + (728 - 727)])
            z3vTyWLIxN = z3vTyWLIxN + 1;
    }
    number[z3vTyWLIxN].E25cQGlsd = Qa0Fhn[strlen (Qa0Fhn) - (968 - 967)];
    number[z3vTyWLIxN].res++;
    {
        int m1q0CK = 0;
        while (m1q0CK < z3vTyWLIxN + 1) {
            cout << "(" << number[m1q0CK].E25cQGlsd << "," << number[m1q0CK].res << ")";
            m1q0CK++;
        };
    }
    return 0;
}

