main () {
    char kwDXSzE;
    char QuZ3U0s4PQ [1001];
    int CELm38O7 (int x);
    int osJ82epvBbD;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int zKMNOCI;
    scanf ("%s", QuZ3U0s4PQ);
    {
        osJ82epvBbD = 633 - 633;
        while (!('\0' == (kwDXSzE = QuZ3U0s4PQ[osJ82epvBbD]))) {
            QuZ3U0s4PQ[osJ82epvBbD] = CELm38O7 (QuZ3U0s4PQ[osJ82epvBbD]);
            osJ82epvBbD = osJ82epvBbD + 1;
        };
    }
    zKMNOCI = 1;
    {
        osJ82epvBbD = 0;
        while ((kwDXSzE = QuZ3U0s4PQ[osJ82epvBbD]) != '\0') {
            if (QuZ3U0s4PQ[osJ82epvBbD + 1] == QuZ3U0s4PQ[osJ82epvBbD])
                zKMNOCI = zKMNOCI + 1;
            else {
                printf ("(%c,%d)", QuZ3U0s4PQ[osJ82epvBbD], zKMNOCI);
                zKMNOCI = 1;
            }
            osJ82epvBbD++;
        };
    };
}

int CELm38O7 (int x) {
    if (x >= 'a' && x <= 'z')
        x = x - 'a' + 'A';
    return (x);
}

