main () {
    char Jln2zXGCYS [(1565 - 566)];
    char QLvBXA2mfJ [(1256 - 257)];
    int BvKjXe;
    int b;
    int bTrcNkFu;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int B9uZ4cH;
    scanf ("%s", Jln2zXGCYS);
    BvKjXe = strlen (Jln2zXGCYS);
    {
        B9uZ4cH = 992 - 992;
        while (B9uZ4cH <= BvKjXe -(304 - 303)) {
            if (Jln2zXGCYS[B9uZ4cH] >= 'a' && Jln2zXGCYS[B9uZ4cH] <= 'z')
                QLvBXA2mfJ[B9uZ4cH] = Jln2zXGCYS[B9uZ4cH] - 'a' + 'A';
            else
                QLvBXA2mfJ[B9uZ4cH] = Jln2zXGCYS[B9uZ4cH];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            B9uZ4cH++;
        };
    }
    bTrcNkFu = (785 - 784);
    {
        b = 310 - 310;
        while (b <= BvKjXe -(269 - 268)) {
            if (QLvBXA2mfJ[b] == QLvBXA2mfJ[b + (282 - 281)])
                bTrcNkFu++;
            else {
                printf ("(%c,%d)", QLvBXA2mfJ[b], bTrcNkFu);
                bTrcNkFu = 1;
            }
            b = b + 1;
        };
    };
}

