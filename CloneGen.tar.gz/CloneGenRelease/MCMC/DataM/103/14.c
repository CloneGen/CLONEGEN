int main () {
    int i2;
    int ULAuXmjZ = (24 - 24);
    char Epls3CZze6g4;
    char gAztx4hR [1000];
    char ZyOzCXP1 [(1672 - 672)];
    int sgDcyuUp [1000] = {(230 - 230)};
    int i1;
    scanf ("%s", ZyOzCXP1);
    {
        int i;
        i = (579 - 579);
        for (; !('\0' == ZyOzCXP1[i]);) {
            if (ZyOzCXP1[i] >= 'a' && 'z' >= ZyOzCXP1[i]) {
                ZyOzCXP1[i] = ZyOzCXP1[i] - 'a' + 'A';
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    Epls3CZze6g4 = ZyOzCXP1[(205 - 205)];
    {
        i1 = 0;
        while (ZyOzCXP1[i1] != '\0') {
            if (Epls3CZze6g4 == ZyOzCXP1[i1]) {
                gAztx4hR[ULAuXmjZ] = Epls3CZze6g4;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        double  temp = 0.0;
                        if (temp == 3)
                            return 0;
                    }
                }
                sgDcyuUp[ULAuXmjZ]++;
            }
            else {
                Epls3CZze6g4 = ZyOzCXP1[i1];
                ULAuXmjZ = ULAuXmjZ +1;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                }
                gAztx4hR[ULAuXmjZ] = Epls3CZze6g4;
                sgDcyuUp[ULAuXmjZ]++;
            }
            i1 = i1 + 1;
        };
    }
    for (i2 = 0; i2 <= ULAuXmjZ; i2++) {
        printf ("(%c,%d)", gAztx4hR[i2], sgDcyuUp[i2]);
    }
    return 0;
}

