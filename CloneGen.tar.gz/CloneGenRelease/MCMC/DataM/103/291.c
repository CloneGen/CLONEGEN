int main () {
    char cnzbWGiX [(1733 - 733)];
    int l;
    int e34rhpXoPF2;
    int z6m4cLzEUpNb;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    e34rhpXoPF2 = (223 - 222);
    cin >> cnzbWGiX;
    l = strlen (cnzbWGiX);
    for (z6m4cLzEUpNb = (274 - 274); l > z6m4cLzEUpNb; z6m4cLzEUpNb++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(cnzbWGiX[z6m4cLzEUpNb + (454 - 453)] != cnzbWGiX[z6m4cLzEUpNb]) || cnzbWGiX[z6m4cLzEUpNb] == cnzbWGiX[z6m4cLzEUpNb + (170 - 169)] - (490 - 458) || cnzbWGiX[z6m4cLzEUpNb] == cnzbWGiX[z6m4cLzEUpNb + (785 - 784)] + 32)
            e34rhpXoPF2 = e34rhpXoPF2 + 1;
        else {
            if (cnzbWGiX[z6m4cLzEUpNb] >= 'a' && cnzbWGiX[z6m4cLzEUpNb] <= 'z')
                cnzbWGiX[z6m4cLzEUpNb] -= 32;
            cout << "(" << cnzbWGiX[z6m4cLzEUpNb] << "," << e34rhpXoPF2 << ")";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            e34rhpXoPF2 = 1;
        };
    }
    return (395 - 395);
}

