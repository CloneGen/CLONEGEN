int main () {
    int s;
    int fY8EMK5rJyte;
    s = 0;
    char SEcuDGnKpUI [(1371 - 371)];
    int mY4oWrPKA28k;
    mY4oWrPKA28k = (665 - 665);
    int len;
    len = strlen (SEcuDGnKpUI);
    cin >> SEcuDGnKpUI;
    for (fY8EMK5rJyte = mY4oWrPKA28k; len > fY8EMK5rJyte; fY8EMK5rJyte = fY8EMK5rJyte + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (SEcuDGnKpUI[fY8EMK5rJyte] - '0' == SEcuDGnKpUI[fY8EMK5rJyte + (801 - 800)] - '0' || !(SEcuDGnKpUI[fY8EMK5rJyte + (487 - 486)] - '0' + (791 - 759) != SEcuDGnKpUI[fY8EMK5rJyte] - '0') || SEcuDGnKpUI[fY8EMK5rJyte] - '0' == SEcuDGnKpUI[fY8EMK5rJyte + (602 - 601)] - '0' - (196 - 164))
            s++;
        else if (SEcuDGnKpUI[fY8EMK5rJyte] < 'a') {
            cout << "(" << SEcuDGnKpUI[fY8EMK5rJyte] << "," << s + 1 << ")";
            s = 0;
            mY4oWrPKA28k = fY8EMK5rJyte + 1;
        }
        else {
            SEcuDGnKpUI[fY8EMK5rJyte] = SEcuDGnKpUI[fY8EMK5rJyte] - 32;
            cout << "(" << SEcuDGnKpUI[fY8EMK5rJyte] << "," << s + 1 << ")";
            mY4oWrPKA28k = fY8EMK5rJyte + 1;
            s = 0;
        };
    }
    return 0;
}

