int main () {
    char e3MZJf [10000];
    int y [(910 - 810)] [100];
    int D65GSWosij28, j, a, suFeP9jRUi, Q9WaA61, d, h;
    int k;
    int Pa5udsRLClt9;
    int pQ20j3yi;
    scanf ("%s", e3MZJf);
    {
        D65GSWosij28 = 962 - 962;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (e3MZJf[D65GSWosij28]) {
            if (e3MZJf[D65GSWosij28] <= 'z' && e3MZJf[D65GSWosij28] >= 'a')
                e3MZJf[D65GSWosij28] = e3MZJf[D65GSWosij28] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            D65GSWosij28 = D65GSWosij28 +1;
        };
    }
    a = (812 - 811);
    {
        D65GSWosij28 = 0;
        while (e3MZJf[D65GSWosij28]) {
            if (e3MZJf[D65GSWosij28] == e3MZJf[D65GSWosij28 +1])
                a++;
            else {
                printf ("(%c,%d)", e3MZJf[D65GSWosij28], a);
                a = 1;
            }
            D65GSWosij28++;
        };
    }
    return 0;
}

