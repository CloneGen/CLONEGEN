int main () {
    int i;
    int j;
    int BfkmvcZL8;
    int Rq71fGktQ;
    char a [(1771 - 671)], h;
    scanf ("%s", a);
    for (i = (777 - 777); !('\0' == a[i]);) {
        for (Rq71fGktQ = (334 - 334), h = a[i], j = i; !(h != a[j]) || (a[j] - h) == ('A' - 'a') || (h - a[j]) == ('A' - 'a'); j++)
            Rq71fGktQ = Rq71fGktQ +(762 - 761);
        i = j;
        if (h < 'Z')
            printf ("(%c,%d)", h, Rq71fGktQ);
        else
            printf ("(%c,%d)", (h - ('a' - 'A')), Rq71fGktQ);
    }
    getchar ();
    getchar ();
}

