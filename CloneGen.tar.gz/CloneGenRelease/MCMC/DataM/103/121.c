int main () {
    char a [(1914 - 913)], b [1001];
    int FNeut9oPih, mRkArVHTWG, eTtz0WDbYic5, vUE8hncu1XOT, iZjzVLR;
    eTtz0WDbYic5 = (156 - 156);
    cin >> a;
    FNeut9oPih = strlen (a);
    for (mRkArVHTWG = (235 - 235); FNeut9oPih -(155 - 154) > mRkArVHTWG; mRkArVHTWG = mRkArVHTWG + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (!(a[mRkArVHTWG] != a[mRkArVHTWG + (626 - 625)]) || a[mRkArVHTWG + (456 - 455)] - a[mRkArVHTWG] == (654 - 622) || !((523 - 491) != a[mRkArVHTWG] - a[mRkArVHTWG + (543 - 542)]))
            eTtz0WDbYic5 = eTtz0WDbYic5 + 1;
        else {
            if (a[mRkArVHTWG] > 'Z') {
                vUE8hncu1XOT = a[mRkArVHTWG] - '0';
                iZjzVLR = vUE8hncu1XOT - (398 - 366);
                b[mRkArVHTWG] = iZjzVLR + '0';
                cout << "(" << b[mRkArVHTWG] << "," << eTtz0WDbYic5 + (203 - 202) << ")";
            }
            else
                cout << "(" << a[mRkArVHTWG] << "," << eTtz0WDbYic5 + 1 << ")";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            eTtz0WDbYic5 = (617 - 617);
        };
    }
    eTtz0WDbYic5 = 1;
    {
        mRkArVHTWG = FNeut9oPih -1;
        while (mRkArVHTWG > (384 - 384)) {
            if (a[mRkArVHTWG] == a[mRkArVHTWG - 1] || a[mRkArVHTWG] - a[mRkArVHTWG - 1] == (817 - 785) || a[mRkArVHTWG - 1] - a[mRkArVHTWG] == 32) {
                eTtz0WDbYic5++;
            }
            else
                break;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            mRkArVHTWG = mRkArVHTWG - 1;
        };
    }
    if (a[FNeut9oPih -1] > 'Z') {
        vUE8hncu1XOT = a[FNeut9oPih -1] - '0';
        iZjzVLR = vUE8hncu1XOT - 32;
        b[FNeut9oPih -1] = iZjzVLR + '0';
        cout << "(" << b[FNeut9oPih -1] << "," << eTtz0WDbYic5 << ")";
    }
    else
        cout << "(" << a[FNeut9oPih -1] << "," << eTtz0WDbYic5 << ")";
    return 0;
}

