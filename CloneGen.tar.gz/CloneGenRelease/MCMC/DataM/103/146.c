int main (void ) {
    int i = (728 - 728), a4bJDirAB = (850 - 849);
    char jbudHs0l [(1442 - 441)];
    scanf ("%s", jbudHs0l);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (i = (296 - 296); jbudHs0l[i] != '\0'; i = i + 1) {
        if (('a' <= jbudHs0l[i]) && (jbudHs0l[i] <= 'z'))
            jbudHs0l[i] = jbudHs0l[i] - 'a' + 'A';
    }
    for (i = (362 - 361); jbudHs0l[i] != '\0'; i++) {
        if (jbudHs0l[i] == jbudHs0l[i - (498 - 497)])
            a4bJDirAB = a4bJDirAB + 1;
        else {
            printf ("(%c,%d)", jbudHs0l[i - (14 - 13)], a4bJDirAB);
            a4bJDirAB = 1;
        };
    }
    printf ("(%c,%d)", jbudHs0l[i - 1], a4bJDirAB);
    return 0;
}

