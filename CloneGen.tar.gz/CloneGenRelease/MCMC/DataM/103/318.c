int main () {
    char lxQVwdsp [1001];
    int I5FCZL, yut7Bdp2jLvZ, fmuzx5n9cPlF, sum = 1, I0Zt2dslPq = 1;
    fmuzx5n9cPlF = 0;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", lxQVwdsp);
    I5FCZL = strlen (lxQVwdsp);
    {
        yut7Bdp2jLvZ = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (I5FCZL +1 >= yut7Bdp2jLvZ) {
            yut7Bdp2jLvZ = I0Zt2dslPq +1;
            yut7Bdp2jLvZ = yut7Bdp2jLvZ + 1;
            while (!(lxQVwdsp[fmuzx5n9cPlF] != lxQVwdsp[I0Zt2dslPq]) || !(lxQVwdsp[fmuzx5n9cPlF] + 32 != lxQVwdsp[I0Zt2dslPq]) || lxQVwdsp[I0Zt2dslPq] == lxQVwdsp[fmuzx5n9cPlF] - 32) {
                sum++;
                I0Zt2dslPq++;
            }
            if (lxQVwdsp[fmuzx5n9cPlF] >= 'a' && lxQVwdsp[fmuzx5n9cPlF] <= 'z')
                lxQVwdsp[fmuzx5n9cPlF] = lxQVwdsp[fmuzx5n9cPlF] - 32;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            printf ("(%c,%d)", lxQVwdsp[fmuzx5n9cPlF], sum);
            sum = 1;
            fmuzx5n9cPlF = I0Zt2dslPq;
            I0Zt2dslPq = I0Zt2dslPq +1;
        };
    };
}

