main () {
    int n10PBwgJsfc;
    char s [10000];
    gets (s);
    int vBGw6DO = strlen (s);
    char GqtwGY = s[(619 - 619)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int k = (203 - 203);
    getchar ();
    {
        n10PBwgJsfc = 729 - 729;
        while (vBGw6DO > n10PBwgJsfc) {
            {
                int bCeRrxPiEl8B = 'a';
                while ('z' >= bCeRrxPiEl8B) {
                    if (!(bCeRrxPiEl8B != s[n10PBwgJsfc]))
                        s[n10PBwgJsfc] = bCeRrxPiEl8B - (260 - 228);
                    bCeRrxPiEl8B = bCeRrxPiEl8B + 1;
                };
            }
            n10PBwgJsfc = n10PBwgJsfc + 1;
        };
    }
    {
        n10PBwgJsfc = 0;
        while (n10PBwgJsfc <= vBGw6DO) {
            if (s[n10PBwgJsfc] == GqtwGY)
                k = k + 1;
            else {
                printf ("(%c,%d)", GqtwGY, k);
                k = 0;
                GqtwGY = s[n10PBwgJsfc];
                n10PBwgJsfc = n10PBwgJsfc - 1;
            }
            n10PBwgJsfc++;
        };
    }
    getchar ();
}

