int main () {
    int qTq7HFAwBx [1000];
    char a [1000] = {(171 - 171)};
    char b [1000] = {(31 - 31)};
    int len = strlen (a);
    int zLE9ZiY = (958 - 958), j = (409 - 409), k = (825 - 825);
    memset (b, (331 - 331), sizeof (b));
    cin >> a;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (zLE9ZiY = (746 - 746); len > zLE9ZiY; zLE9ZiY = zLE9ZiY + 1)
        if ('a' <= a[zLE9ZiY] && 'z' >= a[zLE9ZiY])
            a[zLE9ZiY] = a[zLE9ZiY] - ('a' - 'A');
    zLE9ZiY = 0;
    b[(420 - 420)] = a[0];
    for (; len > zLE9ZiY;) {
        for (j = zLE9ZiY + (459 - 458); len > j; j++) {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (!(a[zLE9ZiY] == a[j])) {
                k = k + 1;
                b[k] = a[j];
                break;
            };
        }
        zLE9ZiY = j;
    }
    memset (qTq7HFAwBx, 0, sizeof (qTq7HFAwBx));
    {
        k = 0;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        zLE9ZiY = 0;
        while (zLE9ZiY < len && len > k) {
            j = zLE9ZiY;
            zLE9ZiY = zLE9ZiY + 1;
            for (; j < len; j++) {
                if (b[k] != a[j])
                    k++;
                if (b[k] == a[j])
                    qTq7HFAwBx[k]++;
            }
            k++;
        };
    }
    {
        zLE9ZiY = 0;
        while (zLE9ZiY < len) {
            if (b[zLE9ZiY] == 0)
                break;
            cout << "(" << b[zLE9ZiY] << ',' << qTq7HFAwBx[zLE9ZiY] << ")";
            zLE9ZiY = zLE9ZiY + 1;
        };
    }
    cout << endl;
    return 0;
}

