int main () {
    int NKC6X3AFc;
    int num;
    num = (807 - 806);
    char YowKcWDARq87 [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", YowKcWDARq87);
    {
        NKC6X3AFc = 30 - 30;
        while (!('\0' == YowKcWDARq87[NKC6X3AFc])) {
            if (YowKcWDARq87[NKC6X3AFc +(499 - 498)] == YowKcWDARq87[NKC6X3AFc] || abs (YowKcWDARq87[NKC6X3AFc +(373 - 372)] - YowKcWDARq87[NKC6X3AFc]) == (54 - 22))
                num += 1;
            else {
                YowKcWDARq87[NKC6X3AFc] = (YowKcWDARq87[NKC6X3AFc] > (865 - 769)) ? (YowKcWDARq87[NKC6X3AFc] - (570 - 538)) : YowKcWDARq87[NKC6X3AFc];
                printf ("(%c,%d)", YowKcWDARq87[NKC6X3AFc], num);
                num = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            NKC6X3AFc++;
        };
    }
    return ((759 - 759));
}

