char Q8qJWDsFz [1010];

int main () {
    int i = 0, V1AhC74g6I = (217 - 216);
    scanf ("%s", Q8qJWDsFz);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    while (!('\0' == Q8qJWDsFz[i])) {
        if ('a' <= Q8qJWDsFz[i] && Q8qJWDsFz[i] <= 'z')
            Q8qJWDsFz[i] -= (49 - 17);
        if (Q8qJWDsFz[i + (966 - 965)] != Q8qJWDsFz[i] && Q8qJWDsFz[i + 1] != Q8qJWDsFz[i] + 32) {
            printf ("(%c,%d)", Q8qJWDsFz[i], V1AhC74g6I);
            V1AhC74g6I = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
            continue;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        V1AhC74g6I++, i++;
    }
    return 0;
}

