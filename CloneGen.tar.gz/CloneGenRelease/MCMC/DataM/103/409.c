main () {
    char J4yBuz [(1108 - 108)];
    gets (J4yBuz);
    int n;
    int KibU2Fkao;
    n = (514 - 513);
    if ('a' <= J4yBuz[(661 - 661)])
        J4yBuz[(531 - 531)] += 'A' - 'a';
    for (KibU2Fkao = (214 - 213); J4yBuz[KibU2Fkao]; KibU2Fkao++) {
        if (J4yBuz[KibU2Fkao] >= 'a')
            J4yBuz[KibU2Fkao] = J4yBuz[KibU2Fkao] + 'A' - 'a';
        if (J4yBuz[KibU2Fkao] == J4yBuz[KibU2Fkao -(467 - 466)])
            n = n + 1;
        else {
            printf ("(%c,%d)", J4yBuz[KibU2Fkao -(107 - 106)], n);
            n = 1;
        };
    }
    printf ("(%c,%d)", J4yBuz[KibU2Fkao -1], n);
}

