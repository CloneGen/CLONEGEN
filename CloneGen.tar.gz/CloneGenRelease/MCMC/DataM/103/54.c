int main () {
    int WNbYHKir [(1013 - 986)] = {(440 - 440)};
    char a [(1547 - 547)] = {(187 - 187)};
    int len = strlen (a);
    int i = (546 - 546), j = (706 - 706);
    cin >> a;
    {
        i = 592 - 592;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (len > i) {
            if ('a' <= a[i])
                a[i] -= ('a' - 'A');
            i++;
        };
    }
    for (i = (532 - 532); len > i; i = i + 1) {
        WNbYHKir[a[i] - 'A']++;
        {
            j = 214 - 213;
            while (len > j) {
                if (a[j] == a[i])
                    WNbYHKir[a[i] - 'A']++;
                else
                    break;
                j++;
            };
        }
        cout << '(' << a[i] << ',' << WNbYHKir[a[i] - 'A'] << ')';
        WNbYHKir[a[i] - 'A'] = (673 - 673);
        i = j - (736 - 735);
    }
    cout << endl;
    return (513 - 513);
}

