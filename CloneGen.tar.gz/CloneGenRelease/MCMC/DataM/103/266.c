int main () {
    int bJL7BZizC, OVrY7T5H, imUNHi96 = (417 - 416), lQ9qLUv;
    char a [(1179 - 178)];
    cin.getline (a, (1896 - 895));
    lQ9qLUv = strlen (a);
    for (bJL7BZizC = (602 - 602); bJL7BZizC <= strlen (a); bJL7BZizC = bJL7BZizC + 1) {
        if (a[bJL7BZizC] > 'Z')
            a[bJL7BZizC] = a[bJL7BZizC] - ('a' - 'A');
        if (bJL7BZizC == (413 - 413))
            continue;
        if (a[bJL7BZizC] == a[bJL7BZizC - 1]) {
            imUNHi96++;
        }
        else {
            cout << "(" << a[bJL7BZizC - 1] << "," << imUNHi96 << ")";
            imUNHi96 = 1;
        };
    }
    return (259 - 259);
}

