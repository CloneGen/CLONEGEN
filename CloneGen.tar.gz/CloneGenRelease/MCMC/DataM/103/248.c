main () {
    char KQE6NSuVI7 [(1417 - 417)];
    int i = 0, Fu8W73kR = 0, BuRMxYOJlg = 0, NTHCG5;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", KQE6NSuVI7);
    for (; KQE6NSuVI7[i] != '\0';) {
        if ('a' <= KQE6NSuVI7[i] && 'z' >= KQE6NSuVI7[i])
            KQE6NSuVI7[i] = KQE6NSuVI7[i] - 'a' + 'A';
        i = i + 1;
    }
    for (; KQE6NSuVI7[Fu8W73kR] != '\0';) {
        NTHCG5 = 1;
        for (BuRMxYOJlg = Fu8W73kR; KQE6NSuVI7[BuRMxYOJlg] != '\0'; BuRMxYOJlg++) {
            if (KQE6NSuVI7[BuRMxYOJlg] == KQE6NSuVI7[BuRMxYOJlg +1])
                NTHCG5 = NTHCG5 +1;
            else {
                Fu8W73kR = BuRMxYOJlg +1;
                printf ("(%c,%d)", KQE6NSuVI7[BuRMxYOJlg], NTHCG5);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                break;
            };
        };
    };
}

