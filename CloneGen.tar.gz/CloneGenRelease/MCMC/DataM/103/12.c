int main () {
    char AMJhRGw [(1713 - 713)];
    char q5A6CtgYB;
    int HTKsqOC, gbIBiCHYj, alen, DnDkhu6c1eQ = (621 - 621);
    cin.getline (AMJhRGw, 1000);
    alen = strlen (AMJhRGw);
    {
        HTKsqOC = 948 - 948;
        while (alen > HTKsqOC) {
            if (AMJhRGw[HTKsqOC] >= 97 && AMJhRGw[HTKsqOC] <= (596 - 474)) {
                AMJhRGw[HTKsqOC] -= 32;
            }
            HTKsqOC = HTKsqOC +1;
        };
    }
    q5A6CtgYB = AMJhRGw[0];
    for (HTKsqOC = 0; HTKsqOC < alen; HTKsqOC = HTKsqOC +1) {
        do {
            if (AMJhRGw[HTKsqOC] == q5A6CtgYB) {
                DnDkhu6c1eQ = DnDkhu6c1eQ +1;
            }
            if (AMJhRGw[HTKsqOC] != q5A6CtgYB) {
                cout << "(" << q5A6CtgYB << "," << DnDkhu6c1eQ << ")";
                DnDkhu6c1eQ = (692 - 691);
                q5A6CtgYB = AMJhRGw[HTKsqOC];
            }
            HTKsqOC = HTKsqOC +1;
        }
        while (AMJhRGw[HTKsqOC] != '\0');
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        cout << "(" << q5A6CtgYB << "," << DnDkhu6c1eQ << ")";
    }
    return 0;
}

