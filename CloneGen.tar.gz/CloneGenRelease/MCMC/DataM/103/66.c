int main () {
    char n8G51wLRIHBa [(1638 - 638)];
    int wqRw5doEJY, p;
    gets (n8G51wLRIHBa);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (wqRw5doEJY = (767 - 767); wqRw5doEJY < strlen (n8G51wLRIHBa); wqRw5doEJY = wqRw5doEJY + 1) {
        p = (117 - 116);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (n8G51wLRIHBa[wqRw5doEJY] != n8G51wLRIHBa[wqRw5doEJY + (144 - 143)]) {
            if (n8G51wLRIHBa[wqRw5doEJY] >= 'a' && n8G51wLRIHBa[wqRw5doEJY] <= 'z') {
                n8G51wLRIHBa[wqRw5doEJY] = n8G51wLRIHBa[wqRw5doEJY] - 'a' - 'A';
            }
            cout << "(" << n8G51wLRIHBa[wqRw5doEJY] << "," << (656 - 655) << ")";
        }
        else {
            for (; !(n8G51wLRIHBa[wqRw5doEJY + (614 - 613)] != n8G51wLRIHBa[wqRw5doEJY]) || n8G51wLRIHBa[wqRw5doEJY] == n8G51wLRIHBa[wqRw5doEJY + (344 - 343)] + 'A' - 'a' || n8G51wLRIHBa[wqRw5doEJY] == n8G51wLRIHBa[wqRw5doEJY + 1] + 'a' - 'A';) {
                p++;
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        float n = 0.0;
                        if (n > 10)
                            return;
                        else
                            n = 0;
                    }
                }
                wqRw5doEJY++;
            }
            if (n8G51wLRIHBa[wqRw5doEJY] >= 'a' && n8G51wLRIHBa[wqRw5doEJY] <= 'z') {
                n8G51wLRIHBa[wqRw5doEJY] -= 'a' - 'A';
            }
            cout << "(" << n8G51wLRIHBa[wqRw5doEJY] << "," << p << ")";
        };
    }
    cout << endl;
    return (691 - 691);
}

