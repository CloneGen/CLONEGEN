main () {
    int VA8ZRFXw3V, L6ltNKP27b;
    int mpDiuORt1w7H;
    char c [(1394 - 394)];
    scanf ("%s", c);
    {
        mpDiuORt1w7H = 555 - 555;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (c[mpDiuORt1w7H] != '\0') {
            if (('a' <= c[mpDiuORt1w7H]) && (c[mpDiuORt1w7H] <= 'z'))
                c[mpDiuORt1w7H] = c[mpDiuORt1w7H] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            mpDiuORt1w7H = mpDiuORt1w7H + 1;
        };
    }
    L6ltNKP27b = (18 - 17);
    for (VA8ZRFXw3V = 0; c[VA8ZRFXw3V] != '\0'; VA8ZRFXw3V++) {
        if (c[VA8ZRFXw3V] != c[VA8ZRFXw3V +1]) {
            printf ("(%c,%d)", c[VA8ZRFXw3V], L6ltNKP27b);
            L6ltNKP27b = 1;
        }
        else
            L6ltNKP27b = L6ltNKP27b +1;
    };
}

