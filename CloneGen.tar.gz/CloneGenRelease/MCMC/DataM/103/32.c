int main () {
    int lcPIb7TFBl;
    char Cf4glJhjc [1000];
    cin >> Cf4glJhjc;
    {
        lcPIb7TFBl = 349 - 349;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (Cf4glJhjc[lcPIb7TFBl] != '\0') {
            if (Cf4glJhjc[lcPIb7TFBl] >= 'a')
                Cf4glJhjc[lcPIb7TFBl] = Cf4glJhjc[lcPIb7TFBl] - ('a' - 'A');
            lcPIb7TFBl = lcPIb7TFBl + 1;
        };
    }
    {
        lcPIb7TFBl = 0;
        while (Cf4glJhjc[lcPIb7TFBl] != '\0') {
            int MhAc3U = 0;
            while (Cf4glJhjc[lcPIb7TFBl] == Cf4glJhjc[++lcPIb7TFBl]) {
                MhAc3U = MhAc3U +1;
            }
            lcPIb7TFBl = lcPIb7TFBl - 1;
            MhAc3U++;
            cout << "(" << Cf4glJhjc[lcPIb7TFBl] << "," << MhAc3U << ")";
            lcPIb7TFBl++;
        };
    }
    return 0;
}

