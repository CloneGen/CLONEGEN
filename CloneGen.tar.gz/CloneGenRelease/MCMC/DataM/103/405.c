main () {
    char str [1000];
    gets (str);
    int l;
    int Ouj9tYyrvc, r;
    r = 1;
    l = strlen (str);
    {
        Ouj9tYyrvc = 0;
        while (l > Ouj9tYyrvc) {
            if ('z' >= str[Ouj9tYyrvc] && str[Ouj9tYyrvc] >= 'a')
                str[Ouj9tYyrvc] = str[Ouj9tYyrvc] - 'a' + 'A';
            Ouj9tYyrvc++;
        };
    }
    {
        Ouj9tYyrvc = 0;
        while (Ouj9tYyrvc < l) {
            if (str[Ouj9tYyrvc] == str[Ouj9tYyrvc +1])
                r++;
            if (str[Ouj9tYyrvc] != str[Ouj9tYyrvc +1]) {
                printf ("(%c,%d)", str[Ouj9tYyrvc], r);
                r = 1;
            }
            Ouj9tYyrvc++;
        };
    };
}

