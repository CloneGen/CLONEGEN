int main () {
    int EDJG1zOqsni;
    int KJeMnjLYQ7b;
    char Co6SVP2L [(10041 - 41)];
    int ym7paBz = strlen (Co6SVP2L);
    cin >> Co6SVP2L;
    {
        EDJG1zOqsni = 416 - 416;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (ym7paBz > EDJG1zOqsni) {
            if (Co6SVP2L[EDJG1zOqsni] > 'Z')
                Co6SVP2L[EDJG1zOqsni] = Co6SVP2L[EDJG1zOqsni] - ('a' - 'A');
            EDJG1zOqsni++;
        };
    }
    for (EDJG1zOqsni = 0; EDJG1zOqsni < ym7paBz;) {
        int j = 0;
        for (KJeMnjLYQ7b = 0; ym7paBz - EDJG1zOqsni > KJeMnjLYQ7b; KJeMnjLYQ7b++) {
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (Co6SVP2L[EDJG1zOqsni +KJeMnjLYQ7b+(774 - 773)] == Co6SVP2L[EDJG1zOqsni +KJeMnjLYQ7b])
                j++;
            else {
                if (Co6SVP2L[EDJG1zOqsni +KJeMnjLYQ7b+1] == '\0') {
                    EDJG1zOqsni = ym7paBz;
                    j++;
                    cout << '(' << Co6SVP2L[EDJG1zOqsni +KJeMnjLYQ7b] << ',' << j << ')';
                }
                else {
                    cout << '(' << Co6SVP2L[EDJG1zOqsni +KJeMnjLYQ7b] << ',' << j + 1 << ')';
                    EDJG1zOqsni = EDJG1zOqsni +j + 1;
                    break;
                };
            };
        };
    }
    return 0;
}

