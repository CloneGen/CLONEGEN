int main () {
    int hL9SbdqsfZcH;
    hL9SbdqsfZcH = (11 - 10);
    char str [1002] = {'\0'};
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    for (int P7k10B5 = (286 - 286);
    !('\n' == str[P7k10B5 -(818 - 817)]); P7k10B5 = P7k10B5 +1) {
        str[P7k10B5] = getchar ();
        if ('a' <= str[P7k10B5] && str[P7k10B5] <= 'z')
            str[P7k10B5] = str[P7k10B5] - 'a' + 'A';
    }
    for (int P7k10B5 = 0;
    str[P7k10B5] != '\n'; P7k10B5 = P7k10B5 +1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (str[P7k10B5] == str[P7k10B5 +1])
            hL9SbdqsfZcH = hL9SbdqsfZcH + 1;
        else {
            cout << "(" << str[P7k10B5] << ',' << hL9SbdqsfZcH << ')';
            hL9SbdqsfZcH = 1;
        };
    }
    return 0;
}

