int main () {
    int mKFLPMb6BD, rsY0Rvn, IIentJdzgyUS, k;
    char Q2QI4EJhy [(1823 - 823)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", Q2QI4EJhy);
    for (IIentJdzgyUS = (112 - 112); Q2QI4EJhy[IIentJdzgyUS]; IIentJdzgyUS++) {
        if ('z' >= Q2QI4EJhy[IIentJdzgyUS] && 'a' <= Q2QI4EJhy[IIentJdzgyUS])
            Q2QI4EJhy[IIentJdzgyUS] = Q2QI4EJhy[IIentJdzgyUS] - 32;
    }
    for (rsY0Rvn = 0, mKFLPMb6BD = (910 - 909); Q2QI4EJhy[rsY0Rvn] != '\0'; rsY0Rvn++) {
        if (Q2QI4EJhy[rsY0Rvn] == Q2QI4EJhy[rsY0Rvn + 1]) {
            mKFLPMb6BD = mKFLPMb6BD + 1;
        }
        else {
            printf ("(%c,%d)", Q2QI4EJhy[rsY0Rvn], mKFLPMb6BD);
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            mKFLPMb6BD = 1;
        };
    };
}

