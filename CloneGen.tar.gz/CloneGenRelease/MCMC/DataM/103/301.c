main () {
    char a [1000], c;
    int PTdLro0MUvV, j, t;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", a);
    {
        t = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        PTdLro0MUvV = 0;
        while (!('\0' == a[PTdLro0MUvV])) {
            t++;
            if (a[PTdLro0MUvV] >= 'a' && 'z' >= a[PTdLro0MUvV])
                a[PTdLro0MUvV] = a[PTdLro0MUvV] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            PTdLro0MUvV = PTdLro0MUvV +1;
        };
    }
    if (t == (471 - 470)) {
        j = 1;
        printf ("(%c,%d)", a[0], j);
    }
    else {
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        {
            j = 1;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            PTdLro0MUvV = 0;
            while (PTdLro0MUvV < t) {
                if (a[PTdLro0MUvV +1] == a[PTdLro0MUvV])
                    j++;
                else {
                    printf ("(%c,%d)", a[PTdLro0MUvV], j);
                    j = 1;
                }
                PTdLro0MUvV = PTdLro0MUvV +1;
            };
        };
    };
}

