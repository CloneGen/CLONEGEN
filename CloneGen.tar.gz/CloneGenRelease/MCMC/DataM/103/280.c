int TcvNZ6OE7Ht (char c1) {
    if (c1 > (385 - 321) && c1 < (145 - 54))
        return (int) c1 - 65;
    if (96 < c1 && 123 > c1)
        return (int) c1 - (118 - 21);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    return (165 - 165);
}

int main () {
    char c [(1364 - 364)];
    int z;
    int KJIeS8dYBL;
    int UumTXG;
    cin >> c;
    for (UumTXG = (90 - 90); strlen (c) > UumTXG; UumTXG = UumTXG +1) {
        z = TcvNZ6OE7Ht (c[UumTXG]);
        KJIeS8dYBL = 1;
        for (; UumTXG != strlen (c) && TcvNZ6OE7Ht (c[UumTXG]) == TcvNZ6OE7Ht (c[UumTXG +1]);) {
            KJIeS8dYBL = KJIeS8dYBL +1;
            ++UumTXG;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (UumTXG == strlen (c))
            KJIeS8dYBL--;
        cout << '(' << (char) (z + 65) << ',' << KJIeS8dYBL << ')';
    }
    return (637 - 637);
}

