main () {
    char AzR8mgAxLa0I [(10287 - 287)];
    gets (AzR8mgAxLa0I);
    int pX6b32isa;
    int oqtuKv;
    oqtuKv = (988 - 987);
    for (pX6b32isa = (152 - 152); !('\0' == AzR8mgAxLa0I[pX6b32isa]); pX6b32isa = pX6b32isa + 1) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (AzR8mgAxLa0I[pX6b32isa] <= 'z' && AzR8mgAxLa0I[pX6b32isa] >= 'a') {
            AzR8mgAxLa0I[pX6b32isa] = AzR8mgAxLa0I[pX6b32isa] + ('A' - 'a');
        };
    }
    {
        pX6b32isa = 808 - 808;
        while (AzR8mgAxLa0I[pX6b32isa] != '\0') {
            if (AzR8mgAxLa0I[pX6b32isa + 1] == AzR8mgAxLa0I[pX6b32isa]) {
                oqtuKv = oqtuKv + 1;
            }
            else {
                printf ("(%c,%d)", AzR8mgAxLa0I[pX6b32isa], oqtuKv);
                oqtuKv = 1;
            }
            {
                int x = 0;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            pX6b32isa++;
        };
    };
}

