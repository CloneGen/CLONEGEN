int main () {
    int ebyDfZGQIn, count = 0;
    char ga1cO38MJYCr [1001] = {(525 - 525)};
    int zsP3f8 = (382 - 382);
    int k;
    char E5kNY0ZWXH = toupper (ga1cO38MJYCr[0]);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> ga1cO38MJYCr;
    k = strlen (ga1cO38MJYCr);
    {
        ebyDfZGQIn = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (k > ebyDfZGQIn) {
            if (!(E5kNY0ZWXH != ga1cO38MJYCr[ebyDfZGQIn]) || toupper (ga1cO38MJYCr[ebyDfZGQIn]) == E5kNY0ZWXH)
                zsP3f8++;
            else {
                cout << "(" << E5kNY0ZWXH << "," << zsP3f8 << ")";
                zsP3f8 = (884 - 883);
                E5kNY0ZWXH = toupper (ga1cO38MJYCr[ebyDfZGQIn]);
            }
            ebyDfZGQIn++;
        };
    }
    cout << "(" << E5kNY0ZWXH << "," << zsP3f8 << ")";
    return 0;
}

