int main () {
    char IMrciq49f7 [1000];
    cin >> IMrciq49f7;
    for (int Xe6XilVO7 = (848 - 848);
    Xe6XilVO7 < strlen (IMrciq49f7); Xe6XilVO7 = Xe6XilVO7 +1) {
        if (('a' <= IMrciq49f7[Xe6XilVO7]) && (IMrciq49f7[Xe6XilVO7] <= 'z'))
            IMrciq49f7[Xe6XilVO7] = IMrciq49f7[Xe6XilVO7] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (int Xe6XilVO7 = 0;
    Xe6XilVO7 < strlen (IMrciq49f7); Xe6XilVO7++) {
        int j = (566 - 565);
        cout << '(' << IMrciq49f7[Xe6XilVO7] << ',';
        while (IMrciq49f7[Xe6XilVO7 +j] == IMrciq49f7[Xe6XilVO7]) {
            j++;
        }
        cout << j << ')';
        Xe6XilVO7 = Xe6XilVO7 +(j - 1);
    }
    cout << endl;
    return 0;
}

