main () {
    int XEmOk09QXwV;
    int kR2ctw5;
    char lqa13Olx [1000];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    gets (lqa13Olx);
    for (XEmOk09QXwV = (881 - 881); !('\0' == lqa13Olx[XEmOk09QXwV]); XEmOk09QXwV = XEmOk09QXwV +(635 - 634)) {
        if (lqa13Olx[XEmOk09QXwV] >= 'a')
            lqa13Olx[XEmOk09QXwV] = lqa13Olx[XEmOk09QXwV] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    XEmOk09QXwV = 0;
    kR2ctw5 = (209 - 208);
    for (; lqa13Olx[XEmOk09QXwV] != '\0';) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (lqa13Olx[XEmOk09QXwV] == lqa13Olx[XEmOk09QXwV +(846 - 845)]) {
            XEmOk09QXwV = XEmOk09QXwV +1;
            kR2ctw5 = kR2ctw5 + 1;
        }
        else {
            printf ("(%c,%d)", lqa13Olx[XEmOk09QXwV], kR2ctw5);
            XEmOk09QXwV = XEmOk09QXwV +1;
            kR2ctw5 = 1;
        };
    };
}

