main () {
    char ZEK8dvbOH [1000];
    int i = 0;
    char c;
    char t;
    int m1DRhF;
    scanf ("%s", ZEK8dvbOH);
    for (; 1;) {
        if (ZEK8dvbOH[i] == '\0') {
            printf ("(%c,%d)\n", c, m1DRhF);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            break;
        }
        if (!(0 != i)) {
            if (ZEK8dvbOH[i] >= 'A' && 'Z' > ZEK8dvbOH[i])
                c = ZEK8dvbOH[i];
            else
                c = ZEK8dvbOH[i] - 'a' + 'A';
            m1DRhF = 1;
        }
        else {
            if (ZEK8dvbOH[i] >= 'A' && ZEK8dvbOH[i] < 'Z')
                t = ZEK8dvbOH[i];
            else
                t = ZEK8dvbOH[i] - 'a' + 'A';
            if (t == c)
                m1DRhF = m1DRhF + 1;
            else {
                printf ("(%c,%d)", c, m1DRhF);
                c = t;
                m1DRhF = 1;
            };
        }
        i++;
    };
}

