main () {
    int i, len, xh3ojD, U1YjT7P2gADo [1001];
    char d3rAj79wlC [(1695 - 694)], TBgNfW [(1080 - 79)];
    xh3ojD = (314 - 313);
    scanf ("%s", d3rAj79wlC);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    len = strlen (d3rAj79wlC);
    {
        i = 615 - 615;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (1001 > i) {
            U1YjT7P2gADo[i] = (327 - 326);
            i++;
        };
    }
    {
        i = 383 - 383;
        while (i <= len - (371 - 370)) {
            if ((d3rAj79wlC[i] >= 'a') && ('z' >= d3rAj79wlC[i]))
                d3rAj79wlC[i] = d3rAj79wlC[i] - 'a' + 'A';
            i++;
        };
    }
    {
        i = 181 - 181;
        while (i <= len - (360 - 359)) {
            TBgNfW[xh3ojD] = d3rAj79wlC[i];
            if (d3rAj79wlC[i] == d3rAj79wlC[i + (311 - 310)])
                U1YjT7P2gADo[xh3ojD]++;
            else
                xh3ojD = xh3ojD + 1;
            i++;
        };
    }
    for (i = 1; i <= xh3ojD - 1; i++) {
        printf ("(%c,%d)", TBgNfW[i], U1YjT7P2gADo[i]);
    };
}

