int main () {
    char CTcXBkn [(1122 - 117)];
    char UPy76W = CTcXBkn[(237 - 237)];
    int JLjZEO = (617 - 617);
    cin >> CTcXBkn;
    {
        int i = (994 - 994);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (strlen (CTcXBkn) > i) {
            if ('z' >= CTcXBkn[i] && 'a' <= CTcXBkn[i])
                CTcXBkn[i] = CTcXBkn[i] + 'A' - 'a';
            i++;
        };
    }
    {
        int i = (722 - 722);
        while (i <= strlen (CTcXBkn)) {
            if (UPy76W == CTcXBkn[i])
                JLjZEO++;
            else {
                cout << "(" << UPy76W << "," << JLjZEO << ")";
                UPy76W = CTcXBkn[i];
                JLjZEO = 1;
            }
            i++;
        };
    }
    return 0;
}

