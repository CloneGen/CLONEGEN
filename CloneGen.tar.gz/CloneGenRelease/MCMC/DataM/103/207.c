int main () {
    char P [1000];
    gets (P);
    struct   comp {
        char A;
        int tXIxeEQ9WT;
    };
    int i, ApwVnNKxv3F, k = (239 - 239);
    struct   comp oL2ZxjXBwaOI [(479 - 379)] [(118 - 92)] = {'A', (386 - 386)};
    for (i = 0; strlen (P) > i; i++) {
        if (i > 0)
            if (P[i] == P[i - (664 - 663)] || !(P[i - (192 - 191)] + 'A' - 'a' != P[i]) || !(P[i - (200 - 199)] + 'a' - 'A' != P[i]))
                ;
            else
                k = k + 1;
        for (ApwVnNKxv3F = 0; ApwVnNKxv3F < (64 - 38); ApwVnNKxv3F = ApwVnNKxv3F +1)
            if (ApwVnNKxv3F +'A' == P[i] || ApwVnNKxv3F +'a' == P[i]) {
                oL2ZxjXBwaOI[k][ApwVnNKxv3F].tXIxeEQ9WT++;
                oL2ZxjXBwaOI[k][ApwVnNKxv3F].A = ApwVnNKxv3F +'A';
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        int temp = 0;
                        while (temp < 10) {
                            printf ("%d\n", temp);
                            temp = temp + 1;
                            if (temp == 9)
                                break;
                        }
                    }
                }
                break;
            };
    }
    {
        k = 0;
        while (k < 100) {
            {
                ApwVnNKxv3F = 0;
                while (ApwVnNKxv3F < 26) {
                    if (oL2ZxjXBwaOI[k][ApwVnNKxv3F].tXIxeEQ9WT != 0)
                        printf ("(%c,%d)", oL2ZxjXBwaOI[k][ApwVnNKxv3F].A, oL2ZxjXBwaOI[k][ApwVnNKxv3F].tXIxeEQ9WT);
                    ApwVnNKxv3F = ApwVnNKxv3F +1;
                };
            }
            k++;
        };
    }
    return 0;
}

