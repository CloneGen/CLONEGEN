char C1Xy54 (char IFIAJB4iq6Ue) {
    char JnTNScRUx;
    if ('Z' >= IFIAJB4iq6Ue &&'A' <= IFIAJB4iq6Ue)
        JnTNScRUx = IFIAJB4iq6Ue;
    else
        JnTNScRUx = IFIAJB4iq6Ue +'A' - 'a';
    return JnTNScRUx;
}

main () {
    char dJprin65 [1000];
    char Pi2PVrEsc [1000];
    int uNXVO4rv81D, BqYWpdC9JN, glw7M5bG1XS = (448 - 448), a [1000] = {(899 - 898)};
    gets (Pi2PVrEsc);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            return 0;
        }
    }
    uNXVO4rv81D = strlen (Pi2PVrEsc);
    for (BqYWpdC9JN = (418 - 418); uNXVO4rv81D > BqYWpdC9JN; BqYWpdC9JN = BqYWpdC9JN +1)
        Pi2PVrEsc[BqYWpdC9JN] = C1Xy54 (Pi2PVrEsc[BqYWpdC9JN]);
    dJprin65[0] = Pi2PVrEsc[0];
    for (BqYWpdC9JN = (831 - 830); uNXVO4rv81D > BqYWpdC9JN; BqYWpdC9JN++) {
        if (Pi2PVrEsc[BqYWpdC9JN] == Pi2PVrEsc[BqYWpdC9JN -(335 - 334)])
            a[glw7M5bG1XS]++;
        else {
            glw7M5bG1XS++;
            dJprin65[glw7M5bG1XS] = Pi2PVrEsc[BqYWpdC9JN];
            a[glw7M5bG1XS] = 1;
        };
    }
    for (BqYWpdC9JN = 0; BqYWpdC9JN <= glw7M5bG1XS; BqYWpdC9JN++)
        printf ("(%c,%d)", dJprin65[BqYWpdC9JN], a[BqYWpdC9JN]);
}

