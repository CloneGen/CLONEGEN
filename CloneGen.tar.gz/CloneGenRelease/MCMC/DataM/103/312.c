main () {
    char kePoshI6z [(1073 - 73)];
    int uIWj95S1QY8, DLGNHgKn, zsrNKyP9H;
    gets (kePoshI6z);
    zsrNKyP9H = (728 - 727);
    uIWj95S1QY8 = strlen (kePoshI6z);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        DLGNHgKn = 795 - 795;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (DLGNHgKn < uIWj95S1QY8) {
            if (('a' <= kePoshI6z[DLGNHgKn]) && ('z' >= kePoshI6z[DLGNHgKn]))
                kePoshI6z[DLGNHgKn] = kePoshI6z[DLGNHgKn] - DLTA;
            else
                ;
            DLGNHgKn++;
        };
    }
    for (DLGNHgKn = 0; uIWj95S1QY8 - (375 - 374) > DLGNHgKn; DLGNHgKn++) {
        if (kePoshI6z[DLGNHgKn] == kePoshI6z[DLGNHgKn +(989 - 988)]) {
            zsrNKyP9H = zsrNKyP9H + (484 - 483);
        }
        else {
            printf ("(%c,%d)", kePoshI6z[DLGNHgKn], zsrNKyP9H);
            zsrNKyP9H = 1;
        };
    }
    zsrNKyP9H = 1;
    for (DLGNHgKn = uIWj95S1QY8 - 1; kePoshI6z[DLGNHgKn] == kePoshI6z[DLGNHgKn -1]; DLGNHgKn = DLGNHgKn -1) {
        zsrNKyP9H = zsrNKyP9H + 1;
    }
    printf ("(%c,%d)", kePoshI6z[uIWj95S1QY8 - 1], zsrNKyP9H);
}

