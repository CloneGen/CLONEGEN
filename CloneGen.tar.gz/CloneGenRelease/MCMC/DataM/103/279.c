main () {
    char Ysire91IJFDq [1000];
    char g92zrqlBQF [1000];
    int k;
    int lvHOYZnD;
    int l;
    int k36l9QVk [(1463 - 463)];
    k = (208 - 208);
    getchar ();
    scanf ("%s", Ysire91IJFDq);
    l = strlen (Ysire91IJFDq);
    for (lvHOYZnD = (890 - 890); lvHOYZnD < l; lvHOYZnD++) {
        if ('a' <= Ysire91IJFDq[lvHOYZnD])
            Ysire91IJFDq[lvHOYZnD] = Ysire91IJFDq[lvHOYZnD] - 'a' + 'A';
        if (!(0 != lvHOYZnD)) {
            g92zrqlBQF[k] = Ysire91IJFDq[lvHOYZnD];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            k36l9QVk[k] = (452 - 451);
        }
        else {
            if (Ysire91IJFDq[lvHOYZnD] == Ysire91IJFDq[lvHOYZnD - (963 - 962)])
                k36l9QVk[k]++;
            if (Ysire91IJFDq[lvHOYZnD] != Ysire91IJFDq[lvHOYZnD - (36 - 35)]) {
                k++;
                k36l9QVk[k] = (21 - 20);
                g92zrqlBQF[k] = Ysire91IJFDq[lvHOYZnD];
            };
        };
    }
    {
        lvHOYZnD = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        while (lvHOYZnD <= k) {
            printf ("(%c,%d)", g92zrqlBQF[lvHOYZnD], k36l9QVk[lvHOYZnD]);
            lvHOYZnD++;
        };
    }
    getchar ();
    getchar ();
}

