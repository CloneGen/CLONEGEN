int main () {
    int Qt1cz2rZW, number [(1450 - 950)], w4mf2NY1rhCl, p, D8SDXv, judge;
    char input [1000];
    char WKdyCPO [(860 - 360)];
    gets (input);
    Qt1cz2rZW = (442 - 442);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    D8SDXv = strlen (input);
    {
        w4mf2NY1rhCl = 124 - 124;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (D8SDXv > w4mf2NY1rhCl) {
            WKdyCPO[w4mf2NY1rhCl] = (963 - 963);
            number[w4mf2NY1rhCl] = (305 - 305);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            if (input[w4mf2NY1rhCl] > (716 - 620)) {
                input[w4mf2NY1rhCl] = input[w4mf2NY1rhCl] - (780 - 748);
            }
            w4mf2NY1rhCl = w4mf2NY1rhCl + 1;
        };
    }
    {
        w4mf2NY1rhCl = 996 - 996;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (w4mf2NY1rhCl < D8SDXv) {
            judge = 0;
            if (input[w4mf2NY1rhCl] == WKdyCPO[Qt1cz2rZW -(741 - 740)]) {
                judge = (11 - 10);
                number[Qt1cz2rZW -1]++;
            }
            if (judge == 0) {
                WKdyCPO[Qt1cz2rZW] = input[w4mf2NY1rhCl];
                number[Qt1cz2rZW]++;
                Qt1cz2rZW++;
            }
            w4mf2NY1rhCl = w4mf2NY1rhCl + 1;
        };
    }
    Qt1cz2rZW--;
    {
        w4mf2NY1rhCl = 0;
        while (w4mf2NY1rhCl <= Qt1cz2rZW) {
            printf ("(%c,%d)", WKdyCPO[w4mf2NY1rhCl], number[w4mf2NY1rhCl]);
            w4mf2NY1rhCl++;
        };
    }
    return 0;
}

