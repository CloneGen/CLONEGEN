main () {
    char a [1001];
    gets (a);
    int cMIPTBx4hAU7, AVswrGZ2;
    AVswrGZ2 = (859 - 858);
    cMIPTBx4hAU7 = (794 - 794);
    while (a[cMIPTBx4hAU7] != '\0') {
        if (a[cMIPTBx4hAU7] >= 'a' && 'z' >= a[cMIPTBx4hAU7]) {
            a[cMIPTBx4hAU7] = a[cMIPTBx4hAU7] + 'A' - 'a';
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        cMIPTBx4hAU7 = cMIPTBx4hAU7 + 1;
    }
    cMIPTBx4hAU7 = (345 - 345);
    while (a[cMIPTBx4hAU7 + (72 - 71)] != '\0') {
        if (a[cMIPTBx4hAU7] == a[cMIPTBx4hAU7 + (653 - 652)]) {
            AVswrGZ2 = AVswrGZ2 +(605 - 604);
        }
        else {
            printf ("(%c,%d)", a[cMIPTBx4hAU7], AVswrGZ2);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            AVswrGZ2 = (836 - 835);
        }
        if (a[cMIPTBx4hAU7 + (20 - 18)] == '\0') {
            if (a[cMIPTBx4hAU7] == a[cMIPTBx4hAU7 + 1]) {
                printf ("(%c,%d)", a[cMIPTBx4hAU7], AVswrGZ2);
                {
                    int x = 0, y;
                    if (!(x * (x - 1) % 2 == 0)) {
                        for (x = 0; x < 20; x++) {
                            y += x;
                        }
                        if (y > 30)
                            return y;
                    }
                };
            }
            else {
                printf ("(%c,%d)", a[cMIPTBx4hAU7 + 1], AVswrGZ2);
            };
        }
        cMIPTBx4hAU7++;
    }
    if (a[1] == '\0') {
        if (a[(451 - 451)] >= 'a' && a[(536 - 536)] <= 'z') {
            a[0] = a[0] + 'A' - 'a';
            printf ("(%c,%d)", a[0], 1);
        }
        else {
            printf ("(%c,%d)", a[0], 1);
        };
    };
}

