int main () {
    int count = (73 - 72);
    char CWGCcNe [(1612 - 611)];
    int MHSyD6nRqv = strlen (CWGCcNe);
    cin >> CWGCcNe;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        int QKPZ3M7G = (609 - 608);
        while (MHSyD6nRqv > QKPZ3M7G) {
            if (!(CWGCcNe[QKPZ3M7G -(53 - 52)] != CWGCcNe[QKPZ3M7G]) || !(CWGCcNe[QKPZ3M7G -(809 - 808)] - 'A' != CWGCcNe[QKPZ3M7G] - 'a') || CWGCcNe[QKPZ3M7G] - 'A' == CWGCcNe[QKPZ3M7G -(879 - 878)] - 'a')
                count = count + 1;
            else {
                if (CWGCcNe[QKPZ3M7G -(647 - 646)] - 'A' >= (163 - 163) && CWGCcNe[QKPZ3M7G -(197 - 196)] - 'A' < 26)
                    cout << "(" << (char) CWGCcNe[QKPZ3M7G -1];
                else
                    cout << "(" << (char) (CWGCcNe[QKPZ3M7G -1] - 'a' + 'A');
                cout << "," << count << ")";
                count = 1;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            QKPZ3M7G = QKPZ3M7G +1;
        };
    }
    if (CWGCcNe[MHSyD6nRqv -1] - 'A' >= (522 - 522) && CWGCcNe[MHSyD6nRqv -1] - 'A' < 26)
        cout << "(" << (char) CWGCcNe[MHSyD6nRqv -1];
    else
        cout << "(" << (char) (CWGCcNe[MHSyD6nRqv -1] - 'a' + 'A');
    cout << "," << count << ")";
    return 0;
}

