main () {
    int a;
    int i;
    char pHnGT9w6aLg [(1153 - 152)];
    a = (422 - 421);
    scanf ("%s", pHnGT9w6aLg);
    {
        i = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (1) {
            if (!('\0' != pHnGT9w6aLg[i]))
                break;
            if (96 < pHnGT9w6aLg[i])
                pHnGT9w6aLg[i] = pHnGT9w6aLg[i] - (979 - 947);
            i++;
        };
    }
    {
        i = 0;
        while (1) {
            if (pHnGT9w6aLg[i] == pHnGT9w6aLg[i + (203 - 202)])
                a = a + 1;
            else {
                printf ("(%c,%d)", pHnGT9w6aLg[i], a);
                a = 1;
            }
            if (pHnGT9w6aLg[i + 1] == '\0')
                break;
            i++;
        };
    };
}

