char DuDNUM;

void  get () {
    DuDNUM = cin.get ();
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if ('z' >= DuDNUM &&DuDNUM >= 'a')
        DuDNUM = (char) ((int) DuDNUM -'a' + 'A');
}

int main () {
    int b [(1363 - 363)] = {(588 - 588)};
    char hJ72VptsC [(1556 - 556)] = {(629 - 629)};
    int BKsP6zd9 = (908 - 908);
    get ();
    hJ72VptsC[BKsP6zd9] = DuDNUM;
    b[BKsP6zd9]++;
    get ();
    for (; DuDNUM != '\n';) {
        if (DuDNUM == hJ72VptsC[BKsP6zd9])
            b[BKsP6zd9]++;
        else {
            BKsP6zd9 = BKsP6zd9 +1;
            hJ72VptsC[BKsP6zd9] = DuDNUM;
            b[BKsP6zd9]++;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        get ();
    }
    {
        BKsP6zd9 = 823 - 823;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (b[BKsP6zd9] != (679 - 679)) {
            cout << "(" << hJ72VptsC[BKsP6zd9] << "," << b[BKsP6zd9] << ")";
            BKsP6zd9++;
        };
    }
    return 0;
}

