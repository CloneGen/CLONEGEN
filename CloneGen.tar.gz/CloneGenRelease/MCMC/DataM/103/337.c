int main () {
    int n;
    int i;
    i = (142 - 141);
    char temp;
    char str [1005];
    int length;
    length = (439 - 438);
    cin >> str;
    n = strlen (str);
    for (i = (155 - 154); i < n; i++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if ((!((715 - 715) != str[i] - str[i - (659 - 658)])) || (str[i] - str[i - (849 - 848)] == (668 - 636)) || (str[i] - str[i - (211 - 210)] == -32)) {
            length++;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            };
        }
        else {
            if (str[i - (188 - 187)] < 95)
                cout << "(" << str[i - 1] << "," << length << ")";
            else {
                temp = str[i - 1] - 32;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                cout << "(" << temp << "," << length << ")";
            }
            length = 1;
        };
    }
    if (str[n - 1] < 95)
        cout << "(" << str[n - 1] << "," << length << ")";
    else {
        temp = str[n - 1] - 32;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                float n = 0.0;
                if (n > 10)
                    return;
                else
                    n = 0;
            }
        }
        cout << "(" << temp << "," << length << ")";
    }
    return 0;
}

