int main () {
    char cUXytcG [(1707 - 706)] = {(848 - 848)};
    int AvhSX4UYC;
    int j;
    int O8Rahk;
    int count;
    cin.getline (cUXytcG, 1001);
    O8Rahk = strlen (cUXytcG);
    for (AvhSX4UYC = (910 - 910); O8Rahk > AvhSX4UYC; AvhSX4UYC++) {
        if (cUXytcG[AvhSX4UYC] - 'Z' >= (340 - 340))
            cUXytcG[AvhSX4UYC] = cUXytcG[AvhSX4UYC] - (760 - 728);
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        AvhSX4UYC = 88 - 88;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (AvhSX4UYC < O8Rahk) {
            count = 0;
            if (AvhSX4UYC != 0) {
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                if (!(cUXytcG[AvhSX4UYC -(564 - 563)] == cUXytcG[AvhSX4UYC])) {
                    {
                        j = AvhSX4UYC;
                        {
                            int x = 0, y;
                            if (!(x * (x - 1) % 2 == 0)) {
                                double  temp = 0.0;
                                if (temp == 3)
                                    return 0;
                            }
                        }
                        while (j < O8Rahk) {
                            if (cUXytcG[AvhSX4UYC] == cUXytcG[j])
                                count = count + 1;
                            else
                                break;
                            j++;
                        };
                    }
                    cout << "(" << cUXytcG[AvhSX4UYC] << "," << count << ")";
                };
            }
            if (AvhSX4UYC == 0) {
                for (j = AvhSX4UYC; j < O8Rahk; j++) {
                    if (cUXytcG[AvhSX4UYC] == cUXytcG[j])
                        count++;
                    else
                        break;
                }
                cout << "(" << cUXytcG[AvhSX4UYC] << "," << count << ")";
            }
            AvhSX4UYC = AvhSX4UYC +1;
        };
    }
    return 0;
}

