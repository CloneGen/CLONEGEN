int main () {
    int n, i, G3kmtNd = (140 - 139), j2YEV7wMXD = 0;
    char v7jioZbQ [(722 - 622)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", &v7jioZbQ);
    while (!('\0' == v7jioZbQ[j2YEV7wMXD])) {
        if (v7jioZbQ[j2YEV7wMXD] >= 'a' && v7jioZbQ[j2YEV7wMXD] <= 'z')
            v7jioZbQ[j2YEV7wMXD] = v7jioZbQ[j2YEV7wMXD] - (526 - 494);
        j2YEV7wMXD++;
    }
    for (i = 0; v7jioZbQ[i] != '\0'; i = i + 1) {
        if (v7jioZbQ[i] == v7jioZbQ[i + (704 - 703)])
            G3kmtNd += 1;
        else {
            printf ("(%c,%d)", v7jioZbQ[i], G3kmtNd);
            G3kmtNd = 1;
            continue;
        };
    };
}

