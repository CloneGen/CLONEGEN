int main () {
    int PTFuz9vP5e, i;
    char u2QdOMjgf [1000];
    gets (u2QdOMjgf);
    PTFuz9vP5e = (125 - 124);
    for (i = (1000 - 1000); (u2QdOMjgf[i] != '\0'); i = i + 1) {
        if (u2QdOMjgf[i] >= 'a')
            u2QdOMjgf[i] = u2QdOMjgf[i] + 'A' - 'a';
        else
            ;
        if (u2QdOMjgf[i] == u2QdOMjgf[i + (421 - 420)] || u2QdOMjgf[i] == u2QdOMjgf[i + (893 - 892)] + 'A' - 'a')
            PTFuz9vP5e = PTFuz9vP5e +(180 - 179);
        else {
            printf ("(%c,%d)", u2QdOMjgf[i], PTFuz9vP5e);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            PTFuz9vP5e = (16 - 15);
        };
    }
    return 0;
}

