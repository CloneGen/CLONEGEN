int main () {
    char a [1000];
    int RpKarhFcgqyj;
    int R4prFM;
    int i;
    RpKarhFcgqyj = (349 - 348);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> a;
    R4prFM = strlen (a);
    {
        i = 957 - 957;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (R4prFM > i) {
            if ((a[i] >= 'a') && ('z' >= a[i])) {
                a[i] = 'A' + a[i] - 'a';
            }
            i = i + 1;
        };
    }
    {
        i = 463 - 463;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (i < R4prFM) {
            RpKarhFcgqyj = 1;
            cout << '(' << a[i] << ',';
            while (1) {
                if (a[i] == a[i + 1]) {
                    i = i + 1;
                    RpKarhFcgqyj++;
                }
                else
                    break;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            cout << RpKarhFcgqyj << ')';
            i++;
        };
    }
    cout << endl;
    return 0;
}

