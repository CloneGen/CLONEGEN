int main () {
    char nt2mDeEcMVhv [(1213 - 213)];
    int LjXGbREIgsH, iN3lDn1bh, XKoFiVatUp;
    XKoFiVatUp = (203 - 202);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    scanf ("%s", nt2mDeEcMVhv);
    for (LjXGbREIgsH = (421 - 421); nt2mDeEcMVhv[LjXGbREIgsH] != '\0'; LjXGbREIgsH++) {
        if ('a' <= nt2mDeEcMVhv[LjXGbREIgsH])
            nt2mDeEcMVhv[LjXGbREIgsH] = nt2mDeEcMVhv[LjXGbREIgsH] + 'A' - 'a';
        else
            ;
    }
    {
        LjXGbREIgsH = 805 - 805;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (nt2mDeEcMVhv[LjXGbREIgsH] != '\0') {
            if (nt2mDeEcMVhv[LjXGbREIgsH] == nt2mDeEcMVhv[LjXGbREIgsH +1])
                XKoFiVatUp++;
            else {
                printf ("(%c,%d)", nt2mDeEcMVhv[LjXGbREIgsH], XKoFiVatUp);
                XKoFiVatUp = 1;
            }
            LjXGbREIgsH++;
        };
    }
    return 0;
}

