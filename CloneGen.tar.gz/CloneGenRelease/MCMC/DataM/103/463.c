int main () {
    char iSEQklWs;
    char Zdt6rLlk;
    int OQXk9mWYabo;
    iSEQklWs = '0';
    while (cin >> Zdt6rLlk) {
        if (96 < Zdt6rLlk)
            Zdt6rLlk -= (1032 - 1000);
        if (Zdt6rLlk != iSEQklWs) {
            if (iSEQklWs != '0')
                printf ("(%c,%d)", iSEQklWs, OQXk9mWYabo);
            OQXk9mWYabo = (291 - 290);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            iSEQklWs = Zdt6rLlk;
        }
        else
            OQXk9mWYabo = OQXk9mWYabo +1;
    }
    printf ("(%c,%d)", iSEQklWs, OQXk9mWYabo);
    return (970 - 970);
}

