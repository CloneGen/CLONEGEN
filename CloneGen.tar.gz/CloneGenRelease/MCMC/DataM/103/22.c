int main () {
    int gprWQYBIA;
    int AuaDSky1;
    gprWQYBIA = (980 - 979);
    char CzTuFwEN [(1948 - 948)];
    char temp;
    cin >> CzTuFwEN;
    if ((108 - 11) <= CzTuFwEN[(460 - 460)] && CzTuFwEN[(353 - 353)] <= 122)
        temp = CzTuFwEN[(79 - 79)] - (513 - 481);
    else
        temp = CzTuFwEN[0];
    for (AuaDSky1 = (133 - 132); AuaDSky1 < strlen (CzTuFwEN); AuaDSky1++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (CzTuFwEN[AuaDSky1] == temp || !(temp != CzTuFwEN[AuaDSky1] - 32)) {
            gprWQYBIA = gprWQYBIA + 1;
        }
        else {
            if (CzTuFwEN[AuaDSky1] >= 65 && CzTuFwEN[AuaDSky1] < (374 - 284)) {
                cout << "(" << temp << "," << gprWQYBIA << ")";
                gprWQYBIA = (344 - 343);
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                temp = CzTuFwEN[AuaDSky1];
            }
            else if (CzTuFwEN[AuaDSky1] >= 97 && CzTuFwEN[AuaDSky1] < 122) {
                cout << "(" << temp << "," << gprWQYBIA << ")";
                temp = CzTuFwEN[AuaDSky1] - 32;
                gprWQYBIA = (265 - 264);
            };
        };
    }
    cout << "(" << temp << "," << gprWQYBIA << ")";
    return 0;
}

