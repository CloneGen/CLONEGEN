char msbHioR (char x);

int main () {
    char a [(1959 - 956)];
    char aKlE0bQI2Pim;
    int PGzbd3Tf;
    int uAkZ28z6M;
    int jNJjoO0;
    PGzbd3Tf = (922 - 922);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    PGzbd3Tf = (800 - 799);
    cin >> a;
    jNJjoO0 = strlen (a);
    aKlE0bQI2Pim = msbHioR (a[(507 - 507)]);
    {
        uAkZ28z6M = 743 - 742;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (uAkZ28z6M < jNJjoO0) {
            if (msbHioR (a[uAkZ28z6M]) == aKlE0bQI2Pim)
                PGzbd3Tf = PGzbd3Tf +1;
            if (msbHioR (a[uAkZ28z6M]) != aKlE0bQI2Pim) {
                cout << "(" << aKlE0bQI2Pim << "," << PGzbd3Tf << ")";
                aKlE0bQI2Pim = msbHioR (a[uAkZ28z6M]);
                PGzbd3Tf = (772 - 771);
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            uAkZ28z6M++;
        };
    }
    cout << "(" << aKlE0bQI2Pim << "," << PGzbd3Tf << ")";
    return 0;
}

char msbHioR (char x) {
    if (x >= 'a' && x <= 'z')
        return (x - 'a' + 'A');
    else
        return x;
}

