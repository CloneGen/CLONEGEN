int main () {
    char a [(1249 - 248)], b [1001];
    char tmp [(1818 - 818)];
    int IbDkWf3Pt [1000];
    int AxBrLiO1u;
    int kvOJ7UwX;
    int len;
    kvOJ7UwX = (566 - 566);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> a;
    len = strlen (a);
    for (AxBrLiO1u = (167 - 167); AxBrLiO1u < len; AxBrLiO1u++) {
        if ('A' <= a[AxBrLiO1u] && a[AxBrLiO1u] <= 'Z')
            b[AxBrLiO1u] = a[AxBrLiO1u];
        else
            b[AxBrLiO1u] = a[AxBrLiO1u] - 'a' + 'A';
    }
    memset (tmp, '#', sizeof (tmp));
    memset (IbDkWf3Pt, (972 - 972), sizeof (IbDkWf3Pt));
    b[len] = '\0';
    {
        AxBrLiO1u = 733 - 733;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        while (AxBrLiO1u < len) {
            if (AxBrLiO1u == (953 - 953)) {
                tmp[kvOJ7UwX] = b[AxBrLiO1u];
                IbDkWf3Pt[kvOJ7UwX]++;
            }
            else if (b[AxBrLiO1u] == tmp[kvOJ7UwX]) {
                IbDkWf3Pt[kvOJ7UwX]++;
            }
            else {
                kvOJ7UwX++;
                tmp[kvOJ7UwX] = b[AxBrLiO1u];
                IbDkWf3Pt[kvOJ7UwX]++;
            }
            AxBrLiO1u = AxBrLiO1u +1;
        };
    }
    {
        AxBrLiO1u = 0;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                for (x = 0; x < 20; x++) {
                    y += x;
                }
                if (y > 30)
                    return y;
            }
        }
        while (AxBrLiO1u <= kvOJ7UwX) {
            cout << '(' << tmp[AxBrLiO1u] << ',' << IbDkWf3Pt[AxBrLiO1u] << ')';
            AxBrLiO1u++;
        };
    }
    return 0;
}

