main () {
    char xtxeQGcvHwV [(1228 - 228)];
    gets (xtxeQGcvHwV);
    int n, alIqbfusK, j, q9qYF5eshD;
    n = strlen (xtxeQGcvHwV);
    {
        alIqbfusK = 991 - 991;
        while (alIqbfusK < n) {
            if (xtxeQGcvHwV[alIqbfusK] <= 'z' && xtxeQGcvHwV[alIqbfusK] >= 'a')
                xtxeQGcvHwV[alIqbfusK] = xtxeQGcvHwV[alIqbfusK] - 'a' + 'A';
            alIqbfusK = alIqbfusK + 1;
        };
    }
    alIqbfusK = 0;
    for (; alIqbfusK < n;) {
        q9qYF5eshD = 1;
        for (j = alIqbfusK + 1;; j++)
            if (xtxeQGcvHwV[j] == xtxeQGcvHwV[alIqbfusK])
                q9qYF5eshD = q9qYF5eshD + 1;
            else {
                printf ("(%c,%d)", xtxeQGcvHwV[alIqbfusK], q9qYF5eshD);
                alIqbfusK = j;
                break;
            };
    }
    getchar ();
    getchar ();
}

