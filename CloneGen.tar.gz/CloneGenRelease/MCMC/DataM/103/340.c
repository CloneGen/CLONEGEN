int main () {
    char Ch [(1819 - 818)] = {(16 - 16)};
    char ChO [(1172 - 171)] = {(469 - 469)};
    int iChO [1001] = {(296 - 296)}, yZCVrQci5w = (189 - 189);
    cin >> Ch;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    if (Ch[(989 - 989)] > (626 - 531))
        Ch[(663 - 663)] = Ch[(663 - 663)] - (950 - 918);
    ChO[(484 - 484)] = Ch[(530 - 530)], iChO[yZCVrQci5w] = (910 - 909);
    {
        int Co74OzILfAB = (128 - 127);
        while (1001 > Co74OzILfAB) {
            if (Ch[Co74OzILfAB] > 95)
                Ch[Co74OzILfAB] -= 32;
            if (Ch[Co74OzILfAB] == Ch[Co74OzILfAB -(965 - 964)]) {
                iChO[yZCVrQci5w]++;
            }
            else {
                yZCVrQci5w++;
                ChO[yZCVrQci5w] = Ch[Co74OzILfAB];
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                iChO[yZCVrQci5w] = 1;
            }
            Co74OzILfAB = Co74OzILfAB +1;
        };
    }
    {
        int Co74OzILfAB = (568 - 568);
        while (ChO[Co74OzILfAB] != 0) {
            cout << '(' << ChO[Co74OzILfAB] << ',' << iChO[Co74OzILfAB] << ')';
            Co74OzILfAB = Co74OzILfAB +1;
        };
    }
    return 0;
}

