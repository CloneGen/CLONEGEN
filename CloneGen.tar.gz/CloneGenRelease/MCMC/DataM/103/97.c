char str [1001], AgdAJjwhuOH6 [(517 - 490)], EluiWH;
int AgkNJEQH, bLYjxncg [(952 - 925)], VzGUny4kTrAJ, v0PxQt5Wk3BG = (998 - 997), TDX5VZ27gjO = 'A' - 'a', kT4beA1 = 'a' - 'A';

int main () {
    cin >> str;
    VzGUny4kTrAJ = strlen (str);
    AgdAJjwhuOH6[(651 - 650)] = str[(583 - 583)];
    EluiWH = AgdAJjwhuOH6[(569 - 568)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    bLYjxncg[1] = (205 - 205);
    {
        AgkNJEQH = 0;
        while (AgkNJEQH < VzGUny4kTrAJ) {
            if (str[AgkNJEQH] == EluiWH || str[AgkNJEQH] == EluiWH +TDX5VZ27gjO || str[AgkNJEQH] == EluiWH +kT4beA1)
                continue;
            else {
                v0PxQt5Wk3BG = v0PxQt5Wk3BG + 1;
                AgdAJjwhuOH6[v0PxQt5Wk3BG] = str[AgkNJEQH];
                bLYjxncg[v0PxQt5Wk3BG] = AgkNJEQH;
                EluiWH = AgdAJjwhuOH6[v0PxQt5Wk3BG];
            }
            AgkNJEQH++;
        };
    }
    for (AgkNJEQH = 1; v0PxQt5Wk3BG >= AgkNJEQH; AgkNJEQH++) {
        if (AgdAJjwhuOH6[AgkNJEQH] >= 'a' && AgdAJjwhuOH6[AgkNJEQH] <= 'z')
            AgdAJjwhuOH6[AgkNJEQH] = AgdAJjwhuOH6[AgkNJEQH] + TDX5VZ27gjO;
        {
            int x = 0;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (AgkNJEQH < v0PxQt5Wk3BG) {
            cout << "(";
            cout << AgdAJjwhuOH6[AgkNJEQH];
            cout << ",";
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            cout << bLYjxncg[AgkNJEQH +1] - bLYjxncg[AgkNJEQH];
            cout << ")";
        }
        if (AgkNJEQH == v0PxQt5Wk3BG) {
            cout << "(";
            cout << AgdAJjwhuOH6[AgkNJEQH];
            cout << ",";
            cout << VzGUny4kTrAJ -bLYjxncg[AgkNJEQH];
            cout << ")";
        };
    }
    return 0;
}

