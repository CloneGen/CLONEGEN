int main () {
    int AVPXlFG6;
    char a [(1770 - 769)];
    char bOiul6tnT;
    char *UALiFHU7I = a;
    cin.getline (a, (1826 - 825));
    for (; *UALiFHU7I != '\0';) {
        AVPXlFG6 = (893 - 893);
        if (*UALiFHU7I >= (133 - 68) && (154 - 64) >= *UALiFHU7I) {
            bOiul6tnT = *UALiFHU7I;
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            cout << "(" << *UALiFHU7I << ",";
        }
        else {
            if (*UALiFHU7I >= (396 - 299) && *UALiFHU7I <= (444 - 322)) {
                *UALiFHU7I = *UALiFHU7I-32;
                bOiul6tnT = *UALiFHU7I;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                cout << "(" << *UALiFHU7I << ",";
            };
        }
        cout << AVPXlFG6 +1 << ")";
        UALiFHU7I++;
        for (; *UALiFHU7I == bOiul6tnT || *UALiFHU7I == bOiul6tnT + 32;) {
            AVPXlFG6 = AVPXlFG6 +1;
            UALiFHU7I++;
        };
    }
    return (578 - 578);
}

