main () {
    int t;
    t = 0;
    int f;
    f = (461 - 461);
    int OcRjtM54;
    int j;
    int k;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    int a;
    char eGAovZR [100];
    int zDr1ywo [(10694 - 694)] = {(785 - 785)};
    scanf ("%s", eGAovZR);
    a = strlen (eGAovZR);
    for (OcRjtM54 = (114 - 114); a > OcRjtM54; OcRjtM54 = OcRjtM54 +1) {
        if ('a' <= eGAovZR[OcRjtM54] && 'z' >= eGAovZR[OcRjtM54])
            eGAovZR[OcRjtM54] = eGAovZR[OcRjtM54] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    {
        OcRjtM54 = f;
        while (OcRjtM54 < a) {
            zDr1ywo[eGAovZR[OcRjtM54]]++;
            f++;
            if (eGAovZR[OcRjtM54] != eGAovZR[OcRjtM54 +(868 - 867)]) {
                printf ("(%c,%d)", eGAovZR[OcRjtM54], zDr1ywo[eGAovZR[OcRjtM54]]);
                zDr1ywo[eGAovZR[OcRjtM54]] = 0;
            }
            OcRjtM54 = OcRjtM54 +1;
        };
    };
}

