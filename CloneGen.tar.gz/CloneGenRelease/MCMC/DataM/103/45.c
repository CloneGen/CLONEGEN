main () {
    int h;
    int rKGYV1n [1020];
    int M5dZnuS;
    h = (905 - 905);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    int IwrksD1F7qT6, j;
    char OzGUrkF9Tsn8 [(1687 - 667)];
    int hwScW6bnl8;
    scanf ("%s", OzGUrkF9Tsn8);
    IwrksD1F7qT6 = strlen (OzGUrkF9Tsn8);
    if (IwrksD1F7qT6 == (52 - 51) && (793 - 793) <= (OzGUrkF9Tsn8[(595 - 595)] - 'a'))
        printf ("(%c,%d)", OzGUrkF9Tsn8[(329 - 329)] - (258 - 226), (490 - 489));
    else {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (IwrksD1F7qT6 == (802 - 801) && 0 >= (OzGUrkF9Tsn8[0] - 'a'))
            printf ("(%c,%d)", OzGUrkF9Tsn8[hwScW6bnl8], (771 - 770));
        else {
            for (hwScW6bnl8 = 0; hwScW6bnl8 <= IwrksD1F7qT6 -(747 - 745);) {
                {
                    M5dZnuS = 1;
                    hwScW6bnl8 = h;
                    while (hwScW6bnl8 <= IwrksD1F7qT6 -2) {
                        if (OzGUrkF9Tsn8[hwScW6bnl8] - OzGUrkF9Tsn8[hwScW6bnl8 + 1] == 0 || OzGUrkF9Tsn8[hwScW6bnl8] - OzGUrkF9Tsn8[hwScW6bnl8 + 1] == 32 || OzGUrkF9Tsn8[hwScW6bnl8] - OzGUrkF9Tsn8[hwScW6bnl8 + 1] == -32) {
                            M5dZnuS = M5dZnuS +1;
                        }
                        else
                            break;
                        hwScW6bnl8 = hwScW6bnl8 + 1;
                    };
                }
                h = hwScW6bnl8 + 1;
                if (OzGUrkF9Tsn8[hwScW6bnl8] - 'a' >= 0)
                    printf ("(%c,%d)", OzGUrkF9Tsn8[hwScW6bnl8] - 32, M5dZnuS);
                else
                    printf ("(%c,%d)", OzGUrkF9Tsn8[hwScW6bnl8], M5dZnuS);
            };
        };
    };
}

