struct   HZz5Ny6ax {
    char dUbwhWI;
    int gs;
}
HZz5Ny6ax [(1553 - 552)];

void  main () {
    char a [(1655 - 654)] = {'\0'};
    gets (a);
    int J48AkYCZO9, iCmBRF8DkIE, GlcJ1S;
    iCmBRF8DkIE = 0;
    GlcJ1S = strlen (a);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (J48AkYCZO9 = (629 - 629); J48AkYCZO9 < (1286 - 285); J48AkYCZO9++)
        HZz5Ny6ax[J48AkYCZO9].gs = (257 - 257);
    HZz5Ny6ax[(85 - 85)].dUbwhWI = a[(959 - 959)];
    HZz5Ny6ax[0].gs = (157 - 156);
    {
        J48AkYCZO9 = 379 - 378;
        while (GlcJ1S > J48AkYCZO9) {
            if (!(HZz5Ny6ax[iCmBRF8DkIE].dUbwhWI != a[J48AkYCZO9]) || !((HZz5Ny6ax[iCmBRF8DkIE].dUbwhWI + 32) != a[J48AkYCZO9]) || a[J48AkYCZO9] == HZz5Ny6ax[iCmBRF8DkIE].dUbwhWI - 32)
                HZz5Ny6ax[iCmBRF8DkIE].gs++;
            else {
                iCmBRF8DkIE = iCmBRF8DkIE + 1;
                HZz5Ny6ax[iCmBRF8DkIE].dUbwhWI = a[J48AkYCZO9];
                HZz5Ny6ax[iCmBRF8DkIE].gs = 1;
            }
            J48AkYCZO9++;
        };
    }
    for (J48AkYCZO9 = 0; J48AkYCZO9 <= iCmBRF8DkIE; J48AkYCZO9++) {
        if (HZz5Ny6ax[J48AkYCZO9].dUbwhWI >= 'a')
            HZz5Ny6ax[J48AkYCZO9].dUbwhWI = HZz5Ny6ax[J48AkYCZO9].dUbwhWI - 32;
        printf ("(%c,%d)", HZz5Ny6ax[J48AkYCZO9].dUbwhWI, HZz5Ny6ax[J48AkYCZO9].gs);
    };
}

