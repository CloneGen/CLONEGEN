int main () {
    int iLdvjVoEUPJ = (457 - 456);
    int bFv1dk;
    char xYkcfdLjpvgH [1001];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
    scanf ("%s", xYkcfdLjpvgH);
    for (bFv1dk = (534 - 534); bFv1dk < strlen (xYkcfdLjpvgH); bFv1dk = bFv1dk + 1) {
        if ('a' <= xYkcfdLjpvgH[bFv1dk] && 'z' >= xYkcfdLjpvgH[bFv1dk])
            xYkcfdLjpvgH[bFv1dk] = xYkcfdLjpvgH[bFv1dk] - 'a' + 'A';
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        };
    }
    for (bFv1dk = 0; bFv1dk < strlen (xYkcfdLjpvgH); bFv1dk++) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        if (xYkcfdLjpvgH[bFv1dk] == xYkcfdLjpvgH[bFv1dk + 1]) {
            iLdvjVoEUPJ++;
        }
        else {
            printf ("(%c,%d)", xYkcfdLjpvgH[bFv1dk], iLdvjVoEUPJ);
            iLdvjVoEUPJ = 1;
        };
    };
}

