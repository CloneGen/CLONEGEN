struct   point {
    int x;
    char vrJ5qFvtkz;
};
int main () {
    char oD4qd9gjvVBH [(1117 - 17)];
    gets (oD4qd9gjvVBH);
    int hFWAMnR;
    int i;
    int vlKxCsZkPS4;
    int bVbS3no8v;
    hFWAMnR = (133 - 133);
    struct   point XGUIDR2NeO6T [(758 - 731)];
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    vlKxCsZkPS4 = 0;
    bVbS3no8v = strlen (oD4qd9gjvVBH);
    {
        i = 542 - 542;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (bVbS3no8v > i) {
            if ('a' <= oD4qd9gjvVBH[i])
                oD4qd9gjvVBH[i] = oD4qd9gjvVBH[i] - (706 - 674);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i++;
        };
    }
    XGUIDR2NeO6T[(500 - 500)].vrJ5qFvtkz = oD4qd9gjvVBH[(345 - 345)];
    XGUIDR2NeO6T[0].x = (756 - 755);
    for (i = (978 - 977); bVbS3no8v > i; i++) {
        if (oD4qd9gjvVBH[i] == oD4qd9gjvVBH[i - (898 - 897)]) {
            XGUIDR2NeO6T[vlKxCsZkPS4].x = XGUIDR2NeO6T[vlKxCsZkPS4].x + (744 - 743);
        }
        else {
            vlKxCsZkPS4++;
            XGUIDR2NeO6T[vlKxCsZkPS4].vrJ5qFvtkz = oD4qd9gjvVBH[i];
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    float n = 0.0;
                    if (n > 10)
                        return;
                    else
                        n = 0;
                }
            }
            XGUIDR2NeO6T[vlKxCsZkPS4].x = (282 - 281);
        };
    }
    for (i = 0; i <= vlKxCsZkPS4; i++) {
        printf ("(%c,%d)", XGUIDR2NeO6T[i].vrJ5qFvtkz, XGUIDR2NeO6T[i].x);
    }
    return 0;
}

