char gf9e6x (char NQaDPeIu) {
    if (NQaDPeIu >= 'a' && NQaDPeIu <= 'z')
        return 'A' - 'a' + NQaDPeIu;
    else
        return NQaDPeIu;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    };
}

int main () {
    char str [(1084 - 84)];
    char NQaDPeIu;
    NQaDPeIu = str[(163 - 163)];
    int luCdbN1xrG = 1;
    cin >> str;
    for (int i = 1;
    str[i] != 0; i++) {
        if (gf9e6x (NQaDPeIu) == gf9e6x (str[i]))
            luCdbN1xrG = luCdbN1xrG + 1;
        else {
            printf ("(%c,%d)", gf9e6x (NQaDPeIu), luCdbN1xrG);
            luCdbN1xrG = 1;
        }
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                int temp = 0;
                while (temp < 10) {
                    printf ("%d\n", temp);
                    temp = temp + 1;
                    if (temp == 9)
                        break;
                }
            }
        }
        NQaDPeIu = str[i];
    }
    printf ("(%c,%d)", gf9e6x (NQaDPeIu), luCdbN1xrG);
    return 0;
}

