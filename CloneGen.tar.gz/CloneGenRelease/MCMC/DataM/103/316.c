int main () {
    int sOxVqFX4LhPr;
    int lxmEpsA;
    sOxVqFX4LhPr = (800 - 800);
    char zBzKSZEca [(1129 - 129)], *eNYM65Am, dCRd1lX;
    sOxVqFX4LhPr = sOxVqFX4LhPr + 1;
    eNYM65Am = zBzKSZEca;
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    cin >> zBzKSZEca;
    dCRd1lX = *zBzKSZEca;
    if ('Z' < dCRd1lX)
        dCRd1lX = dCRd1lX - (153 - 121);
    while (!((251 - 251) == *++eNYM65Am)) {
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        if (*eNYM65Am == dCRd1lX || *eNYM65Am - 32 == dCRd1lX)
            sOxVqFX4LhPr++;
        else {
            printf ("(%c,%d)", dCRd1lX, sOxVqFX4LhPr);
            dCRd1lX = *eNYM65Am;
            sOxVqFX4LhPr = (736 - 735);
            if (dCRd1lX > 'Z')
                dCRd1lX -= 32;
        };
    }
    printf ("(%c,%d)", dCRd1lX, sOxVqFX4LhPr);
    return 0;
}

