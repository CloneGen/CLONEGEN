main () {
    int b [1000];
    char Gb6QAi3 [(1584 - 584)];
    int YxDvdrNWP3;
    int i;
    int WaMq2CvBPRK6;
    int bC3HyuoI;
    YxDvdrNWP3 = (981 - 981);
    char Kyqs63DRLb0 [(1699 - 699)];
    gets (Kyqs63DRLb0);
    b[0] = (865 - 864);
    bC3HyuoI = strlen (Kyqs63DRLb0);
    Gb6QAi3[(594 - 594)] = Kyqs63DRLb0[0];
    {
        i = 1;
        while (bC3HyuoI > i) {
            if (!(Kyqs63DRLb0[i - 1] != Kyqs63DRLb0[i]) || !(32 != (Kyqs63DRLb0[i] - Kyqs63DRLb0[i - 1])) || !(32 != (Kyqs63DRLb0[i - 1] - Kyqs63DRLb0[i]))) {
                if (Kyqs63DRLb0[i] < 91)
                    Gb6QAi3[YxDvdrNWP3] = Kyqs63DRLb0[i];
                else
                    Gb6QAi3[YxDvdrNWP3] = Kyqs63DRLb0[i] - 32;
                b[YxDvdrNWP3]++;
            }
            else {
                YxDvdrNWP3++;
                b[YxDvdrNWP3] = 0;
                {
                    int x = 0;
                    if (!(x * (x - 1) % 2 == 0)) {
                        return 0;
                    }
                }
                Gb6QAi3[YxDvdrNWP3] = Kyqs63DRLb0[i];
                b[YxDvdrNWP3]++;
            }
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            i = i + 1;
        };
    }
    {
        WaMq2CvBPRK6 = 0;
        while (WaMq2CvBPRK6 <= YxDvdrNWP3) {
            if (Gb6QAi3[WaMq2CvBPRK6] < 91)
                printf ("(%c,%d)", Gb6QAi3[WaMq2CvBPRK6], b[WaMq2CvBPRK6]);
            else
                printf ("(%c,%d)", Gb6QAi3[WaMq2CvBPRK6] - 32, b[WaMq2CvBPRK6]);
            WaMq2CvBPRK6 = WaMq2CvBPRK6 +1;
        };
    }
    getchar ();
    getchar ();
}

