int main () {
    int zGOJMfju9, j = (338 - 338), len = (334 - 334), qB1eabIn8 [(1046 - 46)] = {(978 - 978)};
    char zwtCZUz6PM2 [1000];
    char copy [1000] = {'a'};
    cin.getline (zwtCZUz6PM2, 10001, '\n');
    len = strlen (zwtCZUz6PM2);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    {
        zGOJMfju9 = 58 - 58;
        {
            int x = 0, y;
            if (!(x * (x - 1) % 2 == 0)) {
                return 0;
            }
        }
        while (len > zGOJMfju9) {
            if (zwtCZUz6PM2[zGOJMfju9] >= 'a' && 'z' >= zwtCZUz6PM2[zGOJMfju9])
                zwtCZUz6PM2[zGOJMfju9] = zwtCZUz6PM2[zGOJMfju9] + 'A' - 'a';
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            zGOJMfju9 = zGOJMfju9 + 1;
        };
    }
    for (zGOJMfju9 = 0; zGOJMfju9 < len; zGOJMfju9 = zGOJMfju9 + 1) {
        if (zGOJMfju9 == 0) {
            copy[j] = zwtCZUz6PM2[zGOJMfju9];
            qB1eabIn8[j] = (705 - 704);
        }
        if (zwtCZUz6PM2[zGOJMfju9] == zwtCZUz6PM2[zGOJMfju9 - (292 - 291)] && zGOJMfju9 != 0)
            qB1eabIn8[j]++;
        if (zwtCZUz6PM2[zGOJMfju9] != zwtCZUz6PM2[zGOJMfju9 + 1]) {
            copy[++j] = zwtCZUz6PM2[zGOJMfju9 + 1];
            qB1eabIn8[j] = 1;
        };
    }
    {
        zGOJMfju9 = 0;
        while (zGOJMfju9 < j) {
            cout << '(' << copy[zGOJMfju9] << ',' << qB1eabIn8[zGOJMfju9] << ')';
            zGOJMfju9 = zGOJMfju9 + 1;
        };
    }
    cout << endl;
    return 0;
}

