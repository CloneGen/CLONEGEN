int main () {
    char wq7SzFl35fCp [1000];
    gets (wq7SzFl35fCp);
    int HhXN65yP, EZQkAqTfoPW = (970 - 970), j, a [1000] = {(669 - 669)};
    HhXN65yP = strlen (wq7SzFl35fCp);
    {
        int x = 0, y;
        if (!(x * (x - 1) % 2 == 0)) {
            for (x = 0; x < 20; x++) {
                y += x;
            }
            if (y > 30)
                return y;
        }
    }
    for (j = (899 - 899); j < HhXN65yP; j = j + 1)
        if (wq7SzFl35fCp[j] > 96)
            wq7SzFl35fCp[j] = wq7SzFl35fCp[j] - 32;
    for (; HhXN65yP > EZQkAqTfoPW;)
        for (j = (489 - 489); j < HhXN65yP -EZQkAqTfoPW; j++) {
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    return 0;
                }
            }
            if (!(wq7SzFl35fCp[EZQkAqTfoPW +j] != wq7SzFl35fCp[EZQkAqTfoPW])) {
                if (EZQkAqTfoPW +j == HhXN65yP -1)
                    goto loop;
                a[EZQkAqTfoPW]++;
            }
            else {
                EZQkAqTfoPW = EZQkAqTfoPW +j;
                break;
            };
        }
loop :
    for (EZQkAqTfoPW = 0; EZQkAqTfoPW < HhXN65yP; EZQkAqTfoPW++)
        if (a[EZQkAqTfoPW] != 0)
            printf ("(%c,%d)", wq7SzFl35fCp[EZQkAqTfoPW], a[EZQkAqTfoPW]);
    return 0;
}

