void  main () {
    int uW5v1erAP;
    int AFQimBsKl;
    int kk7zi30aT2 [(391 - 91)];
    int MW5iYxyf [300];
    int *wqnP0Dw;
    scanf ("%d", &AFQimBsKl);
    {
        uW5v1erAP = 915 - 915;
        while (uW5v1erAP <= (AFQimBsKl -(650 - 649))) {
            scanf ("%d", &kk7zi30aT2[uW5v1erAP]);
            {
                int x = 0, y;
                if (!(x * (x - 1) % 2 == 0)) {
                    int temp = 0;
                    while (temp < 10) {
                        printf ("%d\n", temp);
                        temp = temp + 1;
                        if (temp == 9)
                            break;
                    }
                }
            }
            uW5v1erAP = uW5v1erAP + 1;
        };
    }
    printf ("%d", kk7zi30aT2[0]);
    for (uW5v1erAP = (560 - 559); (AFQimBsKl -1) >= uW5v1erAP; uW5v1erAP++) {
        for (wqnP0Dw = kk7zi30aT2; wqnP0Dw < &kk7zi30aT2[uW5v1erAP]; wqnP0Dw = wqnP0Dw + 1) {
            if (*wqnP0Dw == kk7zi30aT2[uW5v1erAP])
                break;
        }
        if (wqnP0Dw == &kk7zi30aT2[uW5v1erAP])
            printf (",%d", kk7zi30aT2[uW5v1erAP]);
    };
}

