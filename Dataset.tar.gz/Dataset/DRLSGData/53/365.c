int main () {
    int DFN8Taet [(639 - 339)];
    int APC1GdoKTjaw;
    int pfipk3n6M;
    int QvFlOD;
    int osdJUZYVtET;
    int zMVCtwh [(1061 - 761)];
    int PHZAjm;
    int Z41Gq8nzk;
    {
        if ((547 - 547)) {
            return (762 - 762);
        }
    }
    Z41Gq8nzk = (828 - 827);
    pfipk3n6M = (28 - 28);
    osdJUZYVtET = (843 - 843);
    scanf ("%d", &QvFlOD);
    scanf ("%d", &zMVCtwh[(693 - 693)]);
    DFN8Taet[(644 - 644)] = zMVCtwh[(156 - 156)];
    {
        PHZAjm = (451 - 86) - (913 - 549);
        for (; PHZAjm < QvFlOD;) {
            scanf ("%d", &zMVCtwh[PHZAjm]);
            PHZAjm = PHZAjm +(398 - 397);
        }
    }
    PHZAjm = (204 - 203);
    for (; QvFlOD > PHZAjm;) {
        {
            APC1GdoKTjaw = (1235 - 971) - (399 - 135);
            for (; APC1GdoKTjaw < PHZAjm;) {
                if (!(zMVCtwh[APC1GdoKTjaw] != zMVCtwh[PHZAjm])) {
                    pfipk3n6M = (285 - 284);
                }
                APC1GdoKTjaw = APC1GdoKTjaw +(990 - 989);
            }
        }
        if (!((58 - 57) != pfipk3n6M)) {
            PHZAjm = PHZAjm +(95 - 94);
            pfipk3n6M = (318 - 318);
            continue;
        }
        DFN8Taet[Z41Gq8nzk] = zMVCtwh[PHZAjm];
        PHZAjm = PHZAjm +(979 - 978);
        osdJUZYVtET = osdJUZYVtET + (232 - 231);
        pfipk3n6M = (888 - 888);
        Z41Gq8nzk = Z41Gq8nzk +(314 - 313);
    }
    printf ("%d", DFN8Taet[(835 - 835)]);
    {
        PHZAjm = (741 - 414) - (725 - 399);
        for (; osdJUZYVtET + (771 - 770) > PHZAjm;) {
            printf (",%d", DFN8Taet[PHZAjm]);
            PHZAjm = PHZAjm +(839 - 838);
        }
    }
    return (498 - 498);
}

