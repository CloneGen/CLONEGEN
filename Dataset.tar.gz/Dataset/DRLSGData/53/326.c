void  main () {
    int khJptFTY12lX;
    int o6KcMxrsa3;
    int *yjiCyq;
    int Jq7nebyoQF [(335 - 35)];
    int lE4QBbRn7h [(819 - 519)];
    scanf ("%d", &khJptFTY12lX);
    {
        o6KcMxrsa3 = (159 - 159);
        for (; o6KcMxrsa3 <= (khJptFTY12lX - (661 - 660));) {
            scanf ("%d", &Jq7nebyoQF[o6KcMxrsa3]);
            o6KcMxrsa3 = o6KcMxrsa3 + (267 - 266);
        }
    }
    printf ("%d", Jq7nebyoQF[(384 - 384)]);
    {
        o6KcMxrsa3 = (1753 - 982) - (1333 - 563);
        for (; (khJptFTY12lX - (580 - 579)) >= o6KcMxrsa3;) {
            {
                yjiCyq = Jq7nebyoQF;
                for (; &Jq7nebyoQF[o6KcMxrsa3] > yjiCyq;) {
                    if (*yjiCyq == Jq7nebyoQF[o6KcMxrsa3])
                        break;
                    yjiCyq = yjiCyq + (323 - 322);
                }
            }
            if (yjiCyq == &Jq7nebyoQF[o6KcMxrsa3])
                printf (",%d", Jq7nebyoQF[o6KcMxrsa3]);
            o6KcMxrsa3 = o6KcMxrsa3 + (669 - 668);
        }
    }
}

