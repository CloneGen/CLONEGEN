int main () {
    char k0LDqvUn;
    int x4GotmMi;
    int KiJ6YqzMgb;
    {
        if ((190 - 190)) {
            return (578 - 578);
        }
    }
    x4GotmMi = (968 - 967);
    KiJ6YqzMgb = (310 - 284);
    for (; scanf ("%c", &k0LDqvUn), k0LDqvUn != '\n';) {
        if (k0LDqvUn >= 'A' && k0LDqvUn <= 'Z')
            k0LDqvUn = k0LDqvUn - 'A';
        if (k0LDqvUn >= 'a' && k0LDqvUn <= 'z')
            k0LDqvUn = k0LDqvUn - 'a';
        if ((785 - 759) <= KiJ6YqzMgb)
            KiJ6YqzMgb = k0LDqvUn;
        else if (KiJ6YqzMgb != k0LDqvUn) {
            printf ("(%c,%d)", KiJ6YqzMgb +'A', x4GotmMi);
            x4GotmMi = (804 - 803);
            KiJ6YqzMgb = k0LDqvUn;
        }
        else
            x4GotmMi = x4GotmMi + (125 - 124);
    }
    printf ("(%c,%d)", KiJ6YqzMgb +'A', x4GotmMi);
    return (920 - 920);
}

