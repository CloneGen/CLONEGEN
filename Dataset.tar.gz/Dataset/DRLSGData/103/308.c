int main () {
    char WtzpECZ5 [(1695 - 690)];
    int Bq8clQO1CaW;
    Bq8clQO1CaW = (764 - 764);
    cin >> WtzpECZ5;
    {
        int LucnyrY8FAPv;
        LucnyrY8FAPv = (996 - 996);
        for (; strlen (WtzpECZ5) > LucnyrY8FAPv;) {
            if ('z' >= WtzpECZ5[LucnyrY8FAPv] && WtzpECZ5[LucnyrY8FAPv] >= 'a') {
                WtzpECZ5[LucnyrY8FAPv] = WtzpECZ5[LucnyrY8FAPv] - 'a' + 'A';
            }
            LucnyrY8FAPv = LucnyrY8FAPv +(294 - 293);
        }
    }
    if (WtzpECZ5[(526 - 526)] != WtzpECZ5[(205 - 204)]) {
        cout << "(" << WtzpECZ5[(83 - 83)] << ",1)";
    }
    else {
        Bq8clQO1CaW = Bq8clQO1CaW +(668 - 667);
    }
    {
        int LucnyrY8FAPv;
        LucnyrY8FAPv = (810 - 809);
        for (; strlen (WtzpECZ5) > LucnyrY8FAPv;) {
            Bq8clQO1CaW = Bq8clQO1CaW +(489 - 488);
            if (WtzpECZ5[LucnyrY8FAPv] != WtzpECZ5[LucnyrY8FAPv +(30 - 29)]) {
                cout << "(" << WtzpECZ5[LucnyrY8FAPv] << "," << Bq8clQO1CaW << ")";
                Bq8clQO1CaW = (21 - 21);
            }
            LucnyrY8FAPv = LucnyrY8FAPv +(466 - 465);
        }
    }
}

