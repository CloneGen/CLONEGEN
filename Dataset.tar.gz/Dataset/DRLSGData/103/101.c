int main () {
    char i8ogir7pt [(1412 - 412)] = {(798 - 797)};
    char J4mKeig [(1083 - 83)];
    char aiwoEue6FA [(1035 - 35)] = {(504 - 504)};
    int OxOJjIhVei;
    scanf ("%s", J4mKeig);
    {
        int HOg53Wbx2Q9;
        HOg53Wbx2Q9 = (132 - 132);
        for (; J4mKeig[HOg53Wbx2Q9] != '0';) {
            if ((J4mKeig[HOg53Wbx2Q9] >= 'a') && ('z' >= J4mKeig[HOg53Wbx2Q9]))
                J4mKeig[HOg53Wbx2Q9] = J4mKeig[HOg53Wbx2Q9] - 'a' + 'A';
            else
                J4mKeig[HOg53Wbx2Q9] = J4mKeig[HOg53Wbx2Q9];
            HOg53Wbx2Q9 = HOg53Wbx2Q9 +(789 - 788);
        }
    }
    OxOJjIhVei = (183 - 183);
    aiwoEue6FA[(358 - 358)] = J4mKeig[(76 - 76)];
    {
        int Aw1bSFe;
        Aw1bSFe = (545 - 545);
        for (; J4mKeig[Aw1bSFe] != '\0';) {
            if (!(J4mKeig[Aw1bSFe +(265 - 264)] != J4mKeig[Aw1bSFe])) {
                i8ogir7pt[OxOJjIhVei] = i8ogir7pt[OxOJjIhVei] + (970 - 969);
            }
            else {
                aiwoEue6FA[OxOJjIhVei] = J4mKeig[Aw1bSFe];
                OxOJjIhVei = OxOJjIhVei +(689 - 688);
                i8ogir7pt[OxOJjIhVei] = (80 - 79);
            }
            Aw1bSFe = Aw1bSFe +(692 - 691);
        }
    }
    {
        int IO5I29S;
        IO5I29S = (168 - 168);
        for (; aiwoEue6FA[IO5I29S] != '\0';) {
            {
                if ((45 - 45)) {
                    return (839 - 839);
                }
            }
            printf ("(%c,%d)", aiwoEue6FA[IO5I29S], i8ogir7pt[IO5I29S]);
            IO5I29S = IO5I29S +(812 - 811);
        }
    }
}

