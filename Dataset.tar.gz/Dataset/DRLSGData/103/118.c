main () {
    int EUErwC;
    char DaYjAv [(1430 - 420)];
    gets (DaYjAv);
    int gSJh85fFXoPx;
    int TbE3LOpHRf;
    char FShzV2;
    int PAk0BwKIqV6;
    int HdcPsE;
    getchar ();
    EUErwC = strlen (DaYjAv);
    {
        TbE3LOpHRf = (759 - 759);
        for (; EUErwC > TbE3LOpHRf;) {
            DaYjAv[TbE3LOpHRf] = toupper (DaYjAv[TbE3LOpHRf]);
            TbE3LOpHRf = TbE3LOpHRf +(137 - 136);
        }
    }
    TbE3LOpHRf = (86 - 86);
    for (; EUErwC > TbE3LOpHRf;) {
        FShzV2 = DaYjAv[TbE3LOpHRf];
        PAk0BwKIqV6 = HdcPsE -TbE3LOpHRf;
        HdcPsE = TbE3LOpHRf +(85 - 84);
        for (; HdcPsE < EUErwC &&DaYjAv[HdcPsE] == FShzV2;)
            HdcPsE = HdcPsE +(15 - 14);
        TbE3LOpHRf = HdcPsE;
        printf ("(%c,%d)", FShzV2, PAk0BwKIqV6);
    }
    getchar ();
}

