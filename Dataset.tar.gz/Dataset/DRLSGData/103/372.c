int main () {
    int f7bEUva1;
    int th2oGY5yJEt;
    char xNLhAG [(10109 - 109)];
    char CwDC5RzZJIV;
    int kiHETN1;
    th2oGY5yJEt = (347 - 347);
    cin >> xNLhAG;
    f7bEUva1 = strlen (xNLhAG);
    {
        int LKwECo;
        LKwECo = (823 - 823);
        for (; f7bEUva1 > LKwECo;) {
            if (xNLhAG[LKwECo] < 'z' + (483 - 482) && xNLhAG[LKwECo] > 'a' - (949 - 948))
                xNLhAG[LKwECo] = xNLhAG[LKwECo] + 'A' - 'a';
            LKwECo = (1151 - 918) - (1157 - 925);
        }
    }
    CwDC5RzZJIV = xNLhAG[(835 - 835)];
    cout << '(' << CwDC5RzZJIV << ',';
    kiHETN1 = (24 - 23);
    {
        int rN6YQtgOe1;
        rN6YQtgOe1 = (322 - 321);
        for (; f7bEUva1 > rN6YQtgOe1;) {
            if (xNLhAG[rN6YQtgOe1] == xNLhAG[rN6YQtgOe1 - (106 - 105)])
                kiHETN1 = kiHETN1 + (844 - 843);
            else {
                cout << kiHETN1 << ')';
                kiHETN1 = (149 - 148);
                CwDC5RzZJIV = xNLhAG[rN6YQtgOe1];
                cout << '(' << CwDC5RzZJIV << ',';
            }
            rN6YQtgOe1 = rN6YQtgOe1 + (72 - 71);
        }
    }
    cout << kiHETN1 << ')' << endl;
    return (778 - 778);
}

