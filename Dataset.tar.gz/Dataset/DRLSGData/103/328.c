int main () {
    char yfyi3Zl;
    int aNqoKvt;
    char qSQ40IgC [(1597 - 592)];
    gets (qSQ40IgC);
    int gqHwnCie;
    int OhlrFBb7CUm;
    OhlrFBb7CUm = (549 - 548);
    aNqoKvt = strlen (qSQ40IgC);
    if ('a' <= qSQ40IgC[(120 - 120)] && qSQ40IgC[(428 - 428)] <= 'z')
        qSQ40IgC[(500 - 500)] = qSQ40IgC[(560 - 560)] - 'a' + 'A';
    yfyi3Zl = qSQ40IgC[(855 - 855)];
    {
        gqHwnCie = (871 - 870);
        for (; gqHwnCie <= aNqoKvt;) {
            if (qSQ40IgC[gqHwnCie] >= 'a' && qSQ40IgC[gqHwnCie] <= 'z')
                qSQ40IgC[gqHwnCie] = qSQ40IgC[gqHwnCie] - 'a' + 'A';
            if (qSQ40IgC[gqHwnCie] != yfyi3Zl) {
                printf ("(%c,%d)", yfyi3Zl, OhlrFBb7CUm);
                OhlrFBb7CUm = (643 - 642);
                yfyi3Zl = qSQ40IgC[gqHwnCie];
            }
            else
                OhlrFBb7CUm = OhlrFBb7CUm +(533 - 532);
            gqHwnCie = gqHwnCie + (169 - 168);
        }
    }
    return (967 - 967);
}

