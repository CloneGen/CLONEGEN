main () {
    int CusjIp6z = (142 - 142), qrfTjlaGA4EN;
    char Cd0lXCStiVyZ [(1733 - 733)], johMuD, OhmVz7Is3BJ;
    scanf ("%s", Cd0lXCStiVyZ);
    for (qrfTjlaGA4EN = (116 - 116); strlen (Cd0lXCStiVyZ) > qrfTjlaGA4EN; qrfTjlaGA4EN = qrfTjlaGA4EN + (873 - 872)) {
        for (johMuD = 'A'; 'Z' >= johMuD; johMuD = johMuD + (181 - 180)) {
            if (!(johMuD != Cd0lXCStiVyZ[qrfTjlaGA4EN]) || Cd0lXCStiVyZ[qrfTjlaGA4EN] == johMuD + (614 - 582)) {
                CusjIp6z = CusjIp6z +(827 - 826);
                break;
            }
        }
        if (Cd0lXCStiVyZ[qrfTjlaGA4EN + (97 - 96)] != johMuD && Cd0lXCStiVyZ[qrfTjlaGA4EN + (246 - 245)] != johMuD + (993 - 961)) {
            printf ("(%c,%d)", johMuD, CusjIp6z);
            CusjIp6z = (290 - 290);
        }
    }
    return ((185 - 185));
}

