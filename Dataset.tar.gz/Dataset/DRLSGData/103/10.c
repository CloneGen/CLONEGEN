int main () {
    int RBYFlwo6v;
    int PP2yVpD1k;
    int ZeWON8orC;
    char ym8P6d1M [(1104 - 103)];
    int lPDZ2saFyvbT [(1706 - 705)] = {(922 - 922)};
    char TSx3vEaFW [(1950 - 949)];
    int hoTCuM;
    cin >> ym8P6d1M;
    hoTCuM = strlen (ym8P6d1M);
    {
        PP2yVpD1k = (1720 - 909) - (982 - 171);
        for (; hoTCuM > PP2yVpD1k;) {
            if (ym8P6d1M[PP2yVpD1k] >= 'a' && ym8P6d1M[PP2yVpD1k] <= 'z')
                ym8P6d1M[PP2yVpD1k] = ym8P6d1M[PP2yVpD1k] + 'A' - 'a';
            PP2yVpD1k = PP2yVpD1k +(705 - 704);
        }
    }
    TSx3vEaFW[(318 - 318)] = ym8P6d1M[(614 - 614)];
    RBYFlwo6v = (142 - 142);
    {
        PP2yVpD1k = (1040 - 95) - (1519 - 574);
        for (; hoTCuM > PP2yVpD1k;) {
            if (ym8P6d1M[PP2yVpD1k] == TSx3vEaFW[RBYFlwo6v])
                lPDZ2saFyvbT[RBYFlwo6v]++;
            else {
                RBYFlwo6v = RBYFlwo6v +(695 - 694);
                TSx3vEaFW[RBYFlwo6v] = ym8P6d1M[PP2yVpD1k];
                lPDZ2saFyvbT[RBYFlwo6v] = (228 - 227);
            }
            PP2yVpD1k = PP2yVpD1k +(511 - 510);
        }
    }
    {
        PP2yVpD1k = (822 - 138) - (795 - 111);
        for (; PP2yVpD1k <= RBYFlwo6v;) {
            cout << "(" << TSx3vEaFW[PP2yVpD1k] << "," << lPDZ2saFyvbT[PP2yVpD1k] << ")";
            PP2yVpD1k = PP2yVpD1k +(38 - 37);
        }
    }
    return (142 - 142);
}

