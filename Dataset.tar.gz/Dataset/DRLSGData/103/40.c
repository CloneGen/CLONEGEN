int main () {
    int iB2dSzGQp;
    int muLCle5;
    int hbYxmzvJr8;
    char GK1tnaq3M [(1895 - 895)];
    int NG0kly [(1690 - 690)] = {(733 - 733)};
    char ZHJ9y5RXGs0 [(1764 - 764)] = {'a'};
    iB2dSzGQp = (962 - 962);
    muLCle5 = (898 - 898);
    cin.getline (GK1tnaq3M, (10412 - 411), '\n');
    muLCle5 = strlen (GK1tnaq3M);
    {
        hbYxmzvJr8 = (728 - 728);
        for (; muLCle5 > hbYxmzvJr8;) {
            if (GK1tnaq3M[hbYxmzvJr8] >= 'a' && GK1tnaq3M[hbYxmzvJr8] <= 'z')
                GK1tnaq3M[hbYxmzvJr8] = GK1tnaq3M[hbYxmzvJr8] + 'A' - 'a';
            hbYxmzvJr8 = hbYxmzvJr8 + (724 - 723);
        }
    }
    {
        hbYxmzvJr8 = (1754 - 904) - (924 - 74);
        for (; hbYxmzvJr8 < muLCle5;) {
            if (!((391 - 391) != hbYxmzvJr8)) {
                ZHJ9y5RXGs0[iB2dSzGQp] = GK1tnaq3M[hbYxmzvJr8];
                NG0kly[iB2dSzGQp] = (66 - 65);
            }
            if (!(GK1tnaq3M[hbYxmzvJr8 - (195 - 194)] != GK1tnaq3M[hbYxmzvJr8]) && hbYxmzvJr8 != (666 - 666))
                NG0kly[iB2dSzGQp]++;
            if (GK1tnaq3M[hbYxmzvJr8] != GK1tnaq3M[hbYxmzvJr8 + (269 - 268)]) {
                ZHJ9y5RXGs0[++iB2dSzGQp] = GK1tnaq3M[hbYxmzvJr8 + (926 - 925)];
                NG0kly[iB2dSzGQp] = (632 - 631);
            }
            hbYxmzvJr8 = hbYxmzvJr8 + (310 - 309);
        }
    }
    {
        hbYxmzvJr8 = (476 - 476);
        for (; iB2dSzGQp > hbYxmzvJr8;) {
            cout << '(' << ZHJ9y5RXGs0[hbYxmzvJr8] << ',' << NG0kly[hbYxmzvJr8] << ')';
            hbYxmzvJr8 = hbYxmzvJr8 + (594 - 593);
        }
    }
    cout << endl;
    return (993 - 993);
}

