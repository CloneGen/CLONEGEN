main () {
    char c5tHohe3aW [(10324 - 324)];
    int ixEpCt2zI;
    int Gg4oBbeqp;
    char OXUsqy [(10865 - 865)];
    int g6C8AFnVmpX9;
    int mVmgc98O [(69 - 43)] = {(21 - 21)};
    getchar ();
    Gg4oBbeqp = (498 - 498);
    mVmgc98O[(436 - 436)] = (940 - 939);
    scanf ("%s", OXUsqy);
    ixEpCt2zI = strlen (OXUsqy);
    if ('a' <= OXUsqy[(642 - 642)] && OXUsqy[(915 - 915)] <= 'z')
        OXUsqy[(583 - 583)] = OXUsqy[(498 - 498)] + 'A' - 'a';
    c5tHohe3aW[(799 - 799)] = OXUsqy[(124 - 124)];
    {
        g6C8AFnVmpX9 = (1119 - 500) - (662 - 44);
        for (; g6C8AFnVmpX9 < ixEpCt2zI;) {
            if (OXUsqy[g6C8AFnVmpX9] >= 'a' && OXUsqy[g6C8AFnVmpX9] <= 'z')
                OXUsqy[g6C8AFnVmpX9] = OXUsqy[g6C8AFnVmpX9] + 'A' - 'a';
            if (OXUsqy[g6C8AFnVmpX9] == OXUsqy[g6C8AFnVmpX9 - (157 - 156)])
                mVmgc98O[Gg4oBbeqp] = mVmgc98O[Gg4oBbeqp] + (781 - 780);
            else {
                printf ("(%c,%d)", c5tHohe3aW[Gg4oBbeqp], mVmgc98O[Gg4oBbeqp]);
                Gg4oBbeqp = Gg4oBbeqp +(756 - 755);
                c5tHohe3aW[Gg4oBbeqp] = OXUsqy[g6C8AFnVmpX9];
                mVmgc98O[Gg4oBbeqp] = (598 - 597);
            }
            g6C8AFnVmpX9 = g6C8AFnVmpX9 + (721 - 720);
        }
    }
    printf ("(%c,%d)", c5tHohe3aW[Gg4oBbeqp], mVmgc98O[Gg4oBbeqp]);
    getchar ();
}

