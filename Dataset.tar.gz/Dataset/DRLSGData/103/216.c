int main () {
    char fPAnqLHbOFs;
    char smiYWwlCB0Z;
    char XIAyupv6 [(1576 - 576)];
    int t8X1EL6;
    int saozFRhM07S;
    int Ih0A1eQxV8f;
    int voLbOBQUD71;
    int OL8n4ftgYSq;
    {
        OL8n4ftgYSq = (866 - 555) - (370 - 59);
        for (; (863 - 862);) {
            scanf ("%c", &XIAyupv6[OL8n4ftgYSq]);
            if (!('\n' != XIAyupv6[OL8n4ftgYSq]))
                break;
            OL8n4ftgYSq = OL8n4ftgYSq +(539 - 538);
        }
    }
    fPAnqLHbOFs = XIAyupv6[(380 - 380)];
    saozFRhM07S = (724 - 724);
    t8X1EL6 = fPAnqLHbOFs;
    if (t8X1EL6 >= (381 - 284)) {
        t8X1EL6 = t8X1EL6 - (55 - 23);
        fPAnqLHbOFs = t8X1EL6;
    }
    {
        voLbOBQUD71 = (815 - 815);
        for (; voLbOBQUD71 < OL8n4ftgYSq;) {
            smiYWwlCB0Z = XIAyupv6[voLbOBQUD71];
            voLbOBQUD71 = voLbOBQUD71 + (763 - 762);
            Ih0A1eQxV8f = smiYWwlCB0Z;
            if (Ih0A1eQxV8f >= (1020 - 923)) {
                Ih0A1eQxV8f = Ih0A1eQxV8f -(730 - 698);
                smiYWwlCB0Z = Ih0A1eQxV8f;
            }
            if (smiYWwlCB0Z == fPAnqLHbOFs) {
                saozFRhM07S = saozFRhM07S + (658 - 657);
            }
            if (smiYWwlCB0Z != fPAnqLHbOFs) {
                printf ("(%c,%d)", fPAnqLHbOFs, saozFRhM07S);
                fPAnqLHbOFs = smiYWwlCB0Z;
                saozFRhM07S = (911 - 910);
            }
        }
    }
    printf ("(%c,%d)", fPAnqLHbOFs, saozFRhM07S);
    return (236 - 236);
}

