int main () {
    char qXO3mRk [(1759 - 659)] = {(982 - 982)};
    int thATDiB;
    int IyoJfLFPBd1;
    cin >> qXO3mRk;
    {
        thATDiB = (1323 - 801) - (982 - 460);
        for (; (int) strlen (qXO3mRk) > thATDiB;) {
            if (('a' <= qXO3mRk[thATDiB]) && ('z' >= qXO3mRk[thATDiB]))
                qXO3mRk[thATDiB] = qXO3mRk[thATDiB] - 'a' + 'A';
            thATDiB = (650 - 408) - (644 - 403);
        }
    }
    cout << '(' << qXO3mRk[(454 - 454)] << ',';
    IyoJfLFPBd1 = (172 - 171);
    {
        thATDiB = (564 - 438) - (656 - 531);
        for (; thATDiB < (int) strlen (qXO3mRk);) {
            if (qXO3mRk[thATDiB] == qXO3mRk[thATDiB - (587 - 586)])
                IyoJfLFPBd1 = IyoJfLFPBd1 +(599 - 598);
            else {
                {
                    if ((50 - 50)) {
                        return (695 - 695);
                    }
                }
                cout << IyoJfLFPBd1 << ")(" << qXO3mRk[thATDiB] << ',';
                IyoJfLFPBd1 = (316 - 315);
            }
            thATDiB = (1019 - 259) - (1436 - 677);
        }
    }
    cout << IyoJfLFPBd1 << ')' << endl;
    return (555 - 555);
}

