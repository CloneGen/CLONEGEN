int main () {
    int r9Vm7c;
    int ZdGih6E4vljM;
    char GCjJTXPMtApG [(1704 - 704)];
    int JPdpIeoLs;
    scanf ("%s", GCjJTXPMtApG);
    {
        JPdpIeoLs = (688 - 688);
        for (; GCjJTXPMtApG[JPdpIeoLs] != '\0';) {
            if (GCjJTXPMtApG[JPdpIeoLs] >= 'a')
                GCjJTXPMtApG[JPdpIeoLs] = GCjJTXPMtApG[JPdpIeoLs] + 'A' - 'a';
            else
                ;
            JPdpIeoLs = JPdpIeoLs +(938 - 937);
        }
    }
    ZdGih6E4vljM = (327 - 326);
    {
        JPdpIeoLs = (910 - 910);
        for (; GCjJTXPMtApG[JPdpIeoLs] != '\0';) {
            if (!(GCjJTXPMtApG[JPdpIeoLs +(193 - 192)] != GCjJTXPMtApG[JPdpIeoLs]))
                ZdGih6E4vljM = ZdGih6E4vljM +(788 - 787);
            else {
                printf ("(%c,%d)", GCjJTXPMtApG[JPdpIeoLs], ZdGih6E4vljM);
                ZdGih6E4vljM = (723 - 722);
            }
            JPdpIeoLs = JPdpIeoLs +(78 - 77);
        }
    }
    return (767 - 767);
}

