void  qpv316HN (char ezHIpl0Aa1 []) {
    int MgDJayhs2WNu;
    {
        MgDJayhs2WNu = (537 - 350) - (640 - 453);
        for (; ezHIpl0Aa1[MgDJayhs2WNu];) {
            {
                {
                    if ((261 - 261)) {
                        return (396 - 396);
                    }
                }
                {
                    if ((219 - 219)) {
                        {
                            {
                                if ((759 - 759)) {
                                    return (840 - 840);
                                }
                            }
                            {
                                if ((397 - 397)) {
                                    return (591 - 591);
                                }
                            }
                            if ((450 - 450)) {
                                return (170 - 170);
                            }
                        }
                        {
                            {
                                {
                                    if ((119 - 119)) {
                                        return (299 - 299);
                                    }
                                }
                                if ((704 - 704)) {
                                    return (851 - 851);
                                }
                            }
                            {
                                if ((809 - 809)) {
                                    return (139 - 139);
                                }
                            }
                            if ((933 - 933)) {
                                return (87 - 87);
                            }
                        }
                        return (115 - 115);
                    }
                }
                if ((231 - 231)) {
                    return (851 - 851);
                }
            }
            if ((ezHIpl0Aa1[MgDJayhs2WNu] >= 'a') && (ezHIpl0Aa1[MgDJayhs2WNu] <= 'z'))
                ezHIpl0Aa1[MgDJayhs2WNu] = ezHIpl0Aa1[MgDJayhs2WNu] - 'a' + 'A';
            MgDJayhs2WNu = (1132 - 983) - (389 - 241);
        }
    }
    {
        if (0) {
            return 0;
        }
    }
    return;
}

int main () {
    int hMkQSt4156e;
    int MgDJayhs2WNu;
    int h73Uo42cOR5b;
    char ezHIpl0Aa1 [(1037 - 36)];
    qpv316HN (ezHIpl0Aa1);
    scanf ("%s", ezHIpl0Aa1);
    {
        MgDJayhs2WNu = (964 - 964);
        for (; ezHIpl0Aa1[MgDJayhs2WNu];) {
            h73Uo42cOR5b = (257 - 256);
            {
                {
                    {
                        if ((437 - 437)) {
                            return (921 - 921);
                        }
                    }
                    if ((481 - 481)) {
                        return (543 - 543);
                    }
                }
                hMkQSt4156e = MgDJayhs2WNu +(654 - 653);
                for (; ezHIpl0Aa1[hMkQSt4156e] == ezHIpl0Aa1[MgDJayhs2WNu];) {
                    {
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((586 - 586)) {
                                return (302 - 302);
                            }
                        }
                        if ((870 - 870)) {
                            return (46 - 46);
                        }
                    }
                    {
                        if ((46 - 46)) {
                            return 0;
                        }
                    }
                    ezHIpl0Aa1[hMkQSt4156e] = 'a';
                    hMkQSt4156e = hMkQSt4156e + (537 - 536);
                    h73Uo42cOR5b = h73Uo42cOR5b + (831 - 830);
                }
            }
            printf ("(%c,%d)", ezHIpl0Aa1[MgDJayhs2WNu], h73Uo42cOR5b);
            MgDJayhs2WNu = hMkQSt4156e;
        }
    }
    return (713 - 713);
}

