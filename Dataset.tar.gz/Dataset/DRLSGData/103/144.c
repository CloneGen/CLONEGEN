main () {
    int x3Dpd1th;
    int CaSmE5WYZN4u;
    char CRHJ5yFKdnUO [MAX];
    char shM1HBfb;
    int LOeNRqadkw;
    x3Dpd1th = (589 - 589);
    scanf ("%s", CRHJ5yFKdnUO);
    {
        LOeNRqadkw = (640 - 640);
        for (; (448 - 447);) {
            if ((LOeNRqadkw != (930 - 930)) && (!(CRHJ5yFKdnUO[LOeNRqadkw -(198 - 197)] != CRHJ5yFKdnUO[LOeNRqadkw]) || !(CRHJ5yFKdnUO[LOeNRqadkw -(129 - 128)] - (545 - 513) != CRHJ5yFKdnUO[LOeNRqadkw]) || !(CRHJ5yFKdnUO[LOeNRqadkw -(801 - 800)] + (672 - 640) != CRHJ5yFKdnUO[LOeNRqadkw]))) {
                CaSmE5WYZN4u = CaSmE5WYZN4u +(668 - 667);
            }
            else {
                if (CRHJ5yFKdnUO[LOeNRqadkw] >= 'A' && 'Z' >= CRHJ5yFKdnUO[LOeNRqadkw]) {
                    if (x3Dpd1th)
                        printf ("(%c,%d)", shM1HBfb, CaSmE5WYZN4u);
                    CaSmE5WYZN4u = (98 - 97);
                    x3Dpd1th = (594 - 593);
                    shM1HBfb = CRHJ5yFKdnUO[LOeNRqadkw];
                }
                else {
                    if (x3Dpd1th)
                        printf ("(%c,%d)", shM1HBfb, CaSmE5WYZN4u);
                    x3Dpd1th = (571 - 570);
                    shM1HBfb = CRHJ5yFKdnUO[LOeNRqadkw] - (165 - 133);
                    CaSmE5WYZN4u = (998 - 997);
                }
            }
            if (!('\0' != CRHJ5yFKdnUO[LOeNRqadkw]))
                break;
            LOeNRqadkw = LOeNRqadkw +(924 - 923);
        }
    }
}

