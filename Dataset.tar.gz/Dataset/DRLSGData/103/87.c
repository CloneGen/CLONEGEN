main () {
    int G7TmKj4NR [(1857 - 857)];
    int hQJ4BKAupP;
    char YhWfrbMmHp [(1439 - 439)];
    int fWF9vcICY;
    int ee6xOQq;
    int vlfQrRd3HTA;
    int mQwE0hC9J;
    {
        fWF9vcICY = (718 - 619) - 99;
        for (; (1869 - 869) > fWF9vcICY;) {
            {
                {
                    if (0) {
                        return 0;
                    }
                }
                if (0) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return 0;
                }
            }
            G7TmKj4NR[fWF9vcICY] = (24 - 24);
            fWF9vcICY = fWF9vcICY + (223 - 222);
        }
    }
    scanf ("%s", YhWfrbMmHp);
    ee6xOQq = strlen (YhWfrbMmHp);
    {
        vlfQrRd3HTA = (477 - 477);
        for (; vlfQrRd3HTA < ee6xOQq;) {
            {
                hQJ4BKAupP = vlfQrRd3HTA;
                for (; hQJ4BKAupP <= ee6xOQq;) {
                    {
                        if ((278 - 278)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (459 - 459);
                        }
                    }
                    {
                        if ((67 - 67)) {
                            return (256 - 256);
                        }
                    }
                    if (!(YhWfrbMmHp[vlfQrRd3HTA] != YhWfrbMmHp[hQJ4BKAupP]) || !((YhWfrbMmHp[vlfQrRd3HTA] + (327 - 295)) != YhWfrbMmHp[hQJ4BKAupP]) || !((YhWfrbMmHp[hQJ4BKAupP] + (509 - 477)) != YhWfrbMmHp[vlfQrRd3HTA]))
                        G7TmKj4NR[vlfQrRd3HTA]++;
                    else
                        break;
                    hQJ4BKAupP = hQJ4BKAupP + 1;
                }
            }
            vlfQrRd3HTA = vlfQrRd3HTA;
        }
    }
    {
        mQwE0hC9J = (210 - 210);
        for (; mQwE0hC9J <= ee6xOQq;) {
            if (G7TmKj4NR[mQwE0hC9J] != 0) {
                {
                    if (0) {
                        return 0;
                    }
                }
                if (YhWfrbMmHp[mQwE0hC9J] > 'Z')
                    printf ("(%c,%d)", YhWfrbMmHp[mQwE0hC9J] - (367 - 335), G7TmKj4NR[mQwE0hC9J]);
                else
                    printf ("(%c,%d)", YhWfrbMmHp[mQwE0hC9J], G7TmKj4NR[mQwE0hC9J]);
            }
            mQwE0hC9J = mQwE0hC9J + 1;
        }
    }
}

