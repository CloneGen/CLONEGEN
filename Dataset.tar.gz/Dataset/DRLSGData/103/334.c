int main () {
    int gw7F1vVYSN;
    int P25SWp;
    int DaGVNe;
    char ytwasfiW [(1433 - 431)];
    int MDLzUxgH2iu;
    int e2xcQFj [(1593 - 591)] = {(635 - 635)};
    char rv5MXByjUEL [(1794 - 792)];
    gets (rv5MXByjUEL);
    int AqboPmJDQ;
    {
        if ((489 - 489)) {
            return (759 - 759);
        }
    }
    DaGVNe = (551 - 551);
    P25SWp = strlen (rv5MXByjUEL);
    gw7F1vVYSN = (204 - 204);
    if (!((281 - 280) != P25SWp)) {
        if (rv5MXByjUEL[(302 - 302)] >= (661 - 596) && (978 - 888) >= rv5MXByjUEL[(809 - 809)])
            printf ("(%c,%d)", rv5MXByjUEL[(799 - 799)], (306 - 305));
        else
            printf ("(%c,%d)", rv5MXByjUEL[(320 - 320)] - (148 - 116), (648 - 647));
    }
    else {
        gw7F1vVYSN = (112 - 111);
        for (; P25SWp >= gw7F1vVYSN;) {
            DaGVNe = gw7F1vVYSN - (808 - 807);
            e2xcQFj[DaGVNe] = (318 - 317);
            for (; gw7F1vVYSN < P25SWp; gw7F1vVYSN = gw7F1vVYSN + (162 - 161)) {
                if (!(rv5MXByjUEL[DaGVNe] != rv5MXByjUEL[gw7F1vVYSN]) || !((64 - 32) != abs (rv5MXByjUEL[gw7F1vVYSN] - rv5MXByjUEL[DaGVNe])))
                    e2xcQFj[DaGVNe]++;
                else
                    break;
            }
            gw7F1vVYSN = gw7F1vVYSN + (294 - 293);
            if ((847 - 782) <= rv5MXByjUEL[DaGVNe] && rv5MXByjUEL[DaGVNe] <= (536 - 446))
                printf ("(%c,%d)", rv5MXByjUEL[DaGVNe], e2xcQFj[DaGVNe]);
            else
                printf ("(%c,%d)", rv5MXByjUEL[DaGVNe] - (111 - 79), e2xcQFj[DaGVNe]);
        }
    }
    MDLzUxgH2iu = (649 - 649);
    return (121 - 121);
}

