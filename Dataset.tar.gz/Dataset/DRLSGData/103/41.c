int main () {
    char x6QWcDX;
    int UoP9gXSdbs;
    char wMzV5v [(1186 - 185)];
    int VU4BahKbNR;
    char vzusGFjZk0Tn;
    int ssJWPt4MY;
    ssJWPt4MY = (454 - 453);
    vzusGFjZk0Tn = wMzV5v[(211 - 211)];
    cin.getline (wMzV5v, (1174 - 173));
    UoP9gXSdbs = strlen (wMzV5v);
    if (!((944 - 943) != UoP9gXSdbs)) {
        if ('z' >= vzusGFjZk0Tn && 'a' <= vzusGFjZk0Tn) {
            x6QWcDX = vzusGFjZk0Tn + 'A' - 'a';
            cout << "(" << x6QWcDX << "," << ssJWPt4MY << ")";
        }
        else
            cout << "(" << vzusGFjZk0Tn << "," << ssJWPt4MY << ")";
    }
    {
        VU4BahKbNR = (666 - 665);
        for (; wMzV5v[VU4BahKbNR] != '\0';) {
            if (!(wMzV5v[VU4BahKbNR] != vzusGFjZk0Tn) || !(vzusGFjZk0Tn + 'A' - 'a' != wMzV5v[VU4BahKbNR]) || !(vzusGFjZk0Tn + 'a' - 'A' != wMzV5v[VU4BahKbNR])) {
                ssJWPt4MY = ssJWPt4MY + (106 - 105);
                if (!(UoP9gXSdbs -(536 - 535) != VU4BahKbNR))
                    if ('z' >= vzusGFjZk0Tn && vzusGFjZk0Tn >= 'a') {
                        x6QWcDX = vzusGFjZk0Tn + 'A' - 'a';
                        cout << "(" << x6QWcDX << "," << ssJWPt4MY << ")";
                    }
                    else
                        cout << "(" << vzusGFjZk0Tn << "," << ssJWPt4MY << ")";
            }
            else {
                {
                    if ((558 - 558)) {
                        return (26 - 26);
                    }
                }
                if ('z' >= vzusGFjZk0Tn && 'a' <= vzusGFjZk0Tn) {
                    x6QWcDX = vzusGFjZk0Tn + 'A' - 'a';
                    cout << "(" << x6QWcDX << "," << ssJWPt4MY << ")";
                }
                else
                    cout << "(" << vzusGFjZk0Tn << "," << ssJWPt4MY << ")";
                ssJWPt4MY = (268 - 267);
                vzusGFjZk0Tn = wMzV5v[VU4BahKbNR];
                if (!(UoP9gXSdbs -(631 - 630) != VU4BahKbNR))
                    if ('z' >= vzusGFjZk0Tn && 'a' <= vzusGFjZk0Tn) {
                        x6QWcDX = vzusGFjZk0Tn + 'A' - 'a';
                        cout << "(" << x6QWcDX << "," << ssJWPt4MY << ")";
                    }
                    else
                        cout << "(" << vzusGFjZk0Tn << "," << ssJWPt4MY << ")";
            }
            VU4BahKbNR = VU4BahKbNR +(141 - 140);
        }
    }
    return (468 - 468);
}

