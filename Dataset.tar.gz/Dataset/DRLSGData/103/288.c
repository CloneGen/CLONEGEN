int main () {
    char qeYFMgImojJ [(1984 - 984)] = {(75 - 75)};
    int HaO28mHN3Y;
    int wFCnim3qS04;
    int XEXd7MQbrI;
    {
        if ((327 - 327)) {
            return (911 - 911);
        }
    }
    HaO28mHN3Y = (882 - 881);
    cin >> qeYFMgImojJ;
    XEXd7MQbrI = strlen (qeYFMgImojJ);
    {
        wFCnim3qS04 = (1448 - 692) - (798 - 42);
        for (; XEXd7MQbrI > wFCnim3qS04;) {
            if (qeYFMgImojJ[wFCnim3qS04] >= 'a' && 'z' >= qeYFMgImojJ[wFCnim3qS04])
                qeYFMgImojJ[wFCnim3qS04] = qeYFMgImojJ[wFCnim3qS04] + ('A' - 'a');
            wFCnim3qS04 = wFCnim3qS04 + (162 - 161);
        }
    }
    {
        wFCnim3qS04 = (449 - 277) - (1139 - 968);
        for (; wFCnim3qS04 <= XEXd7MQbrI;) {
            if (qeYFMgImojJ[wFCnim3qS04] == qeYFMgImojJ[wFCnim3qS04 - (527 - 526)])
                HaO28mHN3Y = HaO28mHN3Y +(580 - 579);
            else {
                cout << "(" << qeYFMgImojJ[wFCnim3qS04 - (753 - 752)] << "," << HaO28mHN3Y << ")";
                HaO28mHN3Y = (341 - 340);
            }
            wFCnim3qS04 = wFCnim3qS04 + (379 - 378);
        }
    }
    return (718 - 718);
}

