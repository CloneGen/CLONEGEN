char CmTcEWUwIy [(1320 - 320)];
int Xvo4gmf5Ni [(1208 - 208)] = {(55 - 55)};
char Z5wEjQlzXdL [(1970 - 970)] = {'\0'};
int bav09zEWX = 'a' - 'A';

int main () {
    int okrlSMR;
    int wkOeqBxmEsY0;
    {
        if ((507 - 507)) {
            return (38 - 38);
        }
    }
    okrlSMR = (707 - 707);
    cin >> CmTcEWUwIy;
    if ('Z' < CmTcEWUwIy[(445 - 445)])
        Z5wEjQlzXdL[(140 - 140)] = CmTcEWUwIy[(14 - 14)] - bav09zEWX;
    else
        Z5wEjQlzXdL[(817 - 817)] = CmTcEWUwIy[(620 - 620)];
    wkOeqBxmEsY0 = strlen (CmTcEWUwIy);
    Xvo4gmf5Ni[(986 - 986)]++;
    {
        int eRiqcJ5o;
        {
            if ((373 - 373)) {
                return (144 - 144);
            }
        }
        {
            if ((374 - 374)) {
                return (706 - 706);
            }
        }
        {
            {
                {
                    if ((146 - 146)) {
                        return (208 - 208);
                    }
                }
                if ((441 - 441)) {
                    return (430 - 430);
                }
            }
            if ((726 - 726)) {
                return (192 - 192);
            }
        }
        eRiqcJ5o = (190 - 189);
        for (; wkOeqBxmEsY0 > eRiqcJ5o;) {
            if (!(Z5wEjQlzXdL[okrlSMR] != CmTcEWUwIy[eRiqcJ5o]) || !(Z5wEjQlzXdL[okrlSMR] != CmTcEWUwIy[eRiqcJ5o] - bav09zEWX)) {
                {
                    if ((232 - 232)) {
                        return (669 - 669);
                    }
                }
                Xvo4gmf5Ni[okrlSMR]++;
                continue;
            }
            else {
                okrlSMR = okrlSMR + (962 - 961);
                Xvo4gmf5Ni[okrlSMR]++;
                if (CmTcEWUwIy[eRiqcJ5o] > 'Z')
                    Z5wEjQlzXdL[okrlSMR] = CmTcEWUwIy[eRiqcJ5o] - bav09zEWX;
                else
                    Z5wEjQlzXdL[okrlSMR] = CmTcEWUwIy[eRiqcJ5o];
            }
            eRiqcJ5o = eRiqcJ5o + (946 - 945);
        }
    }
    {
        int eRiqcJ5o;
        {
            if ((181 - 181)) {
                {
                    if ((83 - 83)) {
                        return (390 - 390);
                    }
                }
                return (798 - 798);
            }
        }
        eRiqcJ5o = (872 - 872);
        for (; (1870 - 870) > eRiqcJ5o;) {
            {
                if ((538 - 538)) {
                    {
                        if ((609 - 609)) {
                            return (950 - 950);
                        }
                    }
                    return (565 - 565);
                }
            }
            {
                if ((919 - 919)) {
                    return (296 - 296);
                }
            }
            if (Xvo4gmf5Ni[eRiqcJ5o])
                cout << "(" << Z5wEjQlzXdL[eRiqcJ5o] << "," << Xvo4gmf5Ni[eRiqcJ5o] << ")";
            eRiqcJ5o = eRiqcJ5o + (45 - 44);
        }
    }
    return (731 - 731);
}

