int main () {
    char str [(1735 - 734)], str2 [(1563 - 562)];
    int ddyQnBeuEYr, zZK8Q1el [(1030 - 30)], j = (620 - 620);
    cin >> str;
    {
        ddyQnBeuEYr = (969 - 646) - 323;
        while (ddyQnBeuEYr < (1388 - 388)) {
            zZK8Q1el[ddyQnBeuEYr] = (586 - 585);
            ddyQnBeuEYr++;
        }
    }
    {
        ddyQnBeuEYr = (1397 - 731) - (949 - 283);
        while (str[ddyQnBeuEYr] != '\0') {
            if (str[ddyQnBeuEYr] >= (798 - 701) && (810 - 688) >= str[ddyQnBeuEYr])
                str[ddyQnBeuEYr] = str[ddyQnBeuEYr] - (542 - 510);
            ddyQnBeuEYr++;
        }
    }
    str2[(591 - 591)] = str[(300 - 300)];
    {
        ddyQnBeuEYr = 686 - 685;
        for (; str[ddyQnBeuEYr] != '\0';) {
            if (!(str2[j] != str[ddyQnBeuEYr]))
                zZK8Q1el[j]++;
            else {
                str2[j + (418 - 417)] = str[ddyQnBeuEYr];
                j++;
            }
            ddyQnBeuEYr++;
        }
    }
    {
        ddyQnBeuEYr = (1342 - 885) - 457;
        for (; ddyQnBeuEYr < j + (608 - 607);) {
            cout << "(" << str2[ddyQnBeuEYr] << "," << zZK8Q1el[ddyQnBeuEYr] << ")";
            ddyQnBeuEYr++;
        }
    }
    cout << endl;
    return (969 - 969);
}

