int main () {
    int hzVTgXOe [(1367 - 367)];
    int q2Yobe67ndHx;
    int XcIW4t0nS;
    char WzvCrl [(1928 - 928)];
    int qvXwGafP4u3;
    char lNWCIKUg [(1716 - 716)];
    q2Yobe67ndHx = (958 - 958);
    getchar ();
    getchar ();
    scanf ("%s", lNWCIKUg);
    {
        qvXwGafP4u3 = (506 - 395) - (414 - 303);
        for (; lNWCIKUg[qvXwGafP4u3] != '\0';) {
            if (lNWCIKUg[qvXwGafP4u3] >= 'a' && 'z' >= lNWCIKUg[qvXwGafP4u3])
                lNWCIKUg[qvXwGafP4u3] = lNWCIKUg[qvXwGafP4u3] - (987 - 955);
            if ('A' <= lNWCIKUg[qvXwGafP4u3] && lNWCIKUg[qvXwGafP4u3] <= 'Z')
                lNWCIKUg[qvXwGafP4u3] = lNWCIKUg[qvXwGafP4u3];
            qvXwGafP4u3 = qvXwGafP4u3 + (885 - 884);
        }
    }
    WzvCrl[(391 - 391)] = lNWCIKUg[(825 - 825)];
    {
        qvXwGafP4u3 = (279 - 279);
        for (; lNWCIKUg[qvXwGafP4u3] != '\0';) {
            if (lNWCIKUg[qvXwGafP4u3] == WzvCrl[q2Yobe67ndHx])
                hzVTgXOe[q2Yobe67ndHx]++;
            else {
                q2Yobe67ndHx = q2Yobe67ndHx + (600 - 599);
                WzvCrl[q2Yobe67ndHx] = lNWCIKUg[qvXwGafP4u3];
                hzVTgXOe[q2Yobe67ndHx]++;
            }
            qvXwGafP4u3 = qvXwGafP4u3 + (138 - 137);
        }
    }
    {
        qvXwGafP4u3 = (842 - 842);
        for (; qvXwGafP4u3 <= q2Yobe67ndHx;) {
            printf ("(%c,%d)", WzvCrl[qvXwGafP4u3], hzVTgXOe[qvXwGafP4u3]);
            qvXwGafP4u3 = qvXwGafP4u3 + (669 - 668);
        }
    }
}

