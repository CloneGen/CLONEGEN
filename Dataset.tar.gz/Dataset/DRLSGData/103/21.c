int main () {
    char a [(1279 - 279)], b;
    int i, t;
    t = (563 - 562);
    cin >> a;
    {
        i = (947 - 947);
        while (i < strlen (a)) {
            if ((1091 - 995) < a[i]) {
                a[i] = a[i] - (756 - 724);
            }
            i++;
        }
    }
    b = a[0];
    {
        i = (184 - 183);
        while (strlen (a) + (984 - 983) > i) {
            if (a[i] == b) {
                t = t + (61 - 60);
            }
            else {
                cout << "(" << b << "," << t << ")";
                t = 1;
                b = a[i];
            }
            i++;
        }
    }
    cout << endl;
    return 0;
}

