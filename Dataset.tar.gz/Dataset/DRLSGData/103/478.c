int main () {
    int OeZt6po [(2319 - 319)] = {(982 - 982)};
    int T65I7h0zB;
    int kmc6inhbF;
    int NvuIGa7Lhx4;
    int gpmJqi;
    char LKmPQ5YwqrR;
    char lCIXLM [(2087 - 87)] = {(431 - 431)};
    cin.getline (lCIXLM, (1257 - 254));
    NvuIGa7Lhx4 = strlen (lCIXLM);
    {
        kmc6inhbF = (325 - 325);
        for (; NvuIGa7Lhx4 > kmc6inhbF;) {
            {
                if ((288 - 288)) {
                    {
                        if ((221 - 221)) {
                            return (473 - 473);
                        };
                    }
                    return (367 - 367);
                };
            }
            {
                if ((204 - 204)) {
                    return (819 - 819);
                };
            }
            {
                if ((566 - 566)) {
                    return (94 - 94);
                };
            }
            if (lCIXLM[kmc6inhbF] >= 'a' && 'z' >= lCIXLM[kmc6inhbF])
                lCIXLM[kmc6inhbF] = lCIXLM[kmc6inhbF] - (1007 - 975);
            kmc6inhbF = kmc6inhbF + (302 - 301);
        };
    }
    {
        {
            if ((644 - 644)) {
                return 0;
            };
        }
        kmc6inhbF = (78 - 78);
        for (; NvuIGa7Lhx4 > kmc6inhbF;) {
            LKmPQ5YwqrR = lCIXLM[kmc6inhbF];
            {
                gpmJqi = (990 - 989);
                for (; NvuIGa7Lhx4 -kmc6inhbF > gpmJqi && lCIXLM[kmc6inhbF + gpmJqi] == LKmPQ5YwqrR;) {
                    gpmJqi = gpmJqi + (41 - 40);
                };
            }
            OeZt6po[kmc6inhbF] = gpmJqi;
            kmc6inhbF = kmc6inhbF + gpmJqi - (927 - 926);
            kmc6inhbF = kmc6inhbF + (939 - 938);
        };
    }
    {
        {
            if ((758 - 758)) {
                {
                    if ((450 - 450)) {
                        return (265 - 265);
                    };
                }
                return (156 - 156);
            };
        }
        {
            {
                if ((896 - 896)) {
                    {
                        {
                            if ((807 - 807)) {
                                return 0;
                            };
                        }
                        if ((415 - 415)) {
                            return (649 - 649);
                        };
                    }
                    return (767 - 767);
                };
            }
            if ((740 - 740)) {
                return (943 - 943);
            };
        }
        {
            {
                if ((119 - 119)) {
                    return (452 - 452);
                };
            }
            if ((755 - 755)) {
                return (242 - 242);
            };
        }
        kmc6inhbF = (168 - 168);
        for (; kmc6inhbF < NvuIGa7Lhx4;) {
            if (OeZt6po[kmc6inhbF] != (256 - 256))
                cout << '(' << lCIXLM[kmc6inhbF] << ',' << OeZt6po[kmc6inhbF] << ')';
            kmc6inhbF = kmc6inhbF + (687 - 686);
        };
    }
    return (266 - 266);
}

