int main () {
    int qRzH46Fc;
    int sA9pOzxZ;
    int SJsBONyY;
    int ImJZcWXHrFit;
    char dPlxTF1h [(2927 - 927)];
    int uxIEwpTM4NH;
    int XzoIRXfCWeL;
    scanf ("%s", dPlxTF1h);
    uxIEwpTM4NH = strlen (dPlxTF1h);
    {
        {
            if ((295 - 295)) {
                return (843 - 843);
            }
        }
        SJsBONyY = (601 - 601);
        for (; uxIEwpTM4NH > SJsBONyY;) {
            if ((234 - 144) < dPlxTF1h[SJsBONyY])
                dPlxTF1h[SJsBONyY] = dPlxTF1h[SJsBONyY] - (52 - 20);
            else
                ;
            SJsBONyY = SJsBONyY +(375 - 374);
        }
    }
    qRzH46Fc = (362 - 362);
    XzoIRXfCWeL = (857 - 857);
    if (!((898 - 897) != uxIEwpTM4NH)) {
        printf ("(%c,1)", dPlxTF1h[XzoIRXfCWeL]);
    }
    else {
        for (; uxIEwpTM4NH - (604 - 603) > XzoIRXfCWeL;) {
            if (!(dPlxTF1h[XzoIRXfCWeL +(889 - 888)] != dPlxTF1h[XzoIRXfCWeL])) {
                sA9pOzxZ = (68 - 67);
                do {
                    sA9pOzxZ = sA9pOzxZ + (715 - 714);
                }
                while (!(dPlxTF1h[XzoIRXfCWeL +sA9pOzxZ] != dPlxTF1h[XzoIRXfCWeL]));
                printf ("(%c,%d)", dPlxTF1h[XzoIRXfCWeL], sA9pOzxZ);
                XzoIRXfCWeL = XzoIRXfCWeL +sA9pOzxZ;
            }
            else {
                printf ("(%c,1)", dPlxTF1h[XzoIRXfCWeL]);
                XzoIRXfCWeL = XzoIRXfCWeL +(340 - 339);
                qRzH46Fc = qRzH46Fc + (216 - 215);
            }
            if (!(uxIEwpTM4NH - (148 - 147) != XzoIRXfCWeL))
                printf ("(%c,1)", dPlxTF1h[XzoIRXfCWeL]);
            else
                ;
        }
    }
    getchar ();
    getchar ();
}

