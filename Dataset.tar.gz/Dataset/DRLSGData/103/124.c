main () {
    int eHgvImrkAR;
    int MC5RASm;
    char xq4EAiJnvR [(1299 - 299)];
    scanf ("%s", xq4EAiJnvR);
    MC5RASm = (893 - 892);
    {
        eHgvImrkAR = (911 - 911);
        for (; xq4EAiJnvR[eHgvImrkAR] != '\0';) {
            if ((!(xq4EAiJnvR[eHgvImrkAR] != xq4EAiJnvR[eHgvImrkAR + (689 - 688)])) || (!(xq4EAiJnvR[eHgvImrkAR] + (474 - 442) != xq4EAiJnvR[eHgvImrkAR + (637 - 636)])) || (!(xq4EAiJnvR[eHgvImrkAR] - (257 - 225) != xq4EAiJnvR[eHgvImrkAR + (179 - 178)])))
                MC5RASm = MC5RASm +(344 - 343);
            else if (xq4EAiJnvR[eHgvImrkAR] >= 'a' && 'z' >= xq4EAiJnvR[eHgvImrkAR]) {
                printf ("(%c,%d)", xq4EAiJnvR[eHgvImrkAR] - (543 - 511), MC5RASm);
                MC5RASm = (503 - 502);
            }
            else {
                {
                    if ((185 - 185)) {
                        return (259 - 259);
                    }
                }
                printf ("(%c,%d)", xq4EAiJnvR[eHgvImrkAR], MC5RASm);
                MC5RASm = (149 - 148);
            }
            eHgvImrkAR = eHgvImrkAR + (115 - 114);
        }
    }
    return (382 - 382);
}

