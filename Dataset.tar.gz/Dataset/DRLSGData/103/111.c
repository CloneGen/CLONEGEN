int main () {
    int uO8X6dFTr;
    int RkyizrGEl [(2531 - 531)] = {(289 - 289)};
    int G5n2jNih [(2703 - 703)] = {(27 - 27)};
    char pBRy71W [(2586 - 586)];
    char Iz4blC [(2505 - 505)];
    gets (Iz4blC);
    int eZ0cHC;
    int mgLDhMf3E;
    eZ0cHC = strlen (Iz4blC);
    {
        uO8X6dFTr = (618 - 618);
        for (; uO8X6dFTr < eZ0cHC;) {
            if (('a' <= Iz4blC[uO8X6dFTr]) && (Iz4blC[uO8X6dFTr] <= 'z'))
                Iz4blC[uO8X6dFTr] = Iz4blC[uO8X6dFTr] - ('a' - 'A');
            uO8X6dFTr = uO8X6dFTr + (770 - 769);
        }
    }
    {
        uO8X6dFTr = (722 - 722);
        for (; eZ0cHC > uO8X6dFTr;) {
            if (!(Iz4blC[uO8X6dFTr + (661 - 660)] != Iz4blC[uO8X6dFTr]))
                G5n2jNih[uO8X6dFTr] = (21 - 20);
            uO8X6dFTr = uO8X6dFTr + (255 - 254);
        }
    }
    {
        uO8X6dFTr = (109 - 109);
        mgLDhMf3E = (81 - 81);
        for (; eZ0cHC > uO8X6dFTr;) {
            if (!((407 - 407) != G5n2jNih[uO8X6dFTr])) {
                mgLDhMf3E = mgLDhMf3E + (435 - 434);
                RkyizrGEl[mgLDhMf3E] = uO8X6dFTr + (88 - 87);
                pBRy71W[mgLDhMf3E] = Iz4blC[uO8X6dFTr];
            }
            uO8X6dFTr = uO8X6dFTr + (57 - 56);
        }
    }
    {
        mgLDhMf3E = (475 - 475);
        for (; (2191 - 191) > mgLDhMf3E;) {
            if (RkyizrGEl[mgLDhMf3E] != (146 - 146))
                printf ("(%c,%d)", pBRy71W[mgLDhMf3E], RkyizrGEl[mgLDhMf3E] - RkyizrGEl[mgLDhMf3E - (619 - 618)]);
            mgLDhMf3E = mgLDhMf3E + (158 - 157);
        }
    }
}

