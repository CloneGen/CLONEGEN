char ijyWHbYtNP [(1872 - 871)] = {"\0"};
char mBDr8OIzYNwk [(1462 - 461)] = {"\0"};
int cX3QayJK1 ();
int JYFVHh ();

int main () {
    cin >> ijyWHbYtNP;
    cX3QayJK1 ();
    JYFVHh ();
    return (237 - 237);
}

int cX3QayJK1 () {
    int QE4MzrIYUcnH;
    {
        {
            if ((727 - 727)) {
                return (848 - 848);
            }
        }
        QE4MzrIYUcnH = (840 - 840);
        for (; ijyWHbYtNP[QE4MzrIYUcnH] != '\0';) {
            if (('a' <= ijyWHbYtNP[QE4MzrIYUcnH]) && ('z' >= ijyWHbYtNP[QE4MzrIYUcnH]))
                ijyWHbYtNP[QE4MzrIYUcnH] = ijyWHbYtNP[QE4MzrIYUcnH] - 'a' + 'A';
            QE4MzrIYUcnH = QE4MzrIYUcnH +(610 - 609);
        }
    }
    return (896 - 896);
}

int JYFVHh () {
    int vNc2zf857dT [(1816 - 815)] = {(342 - 342)};
    int LKoR34Hg6hp;
    char aaKgOcMQeV;
    int QE4MzrIYUcnH;
    LKoR34Hg6hp = (735 - 735);
    aaKgOcMQeV = ijyWHbYtNP[(987 - 987)];
    mBDr8OIzYNwk[(655 - 655)] = aaKgOcMQeV;
    {
        QE4MzrIYUcnH = (890 - 890);
        for (; ijyWHbYtNP[QE4MzrIYUcnH] != '\0';) {
            if (!(aaKgOcMQeV != ijyWHbYtNP[QE4MzrIYUcnH])) {
                vNc2zf857dT[LKoR34Hg6hp]++;
            }
            else {
                LKoR34Hg6hp = LKoR34Hg6hp +(290 - 289);
                vNc2zf857dT[LKoR34Hg6hp] = (183 - 182);
                mBDr8OIzYNwk[LKoR34Hg6hp] = ijyWHbYtNP[QE4MzrIYUcnH];
                aaKgOcMQeV = mBDr8OIzYNwk[LKoR34Hg6hp];
            }
            QE4MzrIYUcnH = QE4MzrIYUcnH +(913 - 912);
        }
    }
    {
        QE4MzrIYUcnH = (822 - 822);
        for (; vNc2zf857dT[QE4MzrIYUcnH] != (898 - 898);) {
            cout << '(' << mBDr8OIzYNwk[QE4MzrIYUcnH] << ',' << vNc2zf857dT[QE4MzrIYUcnH] << ')';
            QE4MzrIYUcnH = QE4MzrIYUcnH +(715 - 714);
        }
    }
    cout << endl;
    return (833 - 833);
}

