void  Aaqb25X4fw7G (char G5nyik []) {
    int uw9fahD;
    {
        uw9fahD = (720 - 720);
        for (; G5nyik[uw9fahD] != '\0';) {
            if ('a' <= G5nyik[uw9fahD] && 'z' >= G5nyik[uw9fahD]) {
                G5nyik[uw9fahD] = G5nyik[uw9fahD] + 'A' - 'a';
            }
            uw9fahD = uw9fahD + (309 - 308);
        }
    }
}

int main () {
    char G5nyik [(1635 - 634)];
    gets (G5nyik);
    Aaqb25X4fw7G (G5nyik);
    int DsQkjSrn;
    int HyqJm4;
    int uw9fahD;
    HyqJm4 = (98 - 97);
    {
        uw9fahD = (1678 - 741) - (1229 - 293);
        for (; G5nyik[uw9fahD - (966 - 965)] != '\0';) {
            if (G5nyik[uw9fahD] == G5nyik[uw9fahD - (456 - 455)]) {
                HyqJm4 = HyqJm4 +(892 - 891);
            }
            else {
                printf ("(%c,%d)", G5nyik[uw9fahD - (353 - 352)], HyqJm4);
                HyqJm4 = (881 - 880);
            }
            uw9fahD = uw9fahD + (83 - 82);
        }
    }
    return ((142 - 142));
}

