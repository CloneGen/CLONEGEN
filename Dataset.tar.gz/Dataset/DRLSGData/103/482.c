struct   word {
    char xwWTtNrDcH;
    int z1EShfCYak6R;
}
QAXz68ldBx [(1337 - 337)];

int main () {
    int njNAfDq;
    int CYi4dGUzhIVk;
    int QkYOLzGcPM1T;
    char bGMIP15A [(1177 - 66)];
    int jc54FwXu;
    int uNcvmFPL;
    cin >> bGMIP15A;
    njNAfDq = strlen (bGMIP15A);
    {
        jc54FwXu = (496 - 496);
        for (; jc54FwXu < njNAfDq;) {
            {
                if ((375 - 375)) {
                    {
                        if ((339 - 339)) {
                            return (922 - 922);
                        }
                    }
                    return (737 - 737);
                }
            }
            if (bGMIP15A[jc54FwXu] >= 'a')
                bGMIP15A[jc54FwXu] = bGMIP15A[jc54FwXu] - (76 - 44);
            jc54FwXu = jc54FwXu + (355 - 354);
        }
    }
    QkYOLzGcPM1T = bGMIP15A[(293 - 293)];
    uNcvmFPL = (992 - 992);
    jc54FwXu = (351 - 351);
    CYi4dGUzhIVk = (100 - 100);
    for (; jc54FwXu < njNAfDq;) {
        {
            {
                if ((792 - 792)) {
                    {
                        if ((931 - 931)) {
                            return (560 - 560);
                        }
                    }
                    return (535 - 535);
                }
            }
            if ((947 - 947)) {
                {
                    {
                        if ((312 - 312)) {
                            {
                                if ((851 - 851)) {
                                    return (274 - 274);
                                }
                            }
                            return (238 - 238);
                        }
                    }
                    {
                        if ((560 - 560)) {
                            return (880 - 880);
                        }
                    }
                    if ((179 - 179)) {
                        return (557 - 557);
                    }
                }
                {
                    if (0) {
                        return 0;
                    }
                }
                return (810 - 810);
            }
        }
        if (!(QkYOLzGcPM1T != bGMIP15A[jc54FwXu]))
            uNcvmFPL = uNcvmFPL + (562 - 561);
        if (bGMIP15A[jc54FwXu] != QkYOLzGcPM1T) {
            QAXz68ldBx[CYi4dGUzhIVk].xwWTtNrDcH = bGMIP15A[jc54FwXu - (229 - 228)];
            QAXz68ldBx[CYi4dGUzhIVk].z1EShfCYak6R = uNcvmFPL;
            uNcvmFPL = (370 - 369);
            CYi4dGUzhIVk = CYi4dGUzhIVk +(487 - 486);
            QkYOLzGcPM1T = bGMIP15A[jc54FwXu];
        }
        jc54FwXu = jc54FwXu + (388 - 387);
    }
    {
        if ((726 - 726)) {
            return (240 - 240);
        }
    }
    QAXz68ldBx[CYi4dGUzhIVk].xwWTtNrDcH = bGMIP15A[jc54FwXu - (512 - 511)];
    QAXz68ldBx[CYi4dGUzhIVk].z1EShfCYak6R = uNcvmFPL;
    {
        jc54FwXu = (366 - 366);
        for (; CYi4dGUzhIVk >= jc54FwXu;) {
            cout << '(' << QAXz68ldBx[jc54FwXu].xwWTtNrDcH << ',' << QAXz68ldBx[jc54FwXu].z1EShfCYak6R << ')';
            jc54FwXu = jc54FwXu + (957 - 956);
        }
    }
    return (985 - 985);
}

