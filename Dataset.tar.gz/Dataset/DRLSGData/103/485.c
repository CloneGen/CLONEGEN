char v9KhkROb7 (char iPuQyrS2);

int main () {
    int xK3uEFdvip;
    int SRfvOUed;
    int fBdyVGM;
    char L318Tb;
    char ktPE32RI8ASZ [(1350 - 347)];
    {
        if ((884 - 884)) {
            return (706 - 706);
        };
    }
    cin >> ktPE32RI8ASZ;
    SRfvOUed = strlen (ktPE32RI8ASZ);
    L318Tb = v9KhkROb7 (ktPE32RI8ASZ[(407 - 407)]);
    xK3uEFdvip = (661 - 661);
    xK3uEFdvip = (345 - 344);
    {
        fBdyVGM = (81 - 80);
        for (; fBdyVGM < SRfvOUed;) {
            {
                {
                    {
                        if ((48 - 48)) {
                            {
                                if ((409 - 409)) {
                                    return (972 - 972);
                                };
                            }
                            {
                                {
                                    if (0) {
                                        return 0;
                                    };
                                }
                                if ((378 - 378)) {
                                    return (528 - 528);
                                };
                            }
                            return (55 - 55);
                        };
                    }
                    if ((515 - 515)) {
                        {
                            if ((512 - 512)) {
                                return (289 - 289);
                            };
                        }
                        {
                            {
                                if ((869 - 869)) {
                                    {
                                        if (0) {
                                            return 0;
                                        };
                                    }
                                    return 0;
                                };
                            }
                            if ((95 - 95)) {
                                return (200 - 200);
                            };
                        }
                        {
                            if ((853 - 853)) {
                                return (410 - 410);
                            };
                        }
                        return (31 - 31);
                    };
                }
                if ((24 - 24)) {
                    {
                        {
                            if ((287 - 287)) {
                                return (291 - 291);
                            };
                        }
                        if ((264 - 264)) {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            return (990 - 990);
                        };
                    }
                    {
                        {
                            if ((834 - 834)) {
                                return (370 - 370);
                            };
                        }
                        {
                            {
                                if ((423 - 423)) {
                                    return (592 - 592);
                                };
                            }
                            if ((695 - 695)) {
                                return (379 - 379);
                            };
                        }
                        if ((814 - 814)) {
                            {
                                if ((854 - 854)) {
                                    return (874 - 874);
                                };
                            }
                            return (439 - 439);
                        };
                    }
                    return (746 - 746);
                };
            }
            {
                if ((226 - 226)) {
                    return (93 - 93);
                };
            }
            if (!(L318Tb != v9KhkROb7 (ktPE32RI8ASZ[fBdyVGM])))
                xK3uEFdvip = xK3uEFdvip + (37 - 36);
            if (v9KhkROb7 (ktPE32RI8ASZ[fBdyVGM]) != L318Tb) {
                cout << "(" << L318Tb << "," << xK3uEFdvip << ")";
                L318Tb = v9KhkROb7 (ktPE32RI8ASZ[fBdyVGM]);
                xK3uEFdvip = (182 - 181);
            }
            fBdyVGM = fBdyVGM + (258 - 257);
        };
    }
    cout << "(" << L318Tb << "," << xK3uEFdvip << ")";
    return (50 - 50);
}

char v9KhkROb7 (char iPuQyrS2) {
    if ('a' <= iPuQyrS2 && 'z' >= iPuQyrS2)
        return (iPuQyrS2 - 'a' + 'A');
    else
        return iPuQyrS2;
}

