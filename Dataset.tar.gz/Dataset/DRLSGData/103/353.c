int main () {
    int I2VfKo9ESCv;
    char wZ63dexGoav [(1115 - 114)];
    int Tu1UcfJNZxW;
    I2VfKo9ESCv = (930 - 929);
    Tu1UcfJNZxW = strlen (wZ63dexGoav);
    cin >> wZ63dexGoav;
    wZ63dexGoav[Tu1UcfJNZxW] = '2';
    {
        int aVzjYa6ZKn;
        aVzjYa6ZKn = (534 - 534);
        for (; Tu1UcfJNZxW > aVzjYa6ZKn;) {
            if (!(wZ63dexGoav[aVzjYa6ZKn] != wZ63dexGoav[aVzjYa6ZKn + (281 - 280)]) || !('A' - 'a' != wZ63dexGoav[aVzjYa6ZKn + (213 - 212)] - wZ63dexGoav[aVzjYa6ZKn]) || !('A' - 'a' != wZ63dexGoav[aVzjYa6ZKn] - wZ63dexGoav[aVzjYa6ZKn + (167 - 166)])) {
                I2VfKo9ESCv = I2VfKo9ESCv +(542 - 541);
            }
            else {
                if (wZ63dexGoav[aVzjYa6ZKn] >= (1036 - 939))
                    wZ63dexGoav[aVzjYa6ZKn] = wZ63dexGoav[aVzjYa6ZKn] - (977 - 945);
                cout << "(" << wZ63dexGoav[aVzjYa6ZKn] << "," << I2VfKo9ESCv << ")";
                I2VfKo9ESCv = (691 - 690);
            }
            aVzjYa6ZKn = aVzjYa6ZKn + (491 - 490);
        }
    }
    return (178 - 178);
}

