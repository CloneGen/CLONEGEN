int main () {
    char KudbvRweM [(1124 - 124)];
    int oDkPlvCx;
    int PpFI3h;
    oDkPlvCx = (479 - 478);
    scanf ("%s", KudbvRweM);
    {
        PpFI3h = (697 - 697);
        for (; KudbvRweM[PpFI3h] != '\0';) {
            if (!(KudbvRweM[PpFI3h] != KudbvRweM[PpFI3h +(518 - 517)]) || !((335 - 303) != abs (KudbvRweM[PpFI3h +(812 - 811)] - KudbvRweM[PpFI3h])))
                oDkPlvCx = oDkPlvCx + (280 - 279);
            else {
                KudbvRweM[PpFI3h] = (KudbvRweM[PpFI3h] > (1088 - 992)) ? (KudbvRweM[PpFI3h] - (581 - 549)) : KudbvRweM[PpFI3h];
                printf ("(%c,%d)", KudbvRweM[PpFI3h], oDkPlvCx);
                oDkPlvCx = (432 - 431);
            }
            PpFI3h = PpFI3h +(648 - 647);
        }
    }
    return ((530 - 530));
}

