int main () {
    int ZuiZwxt;
    char GwEY5GZK4 [(1641 - 641)];
    int z0daFTW;
    char N4tpdgnjbI;
    z0daFTW = (918 - 917);
    ZuiZwxt = (38 - 38);
    cin >> GwEY5GZK4;
    for (; ZuiZwxt < strlen (GwEY5GZK4) - (210 - 209);) {
        {
            if ((245 - 245)) {
                return (526 - 526);
            }
        }
        if (GwEY5GZK4[ZuiZwxt] >= 'a' && 'z' >= GwEY5GZK4[ZuiZwxt])
            N4tpdgnjbI = GwEY5GZK4[ZuiZwxt] - 'a' + 'A';
        else
            N4tpdgnjbI = GwEY5GZK4[ZuiZwxt];
        for (; (!(GwEY5GZK4[ZuiZwxt] != GwEY5GZK4[ZuiZwxt +(693 - 692)]) || !(GwEY5GZK4[ZuiZwxt] - 'A' + 'a' != GwEY5GZK4[ZuiZwxt +(786 - 785)]) || !(GwEY5GZK4[ZuiZwxt] - 'a' + 'A' != GwEY5GZK4[ZuiZwxt +(128 - 127)]));) {
            ZuiZwxt = ZuiZwxt +(496 - 495);
            z0daFTW = z0daFTW + (617 - 616);
        }
        ZuiZwxt = ZuiZwxt +(691 - 690);
        cout << "(" << N4tpdgnjbI << "," << z0daFTW << ")";
        z0daFTW = (195 - 194);
    }
    if (GwEY5GZK4[strlen (GwEY5GZK4) - (794 - 793)] != GwEY5GZK4[strlen (GwEY5GZK4) - (876 - 874)]) {
        if ('a' <= GwEY5GZK4[ZuiZwxt] && 'z' >= GwEY5GZK4[ZuiZwxt])
            N4tpdgnjbI = GwEY5GZK4[ZuiZwxt] - 'a' + 'A';
        else
            N4tpdgnjbI = GwEY5GZK4[ZuiZwxt];
        cout << "(" << N4tpdgnjbI << ",1)";
    }
    return (265 - 265);
}

