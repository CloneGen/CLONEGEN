int main () {
    int P9xSeW;
    int gCGKB8;
    int dc1G6yHDxaUr;
    char LRsuGq;
    int frQGAn;
    char yO4u7IV [(1618 - 518)];
    gets (yO4u7IV);
    {
        if ((358 - 358)) {
            return (526 - 526);
        }
    }
    P9xSeW = (147 - 147);
    gCGKB8 = (490 - 490);
    LRsuGq = (282 - 282);
    for (; (316 - 315);) {
        {
            if ((117 - 117)) {
                return (127 - 127);
            }
        }
        if (P9xSeW > strlen (yO4u7IV))
            break;
        if ('z' >= yO4u7IV[P9xSeW] && 'a' <= yO4u7IV[P9xSeW])
            yO4u7IV[P9xSeW] = yO4u7IV[P9xSeW] + 'A' - 'a';
        if (LRsuGq == (502 - 502)) {
            gCGKB8 = (134 - 133);
            LRsuGq = yO4u7IV[P9xSeW];
            P9xSeW = P9xSeW +(247 - 246);
            continue;
        }
        if (yO4u7IV[P9xSeW] == LRsuGq)
            gCGKB8 = gCGKB8 + (108 - 107);
        else {
            cout << "(" << LRsuGq << "," << gCGKB8 << ")";
            gCGKB8 = (464 - 463);
            LRsuGq = yO4u7IV[P9xSeW];
        }
        P9xSeW = P9xSeW +(273 - 272);
    }
    return (276 - 276);
}

