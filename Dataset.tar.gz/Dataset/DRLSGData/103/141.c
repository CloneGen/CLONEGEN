int main () {
    int wr6ZpxSsP3Q1 [(954 - 854)];
    int CIYqnAjW;
    int Zy5I6sXv;
    int B3ifR6qZPrg0;
    char fQ7NKa [(1099 - 999)];
    int twmZLq4zWVBb;
    int BeYd3TGpQBZ;
    char yONFtL [(1193 - 193)];
    Zy5I6sXv = (631 - 630);
    scanf ("%s", yONFtL);
    {
        CIYqnAjW = (1226 - 978) - (1034 - 787);
        for (; strlen (yONFtL) >= CIYqnAjW;) {
            wr6ZpxSsP3Q1[CIYqnAjW] = (174 - 174);
            CIYqnAjW = CIYqnAjW +(1001 - 1000);
        }
    }
    {
        twmZLq4zWVBb = (1000 - 159) - (1537 - 696);
        for (; strlen (yONFtL) - (50 - 49) >= twmZLq4zWVBb;) {
            if (yONFtL[twmZLq4zWVBb] >= (1073 - 976) && yONFtL[twmZLq4zWVBb] <= (879 - 757))
                yONFtL[twmZLq4zWVBb] = yONFtL[twmZLq4zWVBb] - (600 - 568);
            twmZLq4zWVBb = twmZLq4zWVBb + (490 - 489);
        }
    }
    if (strlen (yONFtL) == (292 - 291)) {
        wr6ZpxSsP3Q1[(573 - 572)] = (424 - 423);
        fQ7NKa[(148 - 147)] = yONFtL[(751 - 751)];
    }
    else {
        B3ifR6qZPrg0 = (117 - 116);
        for (; B3ifR6qZPrg0 <= strlen (yONFtL) - (161 - 160);) {
            if (yONFtL[B3ifR6qZPrg0] == yONFtL[B3ifR6qZPrg0 -(123 - 122)]) {
                wr6ZpxSsP3Q1[Zy5I6sXv] = wr6ZpxSsP3Q1[Zy5I6sXv] + (367 - 366);
                fQ7NKa[Zy5I6sXv] = yONFtL[B3ifR6qZPrg0 -(113 - 112)];
            }
            else {
                wr6ZpxSsP3Q1[Zy5I6sXv] = wr6ZpxSsP3Q1[Zy5I6sXv] + (757 - 756);
                fQ7NKa[Zy5I6sXv] = yONFtL[B3ifR6qZPrg0 -(627 - 626)];
                Zy5I6sXv = Zy5I6sXv +(324 - 323);
            }
            if (B3ifR6qZPrg0 == strlen (yONFtL) - (660 - 659)) {
                wr6ZpxSsP3Q1[Zy5I6sXv] = wr6ZpxSsP3Q1[Zy5I6sXv] + (425 - 424);
                fQ7NKa[Zy5I6sXv] = yONFtL[B3ifR6qZPrg0];
            }
            B3ifR6qZPrg0 = B3ifR6qZPrg0 +(93 - 92);
        }
    }
    {
        BeYd3TGpQBZ = (1863 - 986) - (1027 - 151);
        for (; BeYd3TGpQBZ <= Zy5I6sXv;) {
            printf ("(%c,%d)", fQ7NKa[BeYd3TGpQBZ], wr6ZpxSsP3Q1[BeYd3TGpQBZ]);
            BeYd3TGpQBZ = BeYd3TGpQBZ +(643 - 642);
        }
    }
}

