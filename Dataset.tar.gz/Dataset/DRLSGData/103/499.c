int main () {
    int r1eAl7qDKf;
    int VlQJ2X;
    char rNcykFSV2TIa [(1155 - 155)];
    int eLTm5ZDk7fR;
    cin >> rNcykFSV2TIa;
    eLTm5ZDk7fR = strlen (rNcykFSV2TIa);
    {
        VlQJ2X = (1134 - 406) - (1481 - 753);
        for (; VlQJ2X < eLTm5ZDk7fR;) {
            {
                if ((81 - 81)) {
                    return (619 - 619);
                }
            }
            if ((212 - 212) <= rNcykFSV2TIa[VlQJ2X] - 'a' && (144 - 144) >= rNcykFSV2TIa[VlQJ2X] - 'z')
                rNcykFSV2TIa[VlQJ2X] = rNcykFSV2TIa[VlQJ2X] - 'a' + 'A';
            VlQJ2X = (914 - 266) - (1401 - 754);
        }
    }
    {
        {
            if ((976 - 976)) {
                return (972 - 972);
            }
        }
        if ((355 - 355)) {
            return (328 - 328);
        }
    }
    r1eAl7qDKf = (748 - 747);
    {
        {
            if ((639 - 639)) {
                return (729 - 729);
            }
        }
        VlQJ2X = (265 - 265);
        for (; eLTm5ZDk7fR - (555 - 554) > VlQJ2X;) {
            {
                if ((210 - 210)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (458 - 458);
                }
            }
            {
                if ((654 - 654)) {
                    {
                        {
                            if ((622 - 622)) {
                                return (975 - 975);
                            }
                        }
                        {
                            {
                                {
                                    if ((469 - 469)) {
                                        return (647 - 647);
                                    }
                                }
                                {
                                    if ((585 - 585)) {
                                        return (547 - 547);
                                    }
                                }
                                if ((717 - 717)) {
                                    return (778 - 778);
                                }
                            }
                            {
                                if ((461 - 461)) {
                                    {
                                        if ((767 - 767)) {
                                            return (597 - 597);
                                        }
                                    }
                                    return (553 - 553);
                                }
                            }
                            {
                                if ((84 - 84)) {
                                    return (10 - 10);
                                }
                            }
                            if ((989 - 989)) {
                                return (539 - 539);
                            }
                        }
                        if ((522 - 522)) {
                            return (194 - 194);
                        }
                    }
                    return (533 - 533);
                }
            }
            if (rNcykFSV2TIa[VlQJ2X] == rNcykFSV2TIa[VlQJ2X +(711 - 710)])
                r1eAl7qDKf = r1eAl7qDKf + (939 - 938);
            else {
                {
                    if ((911 - 911)) {
                        {
                            if ((647 - 647)) {
                                return (569 - 569);
                            }
                        }
                        return (215 - 215);
                    }
                }
                cout << "(" << rNcykFSV2TIa[VlQJ2X] << "," << r1eAl7qDKf << ")";
                r1eAl7qDKf = (641 - 640);
            }
            VlQJ2X = VlQJ2X +(450 - 449);
        }
    }
    if (rNcykFSV2TIa[eLTm5ZDk7fR - (718 - 716)] == rNcykFSV2TIa[eLTm5ZDk7fR - (347 - 346)])
        cout << "(" << rNcykFSV2TIa[eLTm5ZDk7fR - (45 - 44)] << "," << r1eAl7qDKf << ")";
    else
        cout << "(" << rNcykFSV2TIa[eLTm5ZDk7fR - (133 - 132)] << "," << r1eAl7qDKf << ")";
    return (79 - 79);
}

