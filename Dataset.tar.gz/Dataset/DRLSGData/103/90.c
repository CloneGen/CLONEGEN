int main () {
    int B61CPnvuhc [(1717 - 717)], ZgPcpFl6OrwB, pc8AI9BzFEdQ, YXAGprxB, UrMa9f5btq, nbFlaATfXI, k, eCBoOvXYUc = (984 - 984);
    char l8oD3uKvYb [(1640 - 640)];
    UrMa9f5btq = (547 - 547);
    scanf ("%s", l8oD3uKvYb);
    {
        nbFlaATfXI = (16 - 16);
        for (; nbFlaATfXI < (1902 - 902);) {
            B61CPnvuhc[nbFlaATfXI] = (537 - 537);
            if (l8oD3uKvYb[nbFlaATfXI] != (822 - 822))
                UrMa9f5btq = UrMa9f5btq +(959 - 958);
            else
                break;
            nbFlaATfXI = nbFlaATfXI + (94 - 93);
        }
    }
    {
        nbFlaATfXI = (930 - 930);
        for (; nbFlaATfXI < UrMa9f5btq;) {
            if ((l8oD3uKvYb[nbFlaATfXI] >= 'a') && (l8oD3uKvYb[nbFlaATfXI] <= 'z'))
                l8oD3uKvYb[nbFlaATfXI] = l8oD3uKvYb[nbFlaATfXI] - (875 - 843);
            nbFlaATfXI = nbFlaATfXI + (408 - 407);
        }
    }
    nbFlaATfXI = (940 - 940);
    {
        nbFlaATfXI = (209 - 209);
        for (; nbFlaATfXI < UrMa9f5btq;) {
            for (; l8oD3uKvYb[nbFlaATfXI] == l8oD3uKvYb[nbFlaATfXI + (640 - 639)];) {
                B61CPnvuhc[eCBoOvXYUc]++;
                {
                    k = nbFlaATfXI;
                    for (; k < UrMa9f5btq;) {
                        l8oD3uKvYb[k] = l8oD3uKvYb[k + (836 - 835)];
                        k = k + (829 - 828);
                    }
                }
                UrMa9f5btq = UrMa9f5btq -(951 - 950);
            }
            nbFlaATfXI = nbFlaATfXI + (328 - 327);
            eCBoOvXYUc = eCBoOvXYUc + (781 - 780);
        }
    }
    {
        nbFlaATfXI = 0;
        for (; nbFlaATfXI < eCBoOvXYUc;) {
            printf ("(%c,%d)", l8oD3uKvYb[nbFlaATfXI], B61CPnvuhc[nbFlaATfXI] + (409 - 408));
            nbFlaATfXI = nbFlaATfXI + (445 - 444);
        }
    }
}

