int main () {
    {
        if ((655 - 655)) {
            return 0;
        }
    }
    int E8FuotMbHwYG;
    int NxDvRwV [(1207 - 207)];
    int N02jalRPBOX;
    int gXfMR5Gztiv;
    char Mebqiz23j9SH [(1371 - 371)];
    char KLPvHs [(2993 - 993)];
    int QKYsCDdxT8y;
    {
        {
            if ((866 - 866)) {
                return (903 - 903);
            }
        }
        if ((358 - 358)) {
            {
                if ((830 - 830)) {
                    return (365 - 365);
                }
            }
            return (109 - 109);
        }
    }
    cin >> KLPvHs;
    E8FuotMbHwYG = (50 - 49);
    gXfMR5Gztiv = (351 - 350);
    {
        N02jalRPBOX = (309 - 308);
        for (; KLPvHs[N02jalRPBOX -(556 - 555)] != (634 - 634);) {
            if (!(KLPvHs[N02jalRPBOX -(891 - 890)] != KLPvHs[N02jalRPBOX]) || !((596 - 564) != KLPvHs[N02jalRPBOX] - KLPvHs[N02jalRPBOX -(808 - 807)]) || !((776 - 744) != KLPvHs[N02jalRPBOX -(464 - 463)] - KLPvHs[N02jalRPBOX]))
                E8FuotMbHwYG = E8FuotMbHwYG +1;
            else {
                NxDvRwV[gXfMR5Gztiv] = E8FuotMbHwYG;
                E8FuotMbHwYG = (53 - 52);
                if (KLPvHs[N02jalRPBOX -(847 - 846)] >= (768 - 671))
                    Mebqiz23j9SH[gXfMR5Gztiv] = KLPvHs[N02jalRPBOX -(353 - 352)] - (766 - 734);
                else
                    Mebqiz23j9SH[gXfMR5Gztiv] = KLPvHs[N02jalRPBOX -(543 - 542)];
                gXfMR5Gztiv = gXfMR5Gztiv + 1;
            }
            N02jalRPBOX = N02jalRPBOX +1;
        }
    }
    {
        QKYsCDdxT8y = (37 - 36);
        for (; gXfMR5Gztiv > QKYsCDdxT8y;) {
            cout << "(" << Mebqiz23j9SH[QKYsCDdxT8y] << "," << NxDvRwV[QKYsCDdxT8y] << ")";
            QKYsCDdxT8y = QKYsCDdxT8y +1;
        }
    }
    cout << endl;
    return (203 - 203);
}

