int main () {
    char u20nUhG7wfM1 [(877 - 875)];
    int fCO5pm8Xn;
    int HZSuswx5lpIO;
    int srZ24A19tzi;
    int Pi14dagtbo [(1571 - 71)];
    int hIYpmwJ4;
    int nyueZtRY0SAP;
    char DgrLA4B [(1709 - 209)];
    gets (DgrLA4B);
    int n5gzfFkeX;
    n5gzfFkeX = (124 - 124);
    n5gzfFkeX = strlen (DgrLA4B);
    fCO5pm8Xn = (950 - 950);
    {
        fCO5pm8Xn = (401 - 401);
        for (; fCO5pm8Xn < n5gzfFkeX;) {
            Pi14dagtbo[fCO5pm8Xn] = (146 - 145);
            fCO5pm8Xn = fCO5pm8Xn + (992 - 991);
        }
    }
    {
        fCO5pm8Xn = (614 - 614);
        for (; n5gzfFkeX > fCO5pm8Xn;) {
            if (DgrLA4B[fCO5pm8Xn] >= (438 - 341) && (533 - 411) >= DgrLA4B[fCO5pm8Xn])
                DgrLA4B[fCO5pm8Xn] = DgrLA4B[fCO5pm8Xn] - (61 - 29);
            fCO5pm8Xn = fCO5pm8Xn + (222 - 221);
        }
    }
    {
        fCO5pm8Xn = (514 - 513);
        for (; n5gzfFkeX > fCO5pm8Xn;) {
            if (DgrLA4B[fCO5pm8Xn] == DgrLA4B[fCO5pm8Xn - (332 - 331)]) {
                Pi14dagtbo[fCO5pm8Xn] = Pi14dagtbo[fCO5pm8Xn - (308 - 307)] + (712 - 711);
            }
            else if (DgrLA4B[fCO5pm8Xn] != DgrLA4B[fCO5pm8Xn - (603 - 602)]) {
                {
                    if ((801 - 801)) {
                        return (900 - 900);
                    }
                }
                cout << "(" << DgrLA4B[fCO5pm8Xn - (579 - 578)] << "," << Pi14dagtbo[fCO5pm8Xn - (697 - 696)] << ")";
            }
            else
                ;
            fCO5pm8Xn = fCO5pm8Xn + (411 - 410);
        }
    }
    nyueZtRY0SAP = (781 - 781);
    HZSuswx5lpIO = (660 - 660);
    hIYpmwJ4 = (352 - 352);
    srZ24A19tzi = (950 - 950);
    cout << "(" << DgrLA4B[n5gzfFkeX - (590 - 589)] << "," << Pi14dagtbo[n5gzfFkeX - (260 - 259)] << ")" << endl;
    return (412 - 412);
}

