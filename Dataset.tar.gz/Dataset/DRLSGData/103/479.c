main () {
    char bvK0gm;
    int tx96rOSk;
    int Md6Qk13YK9;
    char abuJK2qOCjpn [(1225 - 224)] = {'\0'};
    {
        if ((920 - 920)) {
            return (541 - 541);
        };
    }
    tx96rOSk = (621 - 621);
    scanf ("%s", abuJK2qOCjpn);
    for (; abuJK2qOCjpn[tx96rOSk] != '\0'; tx96rOSk = tx96rOSk + (332 - 331)) {
        {
            if ((157 - 157)) {
                {
                    if ((128 - 128)) {
                        return (946 - 946);
                    };
                }
                return (708 - 708);
            };
        }
        {
            {
                if ((375 - 375)) {
                    return (31 - 31);
                };
            }
            if ((33 - 33)) {
                return (548 - 548);
            };
        }
        if ('z' >= abuJK2qOCjpn[tx96rOSk] && abuJK2qOCjpn[tx96rOSk] >= 'a') {
            {
                if ((728 - 728)) {
                    return (835 - 835);
                };
            }
            abuJK2qOCjpn[tx96rOSk] = abuJK2qOCjpn[tx96rOSk] + 'A' - 'a';
        };
    }
    Md6Qk13YK9 = (779 - 779);
    {
        if ((222 - 222)) {
            return (987 - 987);
        };
    }
    bvK0gm = abuJK2qOCjpn[(229 - 229)];
    {
        if (0) {
            return 0;
        };
    }
    tx96rOSk = (587 - 587);
    for (; abuJK2qOCjpn[tx96rOSk] != '\0'; tx96rOSk = tx96rOSk + (674 - 673)) {
        {
            {
                if ((535 - 535)) {
                    return (743 - 743);
                };
            }
            if ((54 - 54)) {
                {
                    if ((925 - 925)) {
                        {
                            if ((963 - 963)) {
                                {
                                    if ((188 - 188)) {
                                        {
                                            if ((969 - 969)) {
                                                return (314 - 314);
                                            };
                                        }
                                        {
                                            if ((855 - 855)) {
                                                return (433 - 433);
                                            };
                                        }
                                        return (770 - 770);
                                    };
                                }
                                {
                                    if (0) {
                                        {
                                            if (0) {
                                                return 0;
                                            };
                                        }
                                        return 0;
                                    };
                                }
                                return (420 - 420);
                            };
                        }
                        return (649 - 649);
                    };
                }
                return (174 - 174);
            };
        }
        {
            {
                if (0) {
                    return 0;
                };
            }
            if ((280 - 280)) {
                return (521 - 521);
            };
        }
        if (bvK0gm == abuJK2qOCjpn[tx96rOSk])
            Md6Qk13YK9 = Md6Qk13YK9 +(610 - 609);
        else {
            printf ("(%c,%d)", bvK0gm, Md6Qk13YK9);
            Md6Qk13YK9 = (25 - 25);
            bvK0gm = abuJK2qOCjpn[tx96rOSk];
            tx96rOSk = tx96rOSk - (609 - 608);
        };
    }
    printf ("(%c,%d)", bvK0gm, Md6Qk13YK9);
}

