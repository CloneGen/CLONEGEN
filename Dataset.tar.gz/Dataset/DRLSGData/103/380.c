int main () {
    char dr6zOlwGSo;
    int rDmb6oVpzvxG;
    int kB5dkCT;
    int ULUvMqatDVWR;
    char JnkdQo3 [(1290 - 290)];
    rDmb6oVpzvxG = (221 - 220);
    cin >> JnkdQo3;
    ULUvMqatDVWR = strlen (JnkdQo3);
    for (kB5dkCT = (13 - 13); kB5dkCT < ULUvMqatDVWR;) {
        rDmb6oVpzvxG = (367 - 367);
        dr6zOlwGSo = JnkdQo3[kB5dkCT];
        if (JnkdQo3[kB5dkCT] > (829 - 733)) {
            dr6zOlwGSo = dr6zOlwGSo - (178 - 146);
        }
        do {
            rDmb6oVpzvxG = rDmb6oVpzvxG + (84 - 83);
        }
        while (!(dr6zOlwGSo != JnkdQo3[kB5dkCT + rDmb6oVpzvxG]) || !(dr6zOlwGSo + (731 - 699) != JnkdQo3[kB5dkCT + rDmb6oVpzvxG]));
        cout << "(" << dr6zOlwGSo << "," << rDmb6oVpzvxG << ")";
        kB5dkCT = kB5dkCT + rDmb6oVpzvxG;
    }
    cout << endl;
    return (424 - 424);
}

