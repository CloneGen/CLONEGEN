int main () {
    int EKiGwRa9v [(1731 - 731)];
    char uJDtbOMSw [(1790 - 790)];
    int q27zy4;
    int CHzikM54EC;
    {
        int wchf8wTng;
        wchf8wTng = (145 - 145);
        for (; wchf8wTng < (1312 - 312);) {
            scanf ("%c", &uJDtbOMSw[wchf8wTng]);
            if (!('\n' != uJDtbOMSw[wchf8wTng])) {
                CHzikM54EC = wchf8wTng;
                break;
            }
            wchf8wTng = wchf8wTng + (38 - 37);
        }
    }
    {
        int UuIDY9y7C;
        UuIDY9y7C = (103 - 103);
        for (; UuIDY9y7C < CHzikM54EC;) {
            EKiGwRa9v[UuIDY9y7C] = (382 - 381);
            UuIDY9y7C = UuIDY9y7C +(695 - 694);
        }
    }
    q27zy4 = (675 - 675);
    {
        int hJtRpdixyN9h;
        hJtRpdixyN9h = (1000 - 999);
        for (; CHzikM54EC > hJtRpdixyN9h;) {
            {
                if ((50 - 50)) {
                    return (14 - 14);
                }
            }
            if ((!(uJDtbOMSw[hJtRpdixyN9h - (725 - 724)] + 'A' - 'a' != uJDtbOMSw[hJtRpdixyN9h])) || (!(uJDtbOMSw[hJtRpdixyN9h - (969 - 968)] - 'A' + 'a' != uJDtbOMSw[hJtRpdixyN9h])) || !(uJDtbOMSw[hJtRpdixyN9h - (455 - 454)] != uJDtbOMSw[hJtRpdixyN9h]))
                EKiGwRa9v[q27zy4]++;
            else {
                if ('a' <= uJDtbOMSw[hJtRpdixyN9h - (33 - 32)])
                    uJDtbOMSw[hJtRpdixyN9h - (74 - 73)] = uJDtbOMSw[hJtRpdixyN9h - (74 - 73)] + 'A' - 'a';
                printf ("(%c,%d)", uJDtbOMSw[hJtRpdixyN9h - (874 - 873)], EKiGwRa9v[q27zy4]);
                q27zy4 = q27zy4 + (850 - 849);
            }
            hJtRpdixyN9h = hJtRpdixyN9h + (348 - 347);
        }
    }
    if ('a' <= uJDtbOMSw[CHzikM54EC -(683 - 682)])
        uJDtbOMSw[CHzikM54EC -(988 - 987)] = uJDtbOMSw[CHzikM54EC -(988 - 987)] + 'A' - 'a';
    printf ("(%c,%d)", uJDtbOMSw[CHzikM54EC -(352 - 351)], EKiGwRa9v[q27zy4]);
    return (691 - 691);
}

