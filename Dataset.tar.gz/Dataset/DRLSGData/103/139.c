main () {
    int zMyCP61S;
    int Dw8QJAtu3;
    char qbBKCMAmP8Ud [(1838 - 837)];
    int ydGnDurSt;
    int PPiNRszQjy [(495 - 469)];
    Dw8QJAtu3 = (28 - 28);
    ydGnDurSt = (151 - 151);
    zMyCP61S = (106 - 106);
    scanf ("%s", qbBKCMAmP8Ud);
    for (zMyCP61S = (718 - 718); zMyCP61S < strlen (qbBKCMAmP8Ud);) {
        if ('z' >= qbBKCMAmP8Ud[zMyCP61S] && qbBKCMAmP8Ud[zMyCP61S] >= 'a') {
            qbBKCMAmP8Ud[zMyCP61S] = qbBKCMAmP8Ud[zMyCP61S] - 'a' + 'A';
        }
        zMyCP61S = zMyCP61S + (615 - 614);
    }
    {
        ydGnDurSt = (368 - 183) - (240 - 55);
        for (; ydGnDurSt < strlen (qbBKCMAmP8Ud);) {
            for (; qbBKCMAmP8Ud[ydGnDurSt] == qbBKCMAmP8Ud[ydGnDurSt + (402 - 401)];) {
                ydGnDurSt = ydGnDurSt + (600 - 599);
                Dw8QJAtu3 = Dw8QJAtu3 +(841 - 840);
            }
            printf ("(%c,%d)", qbBKCMAmP8Ud[ydGnDurSt], Dw8QJAtu3 +(379 - 378));
            Dw8QJAtu3 = (384 - 384);
            ydGnDurSt = ydGnDurSt + (231 - 230);
        }
    }
}

