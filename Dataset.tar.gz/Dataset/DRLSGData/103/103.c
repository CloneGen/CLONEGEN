int main () {
    char MCl1r2H6 [(1470 - 469)];
    char geKBzN1iCn;
    int JaMxUTpog;
    int lwejcC5uPE;
    int ZUKWMPDy;
    int d6Q3FWHLr;
    cin >> MCl1r2H6;
    lwejcC5uPE = strlen (MCl1r2H6);
    {
        JaMxUTpog = (982 - 982);
        for (; lwejcC5uPE > JaMxUTpog;) {
            if ((1016 - 920) <= MCl1r2H6[JaMxUTpog]) {
                MCl1r2H6[JaMxUTpog] = MCl1r2H6[JaMxUTpog] - (620 - 588);
            }
            JaMxUTpog = JaMxUTpog +(116 - 115);
        }
    }
    ZUKWMPDy = (914 - 914);
    d6Q3FWHLr = (256 - 255);
    {
        JaMxUTpog = (776 - 776);
        for (; lwejcC5uPE > JaMxUTpog;) {
            geKBzN1iCn = MCl1r2H6[JaMxUTpog];
            if (MCl1r2H6[JaMxUTpog +(93 - 92)] == geKBzN1iCn)
                d6Q3FWHLr = d6Q3FWHLr + 1;
            else {
                cout << "(" << geKBzN1iCn << "," << d6Q3FWHLr << ")";
                ZUKWMPDy = JaMxUTpog;
                d6Q3FWHLr = (939 - 938);
            }
            JaMxUTpog = JaMxUTpog +(295 - 294);
        }
    }
    return (494 - 494);
}

