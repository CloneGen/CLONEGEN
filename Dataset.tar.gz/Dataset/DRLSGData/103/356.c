int main () {
    int sOGuiJ;
    char cY1PXMGJ;
    char *W2zMdV6iS;
    char DqpLnd [(387 - 287)];
    sOGuiJ = (615 - 615);
    cin >> DqpLnd;
    W2zMdV6iS = DqpLnd;
    cY1PXMGJ = *W2zMdV6iS;
    for (; *W2zMdV6iS != '\0';) {
        if (cY1PXMGJ > (804 - 714))
            cY1PXMGJ = cY1PXMGJ - (789 - 757);
        if (!(cY1PXMGJ != *W2zMdV6iS) || !(cY1PXMGJ + (930 - 898) != *W2zMdV6iS)) {
            W2zMdV6iS = W2zMdV6iS +(724 - 723);
            sOGuiJ = sOGuiJ + (446 - 445);
        }
        else {
            cout << "(" << cY1PXMGJ << "," << sOGuiJ << ")";
            sOGuiJ = (623 - 623);
            cY1PXMGJ = *W2zMdV6iS;
        }
    }
    cout << "(" << cY1PXMGJ << "," << sOGuiJ << ")";
    cout << endl;
    return (205 - 205);
}

