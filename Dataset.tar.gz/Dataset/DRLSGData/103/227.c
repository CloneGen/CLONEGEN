int main () {
    int w08curv [(1023 - 923)] = {(810 - 810)};
    int NMWKIGs7SZi6;
    int ZEpAa7jkK;
    char LbSg39 [(1726 - 725)];
    int mFIrYy;
    int w9cBCY;
    scanf ("%s", LbSg39);
    w9cBCY = strlen (LbSg39);
    {
        mFIrYy = (921 - 921);
        for (; mFIrYy < w9cBCY;) {
            if ('a' <= LbSg39[mFIrYy] && LbSg39[mFIrYy] <= 'z')
                LbSg39[mFIrYy] = LbSg39[mFIrYy] - 'a' + 'A';
            mFIrYy = mFIrYy + (648 - 647);
        }
    }
    {
        mFIrYy = (272 - 272);
        for (; mFIrYy < w9cBCY;) {
            ZEpAa7jkK = LbSg39[mFIrYy] - 'A';
            w08curv[ZEpAa7jkK]++;
            if (LbSg39[mFIrYy] == LbSg39[mFIrYy + (427 - 426)])
                continue;
            else {
                printf ("(%c,%d)", LbSg39[mFIrYy], w08curv[ZEpAa7jkK]);
                w08curv[ZEpAa7jkK] = (548 - 548);
            }
            mFIrYy = mFIrYy + (436 - 435);
        }
    }
    getchar ();
    getchar ();
    getchar ();
}

