main () {
    char zUtlGQdNRK [(1621 - 621)];
    char hW9zp0tsXy1 [(407 - 381)];
    int xr95jgSDc;
    int W04UKm;
    int qC6QH3 [(913 - 887)] = {(977 - 977)};
    W04UKm = (923 - 923);
    scanf ("%s", zUtlGQdNRK);
    {
        int d1Vg6s89Q2q5;
        d1Vg6s89Q2q5 = (67 - 67);
        for (; zUtlGQdNRK[d1Vg6s89Q2q5] != '\0';) {
            if (('a' <= zUtlGQdNRK[d1Vg6s89Q2q5]) && (zUtlGQdNRK[d1Vg6s89Q2q5] <= 'z'))
                zUtlGQdNRK[d1Vg6s89Q2q5] = zUtlGQdNRK[d1Vg6s89Q2q5] + ('A' - 'a');
            d1Vg6s89Q2q5 = d1Vg6s89Q2q5 + (137 - 136);
        }
    }
    xr95jgSDc = (43 - 43);
    for (; zUtlGQdNRK[W04UKm] != '\0'; W04UKm = W04UKm +(785 - 784)) {
        if (!(zUtlGQdNRK[W04UKm] != zUtlGQdNRK[W04UKm +(546 - 545)]))
            qC6QH3[xr95jgSDc]++;
        else {
            hW9zp0tsXy1[xr95jgSDc] = zUtlGQdNRK[W04UKm];
            xr95jgSDc = xr95jgSDc + (867 - 866);
        }
    }
    {
        int d1Vg6s89Q2q5;
        d1Vg6s89Q2q5 = (320 - 320);
        for (; xr95jgSDc > d1Vg6s89Q2q5;) {
            printf ("(%c,%d)", hW9zp0tsXy1[d1Vg6s89Q2q5], qC6QH3[d1Vg6s89Q2q5] + (69 - 68));
            d1Vg6s89Q2q5 = d1Vg6s89Q2q5 + (693 - 692);
        }
    }
}

