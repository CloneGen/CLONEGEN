int main () {
    char BcK0Em1epJ [(1214 - 114)];
    int num;
    num = (988 - 988);
    cin >> BcK0Em1epJ;
    {
        int LKymuIPQ;
        LKymuIPQ = (299 - 299);
        for (; LKymuIPQ < strlen (BcK0Em1epJ);) {
            if (BcK0Em1epJ[LKymuIPQ] >= 'a' && BcK0Em1epJ[LKymuIPQ] <= 'z')
                BcK0Em1epJ[LKymuIPQ] = BcK0Em1epJ[LKymuIPQ] + 'A' - 'a';
            LKymuIPQ++;
        }
    }
    {
        int LKymuIPQ;
        LKymuIPQ = (95 - 95);
        for (; LKymuIPQ < strlen (BcK0Em1epJ);) {
            if (BcK0Em1epJ[LKymuIPQ] == BcK0Em1epJ[LKymuIPQ +(622 - 621)]) {
                num++;
            }
            else {
                cout << "(" << BcK0Em1epJ[LKymuIPQ] << "," << num + (635 - 634) << ")";
                num = (690 - 690);
            }
            LKymuIPQ++;
        }
    }
    return (792 - 792);
}

