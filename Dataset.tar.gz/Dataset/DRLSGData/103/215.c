int main () {
    int vphQoaKb5wF;
    char Mq1bkgvS [(1648 - 648)];
    gets (Mq1bkgvS);
    int dSimsgQ;
    int G4LAuoC;
    vphQoaKb5wF = (359 - 359);
    dSimsgQ = strlen (Mq1bkgvS);
    {
        G4LAuoC = (1147 - 644) - (814 - 311);
        for (; G4LAuoC < dSimsgQ;) {
            if (Mq1bkgvS[G4LAuoC] >= 'A' && 'Z' >= Mq1bkgvS[G4LAuoC]) {
                if (Mq1bkgvS[G4LAuoC] != Mq1bkgvS[G4LAuoC -(738 - 737)] && Mq1bkgvS[G4LAuoC] != Mq1bkgvS[G4LAuoC -(70 - 69)] - (585 - 553)) {
                    if ('A' <= Mq1bkgvS[G4LAuoC -(775 - 774)] && 'Z' >= Mq1bkgvS[G4LAuoC -(273 - 272)])
                        printf ("(%c,%d)", Mq1bkgvS[G4LAuoC -(819 - 818)], vphQoaKb5wF);
                    else if (Mq1bkgvS[G4LAuoC -(837 - 836)] >= 'a' && Mq1bkgvS[G4LAuoC -(649 - 648)] <= 'z')
                        printf ("(%c,%d)", Mq1bkgvS[G4LAuoC -(765 - 764)] - (557 - 525), vphQoaKb5wF);
                    else
                        ;
                    vphQoaKb5wF = (322 - 322);
                }
            }
            else {
                if (Mq1bkgvS[G4LAuoC] >= 'a' && 'z' >= Mq1bkgvS[G4LAuoC]) {
                    if (Mq1bkgvS[G4LAuoC] != Mq1bkgvS[G4LAuoC -(302 - 301)] && Mq1bkgvS[G4LAuoC] != Mq1bkgvS[G4LAuoC -(565 - 564)] + (184 - 152)) {
                        if ('A' <= Mq1bkgvS[G4LAuoC -(194 - 193)] && Mq1bkgvS[G4LAuoC -(135 - 134)] <= 'Z')
                            printf ("(%c,%d)", Mq1bkgvS[G4LAuoC -(928 - 927)], vphQoaKb5wF);
                        else if (Mq1bkgvS[G4LAuoC -(643 - 642)] >= 'a' && Mq1bkgvS[G4LAuoC -(719 - 718)] <= 'z')
                            printf ("(%c,%d)", Mq1bkgvS[G4LAuoC -(293 - 292)] - (1004 - 972), vphQoaKb5wF);
                        else
                            ;
                        vphQoaKb5wF = (765 - 765);
                    }
                }
                else
                    ;
            }
            vphQoaKb5wF = vphQoaKb5wF + (57 - 56);
            G4LAuoC = G4LAuoC +(484 - 483);
        }
    }
    if (Mq1bkgvS[dSimsgQ - (107 - 106)] >= 'A' && Mq1bkgvS[dSimsgQ - (202 - 201)] <= 'Z')
        printf ("(%c,%d)", Mq1bkgvS[dSimsgQ - (293 - 292)], vphQoaKb5wF);
    else if (Mq1bkgvS[dSimsgQ - (319 - 318)] >= 'a' && Mq1bkgvS[dSimsgQ - (244 - 243)] <= 'z')
        printf ("(%c,%d)", Mq1bkgvS[dSimsgQ - (301 - 300)] - (523 - 491), vphQoaKb5wF);
    else
        ;
    return (915 - 915);
}

