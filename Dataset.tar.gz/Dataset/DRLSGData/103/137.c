main () {
    int ovu5MgAk;
    char DERSHo8tdJ3;
    int TzfpCMP;
    int pA7LDsh;
    char RYWGs7DV [(1445 - 445)];
    ovu5MgAk = (618 - 617);
    scanf ("%s", RYWGs7DV);
    {
        {
            if ((903 - 903)) {
                return (297 - 297);
            }
        }
        TzfpCMP = (598 - 474) - (495 - 372);
        for (; TzfpCMP < (1179 - 179);) {
            if (!('\0' != RYWGs7DV[TzfpCMP -(548 - 547)]))
                break;
            if (!(RYWGs7DV[TzfpCMP -(423 - 422)] != RYWGs7DV[TzfpCMP]))
                ovu5MgAk = ovu5MgAk + (724 - 723);
            else if (!(RYWGs7DV[TzfpCMP -(637 - 636)] + ('A' - 'a') != RYWGs7DV[TzfpCMP]))
                ovu5MgAk = ovu5MgAk + (286 - 285);
            else if (!(RYWGs7DV[TzfpCMP -(528 - 527)] - ('A' - 'a') != RYWGs7DV[TzfpCMP]))
                ovu5MgAk = ovu5MgAk + (1001 - 1000);
            else {
                if ('A' <= RYWGs7DV[TzfpCMP -(153 - 152)] && RYWGs7DV[TzfpCMP -(156 - 155)] <= 'Z')
                    printf ("(%c,%d)", RYWGs7DV[TzfpCMP -(945 - 944)], ovu5MgAk);
                else {
                    printf ("(%c,%d)", RYWGs7DV[TzfpCMP -(845 - 844)] + 'A' - 'a', ovu5MgAk);
                }
                ovu5MgAk = (827 - 826);
            }
            TzfpCMP = TzfpCMP +(423 - 422);
        }
    }
}

