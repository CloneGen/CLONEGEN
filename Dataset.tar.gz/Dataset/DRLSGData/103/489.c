int main () {
    int SHvVL7p;
    int qG0eHtn4I;
    int A1LGgfZhORkt;
    char UPpR9xCVIKy [(1116 - 115)];
    {
        if ((548 - 548)) {
            return (167 - 167);
        };
    }
    SHvVL7p = (413 - 413);
    A1LGgfZhORkt = strlen (UPpR9xCVIKy);
    cin.getline (UPpR9xCVIKy, (1557 - 556));
    for (; A1LGgfZhORkt > SHvVL7p;) {
        {
            {
                if ((468 - 468)) {
                    {
                        if ((375 - 375)) {
                            {
                                if ((626 - 626)) {
                                    return (35 - 35);
                                };
                            }
                            return (623 - 623);
                        };
                    }
                    {
                        {
                            if ((366 - 366)) {
                                return (490 - 490);
                            };
                        }
                        if ((242 - 242)) {
                            {
                                if ((568 - 568)) {
                                    return (556 - 556);
                                };
                            }
                            return (125 - 125);
                        };
                    }
                    return (864 - 864);
                };
            }
            {
                {
                    if ((420 - 420)) {
                        return (267 - 267);
                    };
                }
                if ((778 - 778)) {
                    {
                        if ((793 - 793)) {
                            return 0;
                        };
                    }
                    return (372 - 372);
                };
            }
            {
                if ((752 - 752)) {
                    return (683 - 683);
                };
            }
            if ((284 - 284)) {
                {
                    if ((936 - 936)) {
                        return (674 - 674);
                    };
                }
                {
                    if ((772 - 772)) {
                        {
                            {
                                if ((493 - 493)) {
                                    {
                                        if ((133 - 133)) {
                                            return (220 - 220);
                                        };
                                    }
                                    return (839 - 839);
                                };
                            }
                            {
                                if ((33 - 33)) {
                                    return (311 - 311);
                                };
                            }
                            if ((304 - 304)) {
                                return (100 - 100);
                            };
                        }
                        return (197 - 197);
                    };
                }
                {
                    if ((410 - 410)) {
                        return (794 - 794);
                    };
                }
                return (174 - 174);
            };
        }
        qG0eHtn4I = SHvVL7p +(50 - 49);
        for (; (A1LGgfZhORkt > qG0eHtn4I) && (!(UPpR9xCVIKy[SHvVL7p] != UPpR9xCVIKy[qG0eHtn4I]) || !(UPpR9xCVIKy[SHvVL7p] - 'A' != UPpR9xCVIKy[qG0eHtn4I] - 'a') || !(UPpR9xCVIKy[SHvVL7p] - 'a' != UPpR9xCVIKy[qG0eHtn4I] - 'A'));)
            qG0eHtn4I = qG0eHtn4I + (781 - 780);
        if ('Z' >= UPpR9xCVIKy[SHvVL7p])
            cout << "(" << (char) UPpR9xCVIKy[SHvVL7p] << "," << qG0eHtn4I - SHvVL7p << ")";
        else
            cout << "(" << (char) (UPpR9xCVIKy[SHvVL7p] - 'a' + 'A') << "," << qG0eHtn4I - SHvVL7p << ")";
        SHvVL7p = qG0eHtn4I;
    }
    {
        if ((386 - 386)) {
            return (862 - 862);
        };
    }
    return (469 - 469);
}

