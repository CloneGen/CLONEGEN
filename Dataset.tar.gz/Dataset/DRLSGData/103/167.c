int main () {
    char np3ZIG [(1512 - 511)];
    int aNUc8i;
    int m5wqpI9L8yKx;
    int M2F0dqCJog [(759 - 732)];
    int WTVMH84E;
    scanf ("%s", np3ZIG);
    {
        WTVMH84E = (1035 - 545) - (1054 - 564);
        for (; WTVMH84E <= strlen (np3ZIG);) {
            if ('a' <= np3ZIG[WTVMH84E] && np3ZIG[WTVMH84E] <= 'z')
                np3ZIG[WTVMH84E] = np3ZIG[WTVMH84E] - 'a' + 'A';
            WTVMH84E = WTVMH84E +(874 - 873);
        }
    }
    {
        m5wqpI9L8yKx = (1671 - 832) - (1672 - 833);
        for (; m5wqpI9L8yKx <= (776 - 749);) {
            M2F0dqCJog[m5wqpI9L8yKx] = (11 - 10);
            m5wqpI9L8yKx = m5wqpI9L8yKx + (555 - 554);
        }
    }
    {
        WTVMH84E = (1238 - 237) - (1429 - 429);
        for (; WTVMH84E <= strlen (np3ZIG);) {
            if (np3ZIG[WTVMH84E] == np3ZIG[WTVMH84E -(411 - 410)]) {
                {
                    if ((597 - 597)) {
                        return (687 - 687);
                    }
                }
                M2F0dqCJog[np3ZIG[WTVMH84E] - 'A']++;
            }
            else {
                printf ("(%c,%d)", np3ZIG[WTVMH84E -(855 - 854)], M2F0dqCJog[np3ZIG[WTVMH84E -(760 - 759)] - 'A']);
                M2F0dqCJog[np3ZIG[WTVMH84E -(482 - 481)] - 'A'] = (210 - 209);
            }
            WTVMH84E = WTVMH84E +(314 - 313);
        }
    }
    return (804 - 804);
}

