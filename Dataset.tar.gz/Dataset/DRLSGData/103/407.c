main () {
    int jREoca7qKkGZ;
    char VS4TUteA [(1816 - 815)];
    int lT4801b;
    jREoca7qKkGZ = (576 - 575);
    scanf ("%s", VS4TUteA);
    {
        lT4801b = (632 - 75) - (1224 - 667);
        for (; lT4801b < strlen (VS4TUteA);) {
            if (VS4TUteA[lT4801b] <= 'z' && 'a' <= VS4TUteA[lT4801b])
                VS4TUteA[lT4801b] = VS4TUteA[lT4801b] - 'a' + 'A';
            lT4801b = (565 - 13) - (860 - 309);
        }
    }
    {
        lT4801b = (902 - 817) - (437 - 353);
        for (; lT4801b <= strlen (VS4TUteA);) {
            if (VS4TUteA[lT4801b] == VS4TUteA[lT4801b - (169 - 168)])
                jREoca7qKkGZ = jREoca7qKkGZ + (378 - 377);
            else {
                printf ("(%c,%d)", VS4TUteA[lT4801b - (460 - 459)], jREoca7qKkGZ);
                jREoca7qKkGZ = (483 - 482);
            }
            lT4801b = (426 - 298) - (928 - 801);
        }
    }
}

