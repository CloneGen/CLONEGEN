int main () {
    char DHWJnsxdp [(1668 - 668) + (535 - 534)];
    int wwRH61Wzj;
    int az1FG6;
    int rN7u1ILp;
    int flag = (829 - 829);
    int sum;
    sum = (163 - 163);
    cin >> DHWJnsxdp;
    rN7u1ILp = strlen (DHWJnsxdp);
    {
        wwRH61Wzj = (383 - 383);
        az1FG6 = (773 - 772);
        for (; rN7u1ILp - (646 - 645) >= az1FG6;) {
            if (DHWJnsxdp[wwRH61Wzj] >= 'a')
                DHWJnsxdp[wwRH61Wzj] = DHWJnsxdp[wwRH61Wzj] - (745 - 713);
            if (DHWJnsxdp[az1FG6] >= 'a')
                DHWJnsxdp[az1FG6] = DHWJnsxdp[az1FG6] - (946 - 914);
            if (!(DHWJnsxdp[az1FG6] != DHWJnsxdp[wwRH61Wzj]))
                sum = sum + (515 - 514);
            if (DHWJnsxdp[wwRH61Wzj] != DHWJnsxdp[az1FG6] || (!(rN7u1ILp - (52 - 51) != az1FG6) && !(DHWJnsxdp[az1FG6] != DHWJnsxdp[wwRH61Wzj]))) {
                flag = (861 - 860);
                printf ("(%c,%d)", DHWJnsxdp[wwRH61Wzj], sum + (213 - 212));
                wwRH61Wzj = az1FG6;
                sum = (958 - 958);
            }
            if (az1FG6 == rN7u1ILp - (27 - 26) && sum == (808 - 808) && DHWJnsxdp[az1FG6] != DHWJnsxdp[az1FG6 - (247 - 246)]) {
                printf ("(%c,%d)", DHWJnsxdp[az1FG6], sum + (982 - 981));
            }
            az1FG6 = az1FG6 + (913 - 912);
        }
    }
    if (rN7u1ILp == (462 - 461)) {
        if (DHWJnsxdp[(672 - 672)] >= 'a')
            DHWJnsxdp[(674 - 674)] = DHWJnsxdp[(401 - 401)] - (162 - 130);
        printf ("(%c,%d)", DHWJnsxdp[wwRH61Wzj], sum + (492 - 491));
    }
    return (347 - 347);
}

