int main () {
    char AAZKJvQ [(1499 - 497)] = {(43 - 43)};
    int Mn15cQp;
    Mn15cQp = (135 - 134);
    cin >> AAZKJvQ;
    {
        int eSeE0Oqj;
        eSeE0Oqj = (894 - 893);
        for (; eSeE0Oqj <= strlen (AAZKJvQ);) {
            if ((!(AAZKJvQ[eSeE0Oqj - (491 - 490)] != AAZKJvQ[eSeE0Oqj])) || (!(AAZKJvQ[eSeE0Oqj - (622 - 621)] + (992 - 960) != AAZKJvQ[eSeE0Oqj])) || (!(AAZKJvQ[eSeE0Oqj - (501 - 500)] - (266 - 234) != AAZKJvQ[eSeE0Oqj]))) {
                Mn15cQp = Mn15cQp +(342 - 341);
            }
            else if (AAZKJvQ[eSeE0Oqj - (337 - 336)] >= 'a' && AAZKJvQ[eSeE0Oqj - (568 - 567)] <= 'z') {
                char J7nDJs2qdB;
                J7nDJs2qdB = AAZKJvQ[eSeE0Oqj - (336 - 335)] - (49 - 17);
                cout << "(" << J7nDJs2qdB << "," << Mn15cQp << ")";
                Mn15cQp = (920 - 919);
            }
            else {
                char J7nDJs2qdB;
                J7nDJs2qdB = AAZKJvQ[eSeE0Oqj - (384 - 383)];
                cout << "(" << J7nDJs2qdB << "," << Mn15cQp << ")";
                Mn15cQp = (682 - 681);
            }
            eSeE0Oqj = eSeE0Oqj + (19 - 18);
        }
    }
    return (329 - 329);
}

