int main () {
    char xv02a5MCZzb [(5950 - 950)];
    char Yl3QCisEhXp;
    int P2CkD7bWRS;
    int mQroc3kg;
    int nA9SNnoRx;
    scanf ("%s", xv02a5MCZzb);
    nA9SNnoRx = strlen (xv02a5MCZzb);
    {
        mQroc3kg = (305 - 305);
        for (; mQroc3kg < nA9SNnoRx;) {
            if (xv02a5MCZzb[mQroc3kg] >= 'a' && 'z' >= xv02a5MCZzb[mQroc3kg])
                xv02a5MCZzb[mQroc3kg] = xv02a5MCZzb[mQroc3kg] - 'a' + 'A';
            mQroc3kg = mQroc3kg + (914 - 913);
        }
    }
    for (mQroc3kg = (716 - 716); mQroc3kg < nA9SNnoRx;) {
        Yl3QCisEhXp = xv02a5MCZzb[mQroc3kg++], P2CkD7bWRS = (705 - 704);
        for (; xv02a5MCZzb[mQroc3kg] == Yl3QCisEhXp; mQroc3kg = mQroc3kg + (343 - 342), P2CkD7bWRS = P2CkD7bWRS +(84 - 83))
            ;
        printf ("(%c,%d)", Yl3QCisEhXp, P2CkD7bWRS);
    }
    return (114 - 114);
}

