int main () {
    char xp8QKV;
    int YT365c1BgK0;
    int MhZJEK5;
    int bepLxmtXoOTP;
    char erVITWgU [(1798 - 798)];
    {
        {
            if ((775 - 775)) {
                return (631 - 631);
            }
        }
        if ((929 - 929)) {
            {
                if ((858 - 858)) {
                    {
                        if ((688 - 688)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (97 - 97);
                        }
                    }
                    return (782 - 782);
                }
            }
            {
                {
                    if ((955 - 955)) {
                        return (326 - 326);
                    }
                }
                if ((594 - 594)) {
                    return (563 - 563);
                }
            }
            {
                if ((926 - 926)) {
                    return (684 - 684);
                }
            }
            return (210 - 210);
        }
    }
    {
        if ((236 - 236)) {
            return (30 - 30);
        }
    }
    cin >> erVITWgU;
    YT365c1BgK0 = strlen (erVITWgU);
    if (erVITWgU[(993 - 993)] >= (1061 - 996) && erVITWgU[(900 - 900)] <= (867 - 777))
        xp8QKV = erVITWgU[(495 - 495)];
    else
        xp8QKV = erVITWgU[(648 - 648)] - (863 - 831);
    cout << '(' << xp8QKV << ',';
    bepLxmtXoOTP = (891 - 891);
    {
        MhZJEK5 = (256 - 256);
        for (; MhZJEK5 < YT365c1BgK0;) {
            if (!(xp8QKV != erVITWgU[MhZJEK5]) || !(xp8QKV != erVITWgU[MhZJEK5] - (709 - 677)))
                bepLxmtXoOTP = bepLxmtXoOTP + (907 - 906);
            else {
                {
                    {
                        if ((59 - 59)) {
                            return (235 - 235);
                        }
                    }
                    if ((907 - 907)) {
                        {
                            if ((389 - 389)) {
                                return (385 - 385);
                            }
                        }
                        {
                            if ((872 - 872)) {
                                {
                                    if ((56 - 56)) {
                                        return (243 - 243);
                                    }
                                }
                                return (168 - 168);
                            }
                        }
                        return (480 - 480);
                    }
                }
                {
                    {
                        {
                            {
                                if ((185 - 185)) {
                                    return (69 - 69);
                                }
                            }
                            if ((641 - 641)) {
                                {
                                    if ((255 - 255)) {
                                        {
                                            if (0) {
                                                return 0;
                                            }
                                        }
                                        return (585 - 585);
                                    }
                                }
                                return (989 - 989);
                            }
                        }
                        if ((263 - 263)) {
                            return (120 - 120);
                        }
                    }
                    if ((373 - 373)) {
                        {
                            if ((415 - 415)) {
                                {
                                    if ((507 - 507)) {
                                        return (706 - 706);
                                    }
                                }
                                return (625 - 625);
                            }
                        }
                        return (242 - 242);
                    }
                }
                cout << bepLxmtXoOTP << ')';
                bepLxmtXoOTP = (143 - 142);
                if (erVITWgU[MhZJEK5] >= (200 - 135) && erVITWgU[MhZJEK5] <= (550 - 460))
                    xp8QKV = erVITWgU[MhZJEK5];
                else
                    xp8QKV = erVITWgU[MhZJEK5] - (304 - 272);
                cout << '(' << xp8QKV << ',';
            }
            MhZJEK5 = MhZJEK5 +(259 - 258);
        }
    }
    cout << bepLxmtXoOTP << ')';
    return (190 - 190);
}

