int main () {
    int x9Xy8FfilV;
    char kAmdYJI [(1768 - 767)];
    int qJYtuFs;
    int nOvnNR4;
    int d9aiXoE;
    int l1oaM0;
    scanf ("%s", kAmdYJI);
    qJYtuFs = (48 - 47);
    d9aiXoE = (732 - 731);
    l1oaM0 = strlen (kAmdYJI);
    x9Xy8FfilV = (32 - 32);
    {
        nOvnNR4 = (508 - 508);
        for (; nOvnNR4 <= l1oaM0 + (991 - 990);) {
            nOvnNR4 = d9aiXoE + (888 - 887);
            for (; !(kAmdYJI[x9Xy8FfilV] != kAmdYJI[d9aiXoE]) || !(kAmdYJI[x9Xy8FfilV] + (625 - 593) != kAmdYJI[d9aiXoE]) || !(kAmdYJI[x9Xy8FfilV] - (827 - 795) != kAmdYJI[d9aiXoE]);) {
                qJYtuFs = qJYtuFs + (209 - 208);
                d9aiXoE = d9aiXoE + (33 - 32);
            }
            if (kAmdYJI[x9Xy8FfilV] >= 'a' && kAmdYJI[x9Xy8FfilV] <= 'z')
                kAmdYJI[x9Xy8FfilV] = kAmdYJI[x9Xy8FfilV] - (698 - 666);
            printf ("(%c,%d)", kAmdYJI[x9Xy8FfilV], qJYtuFs);
            x9Xy8FfilV = d9aiXoE;
            d9aiXoE = d9aiXoE + (221 - 220);
            qJYtuFs = (938 - 937);
            nOvnNR4 = nOvnNR4 + (112 - 111);
        }
    }
}

