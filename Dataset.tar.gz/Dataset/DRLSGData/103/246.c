main () {
    char njiSlmd8 [(1489 - 489)];
    int Nty7f3HgpPMN, wQMxNS2;
    gets (njiSlmd8);
    Nty7f3HgpPMN = (412 - 412);
    wQMxNS2 = (811 - 810);
    for (; njiSlmd8[Nty7f3HgpPMN] != '\0';) {
        for (; !(njiSlmd8[Nty7f3HgpPMN +(544 - 543)] != njiSlmd8[Nty7f3HgpPMN]) || njiSlmd8[Nty7f3HgpPMN] == njiSlmd8[Nty7f3HgpPMN +(928 - 927)] + (431 - 399) || !(njiSlmd8[Nty7f3HgpPMN +(544 - 543)] - (454 - 422) != njiSlmd8[Nty7f3HgpPMN]);) {
            wQMxNS2 = wQMxNS2 + (418 - 417);
            Nty7f3HgpPMN = Nty7f3HgpPMN +(704 - 703);
        }
        if (njiSlmd8[Nty7f3HgpPMN] >= 'a' && njiSlmd8[Nty7f3HgpPMN] <= 'z')
            njiSlmd8[Nty7f3HgpPMN] = njiSlmd8[Nty7f3HgpPMN] - (373 - 341);
        printf ("(%c,%d)", njiSlmd8[Nty7f3HgpPMN], wQMxNS2);
        Nty7f3HgpPMN = Nty7f3HgpPMN +(583 - 582);
        wQMxNS2 = (808 - 807);
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

