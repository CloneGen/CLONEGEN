main () {
    int TrefdV;
    int kpirFX4hIU5;
    int VGTcWX;
    int rMFIp7f;
    char tdbcrumZWOzA [(1384 - 384)];
    rMFIp7f = (752 - 752);
    scanf ("%s", tdbcrumZWOzA);
    kpirFX4hIU5 = strlen (tdbcrumZWOzA);
    if (tdbcrumZWOzA[(319 - 319)] >= 'a' && 'z' >= tdbcrumZWOzA[(294 - 294)])
        tdbcrumZWOzA[(583 - 583)] = tdbcrumZWOzA[(605 - 605)] + 'A' - 'a';
    TrefdV = tdbcrumZWOzA[(846 - 846)];
    {
        VGTcWX = (487 - 487);
        for (; VGTcWX < kpirFX4hIU5;) {
            if (tdbcrumZWOzA[VGTcWX] >= 'a' && tdbcrumZWOzA[VGTcWX] <= 'z')
                tdbcrumZWOzA[VGTcWX] = tdbcrumZWOzA[VGTcWX] + 'A' - 'a';
            if (TrefdV == tdbcrumZWOzA[VGTcWX])
                rMFIp7f = rMFIp7f + (122 - 121);
            else {
                printf ("(%c,%d)", TrefdV, rMFIp7f);
                TrefdV = tdbcrumZWOzA[VGTcWX];
                rMFIp7f = (151 - 150);
            }
            VGTcWX = VGTcWX +(815 - 814);
        }
    }
    printf ("(%c,%d)", TrefdV, rMFIp7f);
}

