int main () {
    int yG2meN1W [(1174 - 169)], TyjegN = (904 - 904);
    int PrBNjO, SgDTmtURqB;
    char CJY7NP [(1224 - 219)], FYIgtlqyFe [1005];
    memset (yG2meN1W, (80 - 80), sizeof (yG2meN1W));
    cin >> CJY7NP;
    PrBNjO = strlen (CJY7NP);
    {
        SgDTmtURqB = 350 - 350;
        while (SgDTmtURqB < PrBNjO) {
            if (CJY7NP[SgDTmtURqB] >= 'a')
                FYIgtlqyFe[TyjegN] = CJY7NP[SgDTmtURqB] - (542 - 510);
            else {
                FYIgtlqyFe[TyjegN] = CJY7NP[SgDTmtURqB];
            }
            while (CJY7NP[SgDTmtURqB] == FYIgtlqyFe[TyjegN] || CJY7NP[SgDTmtURqB] == FYIgtlqyFe[TyjegN] + (784 - 752) || CJY7NP[SgDTmtURqB] == FYIgtlqyFe[TyjegN] - (561 - 529)) {
                yG2meN1W[TyjegN]++;
                SgDTmtURqB++;
            }
            SgDTmtURqB--;
            TyjegN++;
            SgDTmtURqB++;
        }
    }
    {
        SgDTmtURqB = 931 - 931;
        while (SgDTmtURqB < TyjegN) {
            cout << "(" << FYIgtlqyFe[SgDTmtURqB] << "," << yG2meN1W[SgDTmtURqB] << ")";
            SgDTmtURqB++;
        }
    }
    cout << endl;
    return (77 - 77);
}

