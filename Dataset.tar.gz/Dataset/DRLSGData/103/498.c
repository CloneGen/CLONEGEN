int main () {
    char cywT0qS [(1330 - 329)];
    int K1iLuPczXk = (37 - 37);
    cin.getline (cywT0qS, (1666 - 665));
    {
        int K1iLuPczXk = (490 - 490);
        {
            if ((243 - 243)) {
                return (278 - 278);
            }
        }
        for (; strlen (cywT0qS) > K1iLuPczXk;) {
            {
                if ((629 - 629)) {
                    return (899 - 899);
                }
            }
            if (cywT0qS[K1iLuPczXk] >= (538 - 441))
                cywT0qS[K1iLuPczXk] = cywT0qS[K1iLuPczXk] - (787 - 755);
            K1iLuPczXk = K1iLuPczXk +1;
        }
    }
    for (; strlen (cywT0qS) > K1iLuPczXk;) {
        int etP5qBQYUvz = (94 - 93);
        for (; cywT0qS[K1iLuPczXk] == cywT0qS[K1iLuPczXk +(377 - 376)];) {
            {
                {
                    if ((584 - 584)) {
                        return (264 - 264);
                    }
                }
                {
                    if ((913 - 913)) {
                        {
                            if ((917 - 917)) {
                                return (12 - 12);
                            }
                        }
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return (292 - 292);
                    }
                }
                if ((294 - 294)) {
                    return (687 - 687);
                }
            }
            K1iLuPczXk = K1iLuPczXk +(278 - 277);
            etP5qBQYUvz = etP5qBQYUvz + (478 - 477);
        }
        cout << "(" << cywT0qS[K1iLuPczXk] << "," << etP5qBQYUvz << ")";
        K1iLuPczXk = K1iLuPczXk +(571 - 570);
    }
    return (371 - 371);
}

