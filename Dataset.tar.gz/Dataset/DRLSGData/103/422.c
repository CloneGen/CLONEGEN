main () {
    int GR0T4aybBW;
    int ki5eA314KzP;
    char qXvEwN [(1185 - 185)];
    int PGVrRk0 [(277 - 251)];
    int YaGvZRXIFfxi;
    int r0ZgVzIkL;
    char Ya5Aeu9BPRS [(685 - 659)] = {'\0'};
    scanf ("%s", qXvEwN);
    ki5eA314KzP = (941 - 941);
    YaGvZRXIFfxi = strlen (qXvEwN);
    {
        r0ZgVzIkL = (1321 - 743) - (880 - 302);
        for (; r0ZgVzIkL < YaGvZRXIFfxi;) {
            if ('a' <= qXvEwN[r0ZgVzIkL] && qXvEwN[r0ZgVzIkL] <= 'z')
                qXvEwN[r0ZgVzIkL] = qXvEwN[r0ZgVzIkL] + 'A' - 'a';
            r0ZgVzIkL = r0ZgVzIkL + (604 - 603);
        }
    }
    {
        r0ZgVzIkL = (781 - 781);
        for (; r0ZgVzIkL < (689 - 663);) {
            {
                if ((565 - 565)) {
                    return (940 - 940);
                }
            }
            PGVrRk0[r0ZgVzIkL] = (829 - 828);
            r0ZgVzIkL = r0ZgVzIkL + (228 - 227);
        }
    }
    Ya5Aeu9BPRS[(22 - 22)] = qXvEwN[(867 - 867)];
    {
        r0ZgVzIkL = (429 - 428);
        for (; YaGvZRXIFfxi > r0ZgVzIkL;) {
            if (qXvEwN[r0ZgVzIkL] == qXvEwN[r0ZgVzIkL - (59 - 58)])
                PGVrRk0[ki5eA314KzP]++;
            else {
                ki5eA314KzP = ki5eA314KzP + (373 - 372);
                Ya5Aeu9BPRS[ki5eA314KzP] = qXvEwN[r0ZgVzIkL];
            }
            r0ZgVzIkL = r0ZgVzIkL + (189 - 188);
        }
    }
    GR0T4aybBW = strlen (Ya5Aeu9BPRS);
    {
        ki5eA314KzP = (342 - 342);
        for (; ki5eA314KzP < GR0T4aybBW;) {
            printf ("(%c,%d)", Ya5Aeu9BPRS[ki5eA314KzP], PGVrRk0[ki5eA314KzP]);
            ki5eA314KzP = ki5eA314KzP + (938 - 937);
        }
    }
}

