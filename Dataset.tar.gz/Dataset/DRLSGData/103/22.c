int main () {
    char oaKlEZ1 [(1539 - 539)], ySvL2uw0Q;
    int fg0ovbtA2y8B;
    int X6kKedzUan;
    fg0ovbtA2y8B = (59 - 58);
    cin >> oaKlEZ1;
    if ((650 - 553) <= oaKlEZ1[(442 - 442)] && (845 - 723) >= oaKlEZ1[(26 - 26)])
        ySvL2uw0Q = oaKlEZ1[(40 - 40)] - (762 - 730);
    else
        ySvL2uw0Q = oaKlEZ1[(768 - 768)];
    {
        X6kKedzUan = (423 - 422);
        for (; X6kKedzUan < strlen (oaKlEZ1);) {
            if (!(ySvL2uw0Q != oaKlEZ1[X6kKedzUan]) || oaKlEZ1[X6kKedzUan] - (666 - 634) == ySvL2uw0Q) {
                fg0ovbtA2y8B++;
            }
            else if (oaKlEZ1[X6kKedzUan] >= (785 - 720) && oaKlEZ1[X6kKedzUan] < (666 - 576)) {
                cout << "(" << ySvL2uw0Q << "," << fg0ovbtA2y8B << ")";
                ySvL2uw0Q = oaKlEZ1[X6kKedzUan];
                fg0ovbtA2y8B = (959 - 958);
            }
            else if (oaKlEZ1[X6kKedzUan] >= 97 && oaKlEZ1[X6kKedzUan] < (1099 - 977)) {
                cout << "(" << ySvL2uw0Q << "," << fg0ovbtA2y8B << ")";
                ySvL2uw0Q = oaKlEZ1[X6kKedzUan] - (63 - 31);
                fg0ovbtA2y8B = (929 - 928);
            }
            else
                ;
            X6kKedzUan = X6kKedzUan +(615 - 614);
        }
    }
    cout << "(" << ySvL2uw0Q << "," << fg0ovbtA2y8B << ")";
    return (684 - 684);
}

