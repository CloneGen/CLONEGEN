int main () {
    int cPimMGa;
    char H3EQKXpi;
    char CZYrQ9zJwcV [(1587 - 586)];
    int AIheTqa;
    int sTIocr79U;
    cin >> CZYrQ9zJwcV;
    cPimMGa = strlen (CZYrQ9zJwcV);
    if (CZYrQ9zJwcV[(219 - 219)] >= 'a' && 'z' >= CZYrQ9zJwcV[(215 - 215)])
        H3EQKXpi = CZYrQ9zJwcV[(898 - 898)] - (283 - 251);
    else
        H3EQKXpi = CZYrQ9zJwcV[(920 - 920)];
    AIheTqa = (370 - 369);
    {
        sTIocr79U = (631 - 497) - (600 - 467);
        for (; cPimMGa >= sTIocr79U;) {
            if (CZYrQ9zJwcV[sTIocr79U] >= 'a' && CZYrQ9zJwcV[sTIocr79U] <= 'z')
                CZYrQ9zJwcV[sTIocr79U] = CZYrQ9zJwcV[sTIocr79U] - (1015 - 983);
            if (H3EQKXpi == CZYrQ9zJwcV[sTIocr79U])
                AIheTqa = AIheTqa +(736 - 735);
            else {
                cout << '(' << H3EQKXpi << ',' << AIheTqa << ')';
                AIheTqa = (185 - 184);
                H3EQKXpi = CZYrQ9zJwcV[sTIocr79U];
            }
            sTIocr79U = sTIocr79U + (182 - 181);
        }
    }
    return (632 - 632);
}

