int main () {
    char WZXYIdDgwa [(1478 - 477)];
    int nuV0vseN;
    int dHwBt4fE;
    {
        if ((579 - 579)) {
            return (116 - 116);
        }
    }
    cin >> WZXYIdDgwa;
    {
        nuV0vseN = (450 - 450);
        for (; WZXYIdDgwa[nuV0vseN] != '\0';) {
            if ('a' <= WZXYIdDgwa[nuV0vseN] && WZXYIdDgwa[nuV0vseN] <= 'z')
                WZXYIdDgwa[nuV0vseN] = WZXYIdDgwa[nuV0vseN] - (910 - 878);
            nuV0vseN = nuV0vseN + (225 - 224);
        }
    }
    dHwBt4fE = (660 - 659);
    {
        nuV0vseN = (461 - 410) - (1012 - 962);
        for (; WZXYIdDgwa[nuV0vseN] != '\0';) {
            if (WZXYIdDgwa[nuV0vseN] == WZXYIdDgwa[nuV0vseN - (231 - 230)])
                dHwBt4fE = dHwBt4fE + (200 - 199);
            else {
                cout << '(' << WZXYIdDgwa[nuV0vseN - (301 - 300)] << ',' << dHwBt4fE << ')';
                dHwBt4fE = (228 - 227);
            }
            nuV0vseN = nuV0vseN + (585 - 584);
        }
    }
    cout << '(' << WZXYIdDgwa[nuV0vseN - (747 - 746)] << ',' << dHwBt4fE << ')' << endl;
    return (813 - 813);
}

