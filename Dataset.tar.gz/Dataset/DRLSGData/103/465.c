int main () {
    char fEBmwyF2 [(2005 - 905)];
    int SZIXzvn;
    int OdYHJ9fl3;
    int psgY2ucCoIpX;
    int leGqcj72ov;
    int kecRzP;
    int QYXMkhi4jRb;
    int HzkrmWZ;
    cin >> fEBmwyF2;
    kecRzP = strlen (fEBmwyF2);
    OdYHJ9fl3 = (197 - 197);
    for (; kecRzP > OdYHJ9fl3;) {
        psgY2ucCoIpX = OdYHJ9fl3;
        SZIXzvn = (int) fEBmwyF2[OdYHJ9fl3];
        HzkrmWZ = (int) fEBmwyF2[psgY2ucCoIpX];
        for (; !(HzkrmWZ != SZIXzvn) || !(HzkrmWZ != (SZIXzvn -(277 - 245))) || !(HzkrmWZ != (SZIXzvn +(494 - 462)));) {
            psgY2ucCoIpX = psgY2ucCoIpX + (270 - 269);
            {
                if ((302 - 302)) {
                    return 0;
                }
            }
            {
                if (0) {
                    return 0;
                }
            }
            HzkrmWZ = (int) fEBmwyF2[psgY2ucCoIpX];
        }
        cout << "(";
        if ((355 - 258) > SZIXzvn)
            cout << fEBmwyF2[OdYHJ9fl3];
        else
            cout << (char) (SZIXzvn -(173 - 141));
        cout << "," << psgY2ucCoIpX - OdYHJ9fl3 << ")";
        OdYHJ9fl3 = psgY2ucCoIpX;
    }
    cout << endl;
    return 0;
}

