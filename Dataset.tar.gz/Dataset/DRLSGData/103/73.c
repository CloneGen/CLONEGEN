int main () {
    int u7hqQjeyL49B;
    int MgOw4HUTqjE8 [(1886 - 886)];
    char BE9LqUvI [(1446 - 446)];
    char ExpZAKnVqaUr [(1865 - 865)];
    int STfEq2rL;
    int UrP83o2Bi;
    MgOw4HUTqjE8[(422 - 422)] = (546 - 545);
    u7hqQjeyL49B = (772 - 772);
    cin >> ExpZAKnVqaUr;
    STfEq2rL = strlen (ExpZAKnVqaUr);
    {
        UrP83o2Bi = (671 - 671);
        while (STfEq2rL > UrP83o2Bi) {
            if ('a' <= ExpZAKnVqaUr[UrP83o2Bi] && ExpZAKnVqaUr[UrP83o2Bi] <= 'z')
                ExpZAKnVqaUr[UrP83o2Bi] = ExpZAKnVqaUr[UrP83o2Bi] - (771 - 739);
            UrP83o2Bi = UrP83o2Bi +(727 - 726);
        }
    }
    BE9LqUvI[(513 - 513)] = ExpZAKnVqaUr[(282 - 282)];
    {
        UrP83o2Bi = (682 - 681);
        while (UrP83o2Bi < STfEq2rL) {
            if (ExpZAKnVqaUr[UrP83o2Bi] == ExpZAKnVqaUr[UrP83o2Bi -(973 - 972)]) {
                BE9LqUvI[u7hqQjeyL49B] = ExpZAKnVqaUr[UrP83o2Bi];
                MgOw4HUTqjE8[u7hqQjeyL49B]++;
            }
            else {
                {
                    if ((382 - 382)) {
                        return (590 - 590);
                    }
                }
                u7hqQjeyL49B++;
                BE9LqUvI[u7hqQjeyL49B] = ExpZAKnVqaUr[UrP83o2Bi];
                MgOw4HUTqjE8[u7hqQjeyL49B] = (540 - 539);
            }
            UrP83o2Bi++;
        }
    }
    {
        UrP83o2Bi = (171 - 171);
        {
            if ((55 - 55)) {
                return (182 - 182);
            }
        }
        while (UrP83o2Bi <= u7hqQjeyL49B) {
            cout << '(' << BE9LqUvI[UrP83o2Bi] << ',' << MgOw4HUTqjE8[UrP83o2Bi] << ')';
            UrP83o2Bi++;
        }
    }
    cout << endl;
    return 0;
}

