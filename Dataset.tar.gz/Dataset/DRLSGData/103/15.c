int main () {
    char iOMX2KjBUd;
    int PBL9zi;
    char m0Y7QFauig4 [(1206 - 206)];
    cin >> m0Y7QFauig4;
    {
        int UepgRL;
        UepgRL = (396 - 396);
        for (; m0Y7QFauig4[UepgRL] != '\0';) {
            if ('a' <= m0Y7QFauig4[UepgRL])
                m0Y7QFauig4[UepgRL] = m0Y7QFauig4[UepgRL] - 'a' - 'A';
            UepgRL = UepgRL +(721 - 720);
        }
    }
    iOMX2KjBUd = m0Y7QFauig4[(64 - 64)];
    PBL9zi = (150 - 150);
    {
        int UepgRL;
        UepgRL = (370 - 370);
        for (; m0Y7QFauig4[UepgRL] != '\0';) {
            if (m0Y7QFauig4[UepgRL] != iOMX2KjBUd) {
                printf ("(%c,%d)", iOMX2KjBUd, PBL9zi);
                iOMX2KjBUd = m0Y7QFauig4[UepgRL];
                PBL9zi = (553 - 552);
            }
            else
                PBL9zi = PBL9zi +(700 - 699);
            UepgRL = UepgRL +(946 - 945);
        }
    }
    printf ("(%c,%d)", iOMX2KjBUd, PBL9zi);
    return (731 - 731);
}

