int main () {
    char F0IbFk2iGPR [(1604 - 604)];
    int I6e2kusmyW [(1339 - 339)] = {(845 - 845)};
    int EvcdxNG5R3;
    int jIUAECr8jG0;
    char IEvFwsKa1Y [(1157 - 156)];
    char UriSD1J;
    I6e2kusmyW[(810 - 810)] = (610 - 609);
    jIUAECr8jG0 = (732 - 732);
    cin >> IEvFwsKa1Y;
    {
        EvcdxNG5R3 = (786 - 786);
        for (; EvcdxNG5R3 < strlen (IEvFwsKa1Y);) {
            if (IEvFwsKa1Y[EvcdxNG5R3] >= (403 - 306) && IEvFwsKa1Y[EvcdxNG5R3] <= (409 - 287))
                IEvFwsKa1Y[EvcdxNG5R3] = IEvFwsKa1Y[EvcdxNG5R3] - (873 - 841);
            EvcdxNG5R3 = EvcdxNG5R3 +(419 - 418);
        }
    }
    F0IbFk2iGPR[(544 - 544)] = UriSD1J = IEvFwsKa1Y[(500 - 500)];
    {
        EvcdxNG5R3 = (619 - 618);
        for (; strlen (IEvFwsKa1Y) > EvcdxNG5R3;) {
            if (IEvFwsKa1Y[EvcdxNG5R3] == UriSD1J)
                I6e2kusmyW[jIUAECr8jG0]++;
            else {
                jIUAECr8jG0 = jIUAECr8jG0 + (318 - 317);
                I6e2kusmyW[jIUAECr8jG0 + (889 - 888)] = (525 - 524);
                F0IbFk2iGPR[jIUAECr8jG0 + (794 - 793)] = IEvFwsKa1Y[EvcdxNG5R3];
                UriSD1J = IEvFwsKa1Y[EvcdxNG5R3];
            }
            EvcdxNG5R3 = EvcdxNG5R3 +(115 - 114);
        }
    }
    {
        EvcdxNG5R3 = (455 - 455);
        for (; EvcdxNG5R3 <= jIUAECr8jG0;) {
            cout << '(' << F0IbFk2iGPR[EvcdxNG5R3] << ',' << I6e2kusmyW[EvcdxNG5R3] << ')';
            EvcdxNG5R3 = EvcdxNG5R3 +(261 - 260);
        }
    }
    cout << endl;
    return (876 - 876);
}

