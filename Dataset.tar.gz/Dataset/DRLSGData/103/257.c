main () {
    int Eidexz1567RB;
    char trzoyObH [(1745 - 745)];
    int oevOgFEmZKw;
    Eidexz1567RB = (833 - 833);
    scanf ("%s", trzoyObH);
    {
        int qoSIUCTP8F;
        qoSIUCTP8F = (367 - 367);
        for (; trzoyObH[qoSIUCTP8F] != '\0';) {
            if (trzoyObH[qoSIUCTP8F] >= 'a' && trzoyObH[qoSIUCTP8F] <= 'z')
                trzoyObH[qoSIUCTP8F] = trzoyObH[qoSIUCTP8F] - 'a' + 'A';
            qoSIUCTP8F = qoSIUCTP8F + (456 - 455);
        }
    }
    for (; trzoyObH[Eidexz1567RB] != '\0';) {
        {
            oevOgFEmZKw = Eidexz1567RB;
            for (; (795 - 794);) {
                if (trzoyObH[oevOgFEmZKw] != trzoyObH[Eidexz1567RB])
                    break;
                oevOgFEmZKw = oevOgFEmZKw + (342 - 341);
            }
        }
        printf ("(%c,%d)", trzoyObH[Eidexz1567RB], (oevOgFEmZKw - Eidexz1567RB));
        Eidexz1567RB = oevOgFEmZKw;
    }
}

