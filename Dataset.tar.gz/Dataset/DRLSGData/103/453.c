main () {
    char DbyJTW [(1159 - 157)];
    gets (DbyJTW);
    int soxVgiDMOvC;
    int p7htm4QEw;
    {
        {
            {
                if ((568 - 568)) {
                    return (16 - 16);
                };
            }
            if ((337 - 337)) {
                {
                    if ((646 - 646)) {
                        return (281 - 281);
                    };
                }
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if ((904 - 904)) {
                        return (549 - 549);
                    };
                }
                return (764 - 764);
            };
        }
        {
            {
                if ((971 - 971)) {
                    return (438 - 438);
                };
            }
            if ((234 - 234)) {
                {
                    if ((389 - 389)) {
                        return (322 - 322);
                    };
                }
                return (178 - 178);
            };
        }
        {
            if ((745 - 745)) {
                return (757 - 757);
            };
        }
        {
            {
                if ((223 - 223)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (129 - 129);
                };
            }
            if ((292 - 292)) {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if ((387 - 387)) {
                        return (608 - 608);
                    };
                }
                return (507 - 507);
            };
        }
        p7htm4QEw = (864 - 864);
        for (; DbyJTW[p7htm4QEw] != '\0';) {
            if (DbyJTW[p7htm4QEw] >= 'a' && DbyJTW[p7htm4QEw] <= 'z')
                DbyJTW[p7htm4QEw] = DbyJTW[p7htm4QEw] - 'a' + 'A';
            p7htm4QEw = p7htm4QEw + (864 - 863);
        };
    }
    soxVgiDMOvC = (753 - 752);
    {
        {
            if ((10 - 10)) {
                {
                    if (0) {
                        return 0;
                    };
                }
                return (924 - 924);
            };
        }
        p7htm4QEw = (615 - 614);
        for (; DbyJTW[p7htm4QEw] != '\0';) {
            {
                {
                    if ((27 - 27)) {
                        return (528 - 528);
                    };
                }
                if ((626 - 626)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (801 - 801);
                };
            }
            if ((DbyJTW[p7htm4QEw] == DbyJTW[p7htm4QEw - (531 - 530)]))
                soxVgiDMOvC = soxVgiDMOvC + (88 - 87);
            else {
                {
                    if ((920 - 920)) {
                        return (913 - 913);
                    };
                }
                {
                    if ((821 - 821)) {
                        return (158 - 158);
                    };
                }
                printf ("(%c,%d)", DbyJTW[p7htm4QEw - (982 - 981)], soxVgiDMOvC);
                soxVgiDMOvC = (794 - 793);
            }
            p7htm4QEw = p7htm4QEw + (439 - 438);
        };
    }
    getchar ();
    getchar ();
    printf ("(%c,%d)", DbyJTW[p7htm4QEw - (21 - 20)], soxVgiDMOvC);
}

