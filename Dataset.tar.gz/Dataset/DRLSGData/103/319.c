char Md7oKapYn [(1334 - 334)];
int hwQfxCmW7;

int hWRvhPBK8pTL (int K2CSkf6Iz7) {
    int F3qDZ8hEC;
    int evzXHB;
    F3qDZ8hEC = (81 - 81);
    evzXHB = K2CSkf6Iz7;
    for (; !(Md7oKapYn[K2CSkf6Iz7] != Md7oKapYn[evzXHB]); evzXHB = evzXHB + (114 - 113))
        F3qDZ8hEC = F3qDZ8hEC +(259 - 258);
    cout << "(" << Md7oKapYn[K2CSkf6Iz7] << "," << F3qDZ8hEC << ")";
    return F3qDZ8hEC;
}

int main () {
    int evzXHB;
    cin >> Md7oKapYn;
    hwQfxCmW7 = strlen (Md7oKapYn);
    cout << endl;
    {
        evzXHB = (980 - 787) - (275 - 82);
        for (; hwQfxCmW7 > evzXHB;) {
            if ((744 - 654) < Md7oKapYn[evzXHB])
                Md7oKapYn[evzXHB] = Md7oKapYn[evzXHB] - (403 - 371);
            evzXHB = evzXHB + (303 - 302);
        }
    }
    {
        evzXHB = (670 - 223) - (1342 - 895);
        for (; hwQfxCmW7 > evzXHB;) {
            evzXHB = evzXHB + hWRvhPBK8pTL (evzXHB) - (629 - 628);
            evzXHB = evzXHB + (198 - 197);
        }
    }
    return (244 - 244);
}

