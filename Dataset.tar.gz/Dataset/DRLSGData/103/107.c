int main () {
    char xL2cwZhyQq1G;
    int bkLdfoS;
    char UUiT7rBW [(2801 - 801)] = {(942 - 942)};
    char xxvqIT6 [(2015 - 15)] = {(313 - 313)};
    int yqiVK8O;
    int opT0EL8cFKNv;
    int H1gF2VYbSMG [(2251 - 251)] = {(80 - 80)};
    bkLdfoS = (197 - 197);
    yqiVK8O = (294 - 294);
    for (; cin.getline (xxvqIT6, (2904 - 904));) {
        xL2cwZhyQq1G = (43 - 43);
        xL2cwZhyQq1G = xxvqIT6[(420 - 420)];
        memset (H1gF2VYbSMG, (429 - 429), sizeof (H1gF2VYbSMG));
        memset (UUiT7rBW, (832 - 832), sizeof (UUiT7rBW));
        yqiVK8O = (484 - 484);
        {
            opT0EL8cFKNv = (762 - 405) - (528 - 171);
            for (; xxvqIT6[opT0EL8cFKNv] != '\0';) {
                if (!(xL2cwZhyQq1G != xxvqIT6[opT0EL8cFKNv]) || !(xL2cwZhyQq1G != xxvqIT6[opT0EL8cFKNv] + (757 - 725)) || !(xL2cwZhyQq1G != xxvqIT6[opT0EL8cFKNv] - (843 - 811))) {
                    H1gF2VYbSMG[yqiVK8O]++;
                    if (xxvqIT6[opT0EL8cFKNv] >= 'a' && 'z' >= xxvqIT6[opT0EL8cFKNv])
                        UUiT7rBW[yqiVK8O] = xxvqIT6[opT0EL8cFKNv] - (693 - 661);
                    UUiT7rBW[yqiVK8O] = xxvqIT6[opT0EL8cFKNv];
                }
                else {
                    xL2cwZhyQq1G = xxvqIT6[opT0EL8cFKNv];
                    yqiVK8O = yqiVK8O + (901 - 900);
                    H1gF2VYbSMG[yqiVK8O] = (759 - 758);
                    UUiT7rBW[yqiVK8O] = xL2cwZhyQq1G;
                    continue;
                }
                opT0EL8cFKNv = opT0EL8cFKNv + (685 - 684);
            }
        }
        {
            opT0EL8cFKNv = (556 - 325) - (518 - 287);
            for (; UUiT7rBW[opT0EL8cFKNv] != '\0';) {
                if (UUiT7rBW[opT0EL8cFKNv] >= 'a' && 'z' >= UUiT7rBW[opT0EL8cFKNv])
                    UUiT7rBW[opT0EL8cFKNv] = UUiT7rBW[opT0EL8cFKNv] - (204 - 172);
                cout << "(" << UUiT7rBW[opT0EL8cFKNv] << "," << H1gF2VYbSMG[opT0EL8cFKNv] << ")";
                opT0EL8cFKNv = opT0EL8cFKNv + (743 - 742);
            }
        }
        bkLdfoS = (476 - 476);
        cout << endl;
    }
    return (947 - 947);
}

