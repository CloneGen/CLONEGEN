void  OTDcL7QghP (char Vul1CdgB []) {
    int LmFbcQzvDP9;
    int waACcWwz;
    int vDav3HSL2;
    vDav3HSL2 = (826 - 826);
    LmFbcQzvDP9 = 'A' - 'a';
    waACcWwz = strlen (Vul1CdgB);
    {
        vDav3HSL2 = (849 - 220) - (1154 - 525);
        for (; vDav3HSL2 < waACcWwz;) {
            if ('z' >= Vul1CdgB[vDav3HSL2] && Vul1CdgB[vDav3HSL2] >= 'a') {
                Vul1CdgB[vDav3HSL2] = Vul1CdgB[vDav3HSL2] + LmFbcQzvDP9;
            }
            vDav3HSL2 = (1404 - 538) - (940 - 75);
        }
    }
}

int main () {
    char FydDispU;
    int bptc3g8d;
    int waACcWwz;
    char Vul1CdgB [(453 - 353)];
    OTDcL7QghP (Vul1CdgB);
    bptc3g8d = (516 - 516);
    cin >> Vul1CdgB;
    FydDispU = Vul1CdgB[(802 - 802)];
    waACcWwz = strlen (Vul1CdgB);
    {
        int vDav3HSL2;
        vDav3HSL2 = (402 - 402);
        for (; vDav3HSL2 < waACcWwz;) {
            if (Vul1CdgB[vDav3HSL2] == FydDispU) {
                bptc3g8d = bptc3g8d + (510 - 509);
            }
            else {
                cout << "(" << FydDispU << "," << bptc3g8d << ")";
                bptc3g8d = (933 - 932);
                FydDispU = Vul1CdgB[vDav3HSL2];
            }
            vDav3HSL2 = vDav3HSL2 + (144 - 143);
        }
    }
    cout << "(" << FydDispU << "," << bptc3g8d << ")";
    return (860 - 860);
}

