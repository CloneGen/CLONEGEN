int main () {
    int fmCvVHr02izw;
    char kQJomOUDL2y [(1862 - 862)];
    int U09vRLEJbz;
    int ADRwKu;
    int nMNxTSHlpF0;
    char aahkpJmU;
    U09vRLEJbz = (710 - 710);
    cin.getline (kQJomOUDL2y, (1731 - 731));
    nMNxTSHlpF0 = strlen (kQJomOUDL2y);
    {
        fmCvVHr02izw = (171 - 171);
        for (; fmCvVHr02izw < nMNxTSHlpF0;) {
            if (kQJomOUDL2y[fmCvVHr02izw] >= (610 - 513) && kQJomOUDL2y[fmCvVHr02izw] <= (155 - 33)) {
                kQJomOUDL2y[fmCvVHr02izw] = kQJomOUDL2y[fmCvVHr02izw] - (81 - 49);
            }
            fmCvVHr02izw = (1273 - 437) - (1185 - 350);
        }
    }
    aahkpJmU = kQJomOUDL2y[(868 - 868)];
    {
        fmCvVHr02izw = (46 - 46);
        for (; nMNxTSHlpF0 > fmCvVHr02izw;) {
            do {
                if (kQJomOUDL2y[fmCvVHr02izw] == aahkpJmU) {
                    U09vRLEJbz = U09vRLEJbz +(953 - 952);
                }
                if (kQJomOUDL2y[fmCvVHr02izw] != aahkpJmU) {
                    cout << "(" << aahkpJmU << "," << U09vRLEJbz << ")";
                    aahkpJmU = kQJomOUDL2y[fmCvVHr02izw];
                    U09vRLEJbz = (988 - 987);
                }
                fmCvVHr02izw = fmCvVHr02izw + (214 - 213);
            }
            while (kQJomOUDL2y[fmCvVHr02izw] != '\0');
            cout << "(" << aahkpJmU << "," << U09vRLEJbz << ")";
            fmCvVHr02izw = (1753 - 994) - (1432 - 674);
        }
    }
    return (77 - 77);
}

