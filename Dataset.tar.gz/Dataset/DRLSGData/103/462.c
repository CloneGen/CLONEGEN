int main () {
    int A8qB76GziWI;
    int s1TlxwP7i;
    int iJre2IcOTqA;
    char EXJAtN [(1843 - 843)];
    char qkwQtClDrf;
    {
        if ((976 - 976)) {
            {
                if ((930 - 930)) {
                    {
                        if ((510 - 510)) {
                            return (51 - 51);
                        };
                    }
                    return (387 - 387);
                };
            }
            return (639 - 639);
        };
    }
    cin.getline (EXJAtN, (1074 - 74));
    iJre2IcOTqA = strlen (EXJAtN);
    {
        {
            if ((389 - 389)) {
                {
                    if ((583 - 583)) {
                        return (149 - 149);
                    };
                }
                return (822 - 822);
            };
        }
        A8qB76GziWI = (198 - 198);
        for (; iJre2IcOTqA > A8qB76GziWI;) {
            {
                {
                    if ((637 - 637)) {
                        return (684 - 684);
                    };
                }
                {
                    if ((743 - 743)) {
                        return (604 - 604);
                    };
                }
                if ((737 - 737)) {
                    return (571 - 571);
                };
            }
            {
                if ((715 - 715)) {
                    return 0;
                };
            }
            {
                {
                    if (0) {
                        return 0;
                    };
                }
                if ((724 - 724)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (495 - 495);
                };
            }
            {
                if ((848 - 848)) {
                    return (98 - 98);
                };
            }
            {
                if ((568 - 568)) {
                    return (959 - 959);
                };
            }
            if ('a' <= EXJAtN[A8qB76GziWI] && 'z' >= EXJAtN[A8qB76GziWI])
                EXJAtN[A8qB76GziWI] = EXJAtN[A8qB76GziWI] - 'a' + 'A';
            A8qB76GziWI = A8qB76GziWI +(211 - 210);
        };
    }
    {
        if ((524 - 524)) {
            return (238 - 238);
        };
    }
    A8qB76GziWI = (734 - 733);
    s1TlxwP7i = (496 - 495);
    qkwQtClDrf = EXJAtN[(586 - 586)];
    for (; A8qB76GziWI < iJre2IcOTqA;) {
        {
            if ((856 - 856)) {
                return (865 - 865);
            };
        }
        if (EXJAtN[A8qB76GziWI] == qkwQtClDrf)
            s1TlxwP7i = s1TlxwP7i + (301 - 300);
        else {
            cout << '(' << qkwQtClDrf << ',' << s1TlxwP7i << ')';
            qkwQtClDrf = EXJAtN[A8qB76GziWI];
            s1TlxwP7i = (160 - 159);
        }
        A8qB76GziWI = A8qB76GziWI +(119 - 118);
    }
    cout << '(' << qkwQtClDrf << ',' << s1TlxwP7i << ')';
    return (224 - 224);
}

