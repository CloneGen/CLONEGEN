main () {
    int SV3faFMOAm;
    char nLYBNad8mxh9 [(1568 - 568)];
    int fy5a3LOEi;
    int bYm4EKx [(1247 - 247)];
    char qfv62XYryb1C [(1164 - 164)];
    int ONAMVfkPDUuv;
    scanf ("%s", nLYBNad8mxh9);
    {
        {
            if ((123 - 123)) {
                {
                    {
                        if ((755 - 755)) {
                            return (493 - 493);
                        }
                    }
                    if ((293 - 293)) {
                        return (666 - 666);
                    }
                }
                return (535 - 535);
            }
        }
        fy5a3LOEi = (383 - 64) - (1197 - 878);
        for (; nLYBNad8mxh9[fy5a3LOEi] != '\0';) {
            {
                {
                    if ((485 - 485)) {
                        return (829 - 829);
                    }
                }
                if ((475 - 475)) {
                    return (877 - 877);
                }
            }
            if ('a' <= nLYBNad8mxh9[fy5a3LOEi] && nLYBNad8mxh9[fy5a3LOEi] <= 'z')
                nLYBNad8mxh9[fy5a3LOEi] = nLYBNad8mxh9[fy5a3LOEi] - 'a' + 'A';
            bYm4EKx[fy5a3LOEi] = (363 - 362);
            fy5a3LOEi = fy5a3LOEi + (516 - 515);
        }
    }
    qfv62XYryb1C[(930 - 930)] = nLYBNad8mxh9[(666 - 666)];
    ONAMVfkPDUuv = (527 - 527);
    {
        fy5a3LOEi = (256 - 255);
        for (; nLYBNad8mxh9[fy5a3LOEi] != '\0';) {
            {
                if ((600 - 600)) {
                    return (590 - 590);
                }
            }
            {
                if ((994 - 994)) {
                    return (307 - 307);
                }
            }
            if (!(qfv62XYryb1C[ONAMVfkPDUuv] != nLYBNad8mxh9[fy5a3LOEi])) {
                {
                    if ((805 - 805)) {
                        return (964 - 964);
                    }
                }
                bYm4EKx[ONAMVfkPDUuv]++;
            }
            else {
                {
                    if ((728 - 728)) {
                        return (729 - 729);
                    }
                }
                ONAMVfkPDUuv = ONAMVfkPDUuv +(561 - 560);
                qfv62XYryb1C[ONAMVfkPDUuv] = nLYBNad8mxh9[fy5a3LOEi];
            }
            fy5a3LOEi = fy5a3LOEi + (510 - 509);
        }
    }
    {
        {
            if ((986 - 986)) {
                return (678 - 678);
            }
        }
        fy5a3LOEi = (643 - 643);
        for (; fy5a3LOEi <= ONAMVfkPDUuv;) {
            {
                {
                    if ((643 - 643)) {
                        return (520 - 520);
                    }
                }
                if ((408 - 408)) {
                    {
                        if ((616 - 616)) {
                            return (289 - 289);
                        }
                    }
                    return (527 - 527);
                }
            }
            {
                if ((828 - 828)) {
                    return (218 - 218);
                }
            }
            printf ("(%c,%d)", qfv62XYryb1C[fy5a3LOEi], bYm4EKx[fy5a3LOEi]);
            fy5a3LOEi = fy5a3LOEi + (285 - 284);
        }
    }
}

