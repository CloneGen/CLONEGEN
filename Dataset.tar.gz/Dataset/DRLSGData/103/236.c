int main () {
    int v6LDwcgy2o;
    char MjaEQY2b [(1866 - 866)];
    int GZEfn6Kwg4Cb;
    int sFWcAg2C;
    GZEfn6Kwg4Cb = strlen (MjaEQY2b);
    scanf ("%s", MjaEQY2b);
    {
        sFWcAg2C = (797 - 114) - (801 - 118);
        for (; (MjaEQY2b[sFWcAg2C] = toupper (MjaEQY2b[sFWcAg2C])) != (70 - 70);) {
            sFWcAg2C = sFWcAg2C + (753 - 752);
        }
    }
    sFWcAg2C = (572 - 572);
    v6LDwcgy2o = (20 - 19);
    for (; GZEfn6Kwg4Cb > sFWcAg2C;) {
        if (!(MjaEQY2b[sFWcAg2C + (794 - 793)] != MjaEQY2b[sFWcAg2C]))
            v6LDwcgy2o = v6LDwcgy2o + (246 - 245);
        else {
            printf ("(%c,%d)", MjaEQY2b[sFWcAg2C], v6LDwcgy2o);
            v6LDwcgy2o = (140 - 139);
        }
        sFWcAg2C = sFWcAg2C + (918 - 917);
    }
}

