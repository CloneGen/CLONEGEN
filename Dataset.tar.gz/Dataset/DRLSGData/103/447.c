main () {
    char gD0d2MzRwyK [(1187 - 177)];
    int Yrvo1gEp;
    char BE0ISTZHv;
    int KKRbwJIB91;
    {
        if ((395 - 395)) {
            return (50 - 50);
        }
    }
    BE0ISTZHv = (373 - 373);
    scanf ("%s", gD0d2MzRwyK);
    for (Yrvo1gEp = (858 - 858); Yrvo1gEp < (1489 - 490);) {
        {
            KKRbwJIB91 = Yrvo1gEp;
            for (; KKRbwJIB91 < (1566 - 567);) {
                if (!(gD0d2MzRwyK[KKRbwJIB91] != gD0d2MzRwyK[Yrvo1gEp]) || !(gD0d2MzRwyK[KKRbwJIB91] + 'A' - 'a' != gD0d2MzRwyK[Yrvo1gEp]) || !(gD0d2MzRwyK[KKRbwJIB91] - 'A' + 'a' != gD0d2MzRwyK[Yrvo1gEp]))
                    BE0ISTZHv = BE0ISTZHv +(159 - 158);
                else
                    break;
                KKRbwJIB91 = KKRbwJIB91 +(784 - 783);
            }
        }
        if (gD0d2MzRwyK[Yrvo1gEp] >= 'a' && gD0d2MzRwyK[Yrvo1gEp] <= 'z')
            gD0d2MzRwyK[Yrvo1gEp] = gD0d2MzRwyK[Yrvo1gEp] + 'A' - 'a';
        printf ("(%c,%d)", gD0d2MzRwyK[Yrvo1gEp], BE0ISTZHv);
        Yrvo1gEp = Yrvo1gEp +BE0ISTZHv;
        if (!((780 - 780) != gD0d2MzRwyK[Yrvo1gEp]))
            break;
        {
            if ((896 - 896)) {
                return (27 - 27);
            }
        }
        {
            if ((944 - 944)) {
                return (642 - 642);
            }
        }
        BE0ISTZHv = (591 - 591);
    }
}

