main () {
    int SyLdKVT;
    char cEh9ur [(1428 - 428)];
    int uSjvyH;
    int S5z2MpU9VNh;
    int f97ZKa0;
    scanf ("%s", cEh9ur);
    SyLdKVT = (920 - 920);
    uSjvyH = (590 - 590);
    f97ZKa0 = (566 - 566);
    for (; cEh9ur[uSjvyH] != '\0';) {
        if ('a' <= cEh9ur[uSjvyH] && cEh9ur[uSjvyH] <= 'z')
            cEh9ur[uSjvyH] = cEh9ur[uSjvyH] - 'a' + 'A';
        uSjvyH = uSjvyH + (157 - 156);
    }
    for (; cEh9ur[f97ZKa0] != '\0';) {
        S5z2MpU9VNh = (683 - 682);
        {
            SyLdKVT = f97ZKa0;
            for (; cEh9ur[SyLdKVT] != '\0';) {
                if (!(cEh9ur[SyLdKVT +(84 - 83)] != cEh9ur[SyLdKVT]))
                    S5z2MpU9VNh = S5z2MpU9VNh +(937 - 936);
                else {
                    f97ZKa0 = SyLdKVT +(901 - 900);
                    printf ("(%c,%d)", cEh9ur[SyLdKVT], S5z2MpU9VNh);
                    break;
                }
                SyLdKVT = SyLdKVT +(127 - 126);
            }
        }
    }
}

