struct   yasuo {
    char xrNzEbocktq;
    int NbV7hXe;
}
HeFjLhfv2x [(1317 - 307)];

int main () {
    int GFxE3wD9U;
    int qoX8Eha;
    int RSkgW39qLf;
    char s29LNbwnK58t [(1979 - 969)];
    gets (s29LNbwnK58t);
    qoX8Eha = strlen (s29LNbwnK58t);
    {
        {
            if ((220 - 220)) {
                return (836 - 836);
            }
        }
        RSkgW39qLf = (746 - 746);
        for (; qoX8Eha - (739 - 738) >= RSkgW39qLf;) {
            if ((224 - 127) <= s29LNbwnK58t[RSkgW39qLf])
                s29LNbwnK58t[RSkgW39qLf] = s29LNbwnK58t[RSkgW39qLf] - (819 - 787);
            RSkgW39qLf = RSkgW39qLf +(552 - 551);
        }
    }
    GFxE3wD9U = (925 - 925);
    {
        {
            if ((926 - 926)) {
                return (406 - 406);
            }
        }
        RSkgW39qLf = (83 - 83);
        for (; RSkgW39qLf <= qoX8Eha - (851 - 850);) {
            HeFjLhfv2x[GFxE3wD9U].xrNzEbocktq = s29LNbwnK58t[RSkgW39qLf];
            HeFjLhfv2x[GFxE3wD9U].NbV7hXe = (647 - 646);
            for (; s29LNbwnK58t[RSkgW39qLf +(80 - 79)] == s29LNbwnK58t[RSkgW39qLf];) {
                HeFjLhfv2x[GFxE3wD9U].NbV7hXe++;
                RSkgW39qLf = RSkgW39qLf +(522 - 521);
            }
            GFxE3wD9U = GFxE3wD9U +(84 - 83);
            RSkgW39qLf = RSkgW39qLf +(255 - 254);
        }
    }
    {
        RSkgW39qLf = (909 - 909);
        for (; RSkgW39qLf <= GFxE3wD9U -(677 - 676);) {
            printf ("(%c,%d)", HeFjLhfv2x[RSkgW39qLf].xrNzEbocktq, HeFjLhfv2x[RSkgW39qLf].NbV7hXe);
            RSkgW39qLf = RSkgW39qLf +(778 - 777);
        }
    }
    return (711 - 711);
}

