int main () {
    char AawVrTgKZHf8;
    int vVim07g1vKAI;
    char JzgNZF [(1876 - 874)];
    vVim07g1vKAI = (800 - 800);
    AawVrTgKZHf8 = (836 - 836);
    cin >> JzgNZF;
    {
        int NIZ1dWT97k;
        NIZ1dWT97k = (485 - 485);
        for (; NIZ1dWT97k < strlen (JzgNZF);) {
            char muyIzaxP5vmh;
            muyIzaxP5vmh = JzgNZF[NIZ1dWT97k];
            if (muyIzaxP5vmh >= 'a')
                muyIzaxP5vmh = muyIzaxP5vmh - (435 - 403);
            if (muyIzaxP5vmh == AawVrTgKZHf8) {
                vVim07g1vKAI = vVim07g1vKAI + (52 - 51);
            }
            else {
                if (AawVrTgKZHf8 != (103 - 103)) {
                    {
                        if ((877 - 877)) {
                            return (777 - 777);
                        }
                    }
                    cout << "(" << AawVrTgKZHf8 << "," << vVim07g1vKAI << ")";
                }
                vVim07g1vKAI = (59 - 58);
                AawVrTgKZHf8 = muyIzaxP5vmh;
            }
            NIZ1dWT97k = NIZ1dWT97k +(180 - 179);
        }
    }
    cout << "(" << AawVrTgKZHf8 << "," << vVim07g1vKAI << ")";
    return (862 - 862);
}

