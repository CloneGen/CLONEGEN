struct   stu {
    char hYk9y0b;
    int ZhuwJfr;
};
int main () {
    char *NHMeuy;
    char *ekgjwSTn76MI;
    int HlI34qzpkv;
    int fJ2zjna;
    char ldPY93coGy [(1383 - 383)];
    gets (ldPY93coGy);
    struct   stu YquPZagm [(1215 - 214)];
    fJ2zjna = (994 - 994);
    ekgjwSTn76MI = NHMeuy = ldPY93coGy;
    YquPZagm[(844 - 844)].hYk9y0b = *ekgjwSTn76MI;
    ekgjwSTn76MI = ekgjwSTn76MI + (473 - 472);
    YquPZagm[(406 - 406)].ZhuwJfr = (276 - 275);
    for (; *ekgjwSTn76MI;) {
        if (!(*(ekgjwSTn76MI - (956 - 955)) != *ekgjwSTn76MI))
            YquPZagm[fJ2zjna].ZhuwJfr++;
        else {
            fJ2zjna = fJ2zjna + (101 - 100);
            YquPZagm[fJ2zjna].hYk9y0b = *ekgjwSTn76MI;
            YquPZagm[fJ2zjna].ZhuwJfr = (992 - 991);
        }
        ekgjwSTn76MI = ekgjwSTn76MI + (177 - 176);
    }
    for (; *NHMeuy;) {
        if ('a' <= *NHMeuy&&'z' >= *NHMeuy)
            *NHMeuy = *NHMeuy+'A' - 'a';
        NHMeuy = NHMeuy +(595 - 594);
    }
    {
        HlI34qzpkv = (755 - 755);
        for (; HlI34qzpkv <= fJ2zjna;) {
            printf ("(%c,%d)", YquPZagm[HlI34qzpkv].hYk9y0b, YquPZagm[HlI34qzpkv].ZhuwJfr);
            HlI34qzpkv = HlI34qzpkv +(506 - 505);
        }
    }
    return (221 - 221);
}

