main () {
    int T7PvwV;
    int Kl7Xme8RTAZ4;
    int Q8SrIHKTZs;
    int Ka9IuZ;
    int CVAPyk3;
    int RXk3wO;
    char CUmuVHzPTCs [(1335 - 335)];
    gets (CUmuVHzPTCs);
    RXk3wO = strlen (CUmuVHzPTCs);
    {
        Kl7Xme8RTAZ4 = (1539 - 699) - (1292 - 452);
        for (; Kl7Xme8RTAZ4 < RXk3wO;) {
            if (CUmuVHzPTCs[Kl7Xme8RTAZ4] >= 'a' && CUmuVHzPTCs[Kl7Xme8RTAZ4] <= 'z')
                CUmuVHzPTCs[Kl7Xme8RTAZ4] = CUmuVHzPTCs[Kl7Xme8RTAZ4] - 'a' + 'A';
            Kl7Xme8RTAZ4 = Kl7Xme8RTAZ4 +(139 - 138);
        }
    }
    getchar ();
    getchar ();
    Ka9IuZ = (938 - 937);
    {
        Kl7Xme8RTAZ4 = (907 - 907);
        for (; Kl7Xme8RTAZ4 < RXk3wO;) {
            if (CUmuVHzPTCs[Kl7Xme8RTAZ4] == CUmuVHzPTCs[Kl7Xme8RTAZ4 +(386 - 385)])
                Ka9IuZ = Ka9IuZ +(389 - 388);
            else {
                printf ("(%c,%d)", CUmuVHzPTCs[Kl7Xme8RTAZ4], Ka9IuZ);
                Ka9IuZ = (525 - 524);
            }
            Kl7Xme8RTAZ4 = Kl7Xme8RTAZ4 +(396 - 395);
        }
    }
}

