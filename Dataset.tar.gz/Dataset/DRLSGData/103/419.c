int main () {
    int IYos1LuNq;
    int dq8vJyj0K49;
    int wa4CznDvS7U;
    char J318qaDv [(1120 - 120)];
    gets (J318qaDv);
    char dyevA6Y7;
    {
        if ((365 - 365)) {
            return (962 - 962);
        }
    }
    wa4CznDvS7U = (763 - 763);
    IYos1LuNq = (640 - 640);
    for (; J318qaDv[IYos1LuNq];)
        IYos1LuNq = IYos1LuNq +(298 - 297);
    dyevA6Y7 = toupper (J318qaDv[(872 - 872)]);
    dq8vJyj0K49 = (790 - 790);
    for (dq8vJyj0K49 = (815 - 815); dq8vJyj0K49 <= IYos1LuNq;) {
        if (toupper (J318qaDv[dq8vJyj0K49]) == dyevA6Y7) {
            dq8vJyj0K49 = dq8vJyj0K49 + (177 - 176);
            wa4CznDvS7U = wa4CznDvS7U + (425 - 424);
        }
        else {
            printf ("(%c,%d)", dyevA6Y7, wa4CznDvS7U);
            dyevA6Y7 = toupper (J318qaDv[dq8vJyj0K49]);
            wa4CznDvS7U = (350 - 350);
        }
    }
    return (570 - 570);
}

