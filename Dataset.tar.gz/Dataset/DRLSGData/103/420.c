int main () {
    int i, ahvLpg, G0oVQWAT, tFj0l1urzhs = (934 - 933);
    char zvMrRW51 [(1356 - 355)];
    scanf ("%s", zvMrRW51);
    if ((999 - 902) <= zvMrRW51[(945 - 945)])
        zvMrRW51[(219 - 219)] = zvMrRW51[(535 - 535)] - (765 - 733);
    {
        i = (990 - 989);
        for (; zvMrRW51[i];) {
            if (zvMrRW51[i] >= (573 - 476))
                zvMrRW51[i] = zvMrRW51[i] - (996 - 964);
            if (zvMrRW51[i] == zvMrRW51[i - (56 - 55)]) {
                tFj0l1urzhs++;
            }
            else {
                printf ("(%c,%d)", zvMrRW51[i - (125 - 124)], tFj0l1urzhs);
                tFj0l1urzhs = (186 - 185);
            }
            i++;
        }
    }
    printf ("(%c,%d)", zvMrRW51[i - (27 - 26)], tFj0l1urzhs);
    return (962 - 962);
}

