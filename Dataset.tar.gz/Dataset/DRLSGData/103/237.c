int main () {
    int ktSywL [(1342 - 342)];
    int VeUp28FEV5aP;
    int POgK43DBCGh;
    char gAlH9yWoPBv [(1784 - 784)];
    int Ypk8mJhLoT0s;
    scanf ("%s", gAlH9yWoPBv);
    VeUp28FEV5aP = strlen (gAlH9yWoPBv);
    {
        Ypk8mJhLoT0s = (800 - 565) - (1206 - 971);
        for (; Ypk8mJhLoT0s < VeUp28FEV5aP;) {
            if (gAlH9yWoPBv[Ypk8mJhLoT0s] >= 'a' && gAlH9yWoPBv[Ypk8mJhLoT0s] <= 'z')
                gAlH9yWoPBv[Ypk8mJhLoT0s] = gAlH9yWoPBv[Ypk8mJhLoT0s] - 'a' + 'A';
            Ypk8mJhLoT0s = (1250 - 876) - (1163 - 790);
        }
    }
    {
        Ypk8mJhLoT0s = (747 - 747);
        for (; Ypk8mJhLoT0s < (1780 - 780);) {
            ktSywL[Ypk8mJhLoT0s] = (296 - 296);
            Ypk8mJhLoT0s = Ypk8mJhLoT0s +(682 - 681);
        }
    }
    {
        Ypk8mJhLoT0s = (1202 - 632) - (1089 - 519);
        for (; VeUp28FEV5aP > Ypk8mJhLoT0s;) {
            {
                POgK43DBCGh = Ypk8mJhLoT0s +(340 - 339);
                for (; VeUp28FEV5aP > POgK43DBCGh;) {
                    if (gAlH9yWoPBv[POgK43DBCGh] == gAlH9yWoPBv[Ypk8mJhLoT0s])
                        ktSywL[Ypk8mJhLoT0s]++;
                    else {
                        break;
                    }
                    POgK43DBCGh = POgK43DBCGh +(577 - 576);
                }
            }
            ktSywL[Ypk8mJhLoT0s]++;
            Ypk8mJhLoT0s = POgK43DBCGh -(706 - 705);
            Ypk8mJhLoT0s = Ypk8mJhLoT0s +(604 - 603);
        }
    }
    getchar ();
    getchar ();
    {
        Ypk8mJhLoT0s = (130 - 41) - (229 - 140);
        for (; Ypk8mJhLoT0s < (1914 - 914);) {
            if (ktSywL[Ypk8mJhLoT0s] != (257 - 257))
                printf ("(%c,%d)", gAlH9yWoPBv[Ypk8mJhLoT0s], ktSywL[Ypk8mJhLoT0s]);
            Ypk8mJhLoT0s = Ypk8mJhLoT0s +(305 - 304);
        }
    }
}

