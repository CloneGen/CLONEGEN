int main () {
    int OebK6VDdxg;
    int geXzjkymrG;
    char LytQvDqaEKH;
    char VevnQFo [(1466 - 466)];
    memset (VevnQFo, '%', (1837 - 837));
    cin >> VevnQFo;
    geXzjkymrG = (971 - 970);
    OebK6VDdxg = (755 - 755);
    for (; VevnQFo[OebK6VDdxg] != '%';) {
        if ('a' <= VevnQFo[OebK6VDdxg] && VevnQFo[OebK6VDdxg] <= 'z')
            VevnQFo[OebK6VDdxg] = VevnQFo[OebK6VDdxg] + 'A' - 'a';
        OebK6VDdxg = OebK6VDdxg +(992 - 991);
    }
    OebK6VDdxg = (984 - 983);
    LytQvDqaEKH = VevnQFo[(742 - 742)];
    for (; VevnQFo[OebK6VDdxg] != '%';) {
        if (VevnQFo[OebK6VDdxg] == LytQvDqaEKH)
            geXzjkymrG = geXzjkymrG + (719 - 718);
        else {
            cout << "(" << LytQvDqaEKH << "," << geXzjkymrG << ")";
            LytQvDqaEKH = VevnQFo[OebK6VDdxg];
            geXzjkymrG = (134 - 133);
        }
        OebK6VDdxg = OebK6VDdxg +(724 - 723);
    }
    return (932 - 932);
}

