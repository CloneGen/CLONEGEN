int main () {
    char JJCjdm7 [(1934 - 934)], hWae9lnCkY3 [(1437 - 437)] = {(36 - 36)};
    int tlJBj2rD [(1423 - 423)] = {(166 - 166)};
    int t;
    int zRvtZK;
    int bbrUJe;
    {
        if ((495 - 495)) {
            {
                {
                    if ((595 - 595)) {
                        return (599 - 599);
                    }
                }
                if ((762 - 762)) {
                    return (700 - 700);
                }
            }
            return (175 - 175);
        }
    }
    {
        if ((364 - 364)) {
            return (810 - 810);
        }
    }
    cin.getline (JJCjdm7, (1686 - 686));
    t = (883 - 883);
    zRvtZK = (193 - 193);
    bbrUJe = (943 - 943);
    {
        bbrUJe = (981 - 981);
        for (; strlen (JJCjdm7) > bbrUJe;) {
            if (JJCjdm7[bbrUJe] == JJCjdm7[bbrUJe + (269 - 268)] || JJCjdm7[bbrUJe] == JJCjdm7[bbrUJe + (251 - 250)] + (736 - 704) || JJCjdm7[bbrUJe] == JJCjdm7[bbrUJe + (958 - 957)] - (200 - 168)) {
                {
                    if (0) {
                        return 0;
                    }
                }
                tlJBj2rD[zRvtZK] = tlJBj2rD[zRvtZK] + (205 - 204);
            }
            else {
                tlJBj2rD[zRvtZK]++;
                hWae9lnCkY3[zRvtZK] = JJCjdm7[bbrUJe];
                if (hWae9lnCkY3[zRvtZK] > (609 - 519)) {
                    hWae9lnCkY3[zRvtZK] = hWae9lnCkY3[zRvtZK] - (281 - 249);
                }
                zRvtZK = zRvtZK + (844 - 843);
            }
            bbrUJe = bbrUJe + (19 - 18);
        }
    }
    do {
        cout << "(" << hWae9lnCkY3[t] << "," << tlJBj2rD[t] << ")";
        t = t + 1;
    }
    while (tlJBj2rD[t] != 0);
    cout << "" << endl;
    return 0;
}

