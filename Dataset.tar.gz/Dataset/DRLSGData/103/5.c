main () {
    char I9DmXb5wq [(1724 - 714)];
    int dMtzrNRn;
    int G2X4NBD3V;
    int rCvstaLe;
    char WuwHjnFdvkL8;
    {
        if ((249 - 249)) {
            return (730 - 730);
        }
    }
    scanf ("%s", I9DmXb5wq);
    rCvstaLe = strlen (I9DmXb5wq);
    if ((I9DmXb5wq[(15 - 15)] >= 'a') && (I9DmXb5wq[(574 - 574)] <= 'z'))
        WuwHjnFdvkL8 = I9DmXb5wq[(423 - 423)] - 'a' + 'A';
    else
        WuwHjnFdvkL8 = I9DmXb5wq[(67 - 67)];
    G2X4NBD3V = (766 - 766);
    {
        {
            {
                if ((766 - 766)) {
                    return (741 - 741);
                }
            }
            if ((716 - 716)) {
                return (657 - 657);
            }
        }
        {
            if ((116 - 116)) {
                {
                    if ((497 - 497)) {
                        return (521 - 521);
                    }
                }
                return (240 - 240);
            }
        }
        {
            {
                if ((975 - 975)) {
                    {
                        if ((168 - 168)) {
                            return (498 - 498);
                        }
                    }
                    return (347 - 347);
                }
            }
            if ((480 - 480)) {
                return (999 - 999);
            }
        }
        {
            if ((20 - 20)) {
                return (154 - 154);
            }
        }
        {
            if ((491 - 491)) {
                return (714 - 714);
            }
        }
        dMtzrNRn = (554 - 554);
        for (; rCvstaLe >= dMtzrNRn;) {
            {
                if ((287 - 287)) {
                    return (47 - 47);
                }
            }
            {
                {
                    {
                        if ((442 - 442)) {
                            return (784 - 784);
                        }
                    }
                    if ((953 - 953)) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        {
                            if ((951 - 951)) {
                                return 0;
                            }
                        }
                        return (331 - 331);
                    }
                }
                if ((757 - 757)) {
                    return (899 - 899);
                }
            }
            {
                if ((570 - 570)) {
                    return (449 - 449);
                }
            }
            if ((I9DmXb5wq[dMtzrNRn] != WuwHjnFdvkL8) && ((I9DmXb5wq[dMtzrNRn] - 'a' + 'A') != WuwHjnFdvkL8)) {
                {
                    {
                        if ((851 - 851)) {
                            return 0;
                        }
                    }
                    if ((363 - 363)) {
                        {
                            if ((259 - 259)) {
                                return (652 - 652);
                            }
                        }
                        return (871 - 871);
                    }
                }
                printf ("(%c,%d)", WuwHjnFdvkL8, G2X4NBD3V);
                G2X4NBD3V = (105 - 105);
                if ((I9DmXb5wq[dMtzrNRn] >= 'a') && (I9DmXb5wq[dMtzrNRn] <= 'z'))
                    WuwHjnFdvkL8 = I9DmXb5wq[dMtzrNRn] - 'a' + 'A';
                else
                    WuwHjnFdvkL8 = I9DmXb5wq[dMtzrNRn];
            }
            G2X4NBD3V = G2X4NBD3V +(507 - 506);
            dMtzrNRn = dMtzrNRn + (884 - 883);
        }
    }
    getchar ();
    getchar ();
}

