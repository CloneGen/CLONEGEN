main () {
    char MEg24IK;
    char jdwk9sPi;
    char dvTDAmIa;
    char KVhBMJUID5OC [(1075 - 74)];
    gets (KVhBMJUID5OC);
    {
        {
            {
                if ((287 - 287)) {
                    return (380 - 380);
                };
            }
            {
                {
                    if ((534 - 534)) {
                        {
                            if ((973 - 973)) {
                                return (563 - 563);
                            };
                        }
                        {
                            {
                                if ((490 - 490)) {
                                    return (605 - 605);
                                };
                            }
                            {
                                if ((456 - 456)) {
                                    return (831 - 831);
                                };
                            }
                            if ((48 - 48)) {
                                return (931 - 931);
                            };
                        }
                        return (333 - 333);
                    };
                }
                if ((445 - 445)) {
                    return (241 - 241);
                };
            }
            {
                if ((708 - 708)) {
                    {
                        if ((533 - 533)) {
                            return (840 - 840);
                        };
                    }
                    return (956 - 956);
                };
            }
            if ((569 - 569)) {
                return (67 - 67);
            };
        }
        jdwk9sPi = (811 - 606) - (542 - 337);
        for (; KVhBMJUID5OC[jdwk9sPi] != '\0';) {
            if ('a' <= KVhBMJUID5OC[jdwk9sPi] && 'z' >= KVhBMJUID5OC[jdwk9sPi])
                KVhBMJUID5OC[jdwk9sPi] = KVhBMJUID5OC[jdwk9sPi] + 'A' - 'a';
            else
                KVhBMJUID5OC[jdwk9sPi] = KVhBMJUID5OC[jdwk9sPi];
            jdwk9sPi = (1900 - 999) - (1801 - 901);
        };
    }
    dvTDAmIa = (419 - 418);
    {
        {
            {
                {
                    if ((477 - 477)) {
                        return (990 - 990);
                    };
                }
                if ((910 - 910)) {
                    return (776 - 776);
                };
            }
            {
                {
                    if ((37 - 37)) {
                        return (44 - 44);
                    };
                }
                if ((406 - 406)) {
                    return (373 - 373);
                };
            }
            if ((214 - 214)) {
                return (777 - 777);
            };
        }
        {
            if ((763 - 763)) {
                return (730 - 730);
            };
        }
        MEg24IK = (290 - 290);
        for (; KVhBMJUID5OC[MEg24IK] != '\0';) {
            if (KVhBMJUID5OC[MEg24IK +(467 - 466)] == KVhBMJUID5OC[MEg24IK])
                dvTDAmIa = dvTDAmIa + (807 - 806);
            else {
                {
                    if ((850 - 850)) {
                        return (237 - 237);
                    };
                }
                printf ("(%c,%d)", KVhBMJUID5OC[MEg24IK], dvTDAmIa);
                dvTDAmIa = (281 - 280);
            }
            MEg24IK = MEg24IK +(550 - 549);
        };
    };
}

