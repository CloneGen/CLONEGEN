main () {
    char fMVF23dhL [(2934 - 934)];
    gets (fMVF23dhL);
    int l2gN8OiWReG;
    int ScEk9Cq;
    {
        ScEk9Cq = (760 - 760);
        for (; ScEk9Cq < (2435 - 435);) {
            fMVF23dhL[ScEk9Cq] = '\0';
            ScEk9Cq = ScEk9Cq +(695 - 694);
        }
    }
    l2gN8OiWReG = (44 - 43);
    {
        ScEk9Cq = (618 - 618);
        for (; ScEk9Cq < (2704 - 704);) {
            if (!('\0' != fMVF23dhL[ScEk9Cq]))
                break;
            if (!(fMVF23dhL[ScEk9Cq +(870 - 869)] != fMVF23dhL[ScEk9Cq]) || !(fMVF23dhL[ScEk9Cq +(522 - 521)] + ('A' - 'a') != fMVF23dhL[ScEk9Cq]) || !(fMVF23dhL[ScEk9Cq +(912 - 911)] - ('A' - 'a') != fMVF23dhL[ScEk9Cq]))
                l2gN8OiWReG = l2gN8OiWReG + (135 - 134);
            else {
                if (fMVF23dhL[ScEk9Cq] >= 'a')
                    fMVF23dhL[ScEk9Cq] = fMVF23dhL[ScEk9Cq] - ('a' - 'A');
                printf ("(%c,%d)", fMVF23dhL[ScEk9Cq], l2gN8OiWReG);
                l2gN8OiWReG = (366 - 365);
            }
            ScEk9Cq = ScEk9Cq +(361 - 360);
        }
    }
}

