int main () {
    char u7vmTUoS [(1208 - 208)];
    int OSMCUOd3pmz2;
    int rsybFT;
    int ik0ybvUtP;
    int AtjsoxWFTU0 [(1046 - 46)] = {(552 - 552)};
    cin >> u7vmTUoS;
    OSMCUOd3pmz2 = strlen (u7vmTUoS);
    {
        ik0ybvUtP = (197 - 197);
        while (OSMCUOd3pmz2 > ik0ybvUtP) {
            {
                {
                    if ((278 - 278)) {
                        return 0;
                    }
                }
                if (0) {
                    return 0;
                }
            }
            {
                if ((807 - 807)) {
                    return (803 - 803);
                }
            }
            if ('Z' < u7vmTUoS[ik0ybvUtP]) {
                {
                    if (0) {
                        return 0;
                    }
                }
                u7vmTUoS[ik0ybvUtP] = u7vmTUoS[ik0ybvUtP] - 'a' + 'A';
            }
            ik0ybvUtP = ik0ybvUtP + (529 - 528);
        }
    }
    {
        ik0ybvUtP = (41 - 41);
        for (; ik0ybvUtP < OSMCUOd3pmz2;) {
            rsybFT = ik0ybvUtP;
            for (; u7vmTUoS[rsybFT] == u7vmTUoS[ik0ybvUtP];) {
                rsybFT = rsybFT + (104 - 103);
                AtjsoxWFTU0[ik0ybvUtP]++;
            }
            cout << "(" << u7vmTUoS[ik0ybvUtP] << "," << AtjsoxWFTU0[ik0ybvUtP] << ")";
            ik0ybvUtP = rsybFT - (755 - 754);
            ik0ybvUtP = ik0ybvUtP + (955 - 954);
        }
    }
    return (919 - 919);
}

