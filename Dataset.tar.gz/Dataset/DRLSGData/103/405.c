main () {
    int PECfhO2yT;
    int lLUxhtKj2;
    char A7oyevKrq [(1828 - 828)];
    gets (A7oyevKrq);
    int TWKIfEhST;
    PECfhO2yT = strlen (A7oyevKrq);
    {
        lLUxhtKj2 = (1085 - 758) - (1078 - 751);
        for (; PECfhO2yT > lLUxhtKj2;) {
            if (A7oyevKrq[lLUxhtKj2] <= 'z' && 'a' <= A7oyevKrq[lLUxhtKj2])
                A7oyevKrq[lLUxhtKj2] = A7oyevKrq[lLUxhtKj2] - 'a' + 'A';
            lLUxhtKj2 = lLUxhtKj2 + (884 - 883);
        }
    }
    TWKIfEhST = (92 - 91);
    {
        lLUxhtKj2 = (66 - 66);
        for (; PECfhO2yT > lLUxhtKj2;) {
            if (A7oyevKrq[lLUxhtKj2] == A7oyevKrq[lLUxhtKj2 + (486 - 485)])
                TWKIfEhST = TWKIfEhST +(454 - 453);
            if (A7oyevKrq[lLUxhtKj2] != A7oyevKrq[lLUxhtKj2 + (870 - 869)]) {
                printf ("(%c,%d)", A7oyevKrq[lLUxhtKj2], TWKIfEhST);
                TWKIfEhST = (514 - 513);
            }
            lLUxhtKj2 = lLUxhtKj2 + (280 - 279);
        }
    }
}

