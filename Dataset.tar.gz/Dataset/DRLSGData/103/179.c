main () {
    char PfyZ21 [(1284 - 284)];
    int mVfX2LY9h;
    int DDHOAW7v;
    char sSEk2N4aK9 [(1108 - 108)];
    int JgeVhfGA;
    int YNMLytozdG;
    YNMLytozdG = 'A' - 'a';
    scanf ("%s", sSEk2N4aK9);
    {
        {
            if ((840 - 840)) {
                return (164 - 164);
            }
        }
        {
            if ((859 - 859)) {
                return (568 - 568);
            }
        }
        mVfX2LY9h = (1193 - 254) - (1194 - 255);
        for (; sSEk2N4aK9[mVfX2LY9h] != '\0';) {
            if (sSEk2N4aK9[mVfX2LY9h] >= 'a' && sSEk2N4aK9[mVfX2LY9h] <= 'z')
                PfyZ21[mVfX2LY9h] = sSEk2N4aK9[mVfX2LY9h] + YNMLytozdG;
            else
                PfyZ21[mVfX2LY9h] = sSEk2N4aK9[mVfX2LY9h];
            mVfX2LY9h = (892 - 628) - (1227 - 964);
        }
    }
    PfyZ21[mVfX2LY9h] = '\0';
    DDHOAW7v = (557 - 556);
    {
        JgeVhfGA = (1605 - 944) - (1098 - 437);
        for (; PfyZ21[JgeVhfGA +(303 - 302)] != '\0';) {
            if (PfyZ21[JgeVhfGA] == PfyZ21[JgeVhfGA +(219 - 218)]) {
                DDHOAW7v = DDHOAW7v +(205 - 204);
            }
            else {
                printf ("(%c,%d)", PfyZ21[JgeVhfGA], DDHOAW7v);
                DDHOAW7v = (656 - 655);
            }
            JgeVhfGA = JgeVhfGA +(397 - 396);
        }
    }
    printf ("(%c,%d)", PfyZ21[JgeVhfGA], DDHOAW7v);
}

