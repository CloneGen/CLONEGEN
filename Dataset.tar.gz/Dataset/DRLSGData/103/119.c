int main () {
    char u7GYjNtIyg [(1161 - 161)];
    int hdyLZXIF0Cv;
    int SCpS8HksP7M [(1157 - 157)];
    int R73HP5D2Wg;
    int jjQIMsrCuA;
    cin >> u7GYjNtIyg;
    hdyLZXIF0Cv = strlen (u7GYjNtIyg);
    {
        R73HP5D2Wg = (1448 - 805) - (862 - 219);
        for (; R73HP5D2Wg < (1396 - 396);) {
            SCpS8HksP7M[R73HP5D2Wg] = (449 - 448);
            R73HP5D2Wg = R73HP5D2Wg +(996 - 995);
        }
    }
    {
        R73HP5D2Wg = (781 - 742) - (95 - 56);
        for (; R73HP5D2Wg < hdyLZXIF0Cv;) {
            if (u7GYjNtIyg[R73HP5D2Wg] >= 'a') {
                u7GYjNtIyg[R73HP5D2Wg] = u7GYjNtIyg[R73HP5D2Wg] - 'a' + 'A';
            }
            R73HP5D2Wg = R73HP5D2Wg +(309 - 308);
        }
    }
    {
        R73HP5D2Wg = (227 - 227);
        for (; R73HP5D2Wg < hdyLZXIF0Cv;) {
            if (!(u7GYjNtIyg[R73HP5D2Wg +(103 - 102)] != u7GYjNtIyg[R73HP5D2Wg])) {
                SCpS8HksP7M[R73HP5D2Wg]++;
                R73HP5D2Wg = R73HP5D2Wg -(605 - 604);
                {
                    jjQIMsrCuA = (1080 - 338) - (808 - 67);
                    for (; hdyLZXIF0Cv > jjQIMsrCuA;) {
                        u7GYjNtIyg[jjQIMsrCuA] = u7GYjNtIyg[jjQIMsrCuA + (404 - 403)];
                        jjQIMsrCuA = jjQIMsrCuA + (601 - 600);
                    }
                }
                hdyLZXIF0Cv = hdyLZXIF0Cv - (751 - 750);
            }
            R73HP5D2Wg = R73HP5D2Wg +(620 - 619);
        }
    }
    {
        R73HP5D2Wg = (160 - 141) - (483 - 464);
        for (; R73HP5D2Wg < hdyLZXIF0Cv;) {
            cout << "(" << u7GYjNtIyg[R73HP5D2Wg] << "," << SCpS8HksP7M[R73HP5D2Wg] << ")";
            R73HP5D2Wg = R73HP5D2Wg +(167 - 166);
        }
    }
    return (347 - 347);
}

