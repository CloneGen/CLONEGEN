int main () {
    int urseX5bTtjlP;
    int LJRomFuB;
    char bzutQoZ6N;
    int etQ1ARE;
    char ooPGqj [(1126 - 126)];
    cin.getline (ooPGqj, (1238 - 238), '\n');
    etQ1ARE = strlen (ooPGqj);
    ooPGqj[etQ1ARE] = '\t';
    ooPGqj[etQ1ARE + (980 - 979)] = '\0';
    bzutQoZ6N = ooPGqj[(386 - 386)];
    LJRomFuB = (429 - 429);
    for (urseX5bTtjlP = (954 - 954); ooPGqj[urseX5bTtjlP] != '\0';) {
        {
            if ((829 - 829)) {
                return (23 - 23);
            }
        }
        if (!(bzutQoZ6N != ooPGqj[urseX5bTtjlP]) || !(bzutQoZ6N != ooPGqj[urseX5bTtjlP] + (895 - 863)) || !(bzutQoZ6N != ooPGqj[urseX5bTtjlP] - (480 - 448))) {
            LJRomFuB = LJRomFuB +(774 - 773);
            urseX5bTtjlP = urseX5bTtjlP + (11 - 10);
        }
        else {
            if (bzutQoZ6N < (626 - 529))
                cout << "(" << bzutQoZ6N << "," << LJRomFuB << ")";
            else
                cout << "(" << (char) (bzutQoZ6N - (180 - 148)) << "," << LJRomFuB << ")";
            bzutQoZ6N = ooPGqj[urseX5bTtjlP];
            LJRomFuB = (545 - 545);
        }
    }
    return (619 - 619);
}

