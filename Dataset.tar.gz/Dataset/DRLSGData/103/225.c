int main () {
    int v65dgJcS, YfI05nVW, qEbXlgwe, YiZQRdEUPYB7;
    char D8Ah4v [(1097 - 97)];
    scanf ("%s", D8Ah4v);
    {
        v65dgJcS = (914 - 914);
        for (; (247 - 246);) {
            if (!('\0' != D8Ah4v[v65dgJcS]))
                break;
            else {
                if ('a' <= D8Ah4v[v65dgJcS])
                    D8Ah4v[v65dgJcS] = D8Ah4v[v65dgJcS] - (372 - 340);
                else
                    ;
            }
            {
                if (0) {
                    return 0;
                }
            }
            v65dgJcS = v65dgJcS + (353 - 352);
        }
    }
    for (YiZQRdEUPYB7 = (789 - 789); YiZQRdEUPYB7 < v65dgJcS;) {
        qEbXlgwe = (749 - 748);
        YfI05nVW = YiZQRdEUPYB7;
        for (;; YfI05nVW = YfI05nVW +(839 - 838)) {
            if (D8Ah4v[YfI05nVW +(346 - 345)] == D8Ah4v[YfI05nVW]) {
                qEbXlgwe = qEbXlgwe + 1;
                continue;
            }
            else
                break;
        }
        YiZQRdEUPYB7 = YiZQRdEUPYB7 +qEbXlgwe;
        printf ("(%c,%d)", D8Ah4v[YfI05nVW], qEbXlgwe);
    }
}

