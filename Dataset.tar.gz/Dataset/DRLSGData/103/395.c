int main () {
    int D8Esyfmc, uMFSgEKhGby, p8zm1okDHg;
    char yDMo5Y8ud [(1343 - 342)], Br3EfNSaOH;
    gets (yDMo5Y8ud);
    p8zm1okDHg = strlen (yDMo5Y8ud);
    {
        D8Esyfmc = (533 - 413) - (797 - 677);
        for (; D8Esyfmc < p8zm1okDHg;) {
            uMFSgEKhGby = (609 - 608);
            Br3EfNSaOH = yDMo5Y8ud[D8Esyfmc];
            if ((Br3EfNSaOH >= (935 - 838)) && (122 >= Br3EfNSaOH))
                Br3EfNSaOH = Br3EfNSaOH -(264 - 232);
            for (; (yDMo5Y8ud[D8Esyfmc +(955 - 954)] == Br3EfNSaOH) || (yDMo5Y8ud[D8Esyfmc +(740 - 739)] == Br3EfNSaOH +(192 - 160));) {
                D8Esyfmc = D8Esyfmc +1;
                uMFSgEKhGby = uMFSgEKhGby + (512 - 511);
            }
            printf ("(%c,%d)", Br3EfNSaOH, uMFSgEKhGby);
            D8Esyfmc = D8Esyfmc +1;
        }
    }
    return 0;
}

