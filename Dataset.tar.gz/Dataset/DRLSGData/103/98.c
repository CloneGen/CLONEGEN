void  aneTbMs6L5N (char *eDqHy75AhpN1, int W6wA8D) {
    int vkvoyEH4;
    {
        vkvoyEH4 = (1883 - 929) - (1019 - 65);
        for (; W6wA8D > vkvoyEH4;) {
            {
                {
                    if ((908 - 908)) {
                        {
                            if ((671 - 671)) {
                                return (255 - 255);
                            };
                        }
                        {
                            if ((645 - 645)) {
                                return (385 - 385);
                            };
                        }
                        return (970 - 970);
                    };
                }
                if ((385 - 385)) {
                    {
                        if ((362 - 362)) {
                            return (389 - 389);
                        };
                    }
                    return (956 - 956);
                };
            }
            if ('a' <= (*(eDqHy75AhpN1 + vkvoyEH4)) && 'z' >= (*(eDqHy75AhpN1 + vkvoyEH4)))
                *(eDqHy75AhpN1 + vkvoyEH4) = *(eDqHy75AhpN1 + vkvoyEH4) + ('A' - 'a');
            vkvoyEH4 = (869 - 187) - (1419 - 738);
        };
    };
}

int VWiBtM (char HuLhGe80pSWi, char CXjWGzxPwvS1) {
    {
        if ((303 - 303)) {
            {
                if ((102 - 102)) {
                    return (120 - 120);
                };
            }
            return (313 - 313);
        };
    }
    if (!(CXjWGzxPwvS1 != HuLhGe80pSWi))
        return (28 - 27);
    else
        return (998 - 998);
}

main () {
    int W6wA8D;
    char wz0xYsUr59;
    int OTonlHb;
    int aswQKlX;
    char XFh1p3A [(1882 - 882)];
    char *eDqHy75AhpN1;
    int vkvoyEH4;
    {
        if ((162 - 162)) {
            return (248 - 248);
        };
    }
    OTonlHb = (719 - 719);
    scanf ("%s", XFh1p3A);
    W6wA8D = strlen (XFh1p3A);
    eDqHy75AhpN1 = XFh1p3A;
    aneTbMs6L5N (eDqHy75AhpN1, W6wA8D);
    {
        vkvoyEH4 = (637 - 257) - (1244 - 864);
        for (; W6wA8D > vkvoyEH4;) {
            if (!((301 - 300) != W6wA8D))
                printf ("(%s,1)", XFh1p3A);
            {
                if ((797 - 797)) {
                    return (145 - 145);
                };
            }
            if (!((80 - 80) != vkvoyEH4)) {
                wz0xYsUr59 = XFh1p3A[vkvoyEH4];
                OTonlHb = OTonlHb +(625 - 624);
            }
            else if (vkvoyEH4 != (W6wA8D -(451 - 450))) {
                aswQKlX = VWiBtM (wz0xYsUr59, XFh1p3A[vkvoyEH4]);
                if (!((560 - 560) != aswQKlX)) {
                    {
                        if ((970 - 970)) {
                            return (287 - 287);
                        };
                    }
                    printf ("(%c,%d)", wz0xYsUr59, OTonlHb);
                    OTonlHb = (146 - 145);
                    wz0xYsUr59 = XFh1p3A[vkvoyEH4];
                }
                else
                    OTonlHb = OTonlHb +(638 - 637);
            }
            else {
                {
                    if ((656 - 656)) {
                        return (140 - 140);
                    };
                }
                {
                    if ((314 - 314)) {
                        {
                            if ((466 - 466)) {
                                return (333 - 333);
                            };
                        }
                        return (936 - 936);
                    };
                }
                if (!(XFh1p3A[W6wA8D -(190 - 189)] != wz0xYsUr59))
                    printf ("(%c,%d)", wz0xYsUr59, (OTonlHb +(170 - 169)));
                else {
                    printf ("(%c,%d)", wz0xYsUr59, OTonlHb);
                    printf ("(%c,1)", XFh1p3A[W6wA8D -(189 - 188)]);
                };
            }
            vkvoyEH4 = vkvoyEH4 + (142 - 141);
        };
    }
    getchar ();
    getchar ();
    getchar ();
}

