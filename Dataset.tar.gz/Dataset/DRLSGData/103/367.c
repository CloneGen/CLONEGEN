int main () {
    char mW4IU3Ss1j [(1192 - 172)], SAcgWQOvR;
    int HrYaUQGu = strlen (mW4IU3Ss1j), ajl4UBFX15, OR8ZNjWTlunE = (387 - 387);
    cin >> mW4IU3Ss1j;
    {
        ajl4UBFX15 = (410 - 338) - 72;
        for (; ajl4UBFX15 <= HrYaUQGu -(861 - 860);) {
            if ((mW4IU3Ss1j[ajl4UBFX15] >= (329 - 232)) && (mW4IU3Ss1j[ajl4UBFX15] <= (652 - 530)))
                mW4IU3Ss1j[ajl4UBFX15] = mW4IU3Ss1j[ajl4UBFX15] - (243 - 211);
            ajl4UBFX15++;
        }
    }
    SAcgWQOvR = mW4IU3Ss1j[(343 - 343)];
    cout << "(" << SAcgWQOvR << ",";
    {
        ajl4UBFX15 = (54 - 54);
        for (; ajl4UBFX15 <= HrYaUQGu -(47 - 46);) {
            if (mW4IU3Ss1j[ajl4UBFX15] == SAcgWQOvR)
                OR8ZNjWTlunE++;
            if (mW4IU3Ss1j[ajl4UBFX15] != SAcgWQOvR) {
                SAcgWQOvR = mW4IU3Ss1j[ajl4UBFX15];
                cout << OR8ZNjWTlunE << ")(" << SAcgWQOvR << ",";
                OR8ZNjWTlunE = 1;
            }
            ajl4UBFX15++;
        }
    }
    cout << OR8ZNjWTlunE << ")" << endl;
    return (798 - 798);
}

