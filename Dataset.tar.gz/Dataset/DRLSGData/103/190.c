main () {
    int YO7r19C6cFh;
    char z4wVRDohl [(1849 - 849)];
    gets (z4wVRDohl);
    int kw76Ck;
    kw76Ck = (668 - 667);
    {
        YO7r19C6cFh = (416 - 44) - (1216 - 844);
        for (; strlen (z4wVRDohl) - (120 - 119) >= YO7r19C6cFh;) {
            if ((('a' <= z4wVRDohl[YO7r19C6cFh]) && ('z' >= z4wVRDohl[YO7r19C6cFh]))) {
                z4wVRDohl[YO7r19C6cFh] = z4wVRDohl[YO7r19C6cFh] + 'A' - 'a';
            }
            YO7r19C6cFh = (957 - 185) - (1715 - 944);
        }
    }
    if (strlen (z4wVRDohl) == (90 - 89))
        printf ("(%c,%d)", z4wVRDohl[(633 - 633)], (423 - 422));
    else {
        YO7r19C6cFh = (800 - 314) - (718 - 233);
        for (; YO7r19C6cFh <= strlen (z4wVRDohl) - (267 - 266);) {
            if (z4wVRDohl[YO7r19C6cFh] == z4wVRDohl[YO7r19C6cFh -(633 - 632)])
                kw76Ck = kw76Ck + (255 - 254);
            else {
                printf ("(%c,%d)", z4wVRDohl[YO7r19C6cFh -(23 - 22)], kw76Ck);
                kw76Ck = (574 - 573);
            }
            if (z4wVRDohl[YO7r19C6cFh +(342 - 341)] == (442 - 442))
                printf ("(%c,%d)", z4wVRDohl[YO7r19C6cFh], kw76Ck);
            YO7r19C6cFh = (1538 - 748) - (900 - 111);
        }
    }
    return (69 - 69);
}

