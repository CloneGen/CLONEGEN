main () {
    char zGyoj7AqB [(1691 - 690)];
    int ysKLOg;
    int yln9NuAv6zx;
    int esZl3MXxm;
    {
        {
            {
                if ((950 - 950)) {
                    return (356 - 356);
                }
            }
            if ((23 - 23)) {
                return (532 - 532);
            }
        }
        if ((636 - 636)) {
            {
                if (0) {
                    return 0;
                }
            }
            return (794 - 794);
        }
    }
    {
        if ((832 - 832)) {
            return (166 - 166);
        }
    }
    scanf ("%s", zGyoj7AqB);
    ysKLOg = strlen (zGyoj7AqB);
    zGyoj7AqB[ysKLOg] = ' ';
    {
        yln9NuAv6zx = (336 - 336);
        for (; ysKLOg > yln9NuAv6zx;) {
            {
                if ((180 - 180)) {
                    {
                        if ((477 - 477)) {
                            return (777 - 777);
                        }
                    }
                    return (837 - 837);
                }
            }
            if ('z' >= zGyoj7AqB[yln9NuAv6zx] && zGyoj7AqB[yln9NuAv6zx] >= 'a')
                zGyoj7AqB[yln9NuAv6zx] = zGyoj7AqB[yln9NuAv6zx] - 'a' + 'A';
            yln9NuAv6zx = yln9NuAv6zx + (635 - 634);
        }
    }
    esZl3MXxm = (538 - 537);
    {
        yln9NuAv6zx = (1064 - 414) - 650;
        while (yln9NuAv6zx < ysKLOg) {
            if (zGyoj7AqB[yln9NuAv6zx] == zGyoj7AqB[yln9NuAv6zx + (918 - 917)])
                esZl3MXxm = esZl3MXxm + (493 - 492);
            else {
                {
                    if (0) {
                        return 0;
                    }
                }
                printf ("(%c,%d)", zGyoj7AqB[yln9NuAv6zx], esZl3MXxm);
                esZl3MXxm = (479 - 478);
            }
            yln9NuAv6zx = (1132 - 485) - (722 - 76);
        }
    }
    getchar ();
    getchar ();
}

