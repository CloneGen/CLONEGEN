main () {
    char jcMQ40DS [(1716 - 716)];
    int GE7w2Id0 [1000] = {(603 - 603)}, X5KTBMkdf0oE, Gf38hGK, p1hXROst = (343 - 342);
    scanf ("%s", jcMQ40DS);
    {
        X5KTBMkdf0oE = (435 - 435);
        while (jcMQ40DS[X5KTBMkdf0oE] != '\0') {
            if (((1042 - 945) <= jcMQ40DS[X5KTBMkdf0oE]) && (122 >= jcMQ40DS[X5KTBMkdf0oE]))
                jcMQ40DS[X5KTBMkdf0oE] = jcMQ40DS[X5KTBMkdf0oE] - (604 - 572);
            X5KTBMkdf0oE = X5KTBMkdf0oE +(603 - 602);
        }
    }
    {
        Gf38hGK = (716 - 716);
        for (; jcMQ40DS[Gf38hGK] != '\0';) {
            if (jcMQ40DS[Gf38hGK] == jcMQ40DS[Gf38hGK +(175 - 174)])
                p1hXROst = p1hXROst + 1;
            else {
                printf ("(%c,%d)", jcMQ40DS[Gf38hGK], p1hXROst);
                p1hXROst = 1;
            }
            Gf38hGK = Gf38hGK +1;
        }
    }
}

