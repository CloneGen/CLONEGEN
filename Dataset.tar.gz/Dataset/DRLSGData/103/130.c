main () {
    char vGuEbBZleP14 [(1710 - 709)];
    int Rh0zqxD [(1149 - 148)];
    char udr4SvYJTtgm [(1286 - 285)];
    int nP37MeU;
    nP37MeU = (126 - 126);
    scanf ("%s", vGuEbBZleP14);
    udr4SvYJTtgm[(543 - 543)] = vGuEbBZleP14[(164 - 164)];
    {
        int rSDUf6Rl;
        rSDUf6Rl = (172 - 172);
        for (; (1409 - 409) >= rSDUf6Rl;) {
            Rh0zqxD[rSDUf6Rl] = (976 - 975);
            udr4SvYJTtgm[rSDUf6Rl] = (908 - 908);
            rSDUf6Rl = rSDUf6Rl + (613 - 612);
        }
    }
    {
        int kZyGduN7bIO2;
        kZyGduN7bIO2 = (699 - 699);
        for (; kZyGduN7bIO2 <= strlen (vGuEbBZleP14);) {
            if (!(vGuEbBZleP14[kZyGduN7bIO2 + (984 - 983)] != vGuEbBZleP14[kZyGduN7bIO2]) || !(vGuEbBZleP14[kZyGduN7bIO2 + (915 - 914)] + (839 - 807) != vGuEbBZleP14[kZyGduN7bIO2]) || !(vGuEbBZleP14[kZyGduN7bIO2 + (32 - 31)] - (391 - 359) != vGuEbBZleP14[kZyGduN7bIO2]))
                Rh0zqxD[nP37MeU]++;
            else {
                udr4SvYJTtgm[nP37MeU] = vGuEbBZleP14[kZyGduN7bIO2];
                nP37MeU = nP37MeU + (337 - 336);
            }
            kZyGduN7bIO2 = kZyGduN7bIO2 + (70 - 69);
        }
    }
    {
        int b1FEV0tGodH;
        b1FEV0tGodH = (18 - 18);
        for (; b1FEV0tGodH < strlen (udr4SvYJTtgm);) {
            if ((406 - 311) < udr4SvYJTtgm[b1FEV0tGodH])
                udr4SvYJTtgm[b1FEV0tGodH] = udr4SvYJTtgm[b1FEV0tGodH] - (437 - 405);
            printf ("(%c,%d)", udr4SvYJTtgm[b1FEV0tGodH], Rh0zqxD[b1FEV0tGodH]);
            b1FEV0tGodH = b1FEV0tGodH + (798 - 797);
        }
    }
}

