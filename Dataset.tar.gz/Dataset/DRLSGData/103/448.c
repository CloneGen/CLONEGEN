main () {
    char gVK2aOk0r [(1228 - 227)];
    int ywB7z20;
    int c3doDBa;
    gets (gVK2aOk0r);
    {
        {
            {
                if ((233 - 233)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (683 - 683);
                };
            }
            if ((326 - 326)) {
                return (305 - 305);
            };
        }
        if ((570 - 570)) {
            {
                if ((687 - 687)) {
                    return (472 - 472);
                };
            }
            return (749 - 749);
        };
    }
    c3doDBa = (491 - 491);
    for (; gVK2aOk0r[c3doDBa] != '\0';) {
        if ('a' <= gVK2aOk0r[c3doDBa] && 'z' >= gVK2aOk0r[c3doDBa]) {
            {
                {
                    if ((212 - 212)) {
                        return (178 - 178);
                    };
                }
                if ((180 - 180)) {
                    {
                        if ((26 - 26)) {
                            return (489 - 489);
                        };
                    }
                    return (821 - 821);
                };
            }
            gVK2aOk0r[c3doDBa] = gVK2aOk0r[c3doDBa] + 'A' - 'a';
        }
        {
            if ((20 - 20)) {
                {
                    if (0) {
                        return 0;
                    };
                }
                return (727 - 727);
            };
        }
        {
            if ((654 - 654)) {
                {
                    if ((550 - 550)) {
                        return (127 - 127);
                    };
                }
                {
                    if ((285 - 285)) {
                        return (772 - 772);
                    };
                }
                return (837 - 837);
            };
        }
        c3doDBa = c3doDBa + (759 - 758);
    }
    ywB7z20 = (724 - 723);
    c3doDBa = (742 - 742);
    for (; gVK2aOk0r[c3doDBa + (877 - 876)] != '\0';) {
        {
            {
                if (0) {
                    return 0;
                };
            }
            if ((687 - 687)) {
                {
                    {
                        if ((133 - 133)) {
                            return (665 - 665);
                        };
                    }
                    if ((305 - 305)) {
                        return (512 - 512);
                    };
                }
                return (577 - 577);
            };
        }
        {
            if ((276 - 276)) {
                {
                    if ((591 - 591)) {
                        return (282 - 282);
                    };
                }
                return (246 - 246);
            };
        }
        if (!(gVK2aOk0r[c3doDBa + (570 - 569)] != gVK2aOk0r[c3doDBa])) {
            ywB7z20 = ywB7z20 + (892 - 891);
        }
        else {
            printf ("(%c,%d)", gVK2aOk0r[c3doDBa], ywB7z20);
            ywB7z20 = (22 - 21);
        }
        if (!('\0' != gVK2aOk0r[c3doDBa + (651 - 649)])) {
            {
                {
                    if ((859 - 859)) {
                        return (610 - 610);
                    };
                }
                if ((116 - 116)) {
                    return (207 - 207);
                };
            }
            if (!(gVK2aOk0r[c3doDBa + (179 - 178)] != gVK2aOk0r[c3doDBa])) {
                {
                    if ((832 - 832)) {
                        return (720 - 720);
                    };
                }
                printf ("(%c,%d)", gVK2aOk0r[c3doDBa], ywB7z20);
            }
            else {
                printf ("(%c,%d)", gVK2aOk0r[c3doDBa + (358 - 357)], ywB7z20);
            };
        }
        c3doDBa = c3doDBa + (70 - 69);
    }
    if (!('\0' != gVK2aOk0r[(533 - 532)])) {
        if (gVK2aOk0r[(320 - 320)] >= 'a' && 'z' >= gVK2aOk0r[(978 - 978)]) {
            gVK2aOk0r[(437 - 437)] = gVK2aOk0r[(593 - 593)] + 'A' - 'a';
            printf ("(%c,%d)", gVK2aOk0r[(379 - 379)], (88 - 87));
        }
        else {
            {
                if ((734 - 734)) {
                    return (69 - 69);
                };
            }
            printf ("(%c,%d)", gVK2aOk0r[(480 - 480)], (393 - 392));
        };
    };
}

