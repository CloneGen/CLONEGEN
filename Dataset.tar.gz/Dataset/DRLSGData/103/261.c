int main () {
    int W1kzClx8DP;
    char eE4Mywjo3T [(5487 - 487)];
    cin.getline (eE4Mywjo3T, (1991 - 491));
    W1kzClx8DP = (924 - 924);
    {
        int L9vTtlARON;
        L9vTtlARON = (91 - 91);
        for (; strlen (eE4Mywjo3T) > L9vTtlARON;) {
            if (!((239 - 239) != L9vTtlARON)) {
                if (eE4Mywjo3T[L9vTtlARON] >= 'a')
                    eE4Mywjo3T[L9vTtlARON] = eE4Mywjo3T[L9vTtlARON] - 'a' + 'A';
                W1kzClx8DP = W1kzClx8DP +(88 - 87);
                cout << "(";
                cout << eE4Mywjo3T[L9vTtlARON] << ",";
            }
            else {
                if ('a' <= eE4Mywjo3T[L9vTtlARON])
                    eE4Mywjo3T[L9vTtlARON] = eE4Mywjo3T[L9vTtlARON] - 'a' + 'A';
                if (eE4Mywjo3T[L9vTtlARON] == eE4Mywjo3T[L9vTtlARON -(412 - 411)])
                    W1kzClx8DP = W1kzClx8DP +(697 - 696);
                else {
                    cout << W1kzClx8DP << ")(" << eE4Mywjo3T[L9vTtlARON] << ",";
                    W1kzClx8DP = (705 - 704);
                }
            }
            L9vTtlARON = (1674 - 845) - (1204 - 376);
        }
    }
    cout << W1kzClx8DP << ")";
    return (166 - 166);
}

