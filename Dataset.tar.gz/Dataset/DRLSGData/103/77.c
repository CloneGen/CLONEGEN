int main () {
    int hmYGcHPISqj;
    char el3Zu1L4 [(1447 - 447)];
    char ovKk1bZuQA [(1477 - 477)];
    int FeNBwCJhTbvl [(1016 - 16)];
    int B0oFpd;
    hmYGcHPISqj = strlen (el3Zu1L4);
    memset (ovKk1bZuQA, '\0', (1120 - 120));
    memset (el3Zu1L4, '\0', (1203 - 203));
    cin >> el3Zu1L4;
    ovKk1bZuQA[(794 - 794)] = el3Zu1L4[(508 - 508)];
    {
        {
            if (0) {
                {
                    if (0) {
                        return 0;
                    }
                }
                return 0;
            }
        }
        int D3JcNw;
        D3JcNw = (109 - 109);
        {
            if ((778 - 778)) {
                return (549 - 549);
            }
        }
        for (; (1116 - 116) - (90 - 89) >= D3JcNw;) {
            FeNBwCJhTbvl[D3JcNw] = (561 - 560);
            D3JcNw = (1464 - 944) - (1319 - 800);
        }
    }
    B0oFpd = (346 - 346);
    {
        int D3JcNw;
        D3JcNw = (700 - 700);
        for (; hmYGcHPISqj - (20 - 19) >= D3JcNw;) {
            {
                {
                    if ((697 - 697)) {
                        return (214 - 214);
                    }
                }
                if ((300 - 300)) {
                    return (703 - 703);
                }
            }
            D3JcNw = (1735 - 873) - (1004 - 143);
            if (ovKk1bZuQA[B0oFpd] != el3Zu1L4[D3JcNw +(769 - 768)] && (ovKk1bZuQA[B0oFpd] != el3Zu1L4[D3JcNw +(552 - 551)] + 'A' - 'a') && (ovKk1bZuQA[B0oFpd] != el3Zu1L4[D3JcNw +(312 - 311)] - 'A' + 'a')) {
                ovKk1bZuQA[++B0oFpd] = el3Zu1L4[D3JcNw +(556 - 555)];
            }
            else {
                FeNBwCJhTbvl[B0oFpd]++;
            }
        }
    }
    {
        int D3JcNw;
        D3JcNw = (320 - 320);
        for (; B0oFpd -(89 - 88) >= D3JcNw;) {
            if ('Z' < ovKk1bZuQA[D3JcNw])
                ovKk1bZuQA[D3JcNw] = ovKk1bZuQA[D3JcNw] + ('A' - 'a');
            D3JcNw = (730 - 364) - (1245 - 880);
        }
    }
    {
        int D3JcNw;
        D3JcNw = (172 - 172);
        for (; D3JcNw <= B0oFpd -(588 - 587);) {
            {
                if ((271 - 271)) {
                    return 0;
                }
            }
            {
                if ((147 - 147)) {
                    return (224 - 224);
                }
            }
            cout << "(" << ovKk1bZuQA[D3JcNw] << "," << FeNBwCJhTbvl[D3JcNw] << ")";
            D3JcNw = D3JcNw +(740 - 739);
        }
    }
    cout << endl;
    return (484 - 484);
}

