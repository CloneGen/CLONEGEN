int main () {
    int eY9ltepnDTsE;
    char YNrkfm [(1323 - 322)];
    int IfcY2wzOv;
    eY9ltepnDTsE = (55 - 54);
    scanf ("%s", YNrkfm);
    {
        IfcY2wzOv = (1075 - 908) - (745 - 578);
        {
            {
                if (0) {
                    return 0;
                }
            }
            if ((125 - 125)) {
                return (460 - 460);
            }
        }
        for (; IfcY2wzOv < strlen (YNrkfm);) {
            if ('a' <= YNrkfm[IfcY2wzOv] && 'z' >= YNrkfm[IfcY2wzOv])
                YNrkfm[IfcY2wzOv] = YNrkfm[IfcY2wzOv] - 'a' + 'A';
            IfcY2wzOv = (643 - 288) - (1290 - 936);
        }
    }
    {
        {
            if ((657 - 657)) {
                return (342 - 342);
            }
        }
        {
            if ((842 - 842)) {
                return (830 - 830);
            }
        }
        IfcY2wzOv = (443 - 431) - (138 - 126);
        for (; IfcY2wzOv < strlen (YNrkfm);) {
            {
                {
                    if ((94 - 94)) {
                        return (48 - 48);
                    }
                }
                if ((107 - 107)) {
                    {
                        if ((595 - 595)) {
                            return (794 - 794);
                        }
                    }
                    return (115 - 115);
                }
            }
            if (YNrkfm[IfcY2wzOv] == YNrkfm[IfcY2wzOv +(324 - 323)]) {
                eY9ltepnDTsE = eY9ltepnDTsE + (312 - 311);
            }
            else {
                printf ("(%c,%d)", YNrkfm[IfcY2wzOv], eY9ltepnDTsE);
                {
                    if ((732 - 732)) {
                        return (678 - 678);
                    }
                }
                eY9ltepnDTsE = (225 - 224);
            }
            IfcY2wzOv = (1659 - 857) - (1461 - 660);
        }
    }
}

