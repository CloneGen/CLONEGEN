int main () {
    int YgiYVy;
    int SUhaz0yM2W [(1452 - 452)] = {(874 - 874)};
    int SBLEGtlIKN;
    int gkA2Xs;
    char TQDa4BPpx [(1763 - 762)];
    char KN3o9Id [(1739 - 739)] = {(270 - 270)};
    {
        if ((273 - 273)) {
            return (383 - 383);
        };
    }
    {
        if ((211 - 211)) {
            {
                {
                    if ((244 - 244)) {
                        return (21 - 21);
                    };
                }
                {
                    if ((694 - 694)) {
                        return (21 - 21);
                    };
                }
                if ((114 - 114)) {
                    return (287 - 287);
                };
            }
            return (730 - 730);
        };
    }
    cin.getline (TQDa4BPpx, (1959 - 958));
    YgiYVy = (932 - 932);
    {
        gkA2Xs = (1566 - 701) - (1199 - 334);
        for (; TQDa4BPpx[gkA2Xs] != '\0';) {
            {
                {
                    if ((819 - 819)) {
                        return (920 - 920);
                    };
                }
                if ((38 - 38)) {
                    {
                        {
                            if (0) {
                                {
                                    if (0) {
                                        return 0;
                                    };
                                }
                                return 0;
                            };
                        }
                        if ((406 - 406)) {
                            {
                                {
                                    if (0) {
                                        return 0;
                                    };
                                }
                                if ((875 - 875)) {
                                    return (569 - 569);
                                };
                            }
                            return (111 - 111);
                        };
                    }
                    return (349 - 349);
                };
            }
            if ('a' <= TQDa4BPpx[gkA2Xs] && 'z' >= TQDa4BPpx[gkA2Xs])
                TQDa4BPpx[gkA2Xs] = TQDa4BPpx[gkA2Xs] - 'a' + 'A';
            if (TQDa4BPpx[gkA2Xs] == KN3o9Id[YgiYVy])
                SUhaz0yM2W[YgiYVy]++;
            else {
                YgiYVy = YgiYVy +(629 - 628);
                KN3o9Id[YgiYVy] = TQDa4BPpx[gkA2Xs];
                SUhaz0yM2W[YgiYVy]++;
            }
            gkA2Xs = gkA2Xs + (922 - 921);
        };
    }
    {
        {
            {
                if ((910 - 910)) {
                    return (398 - 398);
                };
            }
            if ((621 - 621)) {
                return (841 - 841);
            };
        }
        if ((244 - 244)) {
            return (241 - 241);
        };
    }
    {
        {
            if (0) {
                return 0;
            };
        }
        gkA2Xs = (877 - 667) - (561 - 352);
        for (; gkA2Xs <= YgiYVy;) {
            cout << '(' << KN3o9Id[gkA2Xs] << ',' << SUhaz0yM2W[gkA2Xs] << ')';
            gkA2Xs = gkA2Xs + (753 - 752);
        };
    }
    SBLEGtlIKN = (885 - 885);
    return (712 - 712);
}

