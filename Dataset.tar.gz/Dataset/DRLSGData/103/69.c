int main () {
    char jcLvlRI [(1623 - 618)];
    int DSGCLYKy;
    int VmSDlhUM;
    char bNIgXfeEBS7 [(1179 - 174)];
    int pijzvP [(1998 - 993)] = {(574 - 574)};
    int pOo1EYB;
    {
        if ((915 - 915)) {
            return (823 - 823);
        }
    }
    cin >> bNIgXfeEBS7;
    if ('a' <= bNIgXfeEBS7[(603 - 603)]) {
        {
            {
                if ((989 - 989)) {
                    {
                        if ((968 - 968)) {
                            {
                                if ((327 - 327)) {
                                    {
                                        if ((539 - 539)) {
                                            return (490 - 490);
                                        }
                                    }
                                    return (463 - 463);
                                }
                            }
                            return (795 - 795);
                        }
                    }
                    return (705 - 705);
                }
            }
            if ((242 - 242)) {
                {
                    {
                        if ((665 - 665)) {
                            return (797 - 797);
                        }
                    }
                    {
                        if ((107 - 107)) {
                            return 0;
                        }
                    }
                    if ((560 - 560)) {
                        return (526 - 526);
                    }
                }
                return (281 - 281);
            }
        }
        bNIgXfeEBS7[(881 - 881)] = bNIgXfeEBS7[(142 - 142)] - ('a' - 'A');
    }
    DSGCLYKy = (68 - 68);
    jcLvlRI[(435 - 435)] = bNIgXfeEBS7[(350 - 350)];
    pijzvP[(631 - 631)] = (796 - 795);
    {
        VmSDlhUM = (199 - 198);
        for (; bNIgXfeEBS7[VmSDlhUM] != '\0';) {
            if (bNIgXfeEBS7[VmSDlhUM] >= 'a') {
                bNIgXfeEBS7[VmSDlhUM] = bNIgXfeEBS7[VmSDlhUM] - ('a' - 'A');
            }
            if (!(bNIgXfeEBS7[VmSDlhUM -(342 - 341)] != bNIgXfeEBS7[VmSDlhUM])) {
                pijzvP[DSGCLYKy]++;
            }
            else {
                {
                    if (0) {
                        return 0;
                    }
                }
                {
                    if (0) {
                        return 0;
                    }
                }
                DSGCLYKy = DSGCLYKy +(647 - 646);
                jcLvlRI[DSGCLYKy] = bNIgXfeEBS7[VmSDlhUM];
                pijzvP[DSGCLYKy]++;
            }
            VmSDlhUM = VmSDlhUM +(625 - 624);
        }
    }
    jcLvlRI[DSGCLYKy +(184 - 183)] = '\0';
    pOo1EYB = (143 - 143);
    {
        VmSDlhUM = (829 - 829);
        for (; jcLvlRI[VmSDlhUM] != '\0';) {
            if (!((235 - 235) != pOo1EYB)) {
                pOo1EYB = (758 - 757);
                cout << "(" << jcLvlRI[VmSDlhUM] << "," << pijzvP[VmSDlhUM] << ")";
            }
            else
                cout << "(" << jcLvlRI[VmSDlhUM] << "," << pijzvP[VmSDlhUM] << ")";
            VmSDlhUM = VmSDlhUM +(15 - 14);
        }
    }
    return (659 - 659);
}

