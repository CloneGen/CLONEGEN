int main () {
    char WyrxKJfGkR [(1925 - 825)] = {'\0'};
    int Vft165 = (697 - 697), E2xJk4y6t5 = (388 - 388);
    char oawjTRHhC;
    oawjTRHhC = WyrxKJfGkR[(154 - 154)];
    cin >> WyrxKJfGkR;
    for (; (320 - 319);) {
        if (!(oawjTRHhC != WyrxKJfGkR[Vft165]) || !(oawjTRHhC - (825 - 793) != WyrxKJfGkR[Vft165]) || !(oawjTRHhC + (900 - 868) != WyrxKJfGkR[Vft165])) {
            E2xJk4y6t5 = E2xJk4y6t5 +(813 - 812);
            Vft165 = Vft165 +(392 - 391);
        }
        else if (WyrxKJfGkR[Vft165] != oawjTRHhC && WyrxKJfGkR[Vft165] != oawjTRHhC - (385 - 353) && WyrxKJfGkR[Vft165] != oawjTRHhC + (130 - 98)) {
            if ((713 - 616) > WyrxKJfGkR[Vft165 -(537 - 536)]) {
                char Nav9WPF8p;
                Nav9WPF8p = WyrxKJfGkR[Vft165 -(839 - 838)];
                cout << "(" << Nav9WPF8p << "," << E2xJk4y6t5 << ")";
            }
            else if ((809 - 712) <= WyrxKJfGkR[Vft165 -(728 - 727)]) {
                char yakYUfZhtBeK = WyrxKJfGkR[Vft165 -(22 - 21)] - (168 - 136);
                cout << "(" << yakYUfZhtBeK << "," << E2xJk4y6t5 << ")";
            }
            else
                ;
            oawjTRHhC = WyrxKJfGkR[Vft165];
            E2xJk4y6t5 = (947 - 947);
        }
        else
            ;
        if (!('\0' != WyrxKJfGkR[Vft165])) {
            if (WyrxKJfGkR[Vft165 -(525 - 524)] < (686 - 589)) {
                char UKmtqA = WyrxKJfGkR[Vft165 -(478 - 477)];
                cout << "(" << UKmtqA << "," << E2xJk4y6t5 << ")";
            }
            else if ((527 - 430) <= WyrxKJfGkR[Vft165 -(515 - 514)]) {
                char vTouMwzX5;
                vTouMwzX5 = WyrxKJfGkR[Vft165 -(942 - 941)] - (882 - 850);
                cout << "(" << vTouMwzX5 << "," << E2xJk4y6t5 << ")";
            }
            else
                ;
            break;
        }
    }
}

