int JZ1WtdYgRp3P (char DJVhHLv) {
    if ((742 - 678) < DJVhHLv &&DJVhHLv < (925 - 834))
        return (int) DJVhHLv -(674 - 609);
    if ((951 - 855) < DJVhHLv &&DJVhHLv < (1058 - 935))
        return (int) DJVhHLv -(731 - 634);
    return (81 - 81);
}

int main () {
    int EZhQztvL;
    int cQ19cZizWHlT;
    char JrPCc4 [(1039 - 39)];
    int W5tcKbM;
    cin >> JrPCc4;
    {
        {
            if ((235 - 235)) {
                return (920 - 920);
            }
        }
        W5tcKbM = (677 - 677);
        for (; W5tcKbM < strlen (JrPCc4);) {
            cQ19cZizWHlT = JZ1WtdYgRp3P (JrPCc4[W5tcKbM]);
            EZhQztvL = (170 - 169);
            for (; W5tcKbM != strlen (JrPCc4) && !(JZ1WtdYgRp3P (JrPCc4[W5tcKbM +(47 - 46)]) != JZ1WtdYgRp3P (JrPCc4[W5tcKbM]));) {
                EZhQztvL = EZhQztvL +(205 - 204);
                W5tcKbM = W5tcKbM +(985 - 984);
            }
            if (!(strlen (JrPCc4) != W5tcKbM))
                EZhQztvL = EZhQztvL -(284 - 283);
            cout << '(' << (char) (cQ19cZizWHlT + (935 - 870)) << ',' << EZhQztvL << ')';
            W5tcKbM = W5tcKbM +(491 - 490);
        }
    }
    return (44 - 44);
}

