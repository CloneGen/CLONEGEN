int main () {
    int QHIg93EFZ;
    char UjW3FPaE;
    int GQhDiBztAdE;
    char gvT0Mm;
    char TryR9bF1nTe [(1561 - 561)];
    gvT0Mm = NULL;
    {
        GQhDiBztAdE = (558 - 558);
        for (; GQhDiBztAdE < (1611 - 611);) {
            cin.get (UjW3FPaE);
            if (!('\n' != UjW3FPaE)) {
                cout << QHIg93EFZ << ")" << endl;
                break;
            }
            else {
                if ((275 - 275) <= UjW3FPaE -'a' && UjW3FPaE -'a' <= (461 - 435))
                    UjW3FPaE = 'A' + UjW3FPaE -'a';
                if (gvT0Mm != UjW3FPaE) {
                    if (gvT0Mm != NULL)
                        cout << QHIg93EFZ << ")(" << UjW3FPaE << ",";
                    else
                        cout << "(" << UjW3FPaE << ",";
                    gvT0Mm = UjW3FPaE;
                    QHIg93EFZ = (34 - 33);
                }
                else {
                    QHIg93EFZ = QHIg93EFZ +(828 - 827);
                }
            }
            GQhDiBztAdE = GQhDiBztAdE +(107 - 106);
        }
    }
    return (625 - 625);
}

