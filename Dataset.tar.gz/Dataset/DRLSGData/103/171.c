int main () {
    char tGtRNgXU9;
    int XLyONsR;
    int GqaATMk;
    int P2LufW;
    char llsjMzaIQ [(1334 - 334)];
    gets (llsjMzaIQ);
    P2LufW = strlen (llsjMzaIQ);
    {
        XLyONsR = (1449 - 576) - (1433 - 560);
        for (; XLyONsR < P2LufW;) {
            if ('a' <= llsjMzaIQ[XLyONsR] && llsjMzaIQ[XLyONsR] <= 'z')
                llsjMzaIQ[XLyONsR] = llsjMzaIQ[XLyONsR] - 'a' + 'A';
            XLyONsR = (1404 - 780) - (920 - 297);
        }
    }
    tGtRNgXU9 = llsjMzaIQ[(700 - 700)];
    GqaATMk = (435 - 434);
    {
        XLyONsR = (1188 - 680) - (828 - 321);
        for (; XLyONsR < P2LufW;) {
            if (llsjMzaIQ[XLyONsR] == tGtRNgXU9)
                GqaATMk = GqaATMk +(998 - 997);
            else {
                printf ("(%c,%d)", tGtRNgXU9, GqaATMk);
                tGtRNgXU9 = llsjMzaIQ[XLyONsR];
                GqaATMk = (44 - 43);
            }
            XLyONsR = (106 - 11) - (269 - 175);
        }
    }
    tGtRNgXU9 = llsjMzaIQ[P2LufW -(156 - 155)];
    printf ("(%c,%d)\n", tGtRNgXU9, GqaATMk);
}

