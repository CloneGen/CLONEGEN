main () {
    char dCA0KlUOcm9 [(632 - 399)];
    char n4T5UOXgQl;
    int Sj74xlrMw;
    int Mcu4jEt;
    scanf ("%s", dCA0KlUOcm9);
    {
        Sj74xlrMw = (536 - 536);
        for (; dCA0KlUOcm9[Sj74xlrMw] != '\0';) {
            if ('a' <= dCA0KlUOcm9[Sj74xlrMw] && 'z' >= dCA0KlUOcm9[Sj74xlrMw])
                dCA0KlUOcm9[Sj74xlrMw] = dCA0KlUOcm9[Sj74xlrMw] + 'A' - 'a';
            Sj74xlrMw = Sj74xlrMw +(474 - 473);
        }
    }
    n4T5UOXgQl = dCA0KlUOcm9[(782 - 782)];
    {
        Sj74xlrMw = (67 - 67);
        for (; n4T5UOXgQl != '\0';) {
            {
                Mcu4jEt = (695 - 695);
                for (; !(n4T5UOXgQl != dCA0KlUOcm9[Sj74xlrMw]);) {
                    Sj74xlrMw = Sj74xlrMw +(60 - 59);
                    Mcu4jEt = Mcu4jEt +(555 - 554);
                }
            }
            printf ("(%c,%d)", n4T5UOXgQl, Mcu4jEt +(614 - 613));
            if (!((401 - 401) != Mcu4jEt -Sj74xlrMw))
                Mcu4jEt = Mcu4jEt -(153 - 152);
            n4T5UOXgQl = dCA0KlUOcm9[Sj74xlrMw];
            Sj74xlrMw = Sj74xlrMw +(226 - 225);
        }
    }
}

