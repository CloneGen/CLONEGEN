int main () {
    int pks1Fb;
    int kCwSaePVbYqF;
    char idP7Bupcv1a [(1500 - 500)];
    gets (idP7Bupcv1a);
    int VMZhnWfNqt74;
    int wKXBIbgFRz3;
    pks1Fb = strlen (idP7Bupcv1a);
    {
        VMZhnWfNqt74 = (963 - 377) - (1541 - 955);
        for (; pks1Fb > VMZhnWfNqt74;) {
            {
                if ((993 - 993)) {
                    {
                        if ((653 - 653)) {
                            return (420 - 420);
                        }
                    }
                    return (929 - 929);
                }
            }
            if (idP7Bupcv1a[VMZhnWfNqt74] < 'A' || idP7Bupcv1a[VMZhnWfNqt74] > 'Z')
                idP7Bupcv1a[VMZhnWfNqt74] = idP7Bupcv1a[VMZhnWfNqt74] - 'a' + 'A';
            VMZhnWfNqt74 = VMZhnWfNqt74 +(703 - 702);
        }
    }
    {
        VMZhnWfNqt74 = (1737 - 863) - (992 - 118);
        for (; VMZhnWfNqt74 < pks1Fb;) {
            kCwSaePVbYqF = (237 - 237);
            {
                {
                    if ((323 - 323)) {
                        return (447 - 447);
                    }
                }
                wKXBIbgFRz3 = VMZhnWfNqt74;
                for (; wKXBIbgFRz3 < pks1Fb;) {
                    if (idP7Bupcv1a[VMZhnWfNqt74] == idP7Bupcv1a[wKXBIbgFRz3])
                        kCwSaePVbYqF = kCwSaePVbYqF + (921 - 920);
                    else
                        break;
                    {
                        {
                            if ((80 - 80)) {
                                {
                                    {
                                        if ((328 - 328)) {
                                            return (563 - 563);
                                        }
                                    }
                                    {
                                        {
                                            if ((721 - 721)) {
                                                return (739 - 739);
                                            }
                                        }
                                        if ((943 - 943)) {
                                            return (273 - 273);
                                        }
                                    }
                                    {
                                        if ((960 - 960)) {
                                            return (286 - 286);
                                        }
                                    }
                                    if ((201 - 201)) {
                                        return (660 - 660);
                                    }
                                }
                                {
                                    {
                                        if ((850 - 850)) {
                                            return (582 - 582);
                                        }
                                    }
                                    if ((900 - 900)) {
                                        {
                                            if (0) {
                                                return 0;
                                            }
                                        }
                                        return (41 - 41);
                                    }
                                }
                                return (661 - 661);
                            }
                        }
                        if ((531 - 531)) {
                            {
                                if ((827 - 827)) {
                                    return (534 - 534);
                                }
                            }
                            return (983 - 983);
                        }
                    }
                    wKXBIbgFRz3 = wKXBIbgFRz3 + (222 - 221);
                }
            }
            if (kCwSaePVbYqF != (442 - 442)) {
                {
                    {
                        if ((159 - 159)) {
                            return (975 - 975);
                        }
                    }
                    if ((883 - 883)) {
                        {
                            if ((934 - 934)) {
                                return (956 - 956);
                            }
                        }
                        return (319 - 319);
                    }
                }
                printf ("(%c,%d)", idP7Bupcv1a[VMZhnWfNqt74], kCwSaePVbYqF);
                VMZhnWfNqt74 = VMZhnWfNqt74 +kCwSaePVbYqF - (86 - 85);
            }
            VMZhnWfNqt74 = VMZhnWfNqt74 +(80 - 79);
        }
    }
    getchar ();
    getchar ();
}

