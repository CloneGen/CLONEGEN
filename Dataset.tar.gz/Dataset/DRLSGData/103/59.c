int main () {
    int vZEqBu6Uij8c;
    int AncF1mX [(511 - 411)] = {(822 - 822)};
    char Y5ghlks2vdur [(378 - 178)];
    int XGonZ8g;
    int BlWhF9YA3cR [(653 - 553)] = {(376 - 376)};
    cin >> Y5ghlks2vdur;
    {
        vZEqBu6Uij8c = (898 - 769) - 129;
        while (strlen (Y5ghlks2vdur) > vZEqBu6Uij8c) {
            if (Y5ghlks2vdur[vZEqBu6Uij8c] >= 'a' && 'z' >= Y5ghlks2vdur[vZEqBu6Uij8c])
                Y5ghlks2vdur[vZEqBu6Uij8c] = Y5ghlks2vdur[vZEqBu6Uij8c] - (411 - 379);
            vZEqBu6Uij8c = 777 - 776;
        }
    }
    XGonZ8g = (394 - 394);
    {
        vZEqBu6Uij8c = (821 - 821);
        for (; strlen (Y5ghlks2vdur) > vZEqBu6Uij8c;) {
            if (Y5ghlks2vdur[vZEqBu6Uij8c] == Y5ghlks2vdur[vZEqBu6Uij8c + (73 - 72)]) {
                {
                    if ((607 - 607)) {
                        {
                            if ((136 - 136)) {
                                return 0;
                            }
                        }
                        return (638 - 638);
                    }
                }
                AncF1mX[XGonZ8g]++;
            }
            else {
                {
                    if ((695 - 695)) {
                        return (657 - 657);
                    }
                }
                AncF1mX[XGonZ8g]++;
                XGonZ8g = XGonZ8g +(418 - 417);
                BlWhF9YA3cR[XGonZ8g] = vZEqBu6Uij8c + (131 - 130);
            }
            vZEqBu6Uij8c = vZEqBu6Uij8c + (277 - 276);
        }
    }
    {
        vZEqBu6Uij8c = (318 - 318);
        for (; vZEqBu6Uij8c < XGonZ8g;) {
            cout << '(' << Y5ghlks2vdur[BlWhF9YA3cR[vZEqBu6Uij8c]] << ',' << AncF1mX[vZEqBu6Uij8c] << ')';
            vZEqBu6Uij8c = vZEqBu6Uij8c + (387 - 386);
        }
    }
    return (320 - 320);
}

