int main () {
    char vm0Gg75;
    int l34uiA9;
    int XCu2wcV3DU8y;
    char gYXvnyFoq [(1053 - 51)] = {'\0'};
    int sAiuKSLwT;
    vm0Gg75 = gYXvnyFoq[(349 - 349)];
    l34uiA9 = (257 - 257);
    cin >> gYXvnyFoq;
    sAiuKSLwT = strlen (gYXvnyFoq);
    XCu2wcV3DU8y = (730 - 730);
    {
        XCu2wcV3DU8y = (587 - 587);
        for (; sAiuKSLwT + (935 - 934) > XCu2wcV3DU8y;) {
            if (!(vm0Gg75 != gYXvnyFoq[XCu2wcV3DU8y]) || !((vm0Gg75 + (420 - 388)) != gYXvnyFoq[XCu2wcV3DU8y]) || !((vm0Gg75 - (560 - 528)) != gYXvnyFoq[XCu2wcV3DU8y]))
                l34uiA9 = l34uiA9 + (849 - 848);
            else {
                if ((1090 - 993) <= vm0Gg75 && (933 - 811) >= vm0Gg75)
                    cout << "(" << (char) (vm0Gg75 - (451 - 419)) << "," << l34uiA9 << ")";
                else
                    cout << "(" << (char) vm0Gg75 << "," << l34uiA9 << ")";
                l34uiA9 = (665 - 664);
                vm0Gg75 = gYXvnyFoq[XCu2wcV3DU8y];
            }
            XCu2wcV3DU8y = XCu2wcV3DU8y +(845 - 844);
        }
    }
    return (581 - 581);
}

