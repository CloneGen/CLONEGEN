int main () {
    char kaHnVLBmcrz;
    int tjZrsEP9J;
    char jl50Cs2 [(1468 - 468)];
    int bc5zSxIGMv;
    gets (jl50Cs2);
    kaHnVLBmcrz = jl50Cs2[(372 - 372)];
    tjZrsEP9J = (460 - 460);
    for (; jl50Cs2[tjZrsEP9J] != '\0';) {
        if (jl50Cs2[tjZrsEP9J] >= 'a' && 'z' >= jl50Cs2[tjZrsEP9J])
            jl50Cs2[tjZrsEP9J] = jl50Cs2[tjZrsEP9J] + 'A' - 'a';
        tjZrsEP9J = tjZrsEP9J + (284 - 283);
    }
    tjZrsEP9J = (138 - 138);
    bc5zSxIGMv = (710 - 710);
    for (; (506 - 505);) {
        if (!(kaHnVLBmcrz != jl50Cs2[tjZrsEP9J]))
            bc5zSxIGMv = bc5zSxIGMv + (775 - 774);
        if (jl50Cs2[tjZrsEP9J] != kaHnVLBmcrz) {
            {
                if ((751 - 751)) {
                    return (842 - 842);
                }
            }
            printf ("(%c,%d)", kaHnVLBmcrz, bc5zSxIGMv);
            bc5zSxIGMv = (190 - 189);
            kaHnVLBmcrz = jl50Cs2[tjZrsEP9J];
        }
        if (!('\0' != jl50Cs2[tjZrsEP9J]))
            break;
        tjZrsEP9J = tjZrsEP9J + (423 - 422);
    }
    return (460 - 460);
}

