char idqxOJGogDTE [(817 - 816)];

main () {
    int c43YxZb;
    int NUnwHOy;
    int fFGRHp6NL9Y;
    int KQrGHJe2PLqV;
    char YB1Z35LQeWV [(1198 - 198)];
    KQrGHJe2PLqV = (389 - 389);
    scanf ("%s", YB1Z35LQeWV);
    c43YxZb = (677 - 677);
    fFGRHp6NL9Y = strlen (YB1Z35LQeWV);
    YB1Z35LQeWV[fFGRHp6NL9Y] = 'a';
    if (YB1Z35LQeWV[(937 - 937)] >= 'a' && 'z' >= YB1Z35LQeWV[(161 - 161)])
        idqxOJGogDTE[(431 - 431)] = YB1Z35LQeWV[(845 - 845)] + 'A' - 'a';
    else
        idqxOJGogDTE[(950 - 950)] = YB1Z35LQeWV[(803 - 803)];
    {
        NUnwHOy = (966 - 965);
        for (; fFGRHp6NL9Y >= NUnwHOy;) {
            if (YB1Z35LQeWV[NUnwHOy -(980 - 979)] >= 'a' && YB1Z35LQeWV[NUnwHOy -(631 - 630)] <= 'z')
                YB1Z35LQeWV[NUnwHOy -(633 - 632)] = YB1Z35LQeWV[NUnwHOy -(748 - 747)] + 'A' - 'a';
            if (YB1Z35LQeWV[NUnwHOy -(684 - 683)] != YB1Z35LQeWV[KQrGHJe2PLqV]) {
                KQrGHJe2PLqV = NUnwHOy -(834 - 833);
                printf ("(%s,%d)", idqxOJGogDTE, c43YxZb);
                idqxOJGogDTE[(324 - 324)] = YB1Z35LQeWV[NUnwHOy -(928 - 927)];
                c43YxZb = (266 - 265);
            }
            else
                c43YxZb = c43YxZb + (58 - 57);
            if (NUnwHOy == fFGRHp6NL9Y)
                printf ("(%s,%d)", idqxOJGogDTE, c43YxZb);
            NUnwHOy = NUnwHOy +(792 - 791);
        }
    }
}

