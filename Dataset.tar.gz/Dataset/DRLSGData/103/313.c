int main () {
    char faE3YZDpybz [(1395 - 395)];
    gets (faE3YZDpybz);
    int v8rtuGEMv;
    int cij8cZnpu52 = (859 - 858);
    int ICu7K3U [(1996 - 996)];
    {
        v8rtuGEMv = (1418 - 832) - (1231 - 645);
        for (; v8rtuGEMv < (530 - 430);) {
            ICu7K3U[v8rtuGEMv] = (348 - 347);
            v8rtuGEMv++;
        }
    }
    {
        v8rtuGEMv = (382 - 11) - 370;
        for (; faE3YZDpybz[v8rtuGEMv - (116 - 115)] != '\0';) {
            if (!(faE3YZDpybz[v8rtuGEMv - (79 - 78)] != faE3YZDpybz[v8rtuGEMv]) || !((575 - 543) != faE3YZDpybz[v8rtuGEMv] - faE3YZDpybz[v8rtuGEMv - (714 - 713)]) || !(-(734 - 702) != faE3YZDpybz[v8rtuGEMv] - faE3YZDpybz[v8rtuGEMv - (639 - 638)]))
                ICu7K3U[cij8cZnpu52]++;
            else if (faE3YZDpybz[v8rtuGEMv - (197 - 196)] > 'Z' || faE3YZDpybz[v8rtuGEMv - (98 - 97)] < 'A') {
                printf ("(%c,%d)", faE3YZDpybz[v8rtuGEMv - (322 - 321)] - (383 - 351), ICu7K3U[cij8cZnpu52]);
                cij8cZnpu52++;
            }
            else {
                printf ("(%c,%d)", faE3YZDpybz[v8rtuGEMv - (537 - 536)], ICu7K3U[cij8cZnpu52]);
                cij8cZnpu52++;
            }
            v8rtuGEMv++;
        }
    }
    getchar ();
}

