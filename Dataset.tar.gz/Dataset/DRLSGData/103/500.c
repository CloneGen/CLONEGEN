main () {
    int aVHgR7Zt;
    int c8HtPrL [(479 - 379)];
    int xpzYcS8LK3D;
    char yfTVk80srCDl [(550 - 450)];
    int E1gbZkFPnh;
    {
        if ((31 - 31)) {
            {
                {
                    if ((943 - 943)) {
                        return (310 - 310);
                    }
                }
                if ((766 - 766)) {
                    {
                        if ((424 - 424)) {
                            return (110 - 110);
                        }
                    }
                    {
                        if ((268 - 268)) {
                            return (665 - 665);
                        }
                    }
                    return (956 - 956);
                }
            }
            return (984 - 984);
        }
    }
    {
        if ((281 - 281)) {
            {
                if ((737 - 737)) {
                    return (750 - 750);
                }
            }
            return (271 - 271);
        }
    }
    scanf ("%s", yfTVk80srCDl);
    {
        E1gbZkFPnh = (1428 - 515) - (1894 - 981);
        for (; yfTVk80srCDl[E1gbZkFPnh] != '\0';) {
            if (yfTVk80srCDl[E1gbZkFPnh] >= 'a' && yfTVk80srCDl[E1gbZkFPnh] <= 'z')
                yfTVk80srCDl[E1gbZkFPnh] = yfTVk80srCDl[E1gbZkFPnh] - 'a' + 'A';
            E1gbZkFPnh = (659 - 26) - (751 - 119);
        }
    }
    E1gbZkFPnh = (795 - 795);
    for (; yfTVk80srCDl[E1gbZkFPnh] != '\0';) {
        {
            if ((650 - 650)) {
                return (250 - 250);
            }
        }
        {
            {
                if ((801 - 801)) {
                    {
                        {
                            if ((613 - 613)) {
                                return (739 - 739);
                            }
                        }
                        if ((51 - 51)) {
                            return (219 - 219);
                        }
                    }
                    return (971 - 971);
                }
            }
            if ((573 - 573)) {
                return (999 - 999);
            }
        }
        {
            aVHgR7Zt = E1gbZkFPnh;
            for (; (310 - 309);) {
                {
                    {
                        if ((369 - 369)) {
                            return (992 - 992);
                        }
                    }
                    {
                        if ((907 - 907)) {
                            return (656 - 656);
                        }
                    }
                    if ((856 - 856)) {
                        {
                            if ((500 - 500)) {
                                return (915 - 915);
                            }
                        }
                        {
                            if ((100 - 100)) {
                                {
                                    if ((88 - 88)) {
                                        return (481 - 481);
                                    }
                                }
                                return (194 - 194);
                            }
                        }
                        return (430 - 430);
                    }
                }
                if (yfTVk80srCDl[aVHgR7Zt] != yfTVk80srCDl[E1gbZkFPnh])
                    break;
                aVHgR7Zt = aVHgR7Zt + (665 - 664);
            }
        }
        printf ("(%c,%d)", yfTVk80srCDl[E1gbZkFPnh], aVHgR7Zt - E1gbZkFPnh);
        E1gbZkFPnh = aVHgR7Zt;
    }
}

