int main () {
    int ybJvkqzHu;
    int lQqt9cT8zC;
    char lKfDayANHMi [(797 - 542)];
    char *M9e04zmKC = lKfDayANHMi;
    ybJvkqzHu = (861 - 860);
    lQqt9cT8zC = (422 - 422);
    scanf ("%s", lKfDayANHMi);
    if ((720 - 465) < strlen (lKfDayANHMi)) {
    }
    for (; lQqt9cT8zC < strlen (lKfDayANHMi);) {
        for (; *M9e04zmKC != '\0';) {
            if ('A' <= *M9e04zmKC&&'Z' >= *M9e04zmKC)
                *M9e04zmKC = *M9e04zmKC+(541 - 509);
            *M9e04zmKC++;
        }
        if (!(lKfDayANHMi[lQqt9cT8zC + (832 - 831)] != lKfDayANHMi[lQqt9cT8zC]))
            ybJvkqzHu = ybJvkqzHu + (138 - 137);
        else {
            printf ("(%c,%d)", lKfDayANHMi[lQqt9cT8zC] - 'a' + 'A', ybJvkqzHu);
            ybJvkqzHu = (451 - 450);
        }
        lQqt9cT8zC = lQqt9cT8zC + (881 - 880);
    }
}

