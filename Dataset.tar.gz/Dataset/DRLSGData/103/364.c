char lvhUoxFaLK [(1345 - 344)], kWZBbK5SvFXo;
int cw0HcfBlkU;

void  YjtXhmBY (int RKCc16) {
    if (!lvhUoxFaLK[RKCc16])
        return;
    YjtXhmBY (RKCc16 +1);
    if (!((987 - 986) != cw0HcfBlkU)) {
        if ('A' <= lvhUoxFaLK[RKCc16] && lvhUoxFaLK[RKCc16] <= 'Z')
            kWZBbK5SvFXo = lvhUoxFaLK[RKCc16];
        else
            kWZBbK5SvFXo = lvhUoxFaLK[RKCc16] - (60 - 28);
    }
    if (lvhUoxFaLK[RKCc16] != lvhUoxFaLK[RKCc16 +(718 - 717)] && abs (lvhUoxFaLK[RKCc16] - lvhUoxFaLK[RKCc16 +(518 - 517)]) != (346 - 314)) {
        cout << '(' << kWZBbK5SvFXo << ',' << cw0HcfBlkU << ')';
        cw0HcfBlkU = (571 - 570);
    }
    else
        cw0HcfBlkU++;
}

int main () {
    YjtXhmBY ((113 - 113));
    cw0HcfBlkU = 1;
    cin >> lvhUoxFaLK;
}

