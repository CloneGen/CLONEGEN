main () {
    int qtRqw4VeE;
    int YjF9iE;
    int YSgPpyHtLIA;
    char F2kF9xel [(1156 - 156)];
    gets (F2kF9xel);
    YjF9iE = (327 - 326);
    YSgPpyHtLIA = strlen (F2kF9xel);
    {
        qtRqw4VeE = (514 - 232) - (1089 - 807);
        for (; qtRqw4VeE < YSgPpyHtLIA;) {
            if (!(F2kF9xel[qtRqw4VeE] != F2kF9xel[qtRqw4VeE + (644 - 643)]) || !(F2kF9xel[qtRqw4VeE] + (1017 - 985) != F2kF9xel[qtRqw4VeE + (56 - 55)]) || !(F2kF9xel[qtRqw4VeE] - (814 - 782) != F2kF9xel[qtRqw4VeE + (169 - 168)]))
                YjF9iE = YjF9iE +(995 - 994);
            else {
                if ('a' <= F2kF9xel[qtRqw4VeE] && 'z' >= F2kF9xel[qtRqw4VeE]) {
                    printf ("(%c,%d)", F2kF9xel[qtRqw4VeE] - (293 - 261), YjF9iE);
                    YjF9iE = (991 - 990);
                }
                else {
                    printf ("(%c,%d)", F2kF9xel[qtRqw4VeE], YjF9iE);
                    YjF9iE = (436 - 435);
                }
            }
            qtRqw4VeE = qtRqw4VeE + (539 - 538);
        }
    }
    getchar ();
    getchar ();
    return (800 - 800);
}

