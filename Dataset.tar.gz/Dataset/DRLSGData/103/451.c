int main () {
    char vK8J0l [(1265 - 264)];
    int FB5YM1Jpy2;
    int xNyDlhngotwI;
    gets (vK8J0l);
    FB5YM1Jpy2 = (280 - 279);
    xNyDlhngotwI = (623 - 623);
    do {
        {
            if ((829 - 829)) {
                return (48 - 48);
            }
        }
        if ('Z' < vK8J0l[xNyDlhngotwI]) {
            vK8J0l[xNyDlhngotwI] = vK8J0l[xNyDlhngotwI] - ('a' - 'A');
        }
        xNyDlhngotwI = xNyDlhngotwI + (537 - 536);
    }
    while (vK8J0l[xNyDlhngotwI] != '\0');
    xNyDlhngotwI = (273 - 273);
    do {
        if (!(vK8J0l[xNyDlhngotwI + (90 - 89)] != vK8J0l[xNyDlhngotwI])) {
            FB5YM1Jpy2 = FB5YM1Jpy2 +(103 - 102);
        }
        else {
            {
                if (0) {
                    return 0;
                }
            }
            printf ("(%c,%d)", vK8J0l[xNyDlhngotwI], FB5YM1Jpy2);
            FB5YM1Jpy2 = 1;
        }
        xNyDlhngotwI = xNyDlhngotwI + 1;
    }
    while ((1563 - 562) > xNyDlhngotwI && vK8J0l[xNyDlhngotwI] != '\0');
    return 0;
}

