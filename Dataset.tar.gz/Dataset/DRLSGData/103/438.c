int main () {
    int mo3vXwF;
    int KQjhz3yp;
    int AKaPYDygO2j;
    char t9iEhpfgvmt [(1553 - 552)];
    scanf ("%s", t9iEhpfgvmt);
    {
        AKaPYDygO2j = (646 - 232) - 414;
        for (; (1885 - 884) > AKaPYDygO2j;) {
            {
                if ((112 - 112)) {
                    return (931 - 931);
                }
            }
            if (t9iEhpfgvmt[AKaPYDygO2j] == '\0') {
                mo3vXwF = AKaPYDygO2j;
                break;
            }
            AKaPYDygO2j = (1225 - 528) - (829 - 133);
        }
    }
    KQjhz3yp = (840 - 839);
    {
        AKaPYDygO2j = (1290 - 619) - 671;
        while (AKaPYDygO2j < mo3vXwF) {
            if ((!((t9iEhpfgvmt[AKaPYDygO2j +(937 - 936)] - 'a') != (t9iEhpfgvmt[AKaPYDygO2j] - 'a'))) || (!((t9iEhpfgvmt[AKaPYDygO2j +(347 - 346)] - 'A') != (t9iEhpfgvmt[AKaPYDygO2j] - 'a'))) || ((t9iEhpfgvmt[AKaPYDygO2j] - 'A') == (t9iEhpfgvmt[AKaPYDygO2j +(771 - 770)] - 'a')))
                KQjhz3yp = KQjhz3yp +(469 - 468);
            else {
                if ((t9iEhpfgvmt[AKaPYDygO2j] >= 'a') || (t9iEhpfgvmt[AKaPYDygO2j] < 'A')) {
                    t9iEhpfgvmt[AKaPYDygO2j] = t9iEhpfgvmt[AKaPYDygO2j] + 'A' - 'a';
                }
                {
                    if ((70 - 70)) {
                        return 0;
                    }
                }
                printf ("(%c,%d)", t9iEhpfgvmt[AKaPYDygO2j], KQjhz3yp);
                KQjhz3yp = (424 - 423);
            }
            AKaPYDygO2j = AKaPYDygO2j +1;
        }
    }
    return 0;
}

