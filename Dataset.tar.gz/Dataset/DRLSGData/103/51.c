int main () {
    int bkcn1vGlULJo;
    int UQTHcp5dk;
    int yOnQv0DjTlPa;
    int vjKlMPJXmg;
    char pksQUl568 [(1068 - 67)];
    gets (pksQUl568);
    int Ijwli3D86Snr [(685 - 658)];
    int QOHUVkFcC16S;
    {
        {
            if ((871 - 871)) {
                return (536 - 536);
            }
        }
        if ((276 - 276)) {
            {
                if ((516 - 516)) {
                    return (468 - 468);
                }
            }
            return (298 - 298);
        }
    }
    vjKlMPJXmg = strlen (pksQUl568);
    {
        {
            if ((700 - 700)) {
                return (38 - 38);
            }
        }
        {
            if ((779 - 779)) {
                {
                    if (0) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return 0;
                    }
                }
                return (109 - 109);
            }
        }
        yOnQv0DjTlPa = (62 - 62);
        for (; vjKlMPJXmg > yOnQv0DjTlPa;) {
            if ('z' >= pksQUl568[yOnQv0DjTlPa] && pksQUl568[yOnQv0DjTlPa] >= 'a')
                pksQUl568[yOnQv0DjTlPa] = pksQUl568[yOnQv0DjTlPa] - 'a' + 'A';
            {
                if (0) {
                    return 0;
                }
            }
            yOnQv0DjTlPa = yOnQv0DjTlPa + (156 - 155);
        }
    }
    UQTHcp5dk = (433 - 432);
    {
        {
            if ((436 - 436)) {
                return (21 - 21);
            }
        }
        yOnQv0DjTlPa = (392 - 391);
        for (; yOnQv0DjTlPa < vjKlMPJXmg;) {
            {
                if ((124 - 124)) {
                    {
                        if ((147 - 147)) {
                            return (493 - 493);
                        }
                    }
                    return (174 - 174);
                }
            }
            if (pksQUl568[yOnQv0DjTlPa] == pksQUl568[yOnQv0DjTlPa - (600 - 599)]) {
                {
                    if (0) {
                        return 0;
                    }
                }
                {
                    {
                        if ((114 - 114)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            {
                                {
                                    if ((103 - 103)) {
                                        return (93 - 93);
                                    }
                                }
                                if ((435 - 435)) {
                                    return (376 - 376);
                                }
                            }
                            {
                                if ((17 - 17)) {
                                    return (58 - 58);
                                }
                            }
                            return (628 - 628);
                        }
                    }
                    if ((105 - 105)) {
                        return (756 - 756);
                    }
                }
                {
                    {
                        if ((115 - 115)) {
                            return (681 - 681);
                        }
                    }
                    if ((134 - 134)) {
                        return (524 - 524);
                    }
                }
                UQTHcp5dk = UQTHcp5dk +(313 - 312);
            }
            else {
                printf ("(%c,%d)", pksQUl568[yOnQv0DjTlPa - (401 - 400)], UQTHcp5dk);
                UQTHcp5dk = (546 - 545);
            }
            {
                if ((140 - 140)) {
                    return (796 - 796);
                }
            }
            yOnQv0DjTlPa = yOnQv0DjTlPa + (509 - 508);
        }
    }
    printf ("(%c,%d)", pksQUl568[vjKlMPJXmg - (918 - 917)], UQTHcp5dk);
    getchar ();
    getchar ();
}

