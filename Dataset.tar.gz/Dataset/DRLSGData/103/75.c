main () {
    int jcNz27VJQYAH;
    char aNtnSGz [(1301 - 301)];
    char f8Q67TcHY9xv [(1147 - 147)];
    int kMRWH9 [(1373 - 373)] = {(657 - 656)};
    int QzBdEs0cIG;
    int OKnRuiG2MT;
    {
        if ((319 - 319)) {
            return (104 - 104);
        }
    }
    scanf ("%s", f8Q67TcHY9xv);
    jcNz27VJQYAH = strlen (f8Q67TcHY9xv);
    {
        QzBdEs0cIG = (1017 - 834) - (859 - 676);
        for (; QzBdEs0cIG <= jcNz27VJQYAH - (599 - 598);) {
            if (!('a' != f8Q67TcHY9xv[QzBdEs0cIG]) || !('A' != f8Q67TcHY9xv[QzBdEs0cIG]))
                f8Q67TcHY9xv[QzBdEs0cIG] = 'A';
            if (!('b' != f8Q67TcHY9xv[QzBdEs0cIG]) || !('B' != f8Q67TcHY9xv[QzBdEs0cIG]))
                f8Q67TcHY9xv[QzBdEs0cIG] = 'B';
            if (!('C' != f8Q67TcHY9xv[QzBdEs0cIG]) || !('c' != f8Q67TcHY9xv[QzBdEs0cIG]))
                f8Q67TcHY9xv[QzBdEs0cIG] = 'C';
            if (!('d' != f8Q67TcHY9xv[QzBdEs0cIG]) || !('D' != f8Q67TcHY9xv[QzBdEs0cIG]))
                f8Q67TcHY9xv[QzBdEs0cIG] = 'D';
            QzBdEs0cIG = (1019 - 477) - (1466 - 925);
        }
    }
    OKnRuiG2MT = (12 - 12);
    {
        QzBdEs0cIG = (1425 - 933) - (1292 - 800);
        for (; QzBdEs0cIG <= jcNz27VJQYAH - (381 - 380);) {
            {
                if ((570 - 570)) {
                    {
                        if ((876 - 876)) {
                            return (560 - 560);
                        }
                    }
                    return (592 - 592);
                }
            }
            {
                {
                    if (0) {
                        return 0;
                    }
                }
                {
                    if ((412 - 412)) {
                        return (94 - 94);
                    }
                }
                if ((170 - 170)) {
                    {
                        {
                            if ((515 - 515)) {
                                return (747 - 747);
                            }
                        }
                        if ((735 - 735)) {
                            return (911 - 911);
                        }
                    }
                    return (296 - 296);
                }
            }
            {
                if ((545 - 545)) {
                    return (50 - 50);
                }
            }
            if (!(f8Q67TcHY9xv[QzBdEs0cIG] != f8Q67TcHY9xv[QzBdEs0cIG +(632 - 631)])) {
                kMRWH9[OKnRuiG2MT] = kMRWH9[OKnRuiG2MT] + (929 - 928);
            }
            else {
                {
                    if ((250 - 250)) {
                        return (201 - 201);
                    }
                }
                {
                    if ((23 - 23)) {
                        return (289 - 289);
                    }
                }
                aNtnSGz[OKnRuiG2MT] = f8Q67TcHY9xv[QzBdEs0cIG];
                printf ("(%c,%d)", aNtnSGz[OKnRuiG2MT], kMRWH9[OKnRuiG2MT]);
                OKnRuiG2MT = OKnRuiG2MT +(416 - 415);
                kMRWH9[OKnRuiG2MT] = (28 - 27);
            }
            {
                {
                    if ((313 - 313)) {
                        return (657 - 657);
                    }
                }
                if ((751 - 751)) {
                    return (511 - 511);
                }
            }
            QzBdEs0cIG = (844 - 466) - (554 - 177);
        }
    }
}

