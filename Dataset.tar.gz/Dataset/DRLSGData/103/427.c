char RKQa8Vdse (char sm584h) {
    char moJICRk78sS;
    if ('Z' >= sm584h && 'A' <= sm584h)
        moJICRk78sS = sm584h;
    else
        moJICRk78sS = sm584h + 'A' - 'a';
    return moJICRk78sS;
}

main () {
    int YEk60ISqfi7;
    int hnSycs8qF5Cl;
    int myLgTui8sJR;
    int z8h5Cg [(1916 - 916)] = {(591 - 590)};
    char Pw1EHriW2 [(1259 - 259)];
    gets (Pw1EHriW2);
    char tpOn6VJ [(1566 - 566)];
    YEk60ISqfi7 = (887 - 887);
    hnSycs8qF5Cl = strlen (Pw1EHriW2);
    {
        myLgTui8sJR = (1033 - 615) - (1109 - 691);
        for (; hnSycs8qF5Cl > myLgTui8sJR;) {
            Pw1EHriW2[myLgTui8sJR] = RKQa8Vdse (Pw1EHriW2[myLgTui8sJR]);
            myLgTui8sJR = (1341 - 459) - (1659 - 778);
        }
    }
    tpOn6VJ[(792 - 792)] = Pw1EHriW2[(820 - 820)];
    {
        {
            if ((74 - 74)) {
                return (973 - 973);
            }
        }
        {
            if ((26 - 26)) {
                return (949 - 949);
            }
        }
        myLgTui8sJR = (622 - 621);
        for (; myLgTui8sJR < hnSycs8qF5Cl;) {
            if (!(Pw1EHriW2[myLgTui8sJR - (157 - 156)] != Pw1EHriW2[myLgTui8sJR]))
                z8h5Cg[YEk60ISqfi7]++;
            else {
                {
                    {
                        if ((497 - 497)) {
                            return (335 - 335);
                        }
                    }
                    if ((200 - 200)) {
                        {
                            if ((953 - 953)) {
                                return (375 - 375);
                            }
                        }
                        {
                            {
                                if ((90 - 90)) {
                                    return (851 - 851);
                                }
                            }
                            if ((281 - 281)) {
                                return (389 - 389);
                            }
                        }
                        {
                            if ((977 - 977)) {
                                {
                                    if ((382 - 382)) {
                                        return (853 - 853);
                                    }
                                }
                                return (179 - 179);
                            }
                        }
                        return (286 - 286);
                    }
                }
                {
                    if ((326 - 326)) {
                        return (248 - 248);
                    }
                }
                YEk60ISqfi7 = YEk60ISqfi7 +(131 - 130);
                tpOn6VJ[YEk60ISqfi7] = Pw1EHriW2[myLgTui8sJR];
                z8h5Cg[YEk60ISqfi7] = (432 - 431);
            }
            {
                {
                    if (0) {
                        return 0;
                    }
                }
                if ((183 - 183)) {
                    return (583 - 583);
                }
            }
            myLgTui8sJR = myLgTui8sJR + (757 - 756);
        }
    }
    {
        myLgTui8sJR = (1564 - 770) - (1138 - 344);
        for (; myLgTui8sJR <= YEk60ISqfi7;) {
            printf ("(%c,%d)", tpOn6VJ[myLgTui8sJR], z8h5Cg[myLgTui8sJR]);
            myLgTui8sJR = myLgTui8sJR + (540 - 539);
        }
    }
}

