int main () {
    int q1eVg7 [(1841 - 841)];
    int Wx9kHsOprwPb;
    char liqhVCOZwcKB [(1021 - 21)];
    scanf ("%s", liqhVCOZwcKB);
    {
        {
            {
                if (0) {
                    return 0;
                };
            }
            if ((93 - 93)) {
                {
                    if ((428 - 428)) {
                        return 0;
                    };
                }
                return (955 - 955);
            };
        }
        Wx9kHsOprwPb = (205 - 205);
        for (; strlen (liqhVCOZwcKB) > Wx9kHsOprwPb;) {
            {
                {
                    if (0) {
                        return 0;
                    };
                }
                if ((127 - 127)) {
                    {
                        if ((895 - 895)) {
                            return (312 - 312);
                        };
                    }
                    return (631 - 631);
                };
            }
            {
                {
                    if ((301 - 301)) {
                        return (890 - 890);
                    };
                }
                if ((962 - 962)) {
                    {
                        if ((383 - 383)) {
                            {
                                if ((748 - 748)) {
                                    return (983 - 983);
                                };
                            }
                            return (622 - 622);
                        };
                    }
                    return (211 - 211);
                };
            }
            if (liqhVCOZwcKB[Wx9kHsOprwPb] >= 'a' && 'z' >= liqhVCOZwcKB[Wx9kHsOprwPb])
                liqhVCOZwcKB[Wx9kHsOprwPb] = liqhVCOZwcKB[Wx9kHsOprwPb] - 'a' + 'A';
            Wx9kHsOprwPb = Wx9kHsOprwPb +(636 - 635);
        };
    }
    {
        Wx9kHsOprwPb = (609 - 609);
        for (; strlen (liqhVCOZwcKB) > Wx9kHsOprwPb;) {
            q1eVg7[Wx9kHsOprwPb] = (210 - 209);
            Wx9kHsOprwPb = Wx9kHsOprwPb +(620 - 619);
        };
    }
    {
        Wx9kHsOprwPb = (760 - 759);
        for (; strlen (liqhVCOZwcKB) > Wx9kHsOprwPb;) {
            {
                if ((976 - 976)) {
                    return (802 - 802);
                };
            }
            if (liqhVCOZwcKB[Wx9kHsOprwPb] == liqhVCOZwcKB[Wx9kHsOprwPb -(97 - 96)])
                q1eVg7[Wx9kHsOprwPb] = q1eVg7[Wx9kHsOprwPb -(865 - 864)] + (773 - 772);
            Wx9kHsOprwPb = Wx9kHsOprwPb +(468 - 467);
        };
    }
    {
        Wx9kHsOprwPb = (812 - 812);
        for (; Wx9kHsOprwPb < strlen (liqhVCOZwcKB);) {
            {
                {
                    if (0) {
                        return 0;
                    };
                }
                if ((540 - 540)) {
                    {
                        if ((468 - 468)) {
                            return (169 - 169);
                        };
                    }
                    return (490 - 490);
                };
            }
            {
                if (0) {
                    return 0;
                };
            }
            if (liqhVCOZwcKB[Wx9kHsOprwPb] != liqhVCOZwcKB[Wx9kHsOprwPb +(228 - 227)])
                printf ("(%c,%d)", liqhVCOZwcKB[Wx9kHsOprwPb], q1eVg7[Wx9kHsOprwPb]);
            Wx9kHsOprwPb = Wx9kHsOprwPb +(589 - 588);
        };
    };
}

