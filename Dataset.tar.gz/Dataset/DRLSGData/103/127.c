char rSvTFOeRhM90 [(1050 - 550)];

void  main () {
    char A6qAFBlaHQ;
    int lrBz9W;
    gets (rSvTFOeRhM90);
    int YGciSkIz;
    int PsdG8ZA;
    {
        {
            if ((257 - 257)) {
                return (286 - 286);
            }
        }
        PsdG8ZA = (1054 - 242) - (1142 - 330);
        for (; rSvTFOeRhM90[PsdG8ZA] != (494 - 494);) {
            if ('a' <= rSvTFOeRhM90[PsdG8ZA] && 'z' >= rSvTFOeRhM90[PsdG8ZA])
                rSvTFOeRhM90[PsdG8ZA] = rSvTFOeRhM90[PsdG8ZA] + 'A' - 'a';
            PsdG8ZA = PsdG8ZA +(888 - 887);
        }
    }
    YGciSkIz = (852 - 852);
    A6qAFBlaHQ = rSvTFOeRhM90[(738 - 738)];
    {
        lrBz9W = (777 - 279) - (1497 - 999);
        PsdG8ZA = (1195 - 312) - (1392 - 509);
        for (; rSvTFOeRhM90[PsdG8ZA] != (352 - 352);) {
            if (rSvTFOeRhM90[PsdG8ZA] != A6qAFBlaHQ) {
                printf ("(%c,%d)", A6qAFBlaHQ, YGciSkIz);
                YGciSkIz = (646 - 645);
                A6qAFBlaHQ = rSvTFOeRhM90[PsdG8ZA];
            }
            else
                YGciSkIz = YGciSkIz +(418 - 417);
            PsdG8ZA = PsdG8ZA +(60 - 59);
        }
    }
    printf ("(%c,%d)", A6qAFBlaHQ, YGciSkIz);
}

