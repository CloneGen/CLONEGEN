int main () {
    int i8Qot0nURmC;
    int LSXvkK;
    int Orqy564F;
    int wO0uHQ [(10910 - 910)];
    char UtpYKQ0bAzF [(10167 - 167)];
    char EwC6y1ZV5tgF;
    int P85iOcla4Az;
    int PcpGfsPo2O;
    char WhTfwMlnJq [(10319 - 319)];
    char wUXK5i [(10962 - 962)];
    int RCDOEhLSNTM;
    P85iOcla4Az = (372 - 372);
    scanf ("%s", wUXK5i);
    {
        i8Qot0nURmC = (284 - 284);
        for (; (EwC6y1ZV5tgF = wUXK5i[i8Qot0nURmC]) != '\0';) {
            P85iOcla4Az = P85iOcla4Az +(655 - 654);
            i8Qot0nURmC = i8Qot0nURmC + (115 - 114);
        };
    }
    LSXvkK = (190 - 190);
    Orqy564F = (879 - 878);
    RCDOEhLSNTM = (717 - 717);
    {
        i8Qot0nURmC = (11 - 11);
        for (; (EwC6y1ZV5tgF = wUXK5i[i8Qot0nURmC]) != '\0';) {
            if (!(wUXK5i[i8Qot0nURmC + (346 - 345)] != wUXK5i[i8Qot0nURmC]) || !(wUXK5i[i8Qot0nURmC + (300 - 299)] - (184 - 152) != wUXK5i[i8Qot0nURmC]) || !(wUXK5i[i8Qot0nURmC + (862 - 861)] + (238 - 206) != wUXK5i[i8Qot0nURmC])) {
                Orqy564F = Orqy564F +(902 - 901);
                if (wUXK5i[i8Qot0nURmC] >= (1067 - 970)) {
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC] - (919 - 887);
                }
                else
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC];
                wO0uHQ[LSXvkK] = Orqy564F;
            }
            else if (wUXK5i[i8Qot0nURmC + (372 - 371)] != '\0') {
                if ((977 - 880) <= wUXK5i[i8Qot0nURmC]) {
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC] - (587 - 555);
                }
                else
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC];
                wO0uHQ[LSXvkK] = Orqy564F;
                LSXvkK = LSXvkK +(658 - 657);
                Orqy564F = (518 - 517);
                RCDOEhLSNTM = RCDOEhLSNTM +(74 - 73);
            }
            else {
                RCDOEhLSNTM = RCDOEhLSNTM +(341 - 340);
                if ((161 - 64) <= wUXK5i[i8Qot0nURmC]) {
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC] - (924 - 892);
                }
                else
                    WhTfwMlnJq[LSXvkK] = wUXK5i[i8Qot0nURmC];
                wO0uHQ[LSXvkK] = Orqy564F;
                LSXvkK = LSXvkK +(624 - 623);
            }
            i8Qot0nURmC = i8Qot0nURmC + (390 - 389);
        };
    }
    {
        i8Qot0nURmC = (904 - 904);
        for (; i8Qot0nURmC < RCDOEhLSNTM;) {
            printf ("(%c,%d)", WhTfwMlnJq[i8Qot0nURmC], wO0uHQ[i8Qot0nURmC]);
            i8Qot0nURmC = i8Qot0nURmC + (806 - 805);
        };
    };
}

