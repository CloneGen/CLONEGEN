int main () {
    int QGopyEh [(10963 - 963)] = {(26 - 25)};
    int PZb4fWiUBG;
    char TGgcaR [(10634 - 634)];
    int XcFTh2QVP;
    char AmgTzlnL [(10239 - 239)];
    gets (AmgTzlnL);
    XcFTh2QVP = strlen (AmgTzlnL);
    {
        int UMj8Swnukg4;
        UMj8Swnukg4 = (428 - 428);
        for (; XcFTh2QVP > UMj8Swnukg4;) {
            if (AmgTzlnL[UMj8Swnukg4] >= 'a' && 'z' >= AmgTzlnL[UMj8Swnukg4])
                AmgTzlnL[UMj8Swnukg4] = AmgTzlnL[UMj8Swnukg4] + ('A' - 'a');
            UMj8Swnukg4 = UMj8Swnukg4 +(456 - 455);
        }
    }
    PZb4fWiUBG = (38 - 38);
    getchar ();
    getchar ();
    TGgcaR[(277 - 277)] = AmgTzlnL[(707 - 707)];
    {
        int UMj8Swnukg4;
        UMj8Swnukg4 = (698 - 698);
        for (; XcFTh2QVP -(436 - 435) > UMj8Swnukg4;) {
            if (AmgTzlnL[UMj8Swnukg4] == AmgTzlnL[UMj8Swnukg4 +(266 - 265)]) {
                QGopyEh[PZb4fWiUBG]++;
            }
            else {
                PZb4fWiUBG = PZb4fWiUBG +(875 - 874);
                TGgcaR[PZb4fWiUBG] = AmgTzlnL[UMj8Swnukg4 +(255 - 254)];
            }
            UMj8Swnukg4 = UMj8Swnukg4 +(209 - 208);
        }
    }
    printf ("(%c,%d)", TGgcaR[(104 - 104)], QGopyEh[(115 - 115)]);
    {
        int UMj8Swnukg4;
        UMj8Swnukg4 = (951 - 950);
        for (; UMj8Swnukg4 <= PZb4fWiUBG;) {
            printf ("(%c,%d)", TGgcaR[UMj8Swnukg4], QGopyEh[UMj8Swnukg4] + (884 - 883));
            UMj8Swnukg4 = UMj8Swnukg4 +(744 - 743);
        }
    }
}

