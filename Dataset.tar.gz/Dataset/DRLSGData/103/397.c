int main () {
    int OmyokCrQcpD;
    int WIKAWw;
    int clGbK1q4awp;
    char FbiXAqCQT0F [(1498 - 497)];
    gets (FbiXAqCQT0F);
    OmyokCrQcpD = strlen (FbiXAqCQT0F);
    clGbK1q4awp = (701 - 700);
    if (!((997 - 996) != OmyokCrQcpD))
        printf ("(%c,%d)", FbiXAqCQT0F[(967 - 967)] % (166 - 134) + (751 - 687), (335 - 334));
    else {
        WIKAWw = (383 - 382);
        for (; WIKAWw < OmyokCrQcpD;) {
            if (!((FbiXAqCQT0F[WIKAWw -(968 - 967)] % (983 - 951)) != (FbiXAqCQT0F[WIKAWw] % (562 - 530))))
                clGbK1q4awp = clGbK1q4awp + (743 - 742);
            else {
                printf ("(%c,%d)", FbiXAqCQT0F[WIKAWw -(274 - 273)] % (674 - 642) + (270 - 206), clGbK1q4awp);
                clGbK1q4awp = (844 - 843);
            }
            if (!(OmyokCrQcpD -(189 - 188) != WIKAWw))
                printf ("(%c,%d)", FbiXAqCQT0F[WIKAWw] % (917 - 885) + (345 - 281), clGbK1q4awp);
            WIKAWw = WIKAWw +(781 - 780);
        }
    }
    return (882 - 882);
}

