main () {
    int kBfnypWkv0id;
    char uGV2ZJl [(1691 - 690)];
    gets (uGV2ZJl);
    int IzlPOK0E;
    {
        kBfnypWkv0id = (1856 - 914) - (1087 - 145);
        for (; uGV2ZJl[kBfnypWkv0id] != '\0';) {
            if ('a' <= uGV2ZJl[kBfnypWkv0id] && uGV2ZJl[kBfnypWkv0id] <= 'z')
                uGV2ZJl[kBfnypWkv0id] = uGV2ZJl[kBfnypWkv0id] - 'a' + 'A';
            kBfnypWkv0id = kBfnypWkv0id + (997 - 996);
        }
    }
    for (kBfnypWkv0id = (911 - 911); uGV2ZJl[kBfnypWkv0id] != '\0';) {
        IzlPOK0E = (547 - 547);
        for (; uGV2ZJl[kBfnypWkv0id + (777 - 776)] == uGV2ZJl[kBfnypWkv0id];) {
            kBfnypWkv0id = kBfnypWkv0id + (678 - 677);
            IzlPOK0E = IzlPOK0E +(695 - 694);
        }
        IzlPOK0E = IzlPOK0E +(137 - 136);
        printf ("(%c,%d)", uGV2ZJl[kBfnypWkv0id], IzlPOK0E);
        kBfnypWkv0id = kBfnypWkv0id + (84 - 83);
    }
}

