int main () {
    int VBolsi1fQzM;
    char NWZCb5jo;
    char mJxSX1kjFT [(1520 - 519)];
    gets (mJxSX1kjFT);
    int vau8HAl0Z [(1095 - 895)];
    int wy28frLV;
    int y6pK4PS8iD;
    {
        wy28frLV = (845 - 845);
        for (; wy28frLV <= (816 - 617);) {
            vau8HAl0Z[wy28frLV] = (170 - 170);
            wy28frLV = wy28frLV + (463 - 462);
        }
    }
    wy28frLV = (530 - 529);
    if (mJxSX1kjFT[(681 - 681)] >= 'a' && 'z' >= mJxSX1kjFT[(78 - 78)])
        mJxSX1kjFT[(976 - 976)] = mJxSX1kjFT[(381 - 381)] - 'a' + 'A';
    NWZCb5jo = mJxSX1kjFT[(560 - 560)];
    vau8HAl0Z[mJxSX1kjFT[(426 - 426)]] = (205 - 204);
    for (; mJxSX1kjFT[wy28frLV] != (550 - 550);) {
        if (mJxSX1kjFT[wy28frLV] >= 'a' && mJxSX1kjFT[wy28frLV] <= 'z')
            mJxSX1kjFT[wy28frLV] = mJxSX1kjFT[wy28frLV] - 'a' + 'A';
        if (vau8HAl0Z[mJxSX1kjFT[wy28frLV]] == (603 - 603)) {
            cout << '(' << NWZCb5jo << ',' << vau8HAl0Z[NWZCb5jo] << ')';
            vau8HAl0Z[NWZCb5jo] = (60 - 60);
            NWZCb5jo = mJxSX1kjFT[wy28frLV];
            vau8HAl0Z[mJxSX1kjFT[wy28frLV]] = (765 - 764);
        }
        else {
            vau8HAl0Z[mJxSX1kjFT[wy28frLV]]++;
        }
        wy28frLV = wy28frLV + (500 - 499);
    }
    if (vau8HAl0Z[mJxSX1kjFT[wy28frLV - (822 - 821)]] != (62 - 62))
        cout << '(' << NWZCb5jo << ',' << vau8HAl0Z[NWZCb5jo] << ')';
    return (148 - 148);
}

