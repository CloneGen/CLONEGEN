main () {
    char SR6IsiF4 [(1808 - 807)];
    int hzSVsKOM;
    int Sl8sB0zjrkO;
    int pMBhntc7;
    char IHfIYDV;
    hzSVsKOM = (150 - 149);
    scanf ("%s", SR6IsiF4);
    pMBhntc7 = strlen (SR6IsiF4);
    if ('a' <= SR6IsiF4[(465 - 465)] && 'z' >= SR6IsiF4[(99 - 99)])
        IHfIYDV = 'A' + SR6IsiF4[(270 - 270)] - 'a';
    else
        IHfIYDV = SR6IsiF4[(431 - 431)];
    {
        Sl8sB0zjrkO = (1298 - 856) - (903 - 462);
        for (; pMBhntc7 - (840 - 839) >= Sl8sB0zjrkO;) {
            if (SR6IsiF4[Sl8sB0zjrkO] - IHfIYDV == (916 - 916) || SR6IsiF4[Sl8sB0zjrkO] - IHfIYDV == 'a' - 'A')
                hzSVsKOM = hzSVsKOM + (171 - 170);
            else {
                {
                    if ((995 - 995)) {
                        return (454 - 454);
                    }
                }
                printf ("(%c,%d)", IHfIYDV, hzSVsKOM);
                hzSVsKOM = (161 - 160);
                if (SR6IsiF4[Sl8sB0zjrkO] >= 'a' && SR6IsiF4[Sl8sB0zjrkO] <= 'z')
                    IHfIYDV = 'A' + SR6IsiF4[Sl8sB0zjrkO] - 'a';
                else
                    IHfIYDV = SR6IsiF4[Sl8sB0zjrkO];
            }
            Sl8sB0zjrkO = Sl8sB0zjrkO +(289 - 288);
        }
    }
    printf ("(%c,%d)", IHfIYDV, hzSVsKOM);
}

