main () {
    int F7CMEDhZeX0;
    int cZxj76;
    char hciI1t [(1559 - 559)];
    int DCIDU0KrNVRa;
    DCIDU0KrNVRa = (122 - 121);
    scanf ("%s", hciI1t);
    F7CMEDhZeX0 = strlen (hciI1t);
    {
        int YvPkLER;
        YvPkLER = (886 - 886);
        for (; F7CMEDhZeX0 > YvPkLER;) {
            DCIDU0KrNVRa = (459 - 458);
            {
                cZxj76 = YvPkLER;
                for (; F7CMEDhZeX0 > cZxj76;) {
                    if (!(hciI1t[cZxj76 + (347 - 346)] != hciI1t[cZxj76]) || !(hciI1t[cZxj76 + (87 - 86)] - 'a' + 'A' != hciI1t[cZxj76]) || !(hciI1t[cZxj76] - 'a' + 'A' != hciI1t[cZxj76 + (487 - 486)]))
                        DCIDU0KrNVRa = DCIDU0KrNVRa +(179 - 178);
                    else
                        break;
                    cZxj76 = cZxj76 + (991 - 990);
                }
            }
            if (hciI1t[YvPkLER] >= 'a' && 'z' >= hciI1t[YvPkLER])
                hciI1t[YvPkLER] = hciI1t[YvPkLER] - 'a' + 'A';
            printf ("(%c,%d)", hciI1t[YvPkLER], DCIDU0KrNVRa);
            YvPkLER = YvPkLER +DCIDU0KrNVRa;
        }
    }
}

