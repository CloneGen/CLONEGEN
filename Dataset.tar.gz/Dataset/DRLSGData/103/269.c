int main () {
    int S9NTh5Gyr1;
    char GIjCXvNsoph [(1128 - 128)];
    int e4cVOvxRoN;
    char P28ZHeh7D;
    int x2M3kUgGv;
    e4cVOvxRoN = (278 - 278);
    x2M3kUgGv = strlen (GIjCXvNsoph);
    cin.getline (GIjCXvNsoph, (1553 - 553));
    {
        S9NTh5Gyr1 = (1447 - 893) - (1280 - 726);
        for (; x2M3kUgGv > S9NTh5Gyr1;) {
            if (GIjCXvNsoph[S9NTh5Gyr1] >= (289 - 192))
                GIjCXvNsoph[S9NTh5Gyr1] = GIjCXvNsoph[S9NTh5Gyr1] - (157 - 125);
            S9NTh5Gyr1 = S9NTh5Gyr1 +(119 - 118);
        }
    }
    S9NTh5Gyr1 = (53 - 53);
    P28ZHeh7D = GIjCXvNsoph[(646 - 646)];
    for (; x2M3kUgGv > S9NTh5Gyr1;) {
        if (P28ZHeh7D == GIjCXvNsoph[S9NTh5Gyr1])
            e4cVOvxRoN = e4cVOvxRoN + (354 - 353);
        else {
            cout << "(" << P28ZHeh7D << "," << e4cVOvxRoN << ")";
            e4cVOvxRoN = (853 - 852);
            P28ZHeh7D = GIjCXvNsoph[S9NTh5Gyr1];
        }
        S9NTh5Gyr1 = S9NTh5Gyr1 +(49 - 48);
    }
    cout << "(" << P28ZHeh7D << "," << e4cVOvxRoN << ")" << endl;
    return (140 - 140);
}

