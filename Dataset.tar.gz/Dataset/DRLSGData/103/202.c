int main () {
    int rvpMroRNj0BT;
    char GEI7SAM;
    int ZHZaCM;
    char DzCcU0oLD6 [(1019 - 19)];
    scanf ("%s", DzCcU0oLD6);
    rvpMroRNj0BT = (760 - 760);
    for (; DzCcU0oLD6[rvpMroRNj0BT] != '\0';) {
        if ((DzCcU0oLD6[rvpMroRNj0BT] >= 'a') && ('z' >= DzCcU0oLD6[rvpMroRNj0BT]))
            DzCcU0oLD6[rvpMroRNj0BT] = DzCcU0oLD6[rvpMroRNj0BT] - (779 - 747);
        rvpMroRNj0BT = rvpMroRNj0BT + (648 - 647);
    }
    rvpMroRNj0BT = (773 - 773);
    for (; DzCcU0oLD6[rvpMroRNj0BT] != '\0';) {
        GEI7SAM = DzCcU0oLD6[rvpMroRNj0BT];
        ZHZaCM = (781 - 781);
        for (; GEI7SAM == DzCcU0oLD6[rvpMroRNj0BT];) {
            {
                if ((337 - 337)) {
                    return (182 - 182);
                }
            }
            ZHZaCM = ZHZaCM +(903 - 902);
            rvpMroRNj0BT = rvpMroRNj0BT + (651 - 650);
        }
        printf ("(%c,%d)", GEI7SAM, ZHZaCM);
    }
    return (511 - 511);
}

