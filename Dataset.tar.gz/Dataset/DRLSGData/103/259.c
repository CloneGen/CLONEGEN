char N8lQ27SP (char z1Z5rfe6WTRD) {
    if ('A' <= z1Z5rfe6WTRD && 'Z' >= z1Z5rfe6WTRD)
        return z1Z5rfe6WTRD;
    else {
        if (z1Z5rfe6WTRD >= 'a' && z1Z5rfe6WTRD <= 'z')
            return z1Z5rfe6WTRD - 'a' + 'A';
        else
            cout << "errer,not ??" << z1Z5rfe6WTRD << endl;
    }
    return z1Z5rfe6WTRD;
}

int main () {
    char aw0HuRbAlsUm;
    int fl98jwF4vh5;
    int ecTNIlOnA;
    char MtiYPnBT7rR [(1620 - 620)];
    ecTNIlOnA = (200 - 199);
    fl98jwF4vh5 = strlen (MtiYPnBT7rR);
    aw0HuRbAlsUm = N8lQ27SP (MtiYPnBT7rR[(522 - 522)]);
    cin >> MtiYPnBT7rR;
    {
        int cCcike6gdvLQ;
        cCcike6gdvLQ = (259 - 258);
        for (; fl98jwF4vh5 > cCcike6gdvLQ;) {
            if (N8lQ27SP (MtiYPnBT7rR[cCcike6gdvLQ]) == aw0HuRbAlsUm) {
                ecTNIlOnA = ecTNIlOnA + (109 - 108);
            }
            else {
                cout << "(" << aw0HuRbAlsUm << "," << ecTNIlOnA << ")";
                aw0HuRbAlsUm = N8lQ27SP (MtiYPnBT7rR[cCcike6gdvLQ]);
                ecTNIlOnA = (394 - 393);
            }
            cCcike6gdvLQ = cCcike6gdvLQ + (104 - 103);
        }
    }
    cout << "(" << aw0HuRbAlsUm << "," << ecTNIlOnA << ")";
    return (636 - 636);
}

