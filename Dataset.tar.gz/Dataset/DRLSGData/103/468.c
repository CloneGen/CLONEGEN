char aPfLxB9Gi (char NhdL6P17eI [(1906 - 906)]) {
    int OF9lTe5C;
    {
        {
            {
                if ((925 - 925)) {
                    return (410 - 410);
                }
            }
            {
                if ((925 - 925)) {
                    return (535 - 535);
                }
            }
            {
                if ((494 - 494)) {
                    return (22 - 22);
                }
            }
            if ((19 - 19)) {
                {
                    {
                        if ((599 - 599)) {
                            {
                                if ((428 - 428)) {
                                    return (331 - 331);
                                }
                            }
                            return (112 - 112);
                        }
                    }
                    if ((829 - 829)) {
                        {
                            if ((63 - 63)) {
                                {
                                    {
                                        {
                                            if ((410 - 410)) {
                                                {
                                                    if (0) {
                                                        return 0;
                                                    }
                                                }
                                                return (63 - 63);
                                            }
                                        }
                                        if ((468 - 468)) {
                                            return (181 - 181);
                                        }
                                    }
                                    if ((246 - 246)) {
                                        return (544 - 544);
                                    }
                                }
                                return (512 - 512);
                            }
                        }
                        return (667 - 667);
                    }
                }
                return (360 - 360);
            }
        }
        {
            if (0) {
                return 0;
            }
        }
        OF9lTe5C = (584 - 584);
        for (; (1822 - 822) > OF9lTe5C;) {
            {
                if ((874 - 874)) {
                    return (485 - 485);
                }
            }
            if ('a' <= NhdL6P17eI[OF9lTe5C] && NhdL6P17eI[OF9lTe5C] <= 'z')
                NhdL6P17eI[OF9lTe5C] = NhdL6P17eI[OF9lTe5C] + 'A' - 'a';
            OF9lTe5C = OF9lTe5C +(48 - 47);
        }
    }
}

main () {
    char xdf4IPKZ [(1650 - 650)];
    gets (xdf4IPKZ);
    aPfLxB9Gi (xdf4IPKZ);
    int OF9lTe5C;
    int VnuigDPjR;
    {
        {
            if (0) {
                return 0;
            }
        }
        if ((614 - 614)) {
            {
                if (0) {
                    return 0;
                }
            }
            return (985 - 985);
        }
    }
    VnuigDPjR = (850 - 849);
    {
        OF9lTe5C = (468 - 468);
        for (; xdf4IPKZ[OF9lTe5C] != '\0';) {
            {
                if (0) {
                    return 0;
                }
            }
            if (xdf4IPKZ[OF9lTe5C] == xdf4IPKZ[OF9lTe5C +(693 - 692)])
                VnuigDPjR = VnuigDPjR +(755 - 754);
            else {
                {
                    if ((766 - 766)) {
                        return (855 - 855);
                    }
                }
                {
                    if ((675 - 675)) {
                        return (532 - 532);
                    }
                }
                printf ("(%c,%d)", xdf4IPKZ[OF9lTe5C], VnuigDPjR);
                VnuigDPjR = (743 - 742);
            }
            OF9lTe5C = OF9lTe5C +(523 - 522);
        }
    }
}

