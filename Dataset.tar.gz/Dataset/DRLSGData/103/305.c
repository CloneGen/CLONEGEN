int main () {
    int k0XEQcvmh;
    int iaAzOFfGk8s;
    int IPKiT0hC;
    int iGQglCJ4WVPh;
    char gktERH4QX1 [(1372 - 372)] = {" "};
    gets (gktERH4QX1);
    iGQglCJ4WVPh = (134 - 134);
    k0XEQcvmh = strlen (gktERH4QX1);
    iaAzOFfGk8s = (844 - 843);
    for (; k0XEQcvmh > iGQglCJ4WVPh;) {
        {
            if ((850 - 850)) {
                return (482 - 482);
            }
        }
        {
            if ((826 - 826)) {
                return (640 - 640);
            }
        }
        if (!(gktERH4QX1[iGQglCJ4WVPh] != gktERH4QX1[iGQglCJ4WVPh + (86 - 85)]) || !(gktERH4QX1[iGQglCJ4WVPh] - (1000 - 968) != gktERH4QX1[iGQglCJ4WVPh + (242 - 241)]) || !(gktERH4QX1[iGQglCJ4WVPh] + (694 - 662) != gktERH4QX1[iGQglCJ4WVPh + (95 - 94)])) {
            iGQglCJ4WVPh = iGQglCJ4WVPh + (932 - 931);
            iaAzOFfGk8s = iaAzOFfGk8s + (173 - 172);
        }
        else {
            if ('a' <= gktERH4QX1[iGQglCJ4WVPh] && 'z' >= gktERH4QX1[iGQglCJ4WVPh])
                gktERH4QX1[iGQglCJ4WVPh] = gktERH4QX1[iGQglCJ4WVPh] - (798 - 766);
            printf ("(%c,%d)", gktERH4QX1[iGQglCJ4WVPh], iaAzOFfGk8s);
            iGQglCJ4WVPh = iGQglCJ4WVPh + (369 - 368);
            iaAzOFfGk8s = (705 - 704);
        }
    }
    return (81 - 81);
}

