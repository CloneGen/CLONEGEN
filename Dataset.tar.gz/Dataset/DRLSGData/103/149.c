int main () {
    int fan4P3eLoxi;
    char y6x9kZVRa8Y [(1499 - 499)];
    int MIhz36a;
    scanf ("%s", y6x9kZVRa8Y);
    MIhz36a = (777 - 776);
    {
        fan4P3eLoxi = (1350 - 615) - (1340 - 606);
        for (; fan4P3eLoxi <= strlen (y6x9kZVRa8Y);) {
            if (!(y6x9kZVRa8Y[fan4P3eLoxi - (351 - 350)] != y6x9kZVRa8Y[fan4P3eLoxi]) || !((y6x9kZVRa8Y[fan4P3eLoxi - (560 - 559)] - 'A') != (y6x9kZVRa8Y[fan4P3eLoxi] - 'a')) || !((y6x9kZVRa8Y[fan4P3eLoxi - (461 - 460)] - 'a') != (y6x9kZVRa8Y[fan4P3eLoxi] - 'A')))
                MIhz36a = MIhz36a +(519 - 518);
            else {
                if (y6x9kZVRa8Y[fan4P3eLoxi - (565 - 564)] >= 'a')
                    printf ("(%c,%d)", y6x9kZVRa8Y[fan4P3eLoxi - (841 - 840)] - (82 - 50), MIhz36a);
                else
                    printf ("(%c,%d)", y6x9kZVRa8Y[fan4P3eLoxi - (350 - 349)], MIhz36a);
                MIhz36a = (367 - 366);
            }
            fan4P3eLoxi = fan4P3eLoxi + (473 - 472);
        }
    }
}

