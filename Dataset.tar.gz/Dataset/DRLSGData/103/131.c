int main () {
    char OgRU7pjy [(1015 - 15)];
    int w0XEKTAoFp;
    int WlCK3mt8;
    w0XEKTAoFp = (372 - 371);
    scanf ("%s", OgRU7pjy);
    {
        WlCK3mt8 = (36 - 36);
        for (; OgRU7pjy[WlCK3mt8] != '\0';) {
            if (!(OgRU7pjy[WlCK3mt8 +(954 - 953)] != OgRU7pjy[WlCK3mt8]) || !(OgRU7pjy[WlCK3mt8 +(574 - 573)] - 'a' + 'A' != OgRU7pjy[WlCK3mt8]) || !(OgRU7pjy[WlCK3mt8 +(605 - 604)] - 'A' + 'a' != OgRU7pjy[WlCK3mt8])) {
                if (OgRU7pjy[WlCK3mt8] >= 'A' && 'Z' >= OgRU7pjy[WlCK3mt8]) {
                    if (!(OgRU7pjy[WlCK3mt8 +(149 - 148)] != OgRU7pjy[WlCK3mt8]) || !(OgRU7pjy[WlCK3mt8 +(754 - 753)] - 'a' + 'A' != OgRU7pjy[WlCK3mt8]))
                        w0XEKTAoFp = w0XEKTAoFp + (632 - 631);
                }
                else if (!(OgRU7pjy[WlCK3mt8 +(224 - 223)] != OgRU7pjy[WlCK3mt8]) || !(OgRU7pjy[WlCK3mt8 +(201 - 200)] - 'A' + 'a' != OgRU7pjy[WlCK3mt8]))
                    w0XEKTAoFp = w0XEKTAoFp + (35 - 34);
                else
                    ;
            }
            else {
                if ('A' <= OgRU7pjy[WlCK3mt8] && 'Z' >= OgRU7pjy[WlCK3mt8]) {
                    printf ("(%c,%d)", OgRU7pjy[WlCK3mt8], w0XEKTAoFp);
                    w0XEKTAoFp = (750 - 749);
                }
                if ('a' <= OgRU7pjy[WlCK3mt8] && 'z' >= OgRU7pjy[WlCK3mt8]) {
                    OgRU7pjy[WlCK3mt8] = OgRU7pjy[WlCK3mt8] - 'a' + 'A';
                    printf ("(%c,%d)", OgRU7pjy[WlCK3mt8], w0XEKTAoFp);
                    w0XEKTAoFp = (226 - 225);
                }
            }
            WlCK3mt8 = WlCK3mt8 +(258 - 257);
        }
    }
}

