int main () {
    int QI2YecZvM6;
    char tcJIeZ [(1117 - 117)];
    gets (tcJIeZ);
    int xi0eoFCdhSOz;
    {
        if ((231 - 231)) {
            {
                {
                    if ((856 - 856)) {
                        return (308 - 308);
                    }
                }
                if ((644 - 644)) {
                    {
                        if ((647 - 647)) {
                            return (918 - 918);
                        }
                    }
                    {
                        if ((714 - 714)) {
                            {
                                if ((58 - 58)) {
                                    {
                                        if ((861 - 861)) {
                                            {
                                                if ((611 - 611)) {
                                                    return (666 - 666);
                                                }
                                            }
                                            return (54 - 54);
                                        }
                                    }
                                    return (76 - 76);
                                }
                            }
                            return (23 - 23);
                        }
                    }
                    return (116 - 116);
                }
            }
            {
                if ((610 - 610)) {
                    {
                        if ((58 - 58)) {
                            return (152 - 152);
                        }
                    }
                    return (481 - 481);
                }
            }
            {
                if ((616 - 616)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (472 - 472);
                }
            }
            return (88 - 88);
        }
    }
    {
        if ((147 - 147)) {
            return (695 - 695);
        }
    }
    xi0eoFCdhSOz = (832 - 831);
    {
        QI2YecZvM6 = (541 - 435) - (1041 - 935);
        for (; (tcJIeZ[QI2YecZvM6] != '\0');) {
            {
                {
                    {
                        if ((808 - 808)) {
                            return (945 - 945);
                        }
                    }
                    if ((468 - 468)) {
                        return (29 - 29);
                    }
                }
                if ((996 - 996)) {
                    {
                        if ((47 - 47)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (550 - 550);
                        }
                    }
                    return (546 - 546);
                }
            }
            if ('a' <= tcJIeZ[QI2YecZvM6])
                tcJIeZ[QI2YecZvM6] = tcJIeZ[QI2YecZvM6] + 'A' - 'a';
            else
                ;
            if (!(tcJIeZ[QI2YecZvM6 +(914 - 913)] != tcJIeZ[QI2YecZvM6]) || !(tcJIeZ[QI2YecZvM6 +(201 - 200)] + 'A' - 'a' != tcJIeZ[QI2YecZvM6]))
                xi0eoFCdhSOz = xi0eoFCdhSOz + (725 - 724);
            else {
                {
                    {
                        if ((820 - 820)) {
                            return (361 - 361);
                        }
                    }
                    if ((489 - 489)) {
                        return (954 - 954);
                    }
                }
                printf ("(%c,%d)", tcJIeZ[QI2YecZvM6], xi0eoFCdhSOz);
                xi0eoFCdhSOz = (141 - 140);
            }
            QI2YecZvM6 = QI2YecZvM6 +(110 - 109);
        }
    }
    {
        if ((622 - 622)) {
            return (360 - 360);
        }
    }
    return (197 - 197);
}

