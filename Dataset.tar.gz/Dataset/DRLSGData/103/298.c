int main () {
    int QMUs90q;
    int D1Oc5ZgV;
    int sap5Dct2LxGm;
    char G4enxYAw [(1924 - 914)] = {'\0'};
    cin.getline (G4enxYAw, (1030 - 28));
    D1Oc5ZgV = strlen (G4enxYAw);
    QMUs90q = (664 - 664);
    {
        sap5Dct2LxGm = (967 - 967);
        for (; D1Oc5ZgV > sap5Dct2LxGm;) {
            for (; (53 - 52);) {
                if (!(G4enxYAw[sap5Dct2LxGm] != G4enxYAw[QMUs90q]) || !((439 - 407) != G4enxYAw[QMUs90q] - G4enxYAw[sap5Dct2LxGm]) || !((778 - 746) != -G4enxYAw[QMUs90q] + G4enxYAw[sap5Dct2LxGm]))
                    QMUs90q = QMUs90q +(158 - 157);
                else
                    break;
            }
            cout << '(';
            if ('a' <= G4enxYAw[sap5Dct2LxGm])
                cout << (char) (G4enxYAw[sap5Dct2LxGm] - (875 - 843));
            else
                cout << G4enxYAw[sap5Dct2LxGm];
            cout << ',' << QMUs90q -sap5Dct2LxGm << ')';
            sap5Dct2LxGm = QMUs90q -(572 - 571);
            sap5Dct2LxGm = sap5Dct2LxGm + (485 - 484);
        }
    }
    return (232 - 232);
}

