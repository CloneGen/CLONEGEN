int main () {
    int mWbfqdFHNJxj;
    int r0g4ANDVOE;
    int iTWtVyKiJH;
    char QUQVn6tgJf [(1505 - 504)];
    mWbfqdFHNJxj = strlen (QUQVn6tgJf);
    cin.getline (QUQVn6tgJf, (1317 - 316));
    {
        iTWtVyKiJH = (222 - 222);
        for (; iTWtVyKiJH < mWbfqdFHNJxj;) {
            int qf1pimNg;
            qf1pimNg = (714 - 713);
            if (!(mWbfqdFHNJxj - (916 - 915) != iTWtVyKiJH)) {
                if ((QUQVn6tgJf[iTWtVyKiJH] >= (614 - 517)) && (QUQVn6tgJf[iTWtVyKiJH] <= (274 - 152))) {
                    QUQVn6tgJf[iTWtVyKiJH] = QUQVn6tgJf[iTWtVyKiJH] - (124 - 92);
                }
                cout << '(' << QUQVn6tgJf[iTWtVyKiJH] << ',' << qf1pimNg << ')';
                break;
            }
            {
                r0g4ANDVOE = iTWtVyKiJH + (720 - 719);
                for (; r0g4ANDVOE < mWbfqdFHNJxj;) {
                    if ((!(QUQVn6tgJf[iTWtVyKiJH] != QUQVn6tgJf[r0g4ANDVOE])) || (!(QUQVn6tgJf[iTWtVyKiJH] + (499 - 467) != QUQVn6tgJf[r0g4ANDVOE])) || (!(QUQVn6tgJf[r0g4ANDVOE] - (522 - 490) != QUQVn6tgJf[iTWtVyKiJH]))) {
                        qf1pimNg = qf1pimNg + (909 - 908);
                    }
                    else {
                        break;
                    }
                    r0g4ANDVOE = r0g4ANDVOE + (810 - 809);
                }
            }
            if (((511 - 414) <= QUQVn6tgJf[iTWtVyKiJH]) && (QUQVn6tgJf[iTWtVyKiJH] <= (1043 - 921))) {
                QUQVn6tgJf[iTWtVyKiJH] = QUQVn6tgJf[iTWtVyKiJH] - (777 - 745);
            }
            cout << '(' << QUQVn6tgJf[iTWtVyKiJH] << ',' << qf1pimNg << ')';
            if (r0g4ANDVOE != mWbfqdFHNJxj - (228 - 227)) {
                iTWtVyKiJH = r0g4ANDVOE - (791 - 790);
            }
            iTWtVyKiJH = iTWtVyKiJH + (732 - 731);
        }
    }
    return (505 - 505);
}

