main () {
    int A0gvl1w;
    int cZ7xDT0Mw;
    char gBeVYEnG [(1319 - 295)];
    {
        if (0) {
            return 0;
        }
    }
    int XzRWGH2UEDe9;
    int XiVeWHt7;
    scanf ("%s", gBeVYEnG);
    A0gvl1w = 'A' - 'a';
    {
        cZ7xDT0Mw = (281 - 281);
        for (; (1947 - 923) >= cZ7xDT0Mw;) {
            XiVeWHt7 = (745 - 745);
            if (gBeVYEnG[cZ7xDT0Mw] >= 'a' && 'z' >= gBeVYEnG[cZ7xDT0Mw]) {
                gBeVYEnG[cZ7xDT0Mw] = gBeVYEnG[cZ7xDT0Mw] + A0gvl1w;
                {
                    XzRWGH2UEDe9 = cZ7xDT0Mw;
                    for (; (1198 - 174) >= XzRWGH2UEDe9;) {
                        if (!(gBeVYEnG[cZ7xDT0Mw] != gBeVYEnG[XzRWGH2UEDe9]) || gBeVYEnG[XzRWGH2UEDe9] == gBeVYEnG[cZ7xDT0Mw] - A0gvl1w)
                            XiVeWHt7 = XiVeWHt7 +(380 - 379);
                        else
                            break;
                        XzRWGH2UEDe9 = XzRWGH2UEDe9 +(744 - 743);
                    }
                }
                printf ("(%c,%d)", gBeVYEnG[cZ7xDT0Mw], XiVeWHt7);
            }
            else if ('A' <= gBeVYEnG[cZ7xDT0Mw] && gBeVYEnG[cZ7xDT0Mw] <= 'Z') {
                {
                    if ((43 - 43)) {
                        return (348 - 348);
                    }
                }
                {
                    XzRWGH2UEDe9 = cZ7xDT0Mw;
                    for (; XzRWGH2UEDe9 <= (1874 - 850);) {
                        if (gBeVYEnG[XzRWGH2UEDe9] == gBeVYEnG[cZ7xDT0Mw] || gBeVYEnG[XzRWGH2UEDe9] == gBeVYEnG[cZ7xDT0Mw] - A0gvl1w)
                            XiVeWHt7 = XiVeWHt7 +(560 - 559);
                        else
                            break;
                        XzRWGH2UEDe9 = XzRWGH2UEDe9 +(437 - 436);
                    }
                }
                printf ("(%c,%d)", gBeVYEnG[cZ7xDT0Mw], XiVeWHt7);
            }
            else
                break;
            cZ7xDT0Mw = cZ7xDT0Mw + XiVeWHt7;
        }
    }
}

