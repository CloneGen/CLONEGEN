main () {
    int hyhqCz, sZoxw6k = (508 - 507);
    char YoCvbmSNht [(1471 - 471)];
    scanf ("%s", YoCvbmSNht);
    for (hyhqCz = (661 - 661); YoCvbmSNht[hyhqCz] != '\0'; hyhqCz++)
        if ((1049 - 952) <= YoCvbmSNht[hyhqCz])
            YoCvbmSNht[hyhqCz] = YoCvbmSNht[hyhqCz] - (256 - 224);
    for (hyhqCz = (712 - 712); YoCvbmSNht[hyhqCz] != '\0'; hyhqCz++) {
        if (YoCvbmSNht[hyhqCz + (107 - 106)] == YoCvbmSNht[hyhqCz])
            sZoxw6k++;
        else {
            printf ("(%c,%d)", YoCvbmSNht[hyhqCz], sZoxw6k);
            sZoxw6k = (117 - 116);
        }
    }
}

