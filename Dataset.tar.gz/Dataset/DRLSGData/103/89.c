int main () {
    char I07ISXxfWRN [(1511 - 511)];
    int qg9ZOG;
    int Wv74SUN;
    int wTzNAEx8hkyZ;
    cin >> I07ISXxfWRN;
    wTzNAEx8hkyZ = (320 - 319);
    qg9ZOG = strlen (I07ISXxfWRN);
    {
        {
            if ((535 - 535)) {
                {
                    if ((182 - 182)) {
                        {
                            if ((840 - 840)) {
                                return (836 - 836);
                            };
                        }
                        return (256 - 256);
                    };
                }
                return (430 - 430);
            };
        }
        Wv74SUN = (86 - 86);
        for (; qg9ZOG > Wv74SUN;) {
            {
                if ((375 - 375)) {
                    {
                        {
                            if ((845 - 845)) {
                                return 0;
                            };
                        }
                        if ((689 - 689)) {
                            return (678 - 678);
                        };
                    }
                    return (86 - 86);
                };
            }
            {
                if ((935 - 935)) {
                    return (267 - 267);
                };
            }
            if (('a' <= I07ISXxfWRN[Wv74SUN]) && ('z' >= I07ISXxfWRN[Wv74SUN])) {
                I07ISXxfWRN[Wv74SUN] = 'A' + I07ISXxfWRN[Wv74SUN] - 'a';
            }
            Wv74SUN = Wv74SUN +(113 - 112);
        };
    }
    {
        {
            if (0) {
                return 0;
            };
        }
        Wv74SUN = (503 - 503);
        for (; Wv74SUN < qg9ZOG;) {
            cout << '(' << I07ISXxfWRN[Wv74SUN] << ',';
            wTzNAEx8hkyZ = (294 - 293);
            for (; (706 - 705);) {
                if (I07ISXxfWRN[Wv74SUN] == I07ISXxfWRN[Wv74SUN +(844 - 843)]) {
                    Wv74SUN = Wv74SUN +(571 - 570);
                    wTzNAEx8hkyZ = wTzNAEx8hkyZ + (335 - 334);
                }
                else
                    break;
            }
            cout << wTzNAEx8hkyZ << ')';
            Wv74SUN = Wv74SUN +(75 - 74);
        };
    }
    cout << endl;
    return (165 - 165);
}

