struct   jisuan {
    char qGX9Jzw4iQK;
    int NacXgEIS;
}
HB54sfpyAJ [(1782 - 782)];

int edcJLuU (char vRIMAn) {
    if (vRIMAn >= 'a' && vRIMAn <= 'z')
        return vRIMAn - (1008 - 976);
    else
        return vRIMAn;
}

int main () {
    char siEF8LKnr5q [(1886 - 885)];
    int Y0miXyB7;
    int kpaqvx0or;
    int Qq4ENUpJrs;
    cin >> siEF8LKnr5q;
    Qq4ENUpJrs = strlen (siEF8LKnr5q);
    siEF8LKnr5q[(965 - 965)] = edcJLuU (siEF8LKnr5q[(668 - 668)]);
    HB54sfpyAJ[(461 - 461)].qGX9Jzw4iQK = siEF8LKnr5q[(857 - 857)];
    HB54sfpyAJ[(898 - 898)].NacXgEIS = (777 - 776);
    kpaqvx0or = (40 - 40);
    {
        Y0miXyB7 = (352 - 129) - (787 - 565);
        for (; Qq4ENUpJrs > Y0miXyB7;) {
            siEF8LKnr5q[Y0miXyB7] = edcJLuU (siEF8LKnr5q[Y0miXyB7]);
            if (!(siEF8LKnr5q[Y0miXyB7 -(590 - 589)] != siEF8LKnr5q[Y0miXyB7]))
                HB54sfpyAJ[kpaqvx0or].NacXgEIS++;
            else {
                {
                    if ((598 - 598)) {
                        return (39 - 39);
                    }
                }
                kpaqvx0or = kpaqvx0or + (588 - 587);
                HB54sfpyAJ[kpaqvx0or].qGX9Jzw4iQK = siEF8LKnr5q[Y0miXyB7];
                HB54sfpyAJ[kpaqvx0or].NacXgEIS = (508 - 507);
            }
            Y0miXyB7 = Y0miXyB7 +(440 - 439);
        }
    }
    {
        Y0miXyB7 = (302 - 302);
        for (; kpaqvx0or >= Y0miXyB7;) {
            cout << "(" << HB54sfpyAJ[Y0miXyB7].qGX9Jzw4iQK << "," << HB54sfpyAJ[Y0miXyB7].NacXgEIS << ")";
            Y0miXyB7 = Y0miXyB7 +(345 - 344);
        }
    }
    return (215 - 215);
}

