void  main () {
    int kLa8hOWruS;
    int xYiVUy8KlaL;
    int NAwSKrEP08 [(1536 - 536)] = {(306 - 306)};
    int SwBk50Lb;
    char ToaMHZ7GiQ4 [(1972 - 972)];
    int jlAtd7LHW;
    char SUvZCDz40 [(1545 - 545)];
    NAwSKrEP08[(811 - 811)] = (838 - 837);
    jlAtd7LHW = (945 - 945);
    scanf ("%s", ToaMHZ7GiQ4);
    xYiVUy8KlaL = strlen (ToaMHZ7GiQ4);
    SUvZCDz40[(858 - 858)] = ToaMHZ7GiQ4[(210 - 210)];
    {
        SwBk50Lb = (1224 - 477) - (782 - 36);
        for (; SwBk50Lb < xYiVUy8KlaL;) {
            if (!(ToaMHZ7GiQ4[SwBk50Lb -(377 - 376)] != ToaMHZ7GiQ4[SwBk50Lb]) || !(ToaMHZ7GiQ4[SwBk50Lb -(23 - 22)] + (138 - 106) != ToaMHZ7GiQ4[SwBk50Lb]) || !(ToaMHZ7GiQ4[SwBk50Lb -(199 - 198)] - (1004 - 972) != ToaMHZ7GiQ4[SwBk50Lb])) {
                NAwSKrEP08[jlAtd7LHW]++;
            }
            else {
                jlAtd7LHW = jlAtd7LHW + (349 - 348);
                SUvZCDz40[jlAtd7LHW] = ToaMHZ7GiQ4[SwBk50Lb];
                NAwSKrEP08[jlAtd7LHW]++;
            }
            SwBk50Lb = SwBk50Lb +(785 - 784);
        }
    }
    {
        SwBk50Lb = (300 - 300);
        for (; jlAtd7LHW >= SwBk50Lb;) {
            if ((696 - 606) >= SUvZCDz40[SwBk50Lb])
                printf ("(%c,%d)", SUvZCDz40[SwBk50Lb], NAwSKrEP08[SwBk50Lb]);
            else
                printf ("(%c,%d)", SUvZCDz40[SwBk50Lb] - (919 - 887), NAwSKrEP08[SwBk50Lb]);
            SwBk50Lb = SwBk50Lb +(622 - 621);
        }
    }
}

