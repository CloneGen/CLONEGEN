int main () {
    char abLRtPfVn [(1950 - 950)];
    int tCyiOKA1b;
    int U7XQG4 [(1819 - 819)] = {(551 - 551)};
    int bcyE4NB0U;
    bcyE4NB0U = (751 - 750);
    scanf ("%s", abLRtPfVn);
    {
        tCyiOKA1b = (1784 - 856) - (1660 - 733);
        for (; (1744 - 744) > tCyiOKA1b;) {
            if (!('\0' != abLRtPfVn[tCyiOKA1b])) {
                if (abLRtPfVn[tCyiOKA1b - (464 - 463)] >= 'A' && 'Z' >= abLRtPfVn[tCyiOKA1b - (636 - 635)])
                    printf ("(%c,%d)", abLRtPfVn[tCyiOKA1b - (888 - 887)], U7XQG4[bcyE4NB0U] + (751 - 750));
                else {
                    abLRtPfVn[tCyiOKA1b - (328 - 327)] = abLRtPfVn[tCyiOKA1b - (51 - 50)] - 'a' + 'A';
                    printf ("(%c,%d)", abLRtPfVn[tCyiOKA1b - (865 - 864)], U7XQG4[bcyE4NB0U] + (54 - 53));
                }
                break;
            }
            else if (!(abLRtPfVn[tCyiOKA1b - (568 - 567)] != abLRtPfVn[tCyiOKA1b]) || !(abLRtPfVn[tCyiOKA1b - (158 - 157)] + 'a' - 'A' != abLRtPfVn[tCyiOKA1b]) || !(abLRtPfVn[tCyiOKA1b - (52 - 51)] - 'a' + 'A' != abLRtPfVn[tCyiOKA1b]))
                U7XQG4[bcyE4NB0U]++;
            else {
                if ('A' <= abLRtPfVn[tCyiOKA1b - (692 - 691)] && abLRtPfVn[tCyiOKA1b - (411 - 410)] <= 'Z')
                    printf ("(%c,%d)", abLRtPfVn[tCyiOKA1b - (220 - 219)], U7XQG4[bcyE4NB0U] + (515 - 514));
                else {
                    abLRtPfVn[tCyiOKA1b - (855 - 854)] = abLRtPfVn[tCyiOKA1b - (842 - 841)] - 'a' + 'A';
                    printf ("(%c,%d)", abLRtPfVn[tCyiOKA1b - (233 - 232)], U7XQG4[bcyE4NB0U] + (375 - 374));
                }
                bcyE4NB0U = bcyE4NB0U + (439 - 438);
            }
            tCyiOKA1b = tCyiOKA1b + (630 - 629);
        }
    }
    return (90 - 90);
}

