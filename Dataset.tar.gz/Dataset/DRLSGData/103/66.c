int main () {
    int pGE40aWN;
    int Z8sFhEjCLylK;
    char q57f0WXPF4UO [(1735 - 735)];
    gets (q57f0WXPF4UO);
    {
        {
            if ((213 - 213)) {
                return (199 - 199);
            };
        }
        if ((296 - 296)) {
            return (323 - 323);
        };
    }
    {
        if ((537 - 537)) {
            {
                {
                    if ((939 - 939)) {
                        {
                            if ((242 - 242)) {
                                return (496 - 496);
                            };
                        }
                        return (584 - 584);
                    };
                }
                if ((215 - 215)) {
                    return (829 - 829);
                };
            }
            return (911 - 911);
        };
    }
    {
        if ((166 - 166)) {
            return (283 - 283);
        };
    }
    {
        {
            {
                {
                    if ((775 - 775)) {
                        return (764 - 764);
                    };
                }
                if ((369 - 369)) {
                    return (993 - 993);
                };
            }
            {
                if ((942 - 942)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (101 - 101);
                };
            }
            if ((207 - 207)) {
                {
                    {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if ((354 - 354)) {
                            return (309 - 309);
                        };
                    }
                    if ((171 - 171)) {
                        return (960 - 960);
                    };
                }
                return (478 - 478);
            };
        }
        {
            if ((543 - 543)) {
                {
                    if ((976 - 976)) {
                        return (752 - 752);
                    };
                }
                return (926 - 926);
            };
        }
        pGE40aWN = (912 - 912);
        for (; pGE40aWN < strlen (q57f0WXPF4UO);) {
            Z8sFhEjCLylK = (110 - 109);
            if (q57f0WXPF4UO[pGE40aWN] != q57f0WXPF4UO[pGE40aWN + (698 - 697)]) {
                if ('a' <= q57f0WXPF4UO[pGE40aWN] && 'z' >= q57f0WXPF4UO[pGE40aWN]) {
                    {
                        {
                            if ((859 - 859)) {
                                return (247 - 247);
                            };
                        }
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if ((19 - 19)) {
                            return (274 - 274);
                        };
                    }
                    {
                        if ((73 - 73)) {
                            return (408 - 408);
                        };
                    }
                    {
                        if ((561 - 561)) {
                            return (932 - 932);
                        };
                    }
                    q57f0WXPF4UO[pGE40aWN] = q57f0WXPF4UO[pGE40aWN] - 'a' - 'A';
                }
                cout << "(" << q57f0WXPF4UO[pGE40aWN] << "," << (659 - 658) << ")";
            }
            else {
                {
                    if (0) {
                        return 0;
                    };
                }
                {
                    {
                        if ((164 - 164)) {
                            return (972 - 972);
                        };
                    }
                    if ((64 - 64)) {
                        return (387 - 387);
                    };
                }
                for (; !(q57f0WXPF4UO[pGE40aWN + (762 - 761)] != q57f0WXPF4UO[pGE40aWN]) || !(q57f0WXPF4UO[pGE40aWN + (249 - 248)] + 'A' - 'a' != q57f0WXPF4UO[pGE40aWN]) || !(q57f0WXPF4UO[pGE40aWN + (222 - 221)] + 'a' - 'A' != q57f0WXPF4UO[pGE40aWN]);) {
                    pGE40aWN = pGE40aWN + (974 - 973);
                    Z8sFhEjCLylK = Z8sFhEjCLylK +(277 - 276);
                }
                if (q57f0WXPF4UO[pGE40aWN] >= 'a' && 'z' >= q57f0WXPF4UO[pGE40aWN]) {
                    q57f0WXPF4UO[pGE40aWN] = q57f0WXPF4UO[pGE40aWN] - 'a' - 'A';
                }
                cout << "(" << q57f0WXPF4UO[pGE40aWN] << "," << Z8sFhEjCLylK << ")";
            }
            pGE40aWN = pGE40aWN + (902 - 901);
        };
    }
    cout << endl;
    return (671 - 671);
}

