int main () {
    int RwXufj;
    char Pf1WQ2x7U43e [(310 - 210)];
    int mFdSin;
    int bwo5HP;
    int QGCZ1l;
    bwo5HP = (951 - 951);
    scanf ("%s", &Pf1WQ2x7U43e);
    for (; Pf1WQ2x7U43e[bwo5HP] != '\0';) {
        if ('a' <= Pf1WQ2x7U43e[bwo5HP] && 'z' >= Pf1WQ2x7U43e[bwo5HP])
            Pf1WQ2x7U43e[bwo5HP] = Pf1WQ2x7U43e[bwo5HP] - (935 - 903);
        bwo5HP = bwo5HP + (813 - 812);
    }
    QGCZ1l = (762 - 761);
    {
        RwXufj = (32 - 32);
        for (; Pf1WQ2x7U43e[RwXufj] != '\0';) {
            if (Pf1WQ2x7U43e[RwXufj] == Pf1WQ2x7U43e[RwXufj +(715 - 714)])
                QGCZ1l = QGCZ1l +(956 - 955);
            else {
                printf ("(%c,%d)", Pf1WQ2x7U43e[RwXufj], QGCZ1l);
                QGCZ1l = (737 - 736);
                continue;
            }
            RwXufj = RwXufj +(353 - 352);
        }
    }
}

