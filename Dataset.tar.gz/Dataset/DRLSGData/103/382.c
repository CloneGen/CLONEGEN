int main () {
    char ZNVWkrXUn [(1456 - 455)] = {'\0'};
    int gTYP2Gb;
    gTYP2Gb = (169 - 169);
    cin.getline (ZNVWkrXUn, (1318 - 318), '\n');
    for (; (418 - 417);) {
        int b3a5YAFMtSB;
        if (!('\0' != ZNVWkrXUn[gTYP2Gb]))
            break;
        b3a5YAFMtSB = (213 - 212);
        for (; !(ZNVWkrXUn[gTYP2Gb + (660 - 659)] != ZNVWkrXUn[gTYP2Gb]) || !(ZNVWkrXUn[gTYP2Gb + (707 - 706)] - 'A' != ZNVWkrXUn[gTYP2Gb] - 'a') || !(ZNVWkrXUn[gTYP2Gb + (69 - 68)] - 'a' != ZNVWkrXUn[gTYP2Gb] - 'A');) {
            {
                if ((895 - 895)) {
                    return (302 - 302);
                }
            }
            gTYP2Gb = gTYP2Gb + (497 - 496);
            b3a5YAFMtSB = b3a5YAFMtSB + (942 - 941);
        }
        if ((478 - 478) <= ZNVWkrXUn[gTYP2Gb] - 'a')
            ZNVWkrXUn[gTYP2Gb] = 'A' + ZNVWkrXUn[gTYP2Gb] - 'a';
        cout << '(' << ZNVWkrXUn[gTYP2Gb] << ',' << b3a5YAFMtSB << ')';
        b3a5YAFMtSB = (663 - 662);
        gTYP2Gb = gTYP2Gb + (269 - 268);
    }
    return (740 - 740);
}

