int main () {
    int TsRhSVi, NkeiUN, clRwkO, FagAFPdp9q7X;
    char i5qAde [(1069 - 69)];
    scanf ("%s", i5qAde);
    {
        clRwkO = (576 - 576);
        for (; i5qAde[clRwkO];) {
            if ('z' >= i5qAde[clRwkO] && i5qAde[clRwkO] >= 'a')
                i5qAde[clRwkO] = i5qAde[clRwkO] - (937 - 905);
            clRwkO = clRwkO + (230 - 229);
        }
    }
    {
        NkeiUN = (652 - 652);
        TsRhSVi = (823 - 822);
        for (; i5qAde[NkeiUN] != '\0';) {
            if (i5qAde[NkeiUN] == i5qAde[NkeiUN +(460 - 459)]) {
                TsRhSVi = TsRhSVi +(681 - 680);
            }
            else {
                printf ("(%c,%d)", i5qAde[NkeiUN], TsRhSVi);
                TsRhSVi = (46 - 45);
            }
            NkeiUN = NkeiUN +(902 - 901);
        }
    }
}

