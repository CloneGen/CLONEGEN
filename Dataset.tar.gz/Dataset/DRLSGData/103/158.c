int main () {
    int Oe7TBnwLt;
    char eyWibakUoKw;
    int yz1u0nbgwksi;
    int Y1U3X5;
    int Ej0qALzZ3UC;
    char TqTRLt7rWMsK [(1122 - 122)];
    gets (TqTRLt7rWMsK);
    Y1U3X5 = strlen (TqTRLt7rWMsK);
    {
        Oe7TBnwLt = (467 - 467);
        for (; Y1U3X5 > Oe7TBnwLt;) {
            if ('a' <= TqTRLt7rWMsK[Oe7TBnwLt] && 'z' >= TqTRLt7rWMsK[Oe7TBnwLt])
                TqTRLt7rWMsK[Oe7TBnwLt] = TqTRLt7rWMsK[Oe7TBnwLt] + 'A' - 'a';
            Oe7TBnwLt = Oe7TBnwLt +(746 - 745);
        }
    }
    {
        Oe7TBnwLt = (906 - 906);
        for (; Oe7TBnwLt < Y1U3X5;) {
            Ej0qALzZ3UC = (686 - 685);
            eyWibakUoKw = TqTRLt7rWMsK[Oe7TBnwLt];
        loop :
            if (TqTRLt7rWMsK[Oe7TBnwLt] == TqTRLt7rWMsK[Oe7TBnwLt +(700 - 699)]) {
                goto loop;
                Ej0qALzZ3UC = Ej0qALzZ3UC +(535 - 534);
                Oe7TBnwLt = Oe7TBnwLt +(681 - 680);
            }
            else
                printf ("(%c,%d)", eyWibakUoKw, Ej0qALzZ3UC);
            Oe7TBnwLt = (1030 - 352) - (1040 - 363);
        }
    }
    getchar ();
    getchar ();
}

