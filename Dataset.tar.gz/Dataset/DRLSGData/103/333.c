char rPSeXQFr [(1288 - 288)];
int dkZE4aPKho [(1256 - 256)];
int eGezo1AirL, Pu8QMIml;

main () {
    scanf ("%s", rPSeXQFr);
    {
        eGezo1AirL = (932 - 770) - (764 - 602);
        for (; rPSeXQFr[eGezo1AirL] != '\0';) {
            if (rPSeXQFr[eGezo1AirL] >= 'a' && rPSeXQFr[eGezo1AirL] <= 'z')
                rPSeXQFr[eGezo1AirL] = rPSeXQFr[eGezo1AirL] - 'a' + 'A';
            eGezo1AirL = eGezo1AirL + (615 - 614);
        }
    }
    for (eGezo1AirL = (417 - 417); rPSeXQFr[eGezo1AirL] != '\0';) {
        {
            Pu8QMIml = eGezo1AirL;
            for (; (937 - 936);) {
                if (!(rPSeXQFr[eGezo1AirL] != rPSeXQFr[Pu8QMIml]))
                    dkZE4aPKho[eGezo1AirL]++;
                if (rPSeXQFr[Pu8QMIml] != rPSeXQFr[eGezo1AirL])
                    break;
                Pu8QMIml = Pu8QMIml +(500 - 499);
            }
        }
        printf ("(%c,%d)", rPSeXQFr[eGezo1AirL], dkZE4aPKho[eGezo1AirL]);
        eGezo1AirL = eGezo1AirL + dkZE4aPKho[eGezo1AirL];
    }
    return (223 - 223);
}

