int main () {
    int nyH80Jd;
    int Q7Ubqx8sSd;
    char t0VrCKzyio [(1974 - 974)] = {'\0'};
    nyH80Jd = (623 - 623);
    cin >> t0VrCKzyio;
    for (; t0VrCKzyio[nyH80Jd] != '\0';) {
        {
            {
                if ((248 - 248)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (736 - 736);
                }
            }
            if ((212 - 212)) {
                {
                    if ((339 - 339)) {
                        return (708 - 708);
                    }
                }
                return (450 - 450);
            }
        }
        {
            if ((902 - 902)) {
                {
                    if ((286 - 286)) {
                        return (156 - 156);
                    }
                }
                {
                    if ((836 - 836)) {
                        {
                            if ((763 - 763)) {
                                {
                                    if (0) {
                                        return 0;
                                    }
                                }
                                return (97 - 97);
                            }
                        }
                        return (799 - 799);
                    }
                }
                return (82 - 82);
            }
        }
        if (t0VrCKzyio[nyH80Jd] >= 'a' && 'z' >= t0VrCKzyio[nyH80Jd])
            t0VrCKzyio[nyH80Jd] = t0VrCKzyio[nyH80Jd] - (961 - 929);
        nyH80Jd = nyH80Jd + (942 - 941);
    }
    {
        if ((639 - 639)) {
            return (777 - 777);
        }
    }
    nyH80Jd = (128 - 127);
    Q7Ubqx8sSd = (624 - 623);
    for (; t0VrCKzyio[nyH80Jd] != '\0';) {
        if (t0VrCKzyio[nyH80Jd] == t0VrCKzyio[nyH80Jd - (995 - 994)])
            Q7Ubqx8sSd = Q7Ubqx8sSd +(71 - 70);
        else {
            {
                if ((271 - 271)) {
                    return (641 - 641);
                }
            }
            cout << '(' << t0VrCKzyio[nyH80Jd - (191 - 190)] << ',' << Q7Ubqx8sSd << ')';
            Q7Ubqx8sSd = (109 - 108);
        }
        {
            if ((232 - 232)) {
                {
                    if ((728 - 728)) {
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((212 - 212)) {
                                return (678 - 678);
                            }
                        }
                        return (151 - 151);
                    }
                }
                {
                    if ((868 - 868)) {
                        {
                            if ((536 - 536)) {
                                {
                                    if ((848 - 848)) {
                                        return (555 - 555);
                                    }
                                }
                                return (69 - 69);
                            }
                        }
                        return (148 - 148);
                    }
                }
                return (717 - 717);
            }
        }
        nyH80Jd = nyH80Jd + (149 - 148);
    }
    cout << '(' << t0VrCKzyio[nyH80Jd - (465 - 464)] << ',' << Q7Ubqx8sSd << ')';
    return (470 - 470);
}

