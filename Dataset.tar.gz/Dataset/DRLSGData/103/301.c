main () {
    int lYJcv38UlIs4;
    int HwIYHvVGdp;
    char SVKHxRtd3gNr;
    int KDCreP1gEZ;
    char u7mjCD [(1196 - 196)];
    scanf ("%s", u7mjCD);
    {
        lYJcv38UlIs4 = (214 - 214);
        KDCreP1gEZ = (150 - 150);
        for (; u7mjCD[KDCreP1gEZ] != '\0';) {
            if ('a' <= u7mjCD[KDCreP1gEZ] && 'z' >= u7mjCD[KDCreP1gEZ])
                u7mjCD[KDCreP1gEZ] = u7mjCD[KDCreP1gEZ] + 'A' - 'a';
            KDCreP1gEZ = KDCreP1gEZ +(20 - 19);
            lYJcv38UlIs4 = lYJcv38UlIs4 + (956 - 955);
        }
    }
    if (!((25 - 24) != lYJcv38UlIs4)) {
        HwIYHvVGdp = (866 - 865);
        printf ("(%c,%d)", u7mjCD[(180 - 180)], HwIYHvVGdp);
    }
    else {
        HwIYHvVGdp = (932 - 931);
        KDCreP1gEZ = (646 - 646);
        for (; lYJcv38UlIs4 > KDCreP1gEZ;) {
            if (u7mjCD[KDCreP1gEZ +(567 - 566)] == u7mjCD[KDCreP1gEZ])
                HwIYHvVGdp = HwIYHvVGdp +(95 - 94);
            else {
                printf ("(%c,%d)", u7mjCD[KDCreP1gEZ], HwIYHvVGdp);
                HwIYHvVGdp = (27 - 26);
            }
            KDCreP1gEZ = KDCreP1gEZ +(450 - 449);
        }
    }
}

