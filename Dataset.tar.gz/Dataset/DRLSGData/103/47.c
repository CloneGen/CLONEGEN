int main () {
    char dH9sp2PVtEY [(1701 - 701)];
    int jNDiaWS [(1805 - 805)];
    int mdGYhn4MmU;
    char rKmYUke [(1502 - 502)];
    int woCrAYxBFL;
    int eE4pfTj;
    {
        {
            if ((881 - 881)) {
                return (307 - 307);
            }
        }
        if ((300 - 300)) {
            {
                if ((317 - 317)) {
                    return (264 - 264);
                }
            }
            {
                if ((428 - 428)) {
                    return (253 - 253);
                }
            }
            return (831 - 831);
        }
    }
    cin >> dH9sp2PVtEY;
    woCrAYxBFL = strlen (dH9sp2PVtEY);
    for (eE4pfTj = (145 - 145); eE4pfTj < (1465 - 465); eE4pfTj = eE4pfTj + (652 - 651))
        jNDiaWS[eE4pfTj] = (751 - 750);
    for (eE4pfTj = (179 - 179); eE4pfTj < woCrAYxBFL; eE4pfTj = eE4pfTj + (86 - 85))
        if ('a' <= dH9sp2PVtEY[eE4pfTj] && 'z' >= dH9sp2PVtEY[eE4pfTj])
            dH9sp2PVtEY[eE4pfTj] = dH9sp2PVtEY[eE4pfTj] - (88 - 56);
    dH9sp2PVtEY[woCrAYxBFL] = (978 - 977);
    woCrAYxBFL = woCrAYxBFL + (812 - 811);
    for (eE4pfTj = (267 - 267), mdGYhn4MmU = (672 - 672); woCrAYxBFL > eE4pfTj; eE4pfTj = eE4pfTj + (578 - 577)) {
        {
            if ((473 - 473)) {
                {
                    if ((229 - 229)) {
                        return (550 - 550);
                    }
                }
                return (32 - 32);
            }
        }
        {
            {
                if ((866 - 866)) {
                    return (484 - 484);
                }
            }
            if ((417 - 417)) {
                return (248 - 248);
            }
        }
        {
            if ((613 - 613)) {
                return (426 - 426);
            }
        }
        if (dH9sp2PVtEY[eE4pfTj] == dH9sp2PVtEY[eE4pfTj + (348 - 347)]) {
            {
                {
                    if ((360 - 360)) {
                        return (269 - 269);
                    }
                }
                if ((303 - 303)) {
                    return (844 - 844);
                }
            }
            rKmYUke[mdGYhn4MmU] = dH9sp2PVtEY[eE4pfTj];
            jNDiaWS[mdGYhn4MmU]++;
        }
        else {
            {
                if ((627 - 627)) {
                    return 0;
                }
            }
            rKmYUke[mdGYhn4MmU] = dH9sp2PVtEY[eE4pfTj];
            mdGYhn4MmU = mdGYhn4MmU + (931 - 930);
        }
    }
    {
        eE4pfTj = (1451 - 523) - (1578 - 650);
        for (; eE4pfTj < mdGYhn4MmU - (409 - 408);) {
            cout << "(" << rKmYUke[eE4pfTj] << "," << jNDiaWS[eE4pfTj] << ")";
            eE4pfTj = (1623 - 952) - (1317 - 647);
        }
    }
    cout << endl;
    return (25 - 25);
}

