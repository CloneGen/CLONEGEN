int main () {
    int YWv0NZif5z;
    int f5Co2DPvJ;
    char GWDi36oy;
    int GIxNpWm;
    int EebuFMNj7qTB;
    char FFcl2jmkg [(1103 - 103)] = {'\0'};
    GIxNpWm = (378 - 378);
    EebuFMNj7qTB = (954 - 954);
    YWv0NZif5z = (702 - 702);
    cin.getline (FFcl2jmkg, (1097 - 97));
    {
        f5Co2DPvJ = (1079 - 336) - (1469 - 726);
        for (; f5Co2DPvJ < (1636 - 636);) {
            if (FFcl2jmkg[f5Co2DPvJ] != '\0')
                YWv0NZif5z = YWv0NZif5z +(625 - 624);
            f5Co2DPvJ = f5Co2DPvJ + (527 - 526);
        }
    }
    if (!((646 - 645) != YWv0NZif5z)) {
        if ((FFcl2jmkg[(733 - 733)] >= 'A') && (FFcl2jmkg[(930 - 930)] <= 'Z'))
            EebuFMNj7qTB = FFcl2jmkg[(631 - 631)] - 'A';
        else
            EebuFMNj7qTB = FFcl2jmkg[(632 - 632)] - 'a';
        GWDi36oy = 'A' + EebuFMNj7qTB;
        cout << "(" << GWDi36oy << "," << "1" << ")";
    }
    else {
        {
            f5Co2DPvJ = (630 - 630);
            for (; f5Co2DPvJ < YWv0NZif5z -(431 - 429);) {
                if ((!(FFcl2jmkg[f5Co2DPvJ + (418 - 417)] != FFcl2jmkg[f5Co2DPvJ])) || (!((54 - 22) != FFcl2jmkg[f5Co2DPvJ + (856 - 855)] - FFcl2jmkg[f5Co2DPvJ])) || (!((69 - 37) != FFcl2jmkg[f5Co2DPvJ] - FFcl2jmkg[f5Co2DPvJ + (632 - 631)])))
                    GIxNpWm = GIxNpWm +(194 - 193);
                else {
                    GIxNpWm = GIxNpWm +(421 - 420);
                    if ((FFcl2jmkg[f5Co2DPvJ] >= 'A') && (FFcl2jmkg[f5Co2DPvJ] <= 'Z'))
                        EebuFMNj7qTB = FFcl2jmkg[f5Co2DPvJ] - 'A';
                    else
                        EebuFMNj7qTB = FFcl2jmkg[f5Co2DPvJ] - 'a';
                    GWDi36oy = 'A' + EebuFMNj7qTB;
                    cout << "(" << GWDi36oy << "," << GIxNpWm << ")";
                    GWDi36oy = '\0';
                    GIxNpWm = (270 - 270);
                    EebuFMNj7qTB = (596 - 596);
                }
                f5Co2DPvJ = f5Co2DPvJ + (689 - 688);
            }
        }
        if ((!(FFcl2jmkg[YWv0NZif5z -(755 - 754)] != FFcl2jmkg[YWv0NZif5z -(529 - 527)])) || (!((267 - 235) != FFcl2jmkg[YWv0NZif5z -(587 - 585)] - FFcl2jmkg[YWv0NZif5z -(566 - 565)])) || (!((841 - 809) != FFcl2jmkg[YWv0NZif5z -(468 - 467)] - FFcl2jmkg[YWv0NZif5z -(351 - 349)]))) {
            GIxNpWm = GIxNpWm +(247 - 245);
            if (('A' <= FFcl2jmkg[YWv0NZif5z -(383 - 382)]) && ('Z' >= FFcl2jmkg[YWv0NZif5z -(481 - 480)]))
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(122 - 121)] - 'A';
            else
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(233 - 232)] - 'a';
            GWDi36oy = 'A' + EebuFMNj7qTB;
            cout << "(" << GWDi36oy << "," << GIxNpWm << ")";
        }
        else {
            if ((FFcl2jmkg[YWv0NZif5z -(915 - 913)] >= 'A') && (FFcl2jmkg[YWv0NZif5z -(500 - 498)] <= 'Z'))
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(941 - 939)] - 'A';
            else
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(598 - 596)] - 'a';
            GWDi36oy = 'A' + EebuFMNj7qTB;
            if ((FFcl2jmkg[YWv0NZif5z -(308 - 307)] >= 'A') && (FFcl2jmkg[YWv0NZif5z -(723 - 722)] <= 'Z'))
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(66 - 65)] - 'A';
            else
                EebuFMNj7qTB = FFcl2jmkg[YWv0NZif5z -(56 - 55)] - 'a';
            GIxNpWm = GIxNpWm +(260 - 259);
            cout << "(" << GWDi36oy << "," << GIxNpWm << ")";
            GWDi36oy = 'A' + EebuFMNj7qTB;
            cout << "(" << GWDi36oy << "," << "1" << ")";
        }
    }
    return (505 - 505);
}

