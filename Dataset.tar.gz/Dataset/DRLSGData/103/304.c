int main () {
    int RW4ote;
    char v5q0ztKLDE1 [(1849 - 848)];
    int cWSVsuIi;
    int FhtHVdw;
    cin >> v5q0ztKLDE1;
    RW4ote = strlen (v5q0ztKLDE1);
    FhtHVdw = (459 - 458);
    if (!((186 - 185) != RW4ote)) {
        if ((292 - 195) <= v5q0ztKLDE1[RW4ote -(208 - 207)])
            v5q0ztKLDE1[RW4ote -(889 - 888)] = v5q0ztKLDE1[RW4ote -(142 - 141)] - (585 - 553);
        cout << "(" << v5q0ztKLDE1[RW4ote -(554 - 553)] << "," << FhtHVdw << ")";
    }
    else {
        cWSVsuIi = (268 - 267);
        for (; cWSVsuIi < RW4ote;) {
            if ((!(v5q0ztKLDE1[cWSVsuIi - (963 - 962)] != v5q0ztKLDE1[cWSVsuIi])) || (!(v5q0ztKLDE1[cWSVsuIi - (591 - 590)] + (1010 - 978) != v5q0ztKLDE1[cWSVsuIi])) || (!(v5q0ztKLDE1[cWSVsuIi - (601 - 600)] - (230 - 198) != v5q0ztKLDE1[cWSVsuIi]))) {
                {
                    if ((361 - 361)) {
                        return (407 - 407);
                    }
                }
                FhtHVdw = FhtHVdw +(250 - 249);
            }
            else {
                if ((585 - 488) <= v5q0ztKLDE1[cWSVsuIi - (438 - 437)])
                    v5q0ztKLDE1[cWSVsuIi - (503 - 502)] = v5q0ztKLDE1[cWSVsuIi - (162 - 161)] - (112 - 80);
                cout << "(" << v5q0ztKLDE1[cWSVsuIi - (538 - 537)] << "," << FhtHVdw << ")";
                FhtHVdw = (867 - 866);
            }
            if (!(RW4ote -(256 - 255) != cWSVsuIi)) {
                if ((122 - 25) <= v5q0ztKLDE1[RW4ote -(938 - 937)])
                    v5q0ztKLDE1[RW4ote -(462 - 461)] = v5q0ztKLDE1[RW4ote -(782 - 781)] - (962 - 930);
                cout << "(" << v5q0ztKLDE1[RW4ote -(835 - 834)] << "," << FhtHVdw << ")";
            }
            cWSVsuIi = cWSVsuIi + (93 - 92);
        }
    }
    return (927 - 927);
}

