int main () {
    int ObHCTgouxNy;
    int YQIiqZTSWw;
    char m8mMz6WI2Xb [(1533 - 533)];
    int ZtH3hjdWSso;
    int yAcRbepN37H;
    char fyMfhZi;
    fyMfhZi = '!';
    scanf ("%s", m8mMz6WI2Xb);
    {
        yAcRbepN37H = (656 - 656);
        for (; m8mMz6WI2Xb[yAcRbepN37H] != '\0';) {
            if (m8mMz6WI2Xb[yAcRbepN37H] < (1020 - 923))
                m8mMz6WI2Xb[yAcRbepN37H] = m8mMz6WI2Xb[yAcRbepN37H] + (154 - 122);
            yAcRbepN37H = yAcRbepN37H + (148 - 147);
        }
    }
    {
        yAcRbepN37H = (450 - 450);
        for (; m8mMz6WI2Xb[yAcRbepN37H] != '\0';) {
            ObHCTgouxNy = (769 - 769);
            if (m8mMz6WI2Xb[yAcRbepN37H] != fyMfhZi) {
                fyMfhZi = m8mMz6WI2Xb[yAcRbepN37H];
                {
                    YQIiqZTSWw = yAcRbepN37H;
                    for (; !(fyMfhZi != m8mMz6WI2Xb[YQIiqZTSWw]);) {
                        ObHCTgouxNy = ObHCTgouxNy +(950 - 949);
                        YQIiqZTSWw = YQIiqZTSWw +(137 - 136);
                    }
                }
                printf ("(%c,%d)", m8mMz6WI2Xb[yAcRbepN37H] - (805 - 773), ObHCTgouxNy);
            }
            yAcRbepN37H = yAcRbepN37H + (20 - 19);
        }
    }
    return (434 - 434);
}

