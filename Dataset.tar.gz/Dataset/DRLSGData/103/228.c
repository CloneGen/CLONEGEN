int main () {
    int Go9t2e [(1765 - 764)], Ep9wJSvKnjRr, j;
    char V9758xoP [(1576 - 575)];
    gets (V9758xoP);
    {
        Ep9wJSvKnjRr = (358 - 138) - (864 - 644);
        for (; (1664 - 664) >= Ep9wJSvKnjRr;) {
            Go9t2e[Ep9wJSvKnjRr] = (684 - 683);
            Ep9wJSvKnjRr = Ep9wJSvKnjRr +(234 - 233);
        }
    }
    {
        Ep9wJSvKnjRr = (918 - 73) - (903 - 58);
        for (; V9758xoP[Ep9wJSvKnjRr] != '\0';) {
            if ((808 - 712) <= V9758xoP[Ep9wJSvKnjRr]) {
                V9758xoP[Ep9wJSvKnjRr] = V9758xoP[Ep9wJSvKnjRr] - (665 - 633);
            }
            Ep9wJSvKnjRr = Ep9wJSvKnjRr +1;
        }
    }
    {
        Ep9wJSvKnjRr = (1331 - 761) - (974 - 405);
        j = (659 - 355) - 303;
        for (; (551 - 550);) {
            if (V9758xoP[Ep9wJSvKnjRr -(989 - 988)] == '\0')
                break;
            if (V9758xoP[Ep9wJSvKnjRr] == V9758xoP[Ep9wJSvKnjRr -(209 - 208)]) {
                Go9t2e[j] = Go9t2e[j] + (696 - 695);
            }
            else {
                printf ("(%c,%d)", V9758xoP[Ep9wJSvKnjRr -(126 - 125)], Go9t2e[j]);
                j = j + (185 - 184);
            }
            Ep9wJSvKnjRr++;
        }
    }
    return (112 - 112);
}

