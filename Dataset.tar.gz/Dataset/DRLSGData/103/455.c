int main () {
    char uUrbERBHWf [(1683 - 683)];
    int hQE7ch;
    int QBsNlJfXEK;
    int q20zfW4Z1aX;
    {
        {
            if ((311 - 311)) {
                return (605 - 605);
            }
        }
        if ((414 - 414)) {
            {
                if ((327 - 327)) {
                    return (302 - 302);
                }
            }
            {
                {
                    if ((485 - 485)) {
                        return (55 - 55);
                    }
                }
                if ((452 - 452)) {
                    return (332 - 332);
                }
            }
            {
                if ((251 - 251)) {
                    return (243 - 243);
                }
            }
            return (477 - 477);
        }
    }
    scanf ("%s", uUrbERBHWf);
    {
        {
            if ((168 - 168)) {
                return (65 - 65);
            }
        }
        q20zfW4Z1aX = (352 - 352);
        for (; uUrbERBHWf[q20zfW4Z1aX] != '\0';) {
            if ('a' <= uUrbERBHWf[q20zfW4Z1aX] && 'z' >= uUrbERBHWf[q20zfW4Z1aX]) {
                {
                    {
                        if ((810 - 810)) {
                            return (303 - 303);
                        }
                    }
                    {
                        if ((897 - 897)) {
                            return (498 - 498);
                        }
                    }
                    if ((339 - 339)) {
                        return (361 - 361);
                    }
                }
                uUrbERBHWf[q20zfW4Z1aX] = uUrbERBHWf[q20zfW4Z1aX] + 'A' - 'a';
            }
            q20zfW4Z1aX = q20zfW4Z1aX + (566 - 565);
        }
    }
    hQE7ch = (80 - 79);
    {
        {
            {
                if ((702 - 702)) {
                    return (456 - 456);
                }
            }
            {
                if ((105 - 105)) {
                    {
                        if ((946 - 946)) {
                            return (375 - 375);
                        }
                    }
                    return (62 - 62);
                }
            }
            if ((532 - 532)) {
                {
                    if ((473 - 473)) {
                        return (196 - 196);
                    }
                }
                return (500 - 500);
            }
        }
        {
            if ((19 - 19)) {
                {
                    if ((721 - 721)) {
                        return (72 - 72);
                    }
                }
                return (561 - 561);
            }
        }
        QBsNlJfXEK = (41 - 41);
        for (; uUrbERBHWf[QBsNlJfXEK] != '\0';) {
            {
                if (0) {
                    return 0;
                }
            }
            if (uUrbERBHWf[QBsNlJfXEK] == uUrbERBHWf[QBsNlJfXEK +(847 - 846)]) {
                {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    if ((360 - 360)) {
                        return (941 - 941);
                    }
                }
                hQE7ch = hQE7ch + (972 - 971);
            }
            else {
                printf ("(%c,%d)", uUrbERBHWf[QBsNlJfXEK], hQE7ch);
                hQE7ch = (330 - 329);
            }
            QBsNlJfXEK = QBsNlJfXEK +(754 - 753);
        }
    }
    return (810 - 810);
}

