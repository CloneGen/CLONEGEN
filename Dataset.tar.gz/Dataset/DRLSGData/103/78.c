int main () {
    char dsQAWbXRf [(1572 - 572)];
    int HnxXUHag = (441 - 440), qsmnIGRXD = (812 - 811), ND6Ekbng7CcX = (114 - 114);
    char DeDfl8Nn26 [(1415 - 415)];
    int xYPKbDsSyi [(1528 - 528)];
    {
        if ((942 - 942)) {
            return (816 - 816);
        }
    }
    cin >> dsQAWbXRf;
    for (; HnxXUHag < strlen (dsQAWbXRf);) {
        if (!(dsQAWbXRf[HnxXUHag -(680 - 679)] != dsQAWbXRf[HnxXUHag]) || !((930 - 898) != dsQAWbXRf[HnxXUHag] - dsQAWbXRf[HnxXUHag -(182 - 181)]) || !(-(930 - 898) != dsQAWbXRf[HnxXUHag] - dsQAWbXRf[HnxXUHag -(693 - 692)])) {
            HnxXUHag++;
            qsmnIGRXD++;
        }
        else {
            HnxXUHag++;
            if (dsQAWbXRf[HnxXUHag -(527 - 526)] - 'a' >= (952 - 952))
                DeDfl8Nn26[ND6Ekbng7CcX] = dsQAWbXRf[HnxXUHag -(644 - 643)] - (438 - 406);
            else
                DeDfl8Nn26[ND6Ekbng7CcX] = dsQAWbXRf[HnxXUHag -(107 - 106)];
            xYPKbDsSyi[ND6Ekbng7CcX++] = qsmnIGRXD;
            qsmnIGRXD = (164 - 163);
        }
    }
    if (dsQAWbXRf[HnxXUHag -(761 - 760)] - 'a' >= (697 - 697))
        DeDfl8Nn26[ND6Ekbng7CcX] = dsQAWbXRf[HnxXUHag -(764 - 763)] - (845 - 813);
    else
        DeDfl8Nn26[ND6Ekbng7CcX] = dsQAWbXRf[HnxXUHag -(64 - 63)];
    xYPKbDsSyi[ND6Ekbng7CcX++] = qsmnIGRXD;
    {
        HnxXUHag = (1078 - 959) - (944 - 825);
        while (HnxXUHag < ND6Ekbng7CcX) {
            cout << "(" << DeDfl8Nn26[HnxXUHag] << "," << xYPKbDsSyi[HnxXUHag] << ")";
            HnxXUHag++;
        }
    }
    return (911 - 911);
}

