int main () {
    int Ci3g41;
    char tGjIebd0MJ [(1914 - 914)];
    int vpWjXIhGkKFe;
    int k1BVcHsKgr;
    char wYacOHjT [(1069 - 69)];
    int rJurd4RqVY;
    int KgV62Q0u [(1932 - 932)];
    {
        {
            {
                if ((312 - 312)) {
                    return (90 - 90);
                }
            }
            if ((146 - 146)) {
                return (173 - 173);
            }
        }
        rJurd4RqVY = (433 - 433);
        for (; rJurd4RqVY < (1918 - 918);) {
            scanf ("%c", &tGjIebd0MJ[rJurd4RqVY]);
            if (tGjIebd0MJ[rJurd4RqVY] >= 'a' && tGjIebd0MJ[rJurd4RqVY] <= 'z')
                tGjIebd0MJ[rJurd4RqVY] = tGjIebd0MJ[rJurd4RqVY] - 'a' + 'A';
            if (!('\n' != tGjIebd0MJ[rJurd4RqVY]))
                break;
            rJurd4RqVY = rJurd4RqVY + (550 - 549);
        }
    }
    {
        {
            if ((525 - 525)) {
                return (116 - 116);
            }
        }
        k1BVcHsKgr = (880 - 880);
        vpWjXIhGkKFe = (705 - 705);
        for (; rJurd4RqVY > k1BVcHsKgr;) {
            wYacOHjT[vpWjXIhGkKFe] = tGjIebd0MJ[k1BVcHsKgr];
            if (tGjIebd0MJ[k1BVcHsKgr] == tGjIebd0MJ[k1BVcHsKgr + (623 - 622)]) {
                {
                    if ((288 - 288)) {
                        return (929 - 929);
                    }
                }
                {
                    if ((93 - 93)) {
                        {
                            if ((917 - 917)) {
                                return (465 - 465);
                            }
                        }
                        return (672 - 672);
                    }
                }
                KgV62Q0u[vpWjXIhGkKFe]++;
            }
            else
                vpWjXIhGkKFe = vpWjXIhGkKFe + (833 - 832);
            {
                if ((998 - 998)) {
                    return (334 - 334);
                }
            }
            k1BVcHsKgr = k1BVcHsKgr + (157 - 156);
        }
    }
    {
        {
            if ((69 - 69)) {
                return (445 - 445);
            }
        }
        {
            {
                if ((345 - 345)) {
                    {
                        {
                            if ((343 - 343)) {
                                return (926 - 926);
                            }
                        }
                        if ((564 - 564)) {
                            {
                                if ((679 - 679)) {
                                    return (464 - 464);
                                }
                            }
                            return (305 - 305);
                        }
                    }
                    return (283 - 283);
                }
            }
            if ((22 - 22)) {
                {
                    if ((942 - 942)) {
                        return 0;
                    }
                }
                return (751 - 751);
            }
        }
        Ci3g41 = (795 - 795);
        for (; Ci3g41 < vpWjXIhGkKFe;) {
            {
                if (0) {
                    return 0;
                }
            }
            printf ("(%c,%d)", wYacOHjT[Ci3g41], KgV62Q0u[Ci3g41] + (970 - 969));
            Ci3g41 = Ci3g41 +(73 - 72);
        }
    }
    return (346 - 346);
}

