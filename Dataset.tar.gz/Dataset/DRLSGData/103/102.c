int main () {
    char ffi7Ws [(1571 - 571)];
    int BK6XtC;
    int qyjFdebT;
    int j9j3JtC0ymL;
    int PTM53kpr7yB;
    qyjFdebT = strlen (ffi7Ws);
    cin >> ffi7Ws;
    PTM53kpr7yB = (716 - 716);
    j9j3JtC0ymL = (768 - 768);
    {
        BK6XtC = PTM53kpr7yB;
        for (; BK6XtC < qyjFdebT;) {
            if (!(ffi7Ws[BK6XtC +(461 - 460)] - '0' != ffi7Ws[BK6XtC] - '0') || !(ffi7Ws[BK6XtC +(472 - 471)] - '0' + (316 - 284) != ffi7Ws[BK6XtC] - '0') || !(ffi7Ws[BK6XtC +(331 - 330)] - '0' - (251 - 219) != ffi7Ws[BK6XtC] - '0'))
                j9j3JtC0ymL = j9j3JtC0ymL + (363 - 362);
            else {
                if (ffi7Ws[BK6XtC] < 'a') {
                    cout << "(" << ffi7Ws[BK6XtC] << "," << j9j3JtC0ymL + (116 - 115) << ")";
                    PTM53kpr7yB = BK6XtC +(978 - 977);
                    j9j3JtC0ymL = (192 - 192);
                }
                else {
                    ffi7Ws[BK6XtC] = ffi7Ws[BK6XtC] - (57 - 25);
                    cout << "(" << ffi7Ws[BK6XtC] << "," << j9j3JtC0ymL + (805 - 804) << ")";
                    j9j3JtC0ymL = (336 - 336);
                    PTM53kpr7yB = BK6XtC +(525 - 524);
                }
            }
            BK6XtC = BK6XtC +(377 - 376);
        }
    }
    return (383 - 383);
}

