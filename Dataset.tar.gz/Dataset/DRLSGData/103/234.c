void  main () {
    int N1TiemQzAq;
    int xSCteDN4R;
    char TED2bZA0d [(1457 - 457)];
    scanf ("%s", &TED2bZA0d);
    {
        xSCteDN4R = (332 - 332);
        for (; xSCteDN4R <= (1397 - 398);) {
            if ('z' >= TED2bZA0d[xSCteDN4R] && 'a' <= TED2bZA0d[xSCteDN4R])
                TED2bZA0d[xSCteDN4R] = TED2bZA0d[xSCteDN4R] - (187 - 155);
            xSCteDN4R = xSCteDN4R + (395 - 394);
        }
    }
    N1TiemQzAq = (732 - 731);
    {
        xSCteDN4R = (333 - 333);
        for (; (1446 - 447) > xSCteDN4R;) {
            if (TED2bZA0d[xSCteDN4R + (782 - 781)] == '\0') {
                printf ("(%c,%d)", TED2bZA0d[xSCteDN4R], N1TiemQzAq);
                break;
            }
            else if (TED2bZA0d[xSCteDN4R] == TED2bZA0d[xSCteDN4R + (217 - 216)]) {
                N1TiemQzAq = N1TiemQzAq +(861 - 860);
            }
            else {
                if (TED2bZA0d[xSCteDN4R] != TED2bZA0d[xSCteDN4R + (220 - 219)]) {
                    printf ("(%c,%d)", TED2bZA0d[xSCteDN4R], N1TiemQzAq);
                    N1TiemQzAq = (829 - 828);
                }
                else
                    ;
            }
            xSCteDN4R = xSCteDN4R + (980 - 979);
        }
    }
}

