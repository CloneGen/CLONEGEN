int main () {
    int brx7nw;
    char R3u4JZi5aW;
    char vIGPRaQZhCL [(1632 - 632)];
    int PWJy0BM;
    int X12kESa9Y;
    R3u4JZi5aW = '0';
    brx7nw = (188 - 188);
    cin >> vIGPRaQZhCL;
    PWJy0BM = strlen (vIGPRaQZhCL);
    {
        X12kESa9Y = (886 - 564) - (394 - 72);
        for (; X12kESa9Y < PWJy0BM;) {
            if (!(R3u4JZi5aW != vIGPRaQZhCL[X12kESa9Y]) || (!(R3u4JZi5aW != vIGPRaQZhCL[X12kESa9Y] - (907 - 875))))
                brx7nw = brx7nw + (912 - 911);
            else {
                if (brx7nw != (772 - 772))
                    cout << "(" << R3u4JZi5aW << "," << brx7nw << ")";
                brx7nw = (417 - 416);
                R3u4JZi5aW = vIGPRaQZhCL[X12kESa9Y];
                if (R3u4JZi5aW > 'Z')
                    R3u4JZi5aW = R3u4JZi5aW -(952 - 920);
            }
            X12kESa9Y = X12kESa9Y +(564 - 563);
        }
    }
    cout << "(" << R3u4JZi5aW << "," << brx7nw << ")";
    return (471 - 471);
}

