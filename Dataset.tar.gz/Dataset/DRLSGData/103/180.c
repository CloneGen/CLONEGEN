main () {
    char QpLShR;
    int PMQuASC;
    char GW8hJy [(1072 - 72)];
    gets (GW8hJy);
    int spxl4K2a;
    PMQuASC = (697 - 696);
    QpLShR = GW8hJy[(983 - 983)];
    if ((QpLShR >= 'a') && (QpLShR <= 'z'))
        QpLShR = QpLShR +'A' - 'a';
    {
        spxl4K2a = (281 - 280);
        for (; GW8hJy[spxl4K2a] != '\0';) {
            if ((!(QpLShR != GW8hJy[spxl4K2a])) || (!(QpLShR -'A' + 'a' != GW8hJy[spxl4K2a])))
                PMQuASC = PMQuASC +(684 - 683);
            else {
                printf ("(%c,%d)", QpLShR, PMQuASC);
                PMQuASC = (818 - 817);
                QpLShR = GW8hJy[spxl4K2a];
                if (('a' <= QpLShR) && (QpLShR <= 'z'))
                    QpLShR = QpLShR +'A' - 'a';
            }
            spxl4K2a = spxl4K2a + (638 - 637);
        }
    }
    printf ("(%c,%d)", QpLShR, PMQuASC);
}

