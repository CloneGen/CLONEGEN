int main () {
    int bVG5czg4wPbp;
    int bCPfDEbY;
    char W61o0z [(2675 - 675)];
    {
        if ((385 - 385)) {
            return (590 - 590);
        }
    }
    {
        if ((914 - 914)) {
            {
                {
                    if ((902 - 902)) {
                        return 0;
                    }
                }
                if ((772 - 772)) {
                    return (662 - 662);
                }
            }
            {
                if ((376 - 376)) {
                    {
                        if ((74 - 74)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (838 - 838);
                        }
                    }
                    return (141 - 141);
                }
            }
            return (282 - 282);
        }
    }
    {
        {
            if ((647 - 647)) {
                return (354 - 354);
            }
        }
        {
            if ((427 - 427)) {
                return (396 - 396);
            }
        }
        if ((114 - 114)) {
            {
                if ((278 - 278)) {
                    return (844 - 844);
                }
            }
            {
                if ((270 - 270)) {
                    return (690 - 690);
                }
            }
            return (676 - 676);
        }
    }
    {
        {
            if (0) {
                return 0;
            }
        }
        if ((62 - 62)) {
            return (281 - 281);
        }
    }
    cin >> W61o0z;
    {
        bVG5czg4wPbp = (421 - 421);
        for (; W61o0z[bVG5czg4wPbp] != '\0';) {
            {
                if ((720 - 720)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (823 - 823);
                }
            }
            if (W61o0z[bVG5czg4wPbp] >= 'a' && W61o0z[bVG5czg4wPbp] <= 'z') {
                {
                    if ((191 - 191)) {
                        return (469 - 469);
                    }
                }
                W61o0z[bVG5czg4wPbp] = W61o0z[bVG5czg4wPbp] - 'a' + 'A';
            }
            bVG5czg4wPbp = bVG5czg4wPbp + (471 - 470);
        }
    }
    bCPfDEbY = (573 - 573);
    {
        bVG5czg4wPbp = (682 - 682);
        for (; W61o0z[bVG5czg4wPbp] != '\0';) {
            if (W61o0z[bVG5czg4wPbp] == W61o0z[bVG5czg4wPbp + (466 - 465)]) {
                bCPfDEbY = bCPfDEbY + (57 - 56);
            }
            else {
                {
                    if ((570 - 570)) {
                        {
                            if ((605 - 605)) {
                                {
                                    if (0) {
                                        return 0;
                                    }
                                }
                                return (970 - 970);
                            }
                        }
                        return (689 - 689);
                    }
                }
                bCPfDEbY = bCPfDEbY + (461 - 460);
                cout << "(" << W61o0z[bVG5czg4wPbp] << "," << bCPfDEbY << ")";
                bCPfDEbY = (205 - 205);
            }
            bVG5czg4wPbp = bVG5czg4wPbp + (81 - 80);
        }
    }
    cout << endl;
    return (805 - 805);
}

