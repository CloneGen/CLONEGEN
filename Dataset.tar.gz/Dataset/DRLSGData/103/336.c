int main () {
    int kE5SsKhZMoN;
    int jIXLYa;
    char cULmtX [(1131 - 131)];
    char DgI01t;
    memset (cULmtX, (811 - 811), sizeof (cULmtX));
    jIXLYa = (407 - 407);
    DgI01t = '0';
    cin >> cULmtX;
    kE5SsKhZMoN = strlen (cULmtX);
    {
        int GqH69CfS7v1;
        {
            if ((787 - 787)) {
                return (357 - 357);
            }
        }
        GqH69CfS7v1 = (977 - 977);
        for (; GqH69CfS7v1 <= kE5SsKhZMoN;) {
            char XcNqJn9;
            XcNqJn9 = (!((465 - 464) != isupper (cULmtX[GqH69CfS7v1]))) ? cULmtX[GqH69CfS7v1] : toupper (cULmtX[GqH69CfS7v1]);
            if (!('0' != DgI01t) || XcNqJn9 != DgI01t || !(kE5SsKhZMoN != GqH69CfS7v1)) {
                if (DgI01t != '0')
                    cout << '(' << DgI01t << ',' << jIXLYa << ')';
                DgI01t = XcNqJn9;
                jIXLYa = (177 - 176);
            }
            else {
                jIXLYa = jIXLYa + (29 - 28);
            }
            GqH69CfS7v1 = GqH69CfS7v1 +(738 - 737);
        }
    }
    return (189 - 189);
}

