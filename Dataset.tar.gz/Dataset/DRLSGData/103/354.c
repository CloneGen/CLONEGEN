int main () {
    int J8S1HMeW;
    char isvu6xHl2mzK [(1501 - 501)];
    char sgpXjk5uabM;
    J8S1HMeW = (803 - 803);
    cin >> isvu6xHl2mzK;
    if ('a' <= isvu6xHl2mzK[(601 - 601)] && 'z' >= isvu6xHl2mzK[(357 - 357)])
        sgpXjk5uabM = isvu6xHl2mzK[(538 - 538)] - 'a' + 'A';
    else
        sgpXjk5uabM = isvu6xHl2mzK[(447 - 447)];
    cout << "(" << sgpXjk5uabM << ",";
    {
        int UQmk17320;
        UQmk17320 = (809 - 809);
        for (; isvu6xHl2mzK[UQmk17320] != '\0';) {
            if (!(sgpXjk5uabM != isvu6xHl2mzK[UQmk17320]) || !(sgpXjk5uabM - 'A' + 'a' != isvu6xHl2mzK[UQmk17320])) {
                J8S1HMeW = J8S1HMeW +(750 - 749);
            }
            else {
                if ('a' <= isvu6xHl2mzK[(17 - 17)] && isvu6xHl2mzK[(405 - 405)] <= 'z')
                    sgpXjk5uabM = isvu6xHl2mzK[UQmk17320] - 'a' + 'A';
                else
                    sgpXjk5uabM = isvu6xHl2mzK[UQmk17320];
                cout << J8S1HMeW << ")(" << sgpXjk5uabM << ",";
                J8S1HMeW = (786 - 785);
            }
            UQmk17320 = UQmk17320 +(675 - 674);
        }
    }
    cout << J8S1HMeW << ")" << endl;
    return (645 - 645);
}

