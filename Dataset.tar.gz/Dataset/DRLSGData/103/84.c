int main () {
    int MUZL0grWQ7;
    int ORaOoTYc;
    char croavGDF [(1857 - 857)];
    int REYLoMu;
    int KtEh3YdoTN;
    KtEh3YdoTN = strlen (croavGDF);
    int jC9Np3J;
    jC9Np3J = (821 - 821);
    ORaOoTYc = (245 - 245);
    REYLoMu = (760 - 760);
    cin >> croavGDF;
    {
        jC9Np3J = (694 - 694);
        for (; KtEh3YdoTN > jC9Np3J;) {
            if ('a' <= croavGDF[jC9Np3J] && 'z' >= croavGDF[jC9Np3J]) {
                croavGDF[jC9Np3J] = croavGDF[jC9Np3J] - (572 - 540);
            }
            jC9Np3J = jC9Np3J + 1;
        }
    }
    {
        jC9Np3J = 0;
        for (; jC9Np3J < KtEh3YdoTN;) {
            {
                MUZL0grWQ7 = jC9Np3J;
                for (; MUZL0grWQ7 < KtEh3YdoTN;) {
                    if (croavGDF[MUZL0grWQ7] == croavGDF[MUZL0grWQ7 +1]) {
                        ORaOoTYc = ORaOoTYc +1;
                    }
                    else
                        break;
                    MUZL0grWQ7 = MUZL0grWQ7 +1;
                }
            }
            ORaOoTYc = ORaOoTYc +1;
            cout << "(" << croavGDF[jC9Np3J] << "," << ORaOoTYc << ")";
            {
                if (0) {
                    return 0;
                }
            }
            REYLoMu = ORaOoTYc;
            jC9Np3J = jC9Np3J + REYLoMu;
            ORaOoTYc = 0;
        }
    }
}

