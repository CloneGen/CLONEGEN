main () {
    int Sv8wNMW;
    int khljetqJx;
    char eT7QUOqynSb [(1558 - 557)];
    gets (eT7QUOqynSb);
    {
        khljetqJx = (809 - 609) - (266 - 66);
        for (; eT7QUOqynSb[khljetqJx] != '\0';) {
            if (eT7QUOqynSb[khljetqJx] >= 'a' && 'z' >= eT7QUOqynSb[khljetqJx])
                eT7QUOqynSb[khljetqJx] = eT7QUOqynSb[khljetqJx] - 'a' + 'A';
            khljetqJx = khljetqJx + (93 - 92);
        }
    }
    for (khljetqJx = (318 - 318); eT7QUOqynSb[khljetqJx] != '\0';) {
        Sv8wNMW = (118 - 117);
        for (; eT7QUOqynSb[khljetqJx + (504 - 503)] == eT7QUOqynSb[khljetqJx];) {
            khljetqJx = khljetqJx + (944 - 943);
            Sv8wNMW = Sv8wNMW +(160 - 159);
        }
        printf ("(%c,%d)", eT7QUOqynSb[khljetqJx], Sv8wNMW);
        khljetqJx = khljetqJx + (824 - 823);
    }
}

