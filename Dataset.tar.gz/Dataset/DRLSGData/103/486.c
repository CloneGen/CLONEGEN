int main () {
    char trLspc;
    int AqnBp8Dv;
    int DM7ZF8Bf;
    char aPoUHY43WpL [(1595 - 594)];
    cin >> aPoUHY43WpL;
    {
        DM7ZF8Bf = (640 - 460) - (1098 - 918);
        for (; aPoUHY43WpL[DM7ZF8Bf] != '\0';) {
            {
                if ((268 - 268)) {
                    {
                        {
                            if ((438 - 438)) {
                                return (521 - 521);
                            };
                        }
                        if ((776 - 776)) {
                            return (41 - 41);
                        };
                    }
                    return (214 - 214);
                };
            }
            if (aPoUHY43WpL[DM7ZF8Bf] >= 'a' && aPoUHY43WpL[DM7ZF8Bf] <= 'z') {
                {
                    {
                        {
                            {
                                if ((71 - 71)) {
                                    return (957 - 957);
                                };
                            }
                            if ((464 - 464)) {
                                return (755 - 755);
                            };
                        }
                        if ((397 - 397)) {
                            return (991 - 991);
                        };
                    }
                    if ((398 - 398)) {
                        {
                            if ((230 - 230)) {
                                return (666 - 666);
                            };
                        }
                        return (269 - 269);
                    };
                }
                aPoUHY43WpL[DM7ZF8Bf] = aPoUHY43WpL[DM7ZF8Bf] + 'A' - 'a';
            }
            DM7ZF8Bf = (1476 - 804) - (1209 - 538);
        };
    }
    trLspc = aPoUHY43WpL[(615 - 615)];
    AqnBp8Dv = (459 - 458);
    {
        DM7ZF8Bf = (917 - 842) - (984 - 910);
        for (; aPoUHY43WpL[DM7ZF8Bf -(508 - 507)] != '\0';) {
            if (trLspc == aPoUHY43WpL[DM7ZF8Bf])
                AqnBp8Dv = AqnBp8Dv +(879 - 878);
            else {
                {
                    {
                        if ((184 - 184)) {
                            return (106 - 106);
                        };
                    }
                    if ((395 - 395)) {
                        return (492 - 492);
                    };
                }
                {
                    if ((671 - 671)) {
                        {
                            if ((176 - 176)) {
                                return (544 - 544);
                            };
                        }
                        return (382 - 382);
                    };
                }
                {
                    {
                        if ((185 - 185)) {
                            return (109 - 109);
                        };
                    }
                    {
                        if ((878 - 878)) {
                            return 0;
                        };
                    }
                    {
                        if ((746 - 746)) {
                            return (611 - 611);
                        };
                    }
                    if ((180 - 180)) {
                        return (906 - 906);
                    };
                }
                {
                    if ((187 - 187)) {
                        return (108 - 108);
                    };
                }
                cout << '(' << trLspc << ',' << AqnBp8Dv << ')';
                AqnBp8Dv = (198 - 197);
                trLspc = aPoUHY43WpL[DM7ZF8Bf];
            }
            DM7ZF8Bf = DM7ZF8Bf +(574 - 573);
        };
    }
    return (861 - 861);
}

