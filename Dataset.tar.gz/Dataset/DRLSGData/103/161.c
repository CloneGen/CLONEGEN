int main () {
    char wmfEq7Xbcw [(402 - 350)];
    int Av5HpOMW;
    char S2ahRsx [(1539 - 539)];
    int uXKMY5Tk [(477 - 425)] = {(221 - 220), (746 - 745), (335 - 334), (759 - 758), (429 - 428), (589 - 588), (810 - 809), (119 - 118), (703 - 702), (411 - 410), (957 - 956), (834 - 833), (260 - 259), (910 - 909), (32 - 31), (460 - 459), (755 - 754), (926 - 925), (263 - 262), (281 - 280), (677 - 676), (119 - 118), (895 - 894), (759 - 758), (965 - 964), (252 - 251), (323 - 322), (726 - 725), (495 - 494), (230 - 229), (477 - 476), (658 - 657), (489 - 488), (514 - 513)};
    int d2fKrT;
    int zfvonxBh0;
    getchar ();
    d2fKrT = (100 - 100);
    zfvonxBh0 = strlen (S2ahRsx);
    getchar ();
    scanf ("%s", S2ahRsx);
    {
        Av5HpOMW = (732 - 643) - (408 - 319);
        for (; Av5HpOMW < zfvonxBh0;) {
            if (S2ahRsx[Av5HpOMW] >= 'a' && 'z' >= S2ahRsx[Av5HpOMW])
                S2ahRsx[Av5HpOMW] = S2ahRsx[Av5HpOMW] - 'a' + 'A';
            Av5HpOMW = Av5HpOMW +(528 - 527);
        }
    }
    {
        Av5HpOMW = (243 - 243);
        for (; zfvonxBh0 > Av5HpOMW;) {
            wmfEq7Xbcw[d2fKrT] = S2ahRsx[Av5HpOMW];
            for (; S2ahRsx[Av5HpOMW +(975 - 974)] == S2ahRsx[Av5HpOMW] && Av5HpOMW < (zfvonxBh0 - (137 - 136));) {
                uXKMY5Tk[d2fKrT]++;
                Av5HpOMW = Av5HpOMW +(906 - 905);
            }
            d2fKrT = d2fKrT + (673 - 672);
            Av5HpOMW = Av5HpOMW +(780 - 779);
        }
    }
    {
        Av5HpOMW = (797 - 797);
        for (; Av5HpOMW < d2fKrT;) {
            printf ("(%c,%d)", wmfEq7Xbcw[Av5HpOMW], uXKMY5Tk[Av5HpOMW]);
            Av5HpOMW = Av5HpOMW +(203 - 202);
        }
    }
}

