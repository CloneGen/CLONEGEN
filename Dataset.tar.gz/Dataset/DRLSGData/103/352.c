int main () {
    char tygnXlrP [(1846 - 845)];
    int GEWB9HUa;
    int v9X71iM;
    int eHvNnDR;
    char iE8gbJ1 [(1828 - 827)];
    cin >> iE8gbJ1;
    eHvNnDR = strlen (iE8gbJ1);
    {
        GEWB9HUa = (393 - 393);
        for (; GEWB9HUa < eHvNnDR;) {
            if ((929 - 839) < iE8gbJ1[GEWB9HUa])
                tygnXlrP[GEWB9HUa] = iE8gbJ1[GEWB9HUa] - (472 - 440);
            else
                tygnXlrP[GEWB9HUa] = iE8gbJ1[GEWB9HUa];
            GEWB9HUa = GEWB9HUa +(372 - 371);
        }
    }
    v9X71iM = (300 - 299);
    if (!((298 - 297) != eHvNnDR)) {
        cout << '(' << tygnXlrP[(880 - 880)] << ',' << v9X71iM << ')';
        return (61 - 61);
    }
    {
        GEWB9HUa = (76 - 75);
        for (; eHvNnDR > GEWB9HUa;) {
            if (tygnXlrP[GEWB9HUa] != tygnXlrP[GEWB9HUa -(30 - 29)] && GEWB9HUa != eHvNnDR - (589 - 588)) {
                cout << '(' << tygnXlrP[GEWB9HUa -(370 - 369)] << ',' << v9X71iM << ')';
                v9X71iM = (966 - 965);
            }
            if (tygnXlrP[GEWB9HUa] != tygnXlrP[GEWB9HUa -(370 - 369)] && !(eHvNnDR - (246 - 245) != GEWB9HUa)) {
                cout << '(' << tygnXlrP[GEWB9HUa -(400 - 399)] << ',' << v9X71iM << ')';
                v9X71iM = (609 - 608);
                cout << '(' << tygnXlrP[GEWB9HUa] << ',' << v9X71iM << ')';
            }
            if (!(tygnXlrP[GEWB9HUa -(820 - 819)] != tygnXlrP[GEWB9HUa]) && GEWB9HUa != eHvNnDR - (403 - 402))
                v9X71iM = v9X71iM + (543 - 542);
            if (!(tygnXlrP[GEWB9HUa -(945 - 944)] != tygnXlrP[GEWB9HUa]) && !(eHvNnDR - (237 - 236) != GEWB9HUa)) {
                v9X71iM = v9X71iM + (360 - 359);
                cout << '(' << tygnXlrP[GEWB9HUa -(376 - 375)] << ',' << v9X71iM << ')';
            }
            GEWB9HUa = GEWB9HUa +(848 - 847);
        }
    }
    return (693 - 693);
}

