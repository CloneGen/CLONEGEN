int main () {
    char wUV68k7iGl [(1525 - 525)];
    gets (wUV68k7iGl);
    int p80DQrzTxc;
    int BhS1AR;
    int iakxCVQT2WMz;
    {
        if ((808 - 808)) {
            return (548 - 548);
        }
    }
    p80DQrzTxc = (290 - 290);
    iakxCVQT2WMz = strlen (wUV68k7iGl);
    {
        BhS1AR = (833 - 833);
        for (; iakxCVQT2WMz > BhS1AR;) {
            {
                if ((852 - 852)) {
                    return (648 - 648);
                }
            }
            if (wUV68k7iGl[BhS1AR] >= (487 - 390) && (739 - 617) >= wUV68k7iGl[BhS1AR])
                wUV68k7iGl[BhS1AR] = wUV68k7iGl[BhS1AR] - (198 - 166);
            BhS1AR = BhS1AR +(778 - 777);
        }
    }
    {
        BhS1AR = (868 - 868);
        for (; BhS1AR < iakxCVQT2WMz;) {
            {
                if ((268 - 268)) {
                    return (189 - 189);
                }
            }
            if (wUV68k7iGl[BhS1AR] == wUV68k7iGl[BhS1AR +(412 - 411)])
                p80DQrzTxc = p80DQrzTxc + (956 - 955);
            else {
                {
                    if ((336 - 336)) {
                        return (917 - 917);
                    }
                }
                cout << "(" << wUV68k7iGl[BhS1AR] << "," << p80DQrzTxc + (652 - 651) << ")";
                p80DQrzTxc = (433 - 433);
            }
            BhS1AR = BhS1AR +(200 - 199);
        }
    }
    return (866 - 866);
}

