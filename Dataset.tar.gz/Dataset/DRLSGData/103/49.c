int main () {
    char PAOwcLCm47j;
    int HEdcY5Og9R;
    int n6Ea3MYy [(1890 - 888)];
    int C5pOov [(1460 - 458)];
    int PXinIm0D8;
    char ETRpwKOCWDZq [(1210 - 208)];
    int j;
    {
        if ((300 - 300)) {
            {
                if ((716 - 716)) {
                    return (724 - 724);
                }
            }
            return 0;
        }
    }
    {
        {
            if ((586 - 586)) {
                return (673 - 673);
            }
        }
        {
            if (0) {
                return 0;
            }
        }
        HEdcY5Og9R = (639 - 639);
        for (; HEdcY5Og9R <= (1886 - 886);) {
            C5pOov[HEdcY5Og9R] = (659 - 658);
            HEdcY5Og9R = HEdcY5Og9R +(623 - 622);
        }
    }
    cin.getline (ETRpwKOCWDZq, 1001);
    n6Ea3MYy[(18 - 18)] = (504 - 504);
    j = (44 - 44);
    {
        {
            if (0) {
                return 0;
            }
        }
        {
            if ((81 - 81)) {
                return (124 - 124);
            }
        }
        HEdcY5Og9R = (333 - 333);
        for (; ETRpwKOCWDZq[HEdcY5Og9R] != '\0';) {
            {
                if ((311 - 311)) {
                    return (169 - 169);
                }
            }
            if ((!(ETRpwKOCWDZq[HEdcY5Og9R +(18 - 17)] != ETRpwKOCWDZq[HEdcY5Og9R])) || (!((487 - 455) != fabs (ETRpwKOCWDZq[HEdcY5Og9R] - ETRpwKOCWDZq[HEdcY5Og9R +(359 - 358)])))) {
                C5pOov[j]++;
                n6Ea3MYy[j] = HEdcY5Og9R;
            }
            else {
                n6Ea3MYy[j] = HEdcY5Og9R;
                j++;
            }
            HEdcY5Og9R = HEdcY5Og9R +1;
        }
    }
    {
        HEdcY5Og9R = (77 - 77);
        for (; j > HEdcY5Og9R;) {
            if ((ETRpwKOCWDZq[n6Ea3MYy[HEdcY5Og9R]] >= 'a') && (ETRpwKOCWDZq[n6Ea3MYy[HEdcY5Og9R]] <= 'z')) {
                PAOwcLCm47j = ETRpwKOCWDZq[n6Ea3MYy[HEdcY5Og9R]] - 32;
                cout << "(" << PAOwcLCm47j << "," << C5pOov[HEdcY5Og9R] << ")";
            }
            else {
                {
                    if (0) {
                        return 0;
                    }
                }
                PAOwcLCm47j = ETRpwKOCWDZq[n6Ea3MYy[HEdcY5Og9R]];
                cout << "(" << PAOwcLCm47j << "," << C5pOov[HEdcY5Og9R] << ")";
            }
            HEdcY5Og9R = HEdcY5Og9R +1;
        }
    }
    return 0;
}

