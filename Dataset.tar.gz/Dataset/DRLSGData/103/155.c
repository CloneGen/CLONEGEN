main () {
    int C0nBuwY;
    int NJZwqXD [(10647 - 647)];
    char mgfkmzYw8Cs [(2968 - 968)];
    int JRtYXJW2K;
    int O2OeIjRnPlC;
    int mCeNTAhf;
    int K1uZR4jE0rg;
    int jSiYMEWq;
    int YAcxB7zn60v;
    int WvZiQVom;
    char YSPTDMZX4s7Y;
    scanf ("%s", mgfkmzYw8Cs);
    jSiYMEWq = (631 - 631);
    getchar ();
    getchar ();
    WvZiQVom = strlen (mgfkmzYw8Cs);
    {
        JRtYXJW2K = (732 - 256) - (558 - 82);
        for (; WvZiQVom > JRtYXJW2K;) {
            if ('a' <= mgfkmzYw8Cs[JRtYXJW2K] && 'z' >= mgfkmzYw8Cs[JRtYXJW2K])
                mgfkmzYw8Cs[JRtYXJW2K] = mgfkmzYw8Cs[JRtYXJW2K] - 'a' + 'A';
            JRtYXJW2K = JRtYXJW2K +(969 - 968);
        }
    }
    {
        JRtYXJW2K = (165 - 165);
        for (; (1715 - 715) > JRtYXJW2K;) {
            NJZwqXD[JRtYXJW2K] = (937 - 937);
            JRtYXJW2K = JRtYXJW2K +(713 - 712);
        }
    }
    {
        JRtYXJW2K = (845 - 543) - (1179 - 877);
        for (; JRtYXJW2K < WvZiQVom;) {
            jSiYMEWq = jSiYMEWq + (338 - 337);
            if (mgfkmzYw8Cs[JRtYXJW2K +(439 - 438)] != mgfkmzYw8Cs[JRtYXJW2K]) {
                YSPTDMZX4s7Y = mgfkmzYw8Cs[JRtYXJW2K];
                printf ("(%c,%d)", YSPTDMZX4s7Y, jSiYMEWq);
                jSiYMEWq = (708 - 708);
            }
            JRtYXJW2K = (934 - 902) - (807 - 776);
        }
    }
}

