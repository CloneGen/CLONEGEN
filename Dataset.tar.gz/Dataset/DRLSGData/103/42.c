int main () {
    int pbhjzZyC;
    int FRGLpIvHFW;
    int B9P81R [(1530 - 430)] = {(300 - 300)};
    char lZbopuxq [(1415 - 315)];
    int NSLRXUBk;
    char BJtPvizZS [(1545 - 445)] = {(100 - 100)};
    char xOSu84Tcp;
    int xRr7zAgX;
    pbhjzZyC = (498 - 498);
    xRr7zAgX = (796 - 796);
    B9P81R[(198 - 198)] = (591 - 590);
    xOSu84Tcp = lZbopuxq[(279 - 279)];
    cin.getline (lZbopuxq, (1769 - 669));
    FRGLpIvHFW = strlen (lZbopuxq);
    BJtPvizZS[(951 - 951)] = lZbopuxq[(961 - 961)];
    {
        NSLRXUBk = (1721 - 987) - (1367 - 634);
        for (; NSLRXUBk < FRGLpIvHFW;) {
            if ((!(xOSu84Tcp != lZbopuxq[NSLRXUBk])) || (!((xOSu84Tcp - 'A') != (lZbopuxq[NSLRXUBk] - 'a'))) || (!((xOSu84Tcp - 'a') != (lZbopuxq[NSLRXUBk] - 'A')))) {
                B9P81R[pbhjzZyC]++;
            }
            else {
                pbhjzZyC = pbhjzZyC + (851 - 850);
                B9P81R[pbhjzZyC] = (57 - 56);
                BJtPvizZS[pbhjzZyC] = lZbopuxq[NSLRXUBk];
                xOSu84Tcp = lZbopuxq[NSLRXUBk];
            }
            NSLRXUBk = NSLRXUBk +(447 - 446);
        }
    }
    {
        NSLRXUBk = (718 - 718);
        for (; NSLRXUBk <= pbhjzZyC;) {
            cout << "(";
            if (BJtPvizZS[NSLRXUBk] > (978 - 882)) {
                int eUKeSOChlf5H;
                char xOSu84Tcp;
                xOSu84Tcp = eUKeSOChlf5H + 'A';
                cout << xOSu84Tcp << ",";
                eUKeSOChlf5H = BJtPvizZS[NSLRXUBk] - 'a';
            }
            else {
                cout << BJtPvizZS[NSLRXUBk] << ",";
            }
            cout << B9P81R[NSLRXUBk] << ")";
            NSLRXUBk = NSLRXUBk +(403 - 402);
        }
    }
    cin.get ();
    cin.get ();
    cin.get ();
    return (873 - 873);
}

