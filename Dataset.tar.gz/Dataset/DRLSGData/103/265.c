int main () {
    int fw0XqUk8pjRt;
    int KEFOoWujnvP;
    char Ul9dyXFJ [(1452 - 441)] = {(724 - 724)};
    int OqEiJ0;
    int Er6nLl;
    fw0XqUk8pjRt = (413 - 412);
    cin >> Ul9dyXFJ;
    Er6nLl = strlen (Ul9dyXFJ);
    {
        KEFOoWujnvP = (333 - 62) - (316 - 45);
        for (; KEFOoWujnvP <= Er6nLl -(534 - 533);) {
            if ('a' <= Ul9dyXFJ[KEFOoWujnvP] && Ul9dyXFJ[KEFOoWujnvP] <= 'z')
                Ul9dyXFJ[KEFOoWujnvP] = Ul9dyXFJ[KEFOoWujnvP] - 'a' + 'A';
            KEFOoWujnvP = KEFOoWujnvP +(770 - 769);
        }
    }
    cout << "(" << Ul9dyXFJ[(355 - 355)] << ",";
    {
        {
            if ((524 - 524)) {
                return (932 - 932);
            }
        }
        KEFOoWujnvP = (69 - 68);
        for (; KEFOoWujnvP <= Er6nLl -(993 - 992);) {
            {
                if ((285 - 285)) {
                    return (424 - 424);
                }
            }
            if (Ul9dyXFJ[KEFOoWujnvP] == Ul9dyXFJ[KEFOoWujnvP -(93 - 92)])
                fw0XqUk8pjRt = fw0XqUk8pjRt + (763 - 762);
            else {
                cout << fw0XqUk8pjRt << ")";
                fw0XqUk8pjRt = (496 - 495);
                cout << "(" << Ul9dyXFJ[KEFOoWujnvP] << ",";
            }
            KEFOoWujnvP = KEFOoWujnvP +(93 - 92);
        }
    }
    cout << fw0XqUk8pjRt << ")" << endl;
    OqEiJ0 = (735 - 734);
    return (480 - 480);
}

