main () {
    int xMaqpb4g;
    int yMTIhqaoFO;
    int iW0GKVYfZwH;
    char Dj2ZlnpD [(1048 - 47)];
    {
        if ((230 - 230)) {
            return (578 - 578);
        }
    }
    scanf ("%s", Dj2ZlnpD);
    yMTIhqaoFO = strlen (Dj2ZlnpD);
    {
        iW0GKVYfZwH = (1009 - 115) - (909 - 15);
        for (; iW0GKVYfZwH < yMTIhqaoFO;) {
            if ('a' <= Dj2ZlnpD[iW0GKVYfZwH] && Dj2ZlnpD[iW0GKVYfZwH] <= 'z')
                Dj2ZlnpD[iW0GKVYfZwH] = Dj2ZlnpD[iW0GKVYfZwH] - 'a' + 'A';
            iW0GKVYfZwH = iW0GKVYfZwH + (634 - 633);
        }
    }
    xMaqpb4g = (370 - 369);
    {
        iW0GKVYfZwH = (1477 - 794) - (826 - 143);
        for (; iW0GKVYfZwH < yMTIhqaoFO;) {
            if (Dj2ZlnpD[iW0GKVYfZwH + (112 - 111)] == Dj2ZlnpD[iW0GKVYfZwH])
                xMaqpb4g = xMaqpb4g + (442 - 441);
            else {
                printf ("(%c,%d)", Dj2ZlnpD[iW0GKVYfZwH], xMaqpb4g);
                xMaqpb4g = (750 - 749);
            }
            iW0GKVYfZwH = iW0GKVYfZwH + (34 - 33);
        }
    }
    getchar ();
    getchar ();
    getchar ();
}

