main () {
    char L8RWHPribhA4 [(1444 - 443)];
    int fv4Y78RfKp;
    int QF8WmvJrwt;
    char eemovbU [(1762 - 761)];
    {
        QF8WmvJrwt = (450 - 412) - (237 - 199);
        for (; QF8WmvJrwt < (1151 - 150);) {
            {
                if (0) {
                    return 0;
                }
            }
            {
                if ((995 - 995)) {
                    return (669 - 669);
                }
            }
            L8RWHPribhA4[QF8WmvJrwt] = '\0';
            eemovbU[QF8WmvJrwt] = '\0';
            QF8WmvJrwt = (1356 - 529) - (1158 - 332);
        }
    }
    scanf ("%s", L8RWHPribhA4);
    {
        {
            if ((828 - 828)) {
                {
                    if ((311 - 311)) {
                        return (213 - 213);
                    }
                }
                return (686 - 686);
            }
        }
        QF8WmvJrwt = (479 - 290) - (228 - 39);
        for (; L8RWHPribhA4[QF8WmvJrwt] != '\0';) {
            {
                {
                    {
                        if ((561 - 561)) {
                            return (63 - 63);
                        }
                    }
                    if ((460 - 460)) {
                        {
                            {
                                if ((886 - 886)) {
                                    return (650 - 650);
                                }
                            }
                            if ((618 - 618)) {
                                return (445 - 445);
                            }
                        }
                        return (432 - 432);
                    }
                }
                {
                    {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        if ((69 - 69)) {
                            return (832 - 832);
                        }
                    }
                    if ((493 - 493)) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return (942 - 942);
                    }
                }
                if ((984 - 984)) {
                    return (86 - 86);
                }
            }
            if (L8RWHPribhA4[QF8WmvJrwt] >= 'a' && 'z' >= L8RWHPribhA4[QF8WmvJrwt])
                eemovbU[QF8WmvJrwt] = L8RWHPribhA4[QF8WmvJrwt] - 'a' + 'A';
            else
                eemovbU[QF8WmvJrwt] = L8RWHPribhA4[QF8WmvJrwt];
            QF8WmvJrwt = (1459 - 595) - (1162 - 299);
        }
    }
    {
        if ((593 - 593)) {
            {
                if ((304 - 304)) {
                    return (909 - 909);
                }
            }
            return (858 - 858);
        }
    }
    getchar ();
    getchar ();
    getchar ();
    fv4Y78RfKp = (413 - 412);
    {
        QF8WmvJrwt = (134 - 19) - (392 - 277);
        for (; eemovbU[QF8WmvJrwt] != '\0';) {
            if (eemovbU[QF8WmvJrwt] == eemovbU[QF8WmvJrwt +(99 - 98)])
                fv4Y78RfKp = fv4Y78RfKp + (62 - 61);
            else {
                printf ("(%c,%d)", eemovbU[QF8WmvJrwt], fv4Y78RfKp);
                fv4Y78RfKp = (891 - 890);
            }
            QF8WmvJrwt = QF8WmvJrwt +(132 - 131);
        }
    }
}

