int main () {
    int aXmco9DY;
    int jBCfORLSQbX;
    char CROlFJX9 [(1022 - 22)];
    int lbheN12GWr6;
    scanf ("%s", CROlFJX9);
    {
        int kGKyeNWc2mp;
        kGKyeNWc2mp = (591 - 591);
        for (; CROlFJX9[kGKyeNWc2mp] != '\0';) {
            if ('a' <= CROlFJX9[kGKyeNWc2mp])
                CROlFJX9[kGKyeNWc2mp] = CROlFJX9[kGKyeNWc2mp] - 'a' + 'A';
            else
                CROlFJX9[kGKyeNWc2mp] = CROlFJX9[kGKyeNWc2mp];
            kGKyeNWc2mp = kGKyeNWc2mp + (24 - 23);
        }
    }
    jBCfORLSQbX = (416 - 415);
    {
        int kGKyeNWc2mp;
        kGKyeNWc2mp = (229 - 229);
        for (; CROlFJX9[kGKyeNWc2mp] != '\0';) {
            if (!(CROlFJX9[kGKyeNWc2mp + (973 - 972)] != CROlFJX9[kGKyeNWc2mp])) {
                jBCfORLSQbX = jBCfORLSQbX + (674 - 673);
                continue;
            }
            else {
                printf ("(%c,%d)", CROlFJX9[kGKyeNWc2mp], jBCfORLSQbX);
                jBCfORLSQbX = (810 - 809);
            }
            kGKyeNWc2mp = kGKyeNWc2mp + (539 - 538);
        }
    }
    return (645 - 645);
}

