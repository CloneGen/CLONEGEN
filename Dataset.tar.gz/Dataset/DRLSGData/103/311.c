int main () {
    char xUXzNy [(1069 - 69)];
    int v18KzMbL2PJ;
    char UvuiXgr [(910 - 905)];
    int tzy9sL6;
    v18KzMbL2PJ = (91 - 91);
    cin >> xUXzNy;
    for (tzy9sL6 = (789 - 789); xUXzNy[tzy9sL6] != '\0';) {
        v18KzMbL2PJ = (583 - 583);
        UvuiXgr[(453 - 453)] = xUXzNy[tzy9sL6];
        if (UvuiXgr[(763 - 763)] <= 'z' && 'a' <= UvuiXgr[(909 - 909)])
            UvuiXgr[(327 - 327)] = UvuiXgr[(588 - 588)] - (985 - 953);
        for (; !(UvuiXgr[(448 - 448)] != xUXzNy[tzy9sL6]) || !(UvuiXgr[(113 - 113)] + (814 - 782) != xUXzNy[tzy9sL6]);) {
            if (xUXzNy[tzy9sL6] != '\0')
                tzy9sL6 = tzy9sL6 + (306 - 305);
            v18KzMbL2PJ = v18KzMbL2PJ + (508 - 507);
        }
        cout << "(" << UvuiXgr[(439 - 439)] << "," << v18KzMbL2PJ << ")";
    }
    cout << endl;
    return (364 - 364);
}

