int main () {
    int SGDvZkotzN;
    int rSbn4ez;
    int oVYne6pgPkEW;
    char meCSbXp3g0 [(1675 - 670)];
    char bA4NGMxi0USD;
    cin >> meCSbXp3g0;
    rSbn4ez = strlen (meCSbXp3g0);
    SGDvZkotzN = (97 - 96);
    oVYne6pgPkEW = (665 - 664);
    {
        oVYne6pgPkEW = (666 - 665);
        for (; rSbn4ez > oVYne6pgPkEW;) {
            if ((!((512 - 512) != meCSbXp3g0[oVYne6pgPkEW] - meCSbXp3g0[oVYne6pgPkEW - (874 - 873)])) || (!((715 - 683) != meCSbXp3g0[oVYne6pgPkEW] - meCSbXp3g0[oVYne6pgPkEW - (612 - 611)])) || (!(-(134 - 102) != meCSbXp3g0[oVYne6pgPkEW] - meCSbXp3g0[oVYne6pgPkEW - (341 - 340)]))) {
                SGDvZkotzN = SGDvZkotzN +(376 - 375);
            }
            else {
                if (meCSbXp3g0[oVYne6pgPkEW - (595 - 594)] < (226 - 131))
                    cout << "(" << meCSbXp3g0[oVYne6pgPkEW - (764 - 763)] << "," << SGDvZkotzN << ")";
                else {
                    bA4NGMxi0USD = meCSbXp3g0[oVYne6pgPkEW - (470 - 469)] - (816 - 784);
                    cout << "(" << bA4NGMxi0USD << "," << SGDvZkotzN << ")";
                }
                SGDvZkotzN = (900 - 899);
            }
            oVYne6pgPkEW = oVYne6pgPkEW + (466 - 465);
        }
    }
    if ((925 - 830) > meCSbXp3g0[rSbn4ez - (996 - 995)])
        cout << "(" << meCSbXp3g0[rSbn4ez - (244 - 243)] << "," << SGDvZkotzN << ")";
    else {
        bA4NGMxi0USD = meCSbXp3g0[rSbn4ez - (662 - 661)] - (494 - 462);
        cout << "(" << bA4NGMxi0USD << "," << SGDvZkotzN << ")";
    }
    return (52 - 52);
}

