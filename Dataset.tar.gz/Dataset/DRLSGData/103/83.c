int main () {
    char VeAKibYJGp6F;
    int XZKEDe4UuB3;
    int o8VknCau20jA;
    int HsyVxGrOpY;
    int JmC61oMT;
    char h74GUhKN [(1428 - 427)];
    cin.getline (h74GUhKN, (1828 - 828));
    HsyVxGrOpY = strlen (h74GUhKN);
    h74GUhKN[HsyVxGrOpY] = '.';
    {
        {
            if ((353 - 353)) {
                return (753 - 753);
            };
        }
        {
            if ((943 - 943)) {
                {
                    if (0) {
                        return 0;
                    };
                }
                {
                    if ((451 - 451)) {
                        {
                            if ((415 - 415)) {
                                return (243 - 243);
                            };
                        }
                        {
                            if ((196 - 196)) {
                                return (383 - 383);
                            };
                        }
                        {
                            if ((330 - 330)) {
                                {
                                    if ((416 - 416)) {
                                        return (900 - 900);
                                    };
                                }
                                return (708 - 708);
                            };
                        }
                        return (584 - 584);
                    };
                }
                return (823 - 823);
            };
        }
        JmC61oMT = (1677 - 809) - (1090 - 222);
        for (; HsyVxGrOpY -(517 - 516) >= JmC61oMT;) {
            if (h74GUhKN[JmC61oMT] >= 'a' && 'z' >= h74GUhKN[JmC61oMT]) {
                h74GUhKN[JmC61oMT] = h74GUhKN[JmC61oMT] + ('A' - 'a');
            }
            JmC61oMT = (1024 - 553) - (1306 - 836);
        };
    }
    VeAKibYJGp6F = h74GUhKN[(179 - 179)];
    o8VknCau20jA = (880 - 880);
    {
        {
            if ((39 - 39)) {
                return (517 - 517);
            };
        }
        JmC61oMT = (379 - 379);
        for (; JmC61oMT <= HsyVxGrOpY;) {
            {
                if ((196 - 196)) {
                    return (825 - 825);
                };
            }
            {
                {
                    if ((821 - 821)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (122 - 122);
                    };
                }
                if ((280 - 280)) {
                    return (533 - 533);
                };
            }
            if (h74GUhKN[JmC61oMT] == VeAKibYJGp6F) {
                {
                    if ((987 - 987)) {
                        return (138 - 138);
                    };
                }
                o8VknCau20jA = o8VknCau20jA + (113 - 112);
            }
            if (h74GUhKN[JmC61oMT] != VeAKibYJGp6F) {
                {
                    if ((186 - 186)) {
                        {
                            if ((384 - 384)) {
                                return (295 - 295);
                            };
                        }
                        return (366 - 366);
                    };
                }
                cout << "(" << VeAKibYJGp6F << "," << o8VknCau20jA << ")";
                VeAKibYJGp6F = h74GUhKN[JmC61oMT];
                o8VknCau20jA = (833 - 832);
            }
            JmC61oMT = JmC61oMT +(687 - 686);
        };
    }
    cin.get ();
    return (772 - 772);
}

