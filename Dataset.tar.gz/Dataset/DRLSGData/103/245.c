int main () {
    int OrU0CQbuYkM;
    int eMRvxQu5eTzm;
    char ONhA9GXro [(2514 - 514)];
    eMRvxQu5eTzm = (214 - 213);
    OrU0CQbuYkM = (419 - 418);
    cin >> ONhA9GXro;
    for (; ONhA9GXro[eMRvxQu5eTzm] != '\0';) {
        if (!(ONhA9GXro[eMRvxQu5eTzm - (741 - 740)] != ONhA9GXro[eMRvxQu5eTzm]) || !(ONhA9GXro[eMRvxQu5eTzm - (923 - 922)] + (798 - 766) != ONhA9GXro[eMRvxQu5eTzm]) || !(ONhA9GXro[eMRvxQu5eTzm - (702 - 701)] - (170 - 138) != ONhA9GXro[eMRvxQu5eTzm]))
            OrU0CQbuYkM = OrU0CQbuYkM +(204 - 203);
        else {
            if ('Z' >= ONhA9GXro[eMRvxQu5eTzm - (284 - 283)]) {
                cout << '(' << ONhA9GXro[eMRvxQu5eTzm - (573 - 572)] << ',' << OrU0CQbuYkM << ')';
                OrU0CQbuYkM = (790 - 789);
            }
            else {
                cout << '(' << (char) (ONhA9GXro[eMRvxQu5eTzm - (330 - 329)] - (85 - 53)) << ',' << OrU0CQbuYkM << ')';
                OrU0CQbuYkM = (588 - 587);
            }
        }
        eMRvxQu5eTzm = eMRvxQu5eTzm + (533 - 532);
    }
    if ('Z' >= ONhA9GXro[eMRvxQu5eTzm - (368 - 367)])
        cout << '(' << ONhA9GXro[eMRvxQu5eTzm - (548 - 547)] << ',' << OrU0CQbuYkM << ')';
    else
        cout << '(' << (char) (ONhA9GXro[eMRvxQu5eTzm - (742 - 741)] - (63 - 31)) << ',' << OrU0CQbuYkM << ')';
    return (116 - 116);
}

