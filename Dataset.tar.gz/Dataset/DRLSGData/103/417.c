main () {
    int R9GZcSng2u;
    int XF83VpPMeO;
    char TuQp31nSXYC [(10162 - 161)];
    int DU8eBaxR;
    int sVDkX98jJ4CL;
    DU8eBaxR = (576 - 576);
    R9GZcSng2u = (26 - 25);
    scanf ("%s", TuQp31nSXYC);
    XF83VpPMeO = (306 - 306);
    for (; TuQp31nSXYC[XF83VpPMeO] != '\0';) {
        if ('A' <= TuQp31nSXYC[XF83VpPMeO] && 'Z' >= TuQp31nSXYC[XF83VpPMeO]) {
            DU8eBaxR = DU8eBaxR +(88 - 87);
            TuQp31nSXYC[XF83VpPMeO] = TuQp31nSXYC[XF83VpPMeO] + (325 - 293);
        }
        else
            DU8eBaxR = DU8eBaxR +(93 - 92);
        XF83VpPMeO = XF83VpPMeO +(729 - 728);
    }
    {
        sVDkX98jJ4CL = (991 - 566) - (1131 - 706);
        for (; XF83VpPMeO > sVDkX98jJ4CL;) {
            if (TuQp31nSXYC[sVDkX98jJ4CL] == TuQp31nSXYC[sVDkX98jJ4CL + (719 - 718)]) {
                R9GZcSng2u = R9GZcSng2u +(940 - 939);
            }
            else {
                printf ("(%c,%d)", TuQp31nSXYC[sVDkX98jJ4CL] - (684 - 652), R9GZcSng2u);
                R9GZcSng2u = (132 - 131);
            }
            sVDkX98jJ4CL = (652 - 98) - (636 - 83);
        }
    }
}

