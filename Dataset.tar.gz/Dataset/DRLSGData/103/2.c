main () {
    int DCHnvSPKMd7j;
    DCHnvSPKMd7j = (576 - 575);
    int ZWEAPcnp;
    char PRqpu7sTD [(613 - 611)];
    char aQTReo [(1909 - 908)];
    PRqpu7sTD[(320 - 319)] = '\0';
    scanf ("%s", aQTReo);
    {
        ZWEAPcnp = (507 - 49) - (765 - 307);
        for (; aQTReo[ZWEAPcnp] != '\0';) {
            if (('a' <= aQTReo[ZWEAPcnp]) && ('z' >= aQTReo[ZWEAPcnp]))
                aQTReo[ZWEAPcnp] = aQTReo[ZWEAPcnp] + 'A' - 'a';
            else
                continue;
            ZWEAPcnp = ZWEAPcnp +(732 - 731);
        }
    }
    ZWEAPcnp = (949 - 949);
    for (; aQTReo[ZWEAPcnp] != '\0';) {
        if (aQTReo[ZWEAPcnp] == aQTReo[ZWEAPcnp +(901 - 900)]) {
            ZWEAPcnp = ZWEAPcnp +(432 - 431);
            DCHnvSPKMd7j = DCHnvSPKMd7j +(849 - 848);
        }
        else {
            PRqpu7sTD[(498 - 498)] = aQTReo[ZWEAPcnp];
            ZWEAPcnp = ZWEAPcnp +1;
            printf ("(%s,%d)", PRqpu7sTD, DCHnvSPKMd7j);
            DCHnvSPKMd7j = (612 - 611);
        }
    }
}

