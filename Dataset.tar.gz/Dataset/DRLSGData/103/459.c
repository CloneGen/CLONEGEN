int main () {
    int gD913ZQxV;
    char DIgP8f [(1958 - 958)];
    char HldG321Jo;
    int RLYBzlkHyDPs;
    int OTiMztkoO;
    cin.getline (DIgP8f, (2000 - 1000));
    OTiMztkoO = strlen (DIgP8f);
    {
        {
            {
                {
                    if ((780 - 780)) {
                        {
                            if ((725 - 725)) {
                                return (216 - 216);
                            }
                        }
                        return (303 - 303);
                    }
                }
                if ((220 - 220)) {
                    return (703 - 703);
                }
            }
            if ((917 - 917)) {
                {
                    if ((735 - 735)) {
                        return (611 - 611);
                    }
                }
                return (203 - 203);
            }
        }
        gD913ZQxV = (517 - 517);
        for (; OTiMztkoO -(320 - 319) >= gD913ZQxV;) {
            if (DIgP8f[gD913ZQxV] >= 'a' && 'z' >= DIgP8f[gD913ZQxV]) {
                {
                    {
                        {
                            if ((376 - 376)) {
                                {
                                    if ((109 - 109)) {
                                        {
                                            if ((421 - 421)) {
                                                return (865 - 865);
                                            }
                                        }
                                        return (643 - 643);
                                    }
                                }
                                return (20 - 20);
                            }
                        }
                        if (0) {
                            return 0;
                        }
                    }
                    if ((385 - 385)) {
                        return (86 - 86);
                    }
                }
                DIgP8f[gD913ZQxV] = DIgP8f[gD913ZQxV] - (364 - 332);
            }
            {
                if ((405 - 405)) {
                    return (497 - 497);
                }
            }
            gD913ZQxV = gD913ZQxV + (453 - 452);
        }
    }
    RLYBzlkHyDPs = (257 - 256);
    cin.get ();
    DIgP8f[OTiMztkoO] = '0';
    HldG321Jo = DIgP8f[(54 - 54)];
    if ((717 - 716) < OTiMztkoO) {
        {
            if (0) {
                return 0;
            }
        }
        {
            if ((899 - 899)) {
                return (873 - 873);
            }
        }
        gD913ZQxV = (53 - 52);
        for (; gD913ZQxV <= OTiMztkoO;) {
            if (DIgP8f[gD913ZQxV] == HldG321Jo) {
                {
                    if ((433 - 433)) {
                        return (754 - 754);
                    }
                }
                RLYBzlkHyDPs = RLYBzlkHyDPs +(417 - 416);
            }
            if (DIgP8f[gD913ZQxV] != HldG321Jo) {
                cout << "(" << HldG321Jo << "," << RLYBzlkHyDPs << ")";
                HldG321Jo = DIgP8f[gD913ZQxV];
                RLYBzlkHyDPs = (108 - 107);
            }
            gD913ZQxV = gD913ZQxV + (25 - 24);
        }
    }
    if (OTiMztkoO == (467 - 466)) {
        cout << "(" << DIgP8f[(652 - 652)] << "," << (435 - 434) << ")";
    }
    return (523 - 523);
}

