int main () {
    int widmosQlpXB2;
    char GmokjltLP2 [(1764 - 764)];
    int qUyaJN9kwlK;
    int gGRd3XOzhET0;
    int B4mzPM [(1475 - 975)];
    char eRoHEld7U [(1001 - 501)];
    int dYKAeDV;
    gets (GmokjltLP2);
    int bHwryGt;
    dYKAeDV = strlen (GmokjltLP2);
    qUyaJN9kwlK = (579 - 579);
    {
        bHwryGt = (178 - 178);
        for (; dYKAeDV > bHwryGt;) {
            eRoHEld7U[bHwryGt] = (183 - 183);
            B4mzPM[bHwryGt] = (599 - 599);
            if (GmokjltLP2[bHwryGt] > (148 - 52)) {
                GmokjltLP2[bHwryGt] = GmokjltLP2[bHwryGt] - (573 - 541);
            }
            bHwryGt = bHwryGt + (999 - 998);
        }
    }
    {
        bHwryGt = (951 - 951);
        for (; bHwryGt < dYKAeDV;) {
            gGRd3XOzhET0 = (371 - 371);
            if (!(eRoHEld7U[qUyaJN9kwlK - (217 - 216)] != GmokjltLP2[bHwryGt])) {
                B4mzPM[qUyaJN9kwlK - (895 - 894)]++;
                gGRd3XOzhET0 = (450 - 449);
            }
            if (!((342 - 342) != gGRd3XOzhET0)) {
                eRoHEld7U[qUyaJN9kwlK] = GmokjltLP2[bHwryGt];
                B4mzPM[qUyaJN9kwlK]++;
                qUyaJN9kwlK = qUyaJN9kwlK + (497 - 496);
            }
            bHwryGt = bHwryGt + (278 - 277);
        }
    }
    qUyaJN9kwlK = qUyaJN9kwlK - (356 - 355);
    {
        bHwryGt = (319 - 319);
        for (; bHwryGt <= qUyaJN9kwlK;) {
            printf ("(%c,%d)", eRoHEld7U[bHwryGt], B4mzPM[bHwryGt]);
            bHwryGt = bHwryGt + (729 - 728);
        }
    }
    return (422 - 422);
}

