int main () {
    int r, t = (714 - 713), i = (735 - 735), n, k;
    char c3xjn1uwh [(1591 - 591)];
    cin.getline (c3xjn1uwh, (1040 - 40));
    {
        i = (1698 - 892) - 805;
        for (; c3xjn1uwh[i - (719 - 718)] != '\0';) {
            if (c3xjn1uwh[i - (764 - 763)] == c3xjn1uwh[i] || c3xjn1uwh[i - (385 - 384)] - c3xjn1uwh[i] == (248 - 216) || c3xjn1uwh[i - (654 - 653)] - c3xjn1uwh[i] == -(765 - 733))
                t++;
            else {
                cout << "(" << ((int) c3xjn1uwh[i - (716 - 715)] < (560 - 463) ? c3xjn1uwh[i - (702 - 701)] : (char) (c3xjn1uwh[i - (713 - 712)] - (959 - 927))) << "," << t << ")";
                t = (145 - 144);
            }
            i++;
        }
    }
    return (731 - 731);
}

