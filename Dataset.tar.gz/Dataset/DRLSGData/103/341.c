char hlYONCs0FZ7W;

void  mAPa3ZdR () {
    hlYONCs0FZ7W = cin.mAPa3ZdR ();
    if ('z' >= hlYONCs0FZ7W && 'a' <= hlYONCs0FZ7W)
        hlYONCs0FZ7W = (char) ((int) hlYONCs0FZ7W - 'a' + 'A');
}

int main () {
    int mO7zL9oAa4j [(1925 - 925)] = {(215 - 215)};
    int akSMvPin3Wz;
    char hBaX5U [(1315 - 315)] = {(554 - 554)};
    akSMvPin3Wz = (509 - 509);
    mAPa3ZdR ();
    hBaX5U[akSMvPin3Wz] = hlYONCs0FZ7W;
    mAPa3ZdR ();
    mO7zL9oAa4j[akSMvPin3Wz]++;
    for (; hlYONCs0FZ7W != '\n';) {
        if (!(hBaX5U[akSMvPin3Wz] != hlYONCs0FZ7W))
            mO7zL9oAa4j[akSMvPin3Wz]++;
        else {
            akSMvPin3Wz = akSMvPin3Wz + (805 - 804);
            hBaX5U[akSMvPin3Wz] = hlYONCs0FZ7W;
            mO7zL9oAa4j[akSMvPin3Wz]++;
        }
        mAPa3ZdR ();
    }
    {
        akSMvPin3Wz = (183 - 183);
        for (; mO7zL9oAa4j[akSMvPin3Wz] != (993 - 993);) {
            cout << "(" << hBaX5U[akSMvPin3Wz] << "," << mO7zL9oAa4j[akSMvPin3Wz] << ")";
            akSMvPin3Wz = akSMvPin3Wz + (515 - 514);
        }
    }
    return (853 - 853);
}

