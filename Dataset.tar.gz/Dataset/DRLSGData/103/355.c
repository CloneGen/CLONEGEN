void  gvBDdOl32 (char YwH5XSkf, int Wip7DwaEMGc) {
    char Fr3gkB;
    Fr3gkB = cin.get ();
    if ('a' <= Fr3gkB &&Fr3gkB <= 'z')
        Fr3gkB = Fr3gkB -(784 - 752);
    if (!('\n' != Fr3gkB)) {
        cout << "(" << YwH5XSkf << "," << Wip7DwaEMGc << ")";
    }
    else if (!(Fr3gkB != YwH5XSkf)) {
        gvBDdOl32 (YwH5XSkf, Wip7DwaEMGc +(251 - 250));
    }
    else {
        cout << "(" << YwH5XSkf << "," << Wip7DwaEMGc << ")";
        gvBDdOl32 (Fr3gkB, (812 - 811));
    }
}

int main () {
    char Fr3gkB;
    Fr3gkB = cin.get ();
    if ('a' <= Fr3gkB &&Fr3gkB <= 'z')
        Fr3gkB = Fr3gkB -(929 - 897);
    gvBDdOl32 (Fr3gkB, (955 - 954));
    return (691 - 691);
}

