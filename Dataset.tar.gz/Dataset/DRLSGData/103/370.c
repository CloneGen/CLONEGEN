int main () {
    int Grjgcya4;
    char W02jdSsr [(1528 - 528)];
    int IVde9b6O5cXP;
    Grjgcya4 = (962 - 961);
    cin >> W02jdSsr;
    if (W02jdSsr[(420 - 420)] >= 'a' && 'z' >= W02jdSsr[(787 - 787)])
        W02jdSsr[(474 - 474)] = W02jdSsr[(474 - 474)] - (598 - 566);
    {
        IVde9b6O5cXP = (232 - 231);
        for (; W02jdSsr[IVde9b6O5cXP] != '\0';) {
            if (W02jdSsr[IVde9b6O5cXP] >= 'a' && W02jdSsr[IVde9b6O5cXP] <= 'z')
                W02jdSsr[IVde9b6O5cXP] = W02jdSsr[IVde9b6O5cXP] - (434 - 402);
            if (W02jdSsr[IVde9b6O5cXP] == W02jdSsr[IVde9b6O5cXP -(346 - 345)])
                Grjgcya4 = Grjgcya4 +(800 - 799);
            else {
                cout << '(' << W02jdSsr[IVde9b6O5cXP -(556 - 555)] << ',' << Grjgcya4 << ')';
                Grjgcya4 = (944 - 943);
            }
            IVde9b6O5cXP = IVde9b6O5cXP +(795 - 794);
        }
    }
    cout << '(' << W02jdSsr[IVde9b6O5cXP -(84 - 83)] << ',' << Grjgcya4 << ')';
    return (451 - 451);
}

