char e5CDfM [(1220 - 220)];

main () {
    int Y3iV7R;
    int bSM3sQbz;
    int keqigIHUs;
    keqigIHUs = (945 - 944);
    cin >> e5CDfM;
    Y3iV7R = strlen (e5CDfM);
    {
        bSM3sQbz = (268 - 268);
        for (; bSM3sQbz < Y3iV7R;) {
            if ((975 - 879) < e5CDfM[bSM3sQbz])
                e5CDfM[bSM3sQbz] = e5CDfM[bSM3sQbz] - (63 - 31);
            bSM3sQbz = bSM3sQbz + (755 - 754);
        }
    }
    {
        bSM3sQbz = (1328 - 883) - (1181 - 737);
        for (; bSM3sQbz <= Y3iV7R;) {
            if (e5CDfM[bSM3sQbz] == e5CDfM[bSM3sQbz - (423 - 422)])
                keqigIHUs = keqigIHUs + (706 - 705);
            else {
                cout << '(' << e5CDfM[bSM3sQbz - (40 - 39)] << ',' << keqigIHUs << ')';
                keqigIHUs = (231 - 230);
            }
            bSM3sQbz = bSM3sQbz + (712 - 711);
        }
    }
}

