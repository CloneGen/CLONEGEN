int main () {
    int ST59gd = (332 - 331);
    int EmX1bJ;
    char Xl0vEUpKcuAd;
    char YhXcO6TA = '*';
    int CJS6dtQnMzs;
    CJS6dtQnMzs = (889 - 889);
    EmX1bJ = (98 - 97);
    for (; ST59gd;) {
        CJS6dtQnMzs = CJS6dtQnMzs +1;
        scanf ("%c", &Xl0vEUpKcuAd);
        if (Xl0vEUpKcuAd >= 97 && Xl0vEUpKcuAd <= (519 - 397))
            Xl0vEUpKcuAd = Xl0vEUpKcuAd -32;
        if (Xl0vEUpKcuAd == YhXcO6TA)
            EmX1bJ = EmX1bJ +1;
        else {
            if (YhXcO6TA == '*')
                ;
            else {
                printf ("(%c,%d)", YhXcO6TA, EmX1bJ);
                EmX1bJ = (470 - 469);
            }
        }
        YhXcO6TA = Xl0vEUpKcuAd;
        if (Xl0vEUpKcuAd == '\n')
            break;
    }
    return (994 - 994);
}

