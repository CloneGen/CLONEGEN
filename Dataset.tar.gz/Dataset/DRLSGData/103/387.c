void  main () {
    int qNqS4GE;
    int zUcKVX;
    char Xh3u9jJlVcfd [MAX];
    struct   code {
        char InysPA623UFl;
        int ON6vSr;
    }
    y2oYJhD [MAX];
    int O9OKbcd37N;
    int iG5gMAoE8w;
    iG5gMAoE8w = (50 - 50);
    qNqS4GE = (777 - 777);
    scanf ("%s", Xh3u9jJlVcfd);
    zUcKVX = strlen (Xh3u9jJlVcfd);
    {
        O9OKbcd37N = (306 - 274) - (346 - 314);
        for (; zUcKVX > O9OKbcd37N;) {
            if ((317 - 220) <= Xh3u9jJlVcfd[O9OKbcd37N] && Xh3u9jJlVcfd[O9OKbcd37N] <= (1074 - 952))
                Xh3u9jJlVcfd[O9OKbcd37N] = Xh3u9jJlVcfd[O9OKbcd37N] - (1005 - 973);
            O9OKbcd37N = O9OKbcd37N +(927 - 926);
        }
    }
    for (; zUcKVX > qNqS4GE;) {
        y2oYJhD[iG5gMAoE8w].InysPA623UFl = Xh3u9jJlVcfd[qNqS4GE];
        {
            O9OKbcd37N = qNqS4GE;
            for (; (472 - 471);) {
                {
                    if ((494 - 494)) {
                        return (556 - 556);
                    }
                }
                if (y2oYJhD[iG5gMAoE8w].InysPA623UFl != Xh3u9jJlVcfd[O9OKbcd37N]) {
                    y2oYJhD[iG5gMAoE8w].ON6vSr = O9OKbcd37N -qNqS4GE;
                    iG5gMAoE8w = iG5gMAoE8w + (391 - 390);
                    qNqS4GE = O9OKbcd37N;
                    break;
                }
                O9OKbcd37N = O9OKbcd37N +(825 - 824);
            }
        }
    }
    {
        O9OKbcd37N = (514 - 514);
        for (; O9OKbcd37N < iG5gMAoE8w;) {
            printf ("(%c,%d)", y2oYJhD[O9OKbcd37N].InysPA623UFl, y2oYJhD[O9OKbcd37N].ON6vSr);
            O9OKbcd37N = O9OKbcd37N +(32 - 31);
        }
    }
}

