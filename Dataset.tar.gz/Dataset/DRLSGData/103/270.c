int main () {
    int PJndFBz;
    char twxPGO06lLN4 [(1085 - 85)];
    int P3lZxkbzB60a;
    int rX2qyMWAnJjU;
    int TiA04l5Fy83;
    cin >> twxPGO06lLN4;
    P3lZxkbzB60a = (441 - 441);
    TiA04l5Fy83 = (247 - 247);
    TiA04l5Fy83 = strlen (twxPGO06lLN4);
    {
        PJndFBz = (969 - 969);
        for (; PJndFBz < TiA04l5Fy83;) {
            if ((551 - 454) <= twxPGO06lLN4[PJndFBz])
                twxPGO06lLN4[PJndFBz] = twxPGO06lLN4[PJndFBz] - (279 - 247);
            P3lZxkbzB60a = (683 - 683);
            {
                rX2qyMWAnJjU = PJndFBz;
                for (; rX2qyMWAnJjU < TiA04l5Fy83;) {
                    if (twxPGO06lLN4[PJndFBz] == twxPGO06lLN4[rX2qyMWAnJjU] || twxPGO06lLN4[rX2qyMWAnJjU] == twxPGO06lLN4[PJndFBz] + (106 - 74)) {
                        P3lZxkbzB60a = P3lZxkbzB60a +(255 - 254);
                    }
                    else
                        break;
                    rX2qyMWAnJjU = rX2qyMWAnJjU + (599 - 598);
                }
            }
            cout << '(' << twxPGO06lLN4[PJndFBz] << ',' << P3lZxkbzB60a << ')';
            PJndFBz = rX2qyMWAnJjU - (821 - 820);
            PJndFBz = PJndFBz +(29 - 28);
        }
    }
    return (403 - 403);
}

