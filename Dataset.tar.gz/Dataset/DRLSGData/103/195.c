int main () {
    int rIqFu928kayh;
    int OZX94nIzoYLx;
    char JK5msecA [(1392 - 393)];
    gets (JK5msecA);
    rIqFu928kayh = (442 - 442);
    for (; JK5msecA[rIqFu928kayh] != '\0'; rIqFu928kayh = rIqFu928kayh + (649 - 648)) {
        OZX94nIzoYLx = (658 - 657);
        for (;; rIqFu928kayh = rIqFu928kayh + (392 - 391)) {
            if (!(JK5msecA[rIqFu928kayh + (453 - 452)] != JK5msecA[rIqFu928kayh]) || !(('A' - 'a') != (JK5msecA[rIqFu928kayh] - JK5msecA[rIqFu928kayh + (471 - 470)])) || !(('A' - 'a') != (JK5msecA[rIqFu928kayh + (219 - 218)] - JK5msecA[rIqFu928kayh])))
                OZX94nIzoYLx = OZX94nIzoYLx +(45 - 44);
            else
                break;
        }
        if ('Z' > JK5msecA[rIqFu928kayh])
            printf ("(%c,%d)", JK5msecA[rIqFu928kayh], OZX94nIzoYLx);
        else
            printf ("(%c,%d)", (JK5msecA[rIqFu928kayh] + 'A' - 'a'), OZX94nIzoYLx);
    }
}

