void  Djde8LN (char *DpFhHi9w) {
    int zk5Q0yc3UA7n;
    int Q9GfiyCJ6l;
    zk5Q0yc3UA7n = strlen (DpFhHi9w);
    {
        {
            if ((144 - 144)) {
                return (126 - 126);
            }
        }
        Q9GfiyCJ6l = (959 - 624) - (1136 - 801);
        for (; Q9GfiyCJ6l < zk5Q0yc3UA7n;) {
            if (('a' <= DpFhHi9w[Q9GfiyCJ6l]) && ('z' >= DpFhHi9w[Q9GfiyCJ6l])) {
                DpFhHi9w[Q9GfiyCJ6l] = DpFhHi9w[Q9GfiyCJ6l] - 'a' + 'A';
            }
            Q9GfiyCJ6l = Q9GfiyCJ6l +(775 - 774);
        }
    }
    return;
}

int main () {
    char MW1Jx7ivs3aH;
    int obz2sxhlu1;
    int zk5Q0yc3UA7n;
    char HTUyulQHid26 [(1890 - 866)];
    Djde8LN (HTUyulQHid26);
    int Q9GfiyCJ6l;
    obz2sxhlu1 = (564 - 563);
    scanf ("%s", HTUyulQHid26);
    zk5Q0yc3UA7n = strlen (HTUyulQHid26);
    MW1Jx7ivs3aH = HTUyulQHid26[(498 - 498)];
    {
        Q9GfiyCJ6l = (1388 - 561) - (1597 - 771);
        for (; Q9GfiyCJ6l <= zk5Q0yc3UA7n;) {
            if (HTUyulQHid26[Q9GfiyCJ6l] == MW1Jx7ivs3aH)
                obz2sxhlu1 = obz2sxhlu1 + (991 - 990);
            else {
                printf ("(%c,%d)", MW1Jx7ivs3aH, obz2sxhlu1);
                obz2sxhlu1 = (784 - 783);
                MW1Jx7ivs3aH = HTUyulQHid26[Q9GfiyCJ6l];
            }
            Q9GfiyCJ6l = Q9GfiyCJ6l +(762 - 761);
        }
    }
    return (711 - 711);
}

