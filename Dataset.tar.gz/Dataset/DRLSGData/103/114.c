int main () {
    int c20OSgyUED;
    char IyC1SQrx [(1778 - 776)] = {(927 - 927)};
    int XHRrxWU;
    int ZMk8q7g;
    cin.getline (IyC1SQrx, (1258 - 257), '\n');
    {
        {
            if ((802 - 802)) {
                return (455 - 455);
            }
        }
        ZMk8q7g = (1183 - 726) - (733 - 276);
        for (; IyC1SQrx[ZMk8q7g] != (791 - 791);) {
            c20OSgyUED = (962 - 962);
            {
                XHRrxWU = ZMk8q7g;
                for (; IyC1SQrx[XHRrxWU] != (510 - 510);) {
                    if (!(IyC1SQrx[ZMk8q7g] != IyC1SQrx[XHRrxWU]) || !((IyC1SQrx[ZMk8q7g] + 'A' - 'a') != IyC1SQrx[XHRrxWU]) || !((IyC1SQrx[XHRrxWU] + 'A' - 'a') != IyC1SQrx[ZMk8q7g]))
                        c20OSgyUED = c20OSgyUED + (1001 - 1000);
                    else {
                        break;
                    }
                    XHRrxWU = XHRrxWU +(457 - 456);
                }
            }
            ZMk8q7g = XHRrxWU -(689 - 688);
            if ('z' >= IyC1SQrx[ZMk8q7g] && IyC1SQrx[ZMk8q7g] >= 'a')
                IyC1SQrx[ZMk8q7g] = IyC1SQrx[ZMk8q7g] + 'A' - 'a';
            cout << "(" << IyC1SQrx[ZMk8q7g] << "," << c20OSgyUED << ")";
            ZMk8q7g = ZMk8q7g +(792 - 791);
        }
    }
    return (750 - 750);
}

