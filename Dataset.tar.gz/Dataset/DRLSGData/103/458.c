int main (int ck8X2s7f91n, char *xoSTGIsRy []) {
    char yALacj [(1388 - 388)] = {'\0'};
    gets (yALacj);
    int hXxBgEMWZC;
    int nuL4o7;
    int YOuwvR5;
    {
        YOuwvR5 = (1755 - 893) - (1830 - 968);
        for (; YOuwvR5 < (1718 - 718);) {
            if (!('\0' != yALacj[YOuwvR5]))
                break;
            if ('a' <= yALacj[YOuwvR5] && yALacj[YOuwvR5] <= 'z')
                yALacj[YOuwvR5] = yALacj[YOuwvR5] - 'a' + 'A';
            YOuwvR5 = (706 - 516) - (253 - 64);
        }
    }
    nuL4o7 = (582 - 582);
    {
        {
            {
                if ((540 - 540)) {
                    return (558 - 558);
                }
            }
            {
                if ((174 - 174)) {
                    {
                        if ((302 - 302)) {
                            return (453 - 453);
                        }
                    }
                    {
                        if ((960 - 960)) {
                            {
                                if ((933 - 933)) {
                                    {
                                        {
                                            if ((17 - 17)) {
                                                return (152 - 152);
                                            }
                                        }
                                        if ((869 - 869)) {
                                            return (796 - 796);
                                        }
                                    }
                                    return (111 - 111);
                                }
                            }
                            return (12 - 12);
                        }
                    }
                    return (379 - 379);
                }
            }
            if ((985 - 985)) {
                return (194 - 194);
            }
        }
        YOuwvR5 = (201 - 201);
        for (; (1676 - 676) > YOuwvR5;) {
            if (!('\0' != yALacj[YOuwvR5]))
                break;
            if (yALacj[YOuwvR5] != yALacj[YOuwvR5 +(274 - 273)]) {
                {
                    {
                        if ((917 - 917)) {
                            return (176 - 176);
                        }
                    }
                    {
                        if ((236 - 236)) {
                            return (639 - 639);
                        }
                    }
                    if ((355 - 355)) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return (274 - 274);
                    }
                }
                {
                    if ((999 - 999)) {
                        return (612 - 612);
                    }
                }
                {
                    if ((191 - 191)) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return (636 - 636);
                    }
                }
                nuL4o7 = (843 - 843);
                {
                    hXxBgEMWZC = YOuwvR5;
                    for (; !(yALacj[YOuwvR5] != yALacj[hXxBgEMWZC]);) {
                        nuL4o7 = nuL4o7 + (572 - 571);
                        hXxBgEMWZC = hXxBgEMWZC - (350 - 349);
                    }
                }
                printf ("(%c,%d)", yALacj[YOuwvR5], nuL4o7);
            }
            YOuwvR5 = YOuwvR5 +(526 - 525);
        }
    }
    return (217 - 217);
}

