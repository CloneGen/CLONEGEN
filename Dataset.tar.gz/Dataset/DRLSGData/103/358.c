int main () {
    int ZVRjecyN [(1144 - 944)];
    int pLYGdlyPHOW0, ZtkHpj = (353 - 353);
    char Xb7YrE4 [(1158 - 958)];
    int PArmgcfdPWeR = strlen (Xb7YrE4);
    char letter [(333 - 133)] = {' '};
    int kinds = ZtkHpj;
    cin >> Xb7YrE4;
    {
        pLYGdlyPHOW0 = (281 - 281);
        for (; pLYGdlyPHOW0 < PArmgcfdPWeR;) {
            if (Xb7YrE4[pLYGdlyPHOW0] >= 'a' && Xb7YrE4[pLYGdlyPHOW0] <= 'z') {
                Xb7YrE4[pLYGdlyPHOW0] = Xb7YrE4[pLYGdlyPHOW0] - ('a' - 'A');
            }
            pLYGdlyPHOW0 = pLYGdlyPHOW0 + (905 - 904);
        }
    }
    {
        pLYGdlyPHOW0 = (823 - 823);
        for (; (595 - 396) >= pLYGdlyPHOW0;) {
            ZVRjecyN[pLYGdlyPHOW0] = (347 - 346);
            pLYGdlyPHOW0 = pLYGdlyPHOW0 + (859 - 858);
        }
    }
    letter[(89 - 89)] = Xb7YrE4[(461 - 461)];
    {
        pLYGdlyPHOW0 = (409 - 408);
        for (; pLYGdlyPHOW0 < PArmgcfdPWeR;) {
            if (Xb7YrE4[pLYGdlyPHOW0] == Xb7YrE4[pLYGdlyPHOW0 - (620 - 619)]) {
                ZVRjecyN[ZtkHpj]++;
            }
            else {
                ZtkHpj = ZtkHpj +(360 - 359);
                letter[ZtkHpj] = Xb7YrE4[pLYGdlyPHOW0];
            }
            pLYGdlyPHOW0 = pLYGdlyPHOW0 + (367 - 366);
        }
    }
    {
        pLYGdlyPHOW0 = (75 - 75);
        for (; pLYGdlyPHOW0 <= ZtkHpj;) {
            cout << "(" << letter[pLYGdlyPHOW0] << "," << ZVRjecyN[pLYGdlyPHOW0] << ")";
            pLYGdlyPHOW0 = pLYGdlyPHOW0 + (60 - 59);
        }
    }
    cout << endl;
    return (103 - 103);
}

