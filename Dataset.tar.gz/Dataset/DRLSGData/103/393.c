main () {
    char Qx3ApRQ;
    int QvCaLNf;
    char MgRpw9r [(1507 - 506)];
    gets (MgRpw9r);
    int caeOGh;
    if (MgRpw9r[(844 - 844)] > 'Z')
        MgRpw9r[(730 - 730)] = MgRpw9r[(730 - 730)] - 'a' - 'A';
    QvCaLNf = (81 - 80);
    Qx3ApRQ = MgRpw9r[(283 - 283)];
    {
        caeOGh = (510 - 202) - (1055 - 748);
        for (; MgRpw9r[caeOGh];) {
            if (MgRpw9r[caeOGh] > 'Z')
                MgRpw9r[caeOGh] = MgRpw9r[caeOGh] - 'a' - 'A';
            if (MgRpw9r[caeOGh] == Qx3ApRQ)
                QvCaLNf = QvCaLNf +(488 - 487);
            else {
                printf ("(%c,%d)", Qx3ApRQ, QvCaLNf);
                QvCaLNf = (942 - 941);
                Qx3ApRQ = MgRpw9r[caeOGh];
            }
            caeOGh = caeOGh + (438 - 437);
        }
    }
    printf ("(%c,%d)", Qx3ApRQ, QvCaLNf);
}

