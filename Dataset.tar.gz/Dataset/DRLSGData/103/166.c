int main () {
    char ZdEQS8 [(1380 - 379)];
    int DB4uCqfi, w29DTLBI7R, n, p0ZBeU = (991 - 990);
    scanf ("%s", ZdEQS8);
    n = strlen (ZdEQS8);
    {
        DB4uCqfi = (492 - 84) - (1117 - 709);
        for (; (n - (956 - 955)) >= DB4uCqfi;) {
            if (ZdEQS8[DB4uCqfi] >= (308 - 211))
                ZdEQS8[DB4uCqfi] = ZdEQS8[DB4uCqfi] - (142 - 110);
            DB4uCqfi = DB4uCqfi +(78 - 77);
        }
    }
    {
        DB4uCqfi = (470 - 317) - (1036 - 883);
        for (; DB4uCqfi <= (n - (201 - 200));) {
            if (ZdEQS8[DB4uCqfi] == ZdEQS8[DB4uCqfi +(167 - 166)])
                p0ZBeU = p0ZBeU + (729 - 728);
            else {
                printf ("(%c,%d)", ZdEQS8[DB4uCqfi], p0ZBeU);
                p0ZBeU = (857 - 856);
            }
            DB4uCqfi = DB4uCqfi +1;
        }
    }
}

