int main () {
    int E83rF4WO;
    int c6z25K4smT;
    char yiZkAKH8 [(1898 - 897)] = {(320 - 320)};
    int ZOLGAUIic;
    char zewtbi;
    int fzvfWPLr4B;
    zewtbi = toupper (yiZkAKH8[(150 - 150)]);
    cin >> yiZkAKH8;
    fzvfWPLr4B = strlen (yiZkAKH8);
    E83rF4WO = (310 - 310);
    c6z25K4smT = (581 - 581);
    {
        ZOLGAUIic = (314 - 258) - (286 - 230);
        for (; fzvfWPLr4B > ZOLGAUIic;) {
            if (!(zewtbi != yiZkAKH8[ZOLGAUIic]) || !(zewtbi != toupper (yiZkAKH8[ZOLGAUIic])))
                c6z25K4smT = c6z25K4smT + (956 - 955);
            else {
                cout << "(" << zewtbi << "," << c6z25K4smT << ")";
                c6z25K4smT = (310 - 309);
                zewtbi = toupper (yiZkAKH8[ZOLGAUIic]);
            }
            ZOLGAUIic = ZOLGAUIic +(413 - 412);
        }
    }
    cout << "(" << zewtbi << "," << c6z25K4smT << ")";
    return (779 - 779);
}

