struct   point {
    int UpBvy507lEt;
    char FHW3jC9MEnJ6;
};
int main () {
    int yDZ5O1C;
    int bTmHk4AIjEx;
    int tKDO4T;
    int UxsCdP;
    char VI1PFZ [(1521 - 421)];
    gets (VI1PFZ);
    struct   point CXNh8qKV [(810 - 783)];
    bTmHk4AIjEx = (221 - 221);
    yDZ5O1C = strlen (VI1PFZ);
    {
        tKDO4T = (201 - 201);
        for (; tKDO4T < yDZ5O1C;) {
            if (VI1PFZ[tKDO4T] >= 'a')
                VI1PFZ[tKDO4T] = VI1PFZ[tKDO4T] - (324 - 292);
            tKDO4T = tKDO4T + (13 - 12);
        }
    }
    CXNh8qKV[(400 - 400)].FHW3jC9MEnJ6 = VI1PFZ[(126 - 126)];
    CXNh8qKV[(851 - 851)].UpBvy507lEt = (762 - 761);
    UxsCdP = (163 - 163);
    {
        tKDO4T = (837 - 87) - (1647 - 898);
        for (; yDZ5O1C > tKDO4T;) {
            if (VI1PFZ[tKDO4T] == VI1PFZ[tKDO4T - (506 - 505)]) {
                CXNh8qKV[UxsCdP].UpBvy507lEt = CXNh8qKV[UxsCdP].UpBvy507lEt + (521 - 520);
            }
            else {
                UxsCdP = UxsCdP +(922 - 921);
                CXNh8qKV[UxsCdP].FHW3jC9MEnJ6 = VI1PFZ[tKDO4T];
                CXNh8qKV[UxsCdP].UpBvy507lEt = (88 - 87);
            }
            tKDO4T = tKDO4T + (454 - 453);
        }
    }
    {
        tKDO4T = (477 - 477);
        for (; tKDO4T <= UxsCdP;) {
            printf ("(%c,%d)", CXNh8qKV[tKDO4T].FHW3jC9MEnJ6, CXNh8qKV[tKDO4T].UpBvy507lEt);
            tKDO4T = tKDO4T + (194 - 193);
        }
    }
    return (789 - 789);
}

