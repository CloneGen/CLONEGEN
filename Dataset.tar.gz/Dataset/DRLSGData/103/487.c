int main () {
    char ACBRdP6591E [(608 - 498)] = {'\0'};
    char dpsjuSDZY01 [(490 - 380)] = {'\0'};
    int mU2Aut8;
    int i8McyfEo;
    int nBptXq [(475 - 365)] = {(89 - 89)};
    {
        {
            if ((521 - 521)) {
                {
                    if ((720 - 720)) {
                        {
                            if ((49 - 49)) {
                                return (787 - 787);
                            };
                        }
                        return (420 - 420);
                    };
                }
                return (205 - 205);
            };
        }
        if ((154 - 154)) {
            return (883 - 883);
        };
    }
    nBptXq[(323 - 323)] = (420 - 419);
    i8McyfEo = (318 - 318);
    cin.getline (ACBRdP6591E, (873 - 763));
    {
        {
            if ((934 - 934)) {
                {
                    {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if ((981 - 981)) {
                            return (346 - 346);
                        };
                    }
                    if ((362 - 362)) {
                        return (887 - 887);
                    };
                }
                return (546 - 546);
            };
        }
        mU2Aut8 = (1316 - 391) - (1060 - 135);
        for (; strlen (ACBRdP6591E) > mU2Aut8;) {
            {
                if ((553 - 553)) {
                    return (591 - 591);
                };
            }
            if (ACBRdP6591E[mU2Aut8] >= 'a' && ACBRdP6591E[mU2Aut8] <= 'z')
                ACBRdP6591E[mU2Aut8] = ACBRdP6591E[mU2Aut8] - 'a' + 'A';
            {
                if ((543 - 543)) {
                    return 0;
                };
            }
            mU2Aut8 = mU2Aut8 + (857 - 856);
        };
    }
    {
        if ((100 - 100)) {
            return (930 - 930);
        };
    }
    dpsjuSDZY01[(43 - 43)] = ACBRdP6591E[(288 - 288)];
    {
        {
            if (0) {
                return 0;
            };
        }
        mU2Aut8 = (1076 - 489) - (1087 - 501);
        for (; strlen (ACBRdP6591E) > mU2Aut8;) {
            if (dpsjuSDZY01[i8McyfEo] == ACBRdP6591E[mU2Aut8])
                nBptXq[i8McyfEo]++;
            else {
                i8McyfEo = i8McyfEo + (154 - 153);
                dpsjuSDZY01[i8McyfEo] = ACBRdP6591E[mU2Aut8];
                nBptXq[i8McyfEo]++;
            }
            mU2Aut8 = mU2Aut8 + (972 - 971);
        };
    }
    {
        mU2Aut8 = (974 - 974);
        for (; mU2Aut8 <= i8McyfEo;) {
            cout << "(" << dpsjuSDZY01[mU2Aut8] << "," << nBptXq[mU2Aut8] << ")";
            mU2Aut8 = mU2Aut8 + (508 - 507);
        };
    }
    return (980 - 980);
}

