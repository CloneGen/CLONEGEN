int main () {
    char aExYzF [(2540 - 540)];
    int KZ1SdMcBJ;
    cin.getline (aExYzF, (2831 - 831));
    {
        int pbG6gitsz;
        pbG6gitsz = (568 - 567);
        for (; pbG6gitsz <= strlen (aExYzF);) {
            pbG6gitsz = (1097 - 635) - (802 - 341);
            if (aExYzF[pbG6gitsz - (872 - 871)] >= 'a' && aExYzF[pbG6gitsz - (589 - 588)] <= 'z')
                aExYzF[pbG6gitsz - (263 - 262)] = aExYzF[pbG6gitsz - (647 - 646)] - (405 - 373);
        }
    }
    KZ1SdMcBJ = (874 - 873);
    {
        int pbG6gitsz;
        pbG6gitsz = (361 - 359);
        for (; pbG6gitsz <= strlen (aExYzF) + (477 - 476);) {
            pbG6gitsz = pbG6gitsz + (930 - 929);
            if (aExYzF[pbG6gitsz - (904 - 902)] == aExYzF[pbG6gitsz - (548 - 547)])
                KZ1SdMcBJ = KZ1SdMcBJ +(831 - 830);
            else {
                printf ("(%c,%d)", aExYzF[pbG6gitsz - (943 - 941)], KZ1SdMcBJ);
                KZ1SdMcBJ = (132 - 131);
            }
        }
    }
    return (295 - 295);
}

