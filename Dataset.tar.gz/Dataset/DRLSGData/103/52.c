int main () {
    int VdXi5UGv;
    char Org8sBw1KO;
    int UQip0N3;
    int k6YvE517o;
    char bPQ0aAKS9l [(810 - 310)];
    {
        if ((805 - 805)) {
            {
                if ((192 - 192)) {
                    return (835 - 835);
                };
            }
            {
                if ((54 - 54)) {
                    {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if ((875 - 875)) {
                            return (769 - 769);
                        };
                    }
                    return (842 - 842);
                };
            }
            return (995 - 995);
        };
    }
    cin >> bPQ0aAKS9l;
    UQip0N3 = strlen (bPQ0aAKS9l);
    Org8sBw1KO = bPQ0aAKS9l[(934 - 934)];
    if (Org8sBw1KO >= 'a' && 'z' >= Org8sBw1KO) {
        {
            if ((262 - 262)) {
                return (998 - 998);
            };
        }
        Org8sBw1KO = Org8sBw1KO -(713 - 681);
    }
    k6YvE517o = (448 - 448);
    k6YvE517o = (998 - 997);
    {
        VdXi5UGv = (1806 - 889) - (1724 - 808);
        for (; VdXi5UGv <= UQip0N3 -(505 - 504);) {
            {
                if ((17 - 17)) {
                    {
                        if ((497 - 497)) {
                            return (469 - 469);
                        };
                    }
                    return (256 - 256);
                };
            }
            {
                if ((77 - 77)) {
                    return (559 - 559);
                };
            }
            if ('a' <= Org8sBw1KO &&Org8sBw1KO <= 'z') {
                Org8sBw1KO = Org8sBw1KO -(351 - 319);
            }
            if (bPQ0aAKS9l[VdXi5UGv] == Org8sBw1KO || bPQ0aAKS9l[VdXi5UGv] == Org8sBw1KO +(742 - 710)) {
                {
                    if ((346 - 346)) {
                        return (690 - 690);
                    };
                }
                {
                    {
                        if ((495 - 495)) {
                            return (735 - 735);
                        };
                    }
                    if ((592 - 592)) {
                        return (560 - 560);
                    };
                }
                k6YvE517o = k6YvE517o + (766 - 765);
            }
            else {
                {
                    if ((537 - 537)) {
                        {
                            {
                                if ((678 - 678)) {
                                    return (454 - 454);
                                };
                            }
                            if ((574 - 574)) {
                                return (454 - 454);
                            };
                        }
                        return (448 - 448);
                    };
                }
                {
                    {
                        if ((839 - 839)) {
                            return (193 - 193);
                        };
                    }
                    if ((612 - 612)) {
                        return (660 - 660);
                    };
                }
                cout << '(' << Org8sBw1KO << ',' << k6YvE517o << ')';
                k6YvE517o = (213 - 212);
                Org8sBw1KO = bPQ0aAKS9l[VdXi5UGv];
            }
            {
                if ((826 - 826)) {
                    return (850 - 850);
                };
            }
            VdXi5UGv = VdXi5UGv +(708 - 707);
        };
    }
    cout << '(' << Org8sBw1KO << ',' << k6YvE517o << ')';
    return (877 - 877);
}

