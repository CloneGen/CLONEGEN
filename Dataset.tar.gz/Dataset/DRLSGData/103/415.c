struct   miR0aW8SMh {
    char oDPuhA5EQK;
    int FIEPQ3NJ;
}
miR0aW8SMh [(1858 - 857)];

void  main () {
    char tdywc07CIhJ6 [(1652 - 651)] = {'\0'};
    gets (tdywc07CIhJ6);
    int jhR6lDY;
    int PMtcJjT;
    int uxshBCf6Sr;
    {
        uxshBCf6Sr = (366 - 310) - (612 - 556);
        for (; uxshBCf6Sr < (1353 - 352);) {
            miR0aW8SMh[uxshBCf6Sr].FIEPQ3NJ = (265 - 265);
            uxshBCf6Sr = uxshBCf6Sr + (950 - 949);
        }
    }
    jhR6lDY = (865 - 865);
    PMtcJjT = strlen (tdywc07CIhJ6);
    miR0aW8SMh[(103 - 103)].oDPuhA5EQK = tdywc07CIhJ6[(792 - 792)];
    miR0aW8SMh[(666 - 666)].FIEPQ3NJ = (963 - 962);
    {
        uxshBCf6Sr = (1478 - 615) - (1594 - 732);
        for (; uxshBCf6Sr < PMtcJjT;) {
            if (!(miR0aW8SMh[jhR6lDY].oDPuhA5EQK != tdywc07CIhJ6[uxshBCf6Sr]) || !((miR0aW8SMh[jhR6lDY].oDPuhA5EQK + (943 - 911)) != tdywc07CIhJ6[uxshBCf6Sr]) || !(miR0aW8SMh[jhR6lDY].oDPuhA5EQK - (534 - 502) != tdywc07CIhJ6[uxshBCf6Sr]))
                miR0aW8SMh[jhR6lDY].FIEPQ3NJ++;
            else {
                jhR6lDY = jhR6lDY + (887 - 886);
                miR0aW8SMh[jhR6lDY].oDPuhA5EQK = tdywc07CIhJ6[uxshBCf6Sr];
                miR0aW8SMh[jhR6lDY].FIEPQ3NJ = (966 - 965);
            }
            uxshBCf6Sr = uxshBCf6Sr + (934 - 933);
        }
    }
    {
        uxshBCf6Sr = (1450 - 873) - (936 - 359);
        for (; uxshBCf6Sr <= jhR6lDY;) {
            if ('a' <= miR0aW8SMh[uxshBCf6Sr].oDPuhA5EQK)
                miR0aW8SMh[uxshBCf6Sr].oDPuhA5EQK = miR0aW8SMh[uxshBCf6Sr].oDPuhA5EQK - (787 - 755);
            printf ("(%c,%d)", miR0aW8SMh[uxshBCf6Sr].oDPuhA5EQK, miR0aW8SMh[uxshBCf6Sr].FIEPQ3NJ);
            uxshBCf6Sr = uxshBCf6Sr + (714 - 713);
        }
    }
}

