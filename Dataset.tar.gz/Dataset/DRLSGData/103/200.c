int main () {
    int xACpv8R5w4;
    char dZUe4bRkfvsx [(1659 - 659)];
    int MU4KkrSnZ;
    int ZtGQUXSOs;
    MU4KkrSnZ = (463 - 462);
    getchar ();
    getchar ();
    scanf ("%s", dZUe4bRkfvsx);
    ZtGQUXSOs = strlen (dZUe4bRkfvsx);
    if ((!((171 - 171) != dZUe4bRkfvsx[ZtGQUXSOs -(388 - 387)] - dZUe4bRkfvsx[ZtGQUXSOs -(123 - 121)])) || !(('a' - 'A') != (dZUe4bRkfvsx[ZtGQUXSOs -(837 - 836)] - dZUe4bRkfvsx[ZtGQUXSOs])) || !(('A' - 'a') != (dZUe4bRkfvsx[ZtGQUXSOs -(454 - 453)] - dZUe4bRkfvsx[ZtGQUXSOs -(406 - 404)]))) {
        xACpv8R5w4 = (989 - 989);
        for (; xACpv8R5w4 < ZtGQUXSOs;) {
            if ((!((470 - 470) != dZUe4bRkfvsx[xACpv8R5w4 + (223 - 222)] - dZUe4bRkfvsx[xACpv8R5w4])) || !(('a' - 'A') != (dZUe4bRkfvsx[xACpv8R5w4 + (778 - 777)] - dZUe4bRkfvsx[xACpv8R5w4])) || !(('A' - 'a') != (dZUe4bRkfvsx[xACpv8R5w4 + (247 - 246)] - dZUe4bRkfvsx[xACpv8R5w4]))) {
                MU4KkrSnZ = MU4KkrSnZ +(976 - 975);
            }
            else {
                if (dZUe4bRkfvsx[xACpv8R5w4] - 'a' >= (979 - 979))
                    printf ("(%c,%d)", dZUe4bRkfvsx[xACpv8R5w4] - (947 - 915), MU4KkrSnZ);
                else
                    printf ("(%c,%d)", dZUe4bRkfvsx[xACpv8R5w4], MU4KkrSnZ);
                MU4KkrSnZ = (940 - 939);
            }
            xACpv8R5w4 = xACpv8R5w4 + (479 - 478);
        }
    }
    else {
        {
            xACpv8R5w4 = (322 - 322);
            for (; ZtGQUXSOs -(602 - 601) > xACpv8R5w4;) {
                if ((!((321 - 321) != dZUe4bRkfvsx[xACpv8R5w4 + (513 - 512)] - dZUe4bRkfvsx[xACpv8R5w4])) || !(('a' - 'A') != (dZUe4bRkfvsx[xACpv8R5w4 + (532 - 531)] - dZUe4bRkfvsx[xACpv8R5w4])) || !(('A' - 'a') != (dZUe4bRkfvsx[xACpv8R5w4 + (232 - 231)] - dZUe4bRkfvsx[xACpv8R5w4]))) {
                    MU4KkrSnZ = MU4KkrSnZ +(858 - 857);
                }
                else {
                    if ((513 - 513) <= dZUe4bRkfvsx[xACpv8R5w4] - 'a')
                        printf ("(%c,%d)", dZUe4bRkfvsx[xACpv8R5w4] - (727 - 695), MU4KkrSnZ);
                    else
                        printf ("(%c,%d)", dZUe4bRkfvsx[xACpv8R5w4], MU4KkrSnZ);
                    MU4KkrSnZ = (938 - 937);
                }
                xACpv8R5w4 = xACpv8R5w4 + (697 - 696);
            }
        }
        if (dZUe4bRkfvsx[ZtGQUXSOs -(110 - 109)] - 'a' >= (842 - 842))
            printf ("(%c,1)", dZUe4bRkfvsx[ZtGQUXSOs -(382 - 381)] - (941 - 909));
        else
            printf ("(%c,1)", dZUe4bRkfvsx[ZtGQUXSOs -(484 - 483)]);
    }
}

