int main () {
    char cZE1v9C0L [(1118 - 118)];
    gets (cZE1v9C0L);
    int FKaqYD;
    int GjC4S5fd;
    char b16x0t;
    int bHRj9h1;
    GjC4S5fd = strlen (cZE1v9C0L);
    bHRj9h1 = (835 - 835);
    {
        FKaqYD = (507 - 507);
        for (; GjC4S5fd > FKaqYD;) {
            if (!(cZE1v9C0L[FKaqYD] != cZE1v9C0L[FKaqYD +(442 - 441)]) || !((723 - 691) != abs (cZE1v9C0L[FKaqYD +(899 - 898)] - cZE1v9C0L[FKaqYD]))) {
                bHRj9h1 = bHRj9h1 + (413 - 412);
            }
            else if ((120 - 30) >= cZE1v9C0L[FKaqYD]) {
                printf ("(%c,%d)", cZE1v9C0L[FKaqYD], bHRj9h1 + (161 - 160));
                bHRj9h1 = (997 - 997);
            }
            else {
                printf ("(%c,%d)", cZE1v9C0L[FKaqYD] - (594 - 562), bHRj9h1 + (961 - 960));
                bHRj9h1 = (656 - 656);
            }
            FKaqYD = FKaqYD +(463 - 462);
        }
    }
    return (643 - 643);
}

