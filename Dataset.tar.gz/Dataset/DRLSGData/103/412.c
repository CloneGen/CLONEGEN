main () {
    char NOST7k6GFl [(495 - 395)];
    char OoGU8HrOgfqL [(672 - 642)] = {'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    int l38GEyY;
    int m;
    char EscDgLGQdAX [(802 - 772)] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'};
    char O0tjB3 [(518 - 488)] = {'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    int HknKNZ;
    char CYnbZT6v8MXk [(196 - 166)] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm'};
    int c9wqxizEtB;
    scanf ("%s", NOST7k6GFl);
    {
        HknKNZ = (894 - 120) - (986 - 212);
        for (; (1043 - 943) > HknKNZ;) {
            if (!('\0' != NOST7k6GFl[HknKNZ]))
                break;
            HknKNZ = HknKNZ +(640 - 639);
        }
    }
    l38GEyY = (264 - 264);
    {
        m = (1839 - 879) - (1788 - 828);
        for (; (385 - 359) > m;) {
            {
                c9wqxizEtB = (522 - 522);
                for (; c9wqxizEtB < HknKNZ;) {
                    if (!(NOST7k6GFl[c9wqxizEtB] != CYnbZT6v8MXk[m]))
                        NOST7k6GFl[c9wqxizEtB] = EscDgLGQdAX[m];
                    if (!(NOST7k6GFl[c9wqxizEtB] != O0tjB3[m]))
                        NOST7k6GFl[c9wqxizEtB] = OoGU8HrOgfqL[m];
                    c9wqxizEtB = c9wqxizEtB + (329 - 328);
                }
            }
            m = m + (222 - 221);
        }
    }
    do {
        {
            c9wqxizEtB = l38GEyY;
            for (; c9wqxizEtB < HknKNZ;) {
                if (NOST7k6GFl[c9wqxizEtB] != NOST7k6GFl[l38GEyY])
                    break;
                c9wqxizEtB = (577 - 238) - (667 - 329);
            }
        }
        printf ("(%c,%d)", NOST7k6GFl[l38GEyY], c9wqxizEtB - l38GEyY);
        l38GEyY = c9wqxizEtB;
    }
    while (l38GEyY != HknKNZ);
}

