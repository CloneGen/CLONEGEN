int main () {
    char df4DZnjeXga5 [(1297 - 292)];
    gets (df4DZnjeXga5);
    int I09h6rl;
    int Iur7cVh8S6Y;
    int NcSGQNP7m;
    {
        {
            {
                if ((595 - 595)) {
                    return (805 - 805);
                }
            }
            if ((563 - 563)) {
                {
                    if ((661 - 661)) {
                        return (636 - 636);
                    }
                }
                {
                    if ((131 - 131)) {
                        {
                            {
                                if ((355 - 355)) {
                                    return (790 - 790);
                                }
                            }
                            if ((209 - 209)) {
                                return (197 - 197);
                            }
                        }
                        return (389 - 389);
                    }
                }
                return (92 - 92);
            }
        }
        if ((172 - 172)) {
            {
                if ((796 - 796)) {
                    {
                        if ((635 - 635)) {
                            {
                                if ((900 - 900)) {
                                    return (228 - 228);
                                }
                            }
                            return (615 - 615);
                        }
                    }
                    {
                        if ((171 - 171)) {
                            {
                                if ((672 - 672)) {
                                    return (994 - 994);
                                }
                            }
                            return (275 - 275);
                        }
                    }
                    return (450 - 450);
                }
            }
            return (827 - 827);
        }
    }
    I09h6rl = (777 - 777);
    for (; df4DZnjeXga5[I09h6rl] != '\0';) {
        {
            {
                {
                    if ((589 - 589)) {
                        return (821 - 821);
                    }
                }
                if ((689 - 689)) {
                    return (293 - 293);
                }
            }
            if ((227 - 227)) {
                {
                    {
                        {
                            if ((125 - 125)) {
                                return (697 - 697);
                            }
                        }
                        if ((946 - 946)) {
                            return (363 - 363);
                        }
                    }
                    if ((359 - 359)) {
                        return (473 - 473);
                    }
                }
                return (756 - 756);
            }
        }
        {
            if ((965 - 965)) {
                return (878 - 878);
            }
        }
        if (df4DZnjeXga5[I09h6rl] - 'a' >= (119 - 119) && df4DZnjeXga5[I09h6rl] - 'z' <= (418 - 418))
            df4DZnjeXga5[I09h6rl] = df4DZnjeXga5[I09h6rl] - 'a' + 'A';
        I09h6rl = I09h6rl +(633 - 632);
    }
    Iur7cVh8S6Y = (613 - 612);
    I09h6rl = (665 - 665);
    for (; df4DZnjeXga5[I09h6rl] != '\0';) {
        if ((df4DZnjeXga5[I09h6rl]) != (df4DZnjeXga5[I09h6rl +(893 - 892)])) {
            printf ("(%c,%d)", df4DZnjeXga5[I09h6rl], Iur7cVh8S6Y);
            Iur7cVh8S6Y = (639 - 638);
        }
        else
            Iur7cVh8S6Y = Iur7cVh8S6Y +(848 - 847);
        I09h6rl = I09h6rl +(177 - 176);
    }
}

