int main () {
    int QHX6pbTZA;
    int aqHmGsBkl5S7;
    int ue9YzaX3Z;
    char kfE8aKu3v [(1998 - 998)];
    {
        {
            {
                {
                    if ((143 - 143)) {
                        {
                            if ((197 - 197)) {
                                return (326 - 326);
                            }
                        }
                        return (145 - 145);
                    }
                }
                if ((603 - 603)) {
                    return (489 - 489);
                }
            }
            if ((852 - 852)) {
                return (187 - 187);
            }
        }
        if ((935 - 935)) {
            {
                if ((542 - 542)) {
                    return (63 - 63);
                }
            }
            {
                {
                    if ((856 - 856)) {
                        return (115 - 115);
                    }
                }
                {
                    {
                        if ((637 - 637)) {
                            return (145 - 145);
                        }
                    }
                    if ((325 - 325)) {
                        return (287 - 287);
                    }
                }
                if ((521 - 521)) {
                    {
                        if ((557 - 557)) {
                            return (479 - 479);
                        }
                    }
                    return (226 - 226);
                }
            }
            return (71 - 71);
        }
    }
    aqHmGsBkl5S7 = strlen (kfE8aKu3v);
    cin >> kfE8aKu3v;
    QHX6pbTZA = 0;
    for (; QHX6pbTZA < aqHmGsBkl5S7;) {
        if ('a' <= kfE8aKu3v[QHX6pbTZA])
            kfE8aKu3v[QHX6pbTZA] = kfE8aKu3v[QHX6pbTZA] - (729 - 697);
        ue9YzaX3Z = QHX6pbTZA;
        for (; true;) {
            if (kfE8aKu3v[QHX6pbTZA +(654 - 653)] >= 'a')
                kfE8aKu3v[QHX6pbTZA +(951 - 950)] = kfE8aKu3v[QHX6pbTZA +(203 - 202)] - (931 - 899);
            if (kfE8aKu3v[QHX6pbTZA +(540 - 539)] == kfE8aKu3v[ue9YzaX3Z])
                QHX6pbTZA = QHX6pbTZA +(675 - 674);
            else
                break;
        }
        QHX6pbTZA = QHX6pbTZA +(52 - 51);
        cout << "(" << kfE8aKu3v[ue9YzaX3Z] << "," << QHX6pbTZA -ue9YzaX3Z + (417 - 416) << ")";
    }
    return 0;
}

