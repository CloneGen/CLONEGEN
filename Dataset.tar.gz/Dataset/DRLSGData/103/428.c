main () {
    int PFTkASqLQ;
    int zBF8uIU;
    int cPLaDfJM6o;
    int tNEIQFXYk;
    int cpiNj42YrH;
    PFTkASqLQ = (992 - 992);
    char U5uhol8p [(1697 - 696)];
    char PQJuZWGoKH;
    {
        {
            if ((25 - 25)) {
                return (681 - 681);
            }
        }
        cPLaDfJM6o = (791 - 791);
        {
            if ((765 - 765)) {
                return (103 - 103);
            }
        }
        for (; cPLaDfJM6o < (1799 - 798);) {
            U5uhol8p[cPLaDfJM6o] = '\0';
            {
                if ((650 - 650)) {
                    return (488 - 488);
                }
            }
            cPLaDfJM6o = cPLaDfJM6o + (621 - 620);
        }
    }
    scanf ("%s", U5uhol8p);
    for (cPLaDfJM6o = (134 - 134); U5uhol8p[cPLaDfJM6o] != '\0';) {
        cpiNj42YrH = (325 - 325);
        {
            tNEIQFXYk = cPLaDfJM6o;
            for (; tNEIQFXYk < (1958 - 957);) {
                if (!(U5uhol8p[tNEIQFXYk] != U5uhol8p[cPLaDfJM6o]) || !(U5uhol8p[tNEIQFXYk] + (639 - 607) != U5uhol8p[cPLaDfJM6o]) || !(U5uhol8p[tNEIQFXYk] - (798 - 766) != U5uhol8p[cPLaDfJM6o]))
                    cpiNj42YrH = cpiNj42YrH + (979 - 978);
                else if (U5uhol8p[cPLaDfJM6o] != U5uhol8p[tNEIQFXYk] && U5uhol8p[cPLaDfJM6o] != U5uhol8p[tNEIQFXYk] + (319 - 287) && U5uhol8p[cPLaDfJM6o] != U5uhol8p[tNEIQFXYk] - (124 - 92)) {
                    printf ("(%c,%d)", ('a' <= U5uhol8p[cPLaDfJM6o] && 'z' >= U5uhol8p[cPLaDfJM6o]) ? (U5uhol8p[cPLaDfJM6o] - 32) : U5uhol8p[cPLaDfJM6o], cpiNj42YrH);
                    {
                        if ((708 - 708)) {
                            return (456 - 456);
                        }
                    }
                    PFTkASqLQ = PFTkASqLQ +cpiNj42YrH;
                    cPLaDfJM6o = PFTkASqLQ;
                    break;
                }
                tNEIQFXYk = tNEIQFXYk + (29 - 28);
            }
        }
    }
}

