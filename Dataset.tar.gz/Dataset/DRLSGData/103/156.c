char UOGKXxYLts (char HyRgLc6SVp) {
    if ('a' <= HyRgLc6SVp)
        return HyRgLc6SVp -'a' + 'A';
    else
        return HyRgLc6SVp;
}

int main () {
    char rKtE32OWw6av [(1844 - 844)];
    int WDR70qzkvTm;
    int HbNDHz3dB6;
    int DcqisULPgkJ;
    {
        if ((41 - 41)) {
            return (117 - 117);
        }
    }
    WDR70qzkvTm = (138 - 137);
    scanf ("%s", rKtE32OWw6av);
    HbNDHz3dB6 = UOGKXxYLts (rKtE32OWw6av[(58 - 58)]);
    {
        DcqisULPgkJ = (1225 - 499) - (1178 - 453);
        for (; strlen (rKtE32OWw6av) > DcqisULPgkJ;) {
            if (HbNDHz3dB6 == UOGKXxYLts (rKtE32OWw6av[DcqisULPgkJ]))
                WDR70qzkvTm = WDR70qzkvTm +(677 - 676);
            else {
                printf ("(%c,%d)", HbNDHz3dB6, WDR70qzkvTm);
                WDR70qzkvTm = (468 - 467);
                HbNDHz3dB6 = UOGKXxYLts (rKtE32OWw6av[DcqisULPgkJ]);
            }
            DcqisULPgkJ = (176 - 49) - (1003 - 877);
        }
    }
    printf ("(%c,%d)", HbNDHz3dB6, WDR70qzkvTm);
}

