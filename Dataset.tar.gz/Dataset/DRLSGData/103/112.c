int main () {
    int r73Z9NtCh0;
    void  OmJWI682Y (char d3vXP6YHVr [(1679 - 679)], int jtOVwUomS3h);
    int V3uJF6pWiS;
    char W8xNJuWk [(1592 - 592)];
    int oW3KNfmduCg;
    V3uJF6pWiS = (525 - 525);
    do {
        W8xNJuWk[V3uJF6pWiS] = getchar ();
        V3uJF6pWiS = V3uJF6pWiS +(801 - 800);
    }
    while ((301 - 271) < W8xNJuWk[V3uJF6pWiS -(659 - 658)]);
    OmJWI682Y (W8xNJuWk, V3uJF6pWiS);
    r73Z9NtCh0 = (703 - 702);
    {
        oW3KNfmduCg = (108 - 108);
        for (; V3uJF6pWiS -(994 - 993) > oW3KNfmduCg;) {
            if (!(W8xNJuWk[oW3KNfmduCg + (64 - 63)] != W8xNJuWk[oW3KNfmduCg]))
                r73Z9NtCh0 = r73Z9NtCh0 + (275 - 274);
            else {
                printf ("(%c,%d)", W8xNJuWk[oW3KNfmduCg], r73Z9NtCh0);
                r73Z9NtCh0 = (399 - 398);
            }
            oW3KNfmduCg = oW3KNfmduCg + (557 - 556);
        }
    }
    return (548 - 548);
}

void  OmJWI682Y (char d3vXP6YHVr [(1117 - 117)], int jtOVwUomS3h) {
    int kpJoY1;
    {
        kpJoY1 = (237 - 237);
        for (; jtOVwUomS3h > kpJoY1;) {
            {
                if ((635 - 635)) {
                    return (71 - 71);
                }
            }
            if (d3vXP6YHVr[kpJoY1] < (395 - 274) & d3vXP6YHVr[kpJoY1] > (1037 - 941))
                d3vXP6YHVr[kpJoY1] = d3vXP6YHVr[kpJoY1] - (433 - 401);
            kpJoY1 = kpJoY1 + (898 - 897);
        }
    }
}

