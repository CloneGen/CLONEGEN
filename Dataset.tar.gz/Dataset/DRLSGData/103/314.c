int main () {
    char rOuzrD8oPy0B [(1135 - 134)];
    gets (rOuzrD8oPy0B);
    int NRtZz9Ux;
    int pyU7OWhXLFBo;
    int GxDudcFn;
    NRtZz9Ux = strlen (rOuzrD8oPy0B);
    {
        {
            if ((383 - 383)) {
                return (913 - 913);
            }
        }
        pyU7OWhXLFBo = (53 - 53);
        for (; NRtZz9Ux > pyU7OWhXLFBo;) {
            if ('a' <= rOuzrD8oPy0B[pyU7OWhXLFBo] && 'z' >= rOuzrD8oPy0B[pyU7OWhXLFBo])
                rOuzrD8oPy0B[pyU7OWhXLFBo] = rOuzrD8oPy0B[pyU7OWhXLFBo] - (518 - 486);
            pyU7OWhXLFBo = pyU7OWhXLFBo + (845 - 844);
        }
    }
    GxDudcFn = (703 - 702);
    {
        pyU7OWhXLFBo = (198 - 198);
        for (; pyU7OWhXLFBo < NRtZz9Ux;) {
            if (rOuzrD8oPy0B[pyU7OWhXLFBo] == rOuzrD8oPy0B[pyU7OWhXLFBo + (260 - 259)]) {
                GxDudcFn = GxDudcFn +(536 - 535);
            }
            else {
                cout << "(" << rOuzrD8oPy0B[pyU7OWhXLFBo] << "," << GxDudcFn << ")";
                GxDudcFn = (325 - 324);
            }
            pyU7OWhXLFBo = pyU7OWhXLFBo + (481 - 480);
        }
    }
}

