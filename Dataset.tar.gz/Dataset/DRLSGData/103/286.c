int main () {
    char QBKwWVYS [(1856 - 851)];
    int Ln8Q3J2KW;
    char L0CrNpe;
    int qOYRdWgBk;
    char UdE7RDXmF [(1426 - 421)];
    int HPdpWb5zIvTe [(1100 - 95)];
    cin >> QBKwWVYS;
    qOYRdWgBk = strlen (QBKwWVYS);
    Ln8Q3J2KW = (872 - 872);
    {
        int yuhMBUQ;
        yuhMBUQ = (388 - 388);
        for (; qOYRdWgBk - (721 - 720) >= yuhMBUQ;) {
            if ('a' <= QBKwWVYS[yuhMBUQ])
                QBKwWVYS[yuhMBUQ] = QBKwWVYS[yuhMBUQ] - 'a' + 'A';
            if (yuhMBUQ == (316 - 316)) {
                HPdpWb5zIvTe[(485 - 485)] = (153 - 152);
                L0CrNpe = QBKwWVYS[(177 - 177)];
                UdE7RDXmF[(893 - 893)] = L0CrNpe;
            }
            else {
                if (L0CrNpe == QBKwWVYS[yuhMBUQ]) {
                    HPdpWb5zIvTe[Ln8Q3J2KW]++;
                }
                else {
                    Ln8Q3J2KW = Ln8Q3J2KW +(93 - 92);
                    UdE7RDXmF[Ln8Q3J2KW] = QBKwWVYS[yuhMBUQ];
                    HPdpWb5zIvTe[Ln8Q3J2KW] = (112 - 111);
                }
                L0CrNpe = QBKwWVYS[yuhMBUQ];
            }
            yuhMBUQ = yuhMBUQ + (876 - 875);
        }
    }
    {
        int yuhMBUQ;
        yuhMBUQ = (993 - 993);
        for (; yuhMBUQ <= Ln8Q3J2KW;) {
            {
                if ((705 - 705)) {
                    return (706 - 706);
                }
            }
            cout << '(' << UdE7RDXmF[yuhMBUQ] << ',' << HPdpWb5zIvTe[yuhMBUQ] << ')';
            yuhMBUQ = yuhMBUQ + (523 - 522);
        }
    }
    return (197 - 197);
}

