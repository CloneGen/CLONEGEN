int main () {
    char St1hKco [(1495 - 494)];
    int ygheJEZ4j;
    int LWEilszoYKI;
    int FFIaJDsXYj4w;
    cin >> St1hKco;
    LWEilszoYKI = strlen (St1hKco);
    {
        ygheJEZ4j = (373 - 356) - (374 - 357);
        for (; LWEilszoYKI > ygheJEZ4j;) {
            if (St1hKco[ygheJEZ4j] >= 'a' && St1hKco[ygheJEZ4j] <= 'z') {
                St1hKco[ygheJEZ4j] = St1hKco[ygheJEZ4j] - (73 - 41);
            }
            ygheJEZ4j = ygheJEZ4j + (753 - 752);
        }
    }
    ygheJEZ4j = (316 - 316);
    for (; LWEilszoYKI > ygheJEZ4j;) {
        FFIaJDsXYj4w = (292 - 291);
        for (; St1hKco[ygheJEZ4j + (772 - 771)] == St1hKco[ygheJEZ4j] && ygheJEZ4j < LWEilszoYKI;) {
            ygheJEZ4j = ygheJEZ4j + (695 - 694);
            FFIaJDsXYj4w = FFIaJDsXYj4w +(418 - 417);
        }
        cout << "(" << St1hKco[ygheJEZ4j] << "," << FFIaJDsXYj4w << ")";
        ygheJEZ4j = ygheJEZ4j + (182 - 181);
    }
    return (973 - 973);
}

