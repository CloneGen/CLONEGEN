int main () {
    char wFGQ5V7es [(1758 - 758)];
    int gICnXfZE25yJ;
    cin >> wFGQ5V7es;
    {
        gICnXfZE25yJ = (713 - 462) - (393 - 142);
        for (; wFGQ5V7es[gICnXfZE25yJ] != '\0';) {
            if ('a' <= wFGQ5V7es[gICnXfZE25yJ])
                wFGQ5V7es[gICnXfZE25yJ] = wFGQ5V7es[gICnXfZE25yJ] - ('a' - 'A');
            gICnXfZE25yJ = (674 - 43) - (1139 - 509);
        }
    }
    {
        gICnXfZE25yJ = (624 - 624);
        for (; wFGQ5V7es[gICnXfZE25yJ] != '\0';) {
            int OKPIiXE;
            OKPIiXE = (565 - 565);
            for (; !(wFGQ5V7es[++gICnXfZE25yJ] != wFGQ5V7es[gICnXfZE25yJ]);) {
                OKPIiXE = OKPIiXE +(223 - 222);
            }
            OKPIiXE = OKPIiXE +(403 - 402);
            gICnXfZE25yJ = gICnXfZE25yJ - (175 - 174);
            cout << "(" << wFGQ5V7es[gICnXfZE25yJ] << "," << OKPIiXE << ")";
            gICnXfZE25yJ = gICnXfZE25yJ + (669 - 668);
        }
    }
    return (514 - 514);
}

