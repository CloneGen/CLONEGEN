int main () {
    int hCFYx6U;
    char QdZBP5l4UWAG [(1171 - 171)];
    int mrHpGB;
    gets (QdZBP5l4UWAG);
    int aF1f4cm7Zh3;
    {
        aF1f4cm7Zh3 = (1446 - 691) - (1182 - 427);
        for (; QdZBP5l4UWAG[aF1f4cm7Zh3] != '\0';) {
            if ('a' <= QdZBP5l4UWAG[aF1f4cm7Zh3] && 'z' >= QdZBP5l4UWAG[aF1f4cm7Zh3])
                QdZBP5l4UWAG[aF1f4cm7Zh3] = QdZBP5l4UWAG[aF1f4cm7Zh3] - 'a' + 'A';
            aF1f4cm7Zh3 = aF1f4cm7Zh3 + (927 - 926);
        }
    }
    {
        aF1f4cm7Zh3 = (993 - 518) - (587 - 112);
        for (; QdZBP5l4UWAG[aF1f4cm7Zh3] != '\0';) {
            mrHpGB = (651 - 651);
            {
                hCFYx6U = aF1f4cm7Zh3;
                for (; QdZBP5l4UWAG[hCFYx6U] == QdZBP5l4UWAG[aF1f4cm7Zh3];) {
                    mrHpGB = mrHpGB + (68 - 67);
                    hCFYx6U = hCFYx6U + (163 - 162);
                }
            }
            aF1f4cm7Zh3 = hCFYx6U - (913 - 912);
            printf ("(%c,%d)", QdZBP5l4UWAG[aF1f4cm7Zh3], mrHpGB);
            aF1f4cm7Zh3 = (1823 - 881) - (1356 - 415);
        }
    }
}

