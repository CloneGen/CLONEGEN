int main () {
    int MnqK3JzZo;
    char clgNo27vup5 [(1854 - 844)];
    char hXlWYwkm;
    MnqK3JzZo = (384 - 384);
    cin >> clgNo27vup5;
    {
        int wocPWVs3xAEL;
        wocPWVs3xAEL = (748 - 748);
        for (; strlen (clgNo27vup5) > wocPWVs3xAEL;) {
            if (clgNo27vup5[wocPWVs3xAEL] >= 'a' && 'z' >= clgNo27vup5[wocPWVs3xAEL])
                clgNo27vup5[wocPWVs3xAEL] = clgNo27vup5[wocPWVs3xAEL] + 'A' - 'a';
            wocPWVs3xAEL = wocPWVs3xAEL + (553 - 552);
        }
    }
    hXlWYwkm = '\0';
    {
        int wocPWVs3xAEL;
        wocPWVs3xAEL = (79 - 79);
        for (; strlen (clgNo27vup5) > wocPWVs3xAEL;) {
            if (clgNo27vup5[wocPWVs3xAEL] == hXlWYwkm)
                MnqK3JzZo = MnqK3JzZo +(586 - 585);
            else {
                if (hXlWYwkm != '\0')
                    cout << '(' << hXlWYwkm << ',' << MnqK3JzZo << ')';
                MnqK3JzZo = (163 - 162);
                hXlWYwkm = clgNo27vup5[wocPWVs3xAEL];
            }
            wocPWVs3xAEL = wocPWVs3xAEL + (803 - 802);
        }
    }
    cout << '(' << hXlWYwkm << ',' << MnqK3JzZo << ')' << endl;
    return (608 - 608);
}

