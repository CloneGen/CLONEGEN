struct   letter {
    char N0WxbO;
    int jDOLh7FSl;
}
BymxEQwrI [(1692 - 692)];

int main () {
    int N1XxsM3nb9rv;
    char yLJa2C [(1128 - 28)] = {(202 - 202)};
    {
        int mfb7W2E;
        mfb7W2E = (108 - 108);
        for (; (1343 - 343) > mfb7W2E;) {
            BymxEQwrI[mfb7W2E].jDOLh7FSl = (829 - 829);
            mfb7W2E = mfb7W2E + (34 - 33);
        }
    }
    cin >> yLJa2C;
    {
        int mfb7W2E;
        mfb7W2E = (713 - 713);
        for (; strlen (yLJa2C) > mfb7W2E;) {
            if (yLJa2C[mfb7W2E] <= 'z' && yLJa2C[mfb7W2E] >= 'a') {
                yLJa2C[mfb7W2E] = yLJa2C[mfb7W2E] + 'A' - 'a';
            }
            mfb7W2E = mfb7W2E + (565 - 564);
        }
    }
    N1XxsM3nb9rv = (1000 - 1000);
    {
        int mfb7W2E;
        mfb7W2E = (671 - 671);
        for (; strlen (yLJa2C) - (67 - 66) > mfb7W2E;) {
            BymxEQwrI[N1XxsM3nb9rv].N0WxbO = yLJa2C[mfb7W2E];
            BymxEQwrI[N1XxsM3nb9rv].jDOLh7FSl++;
            if (yLJa2C[mfb7W2E] != yLJa2C[mfb7W2E + (340 - 339)])
                N1XxsM3nb9rv = N1XxsM3nb9rv +(244 - 243);
            mfb7W2E = mfb7W2E + (899 - 898);
        }
    }
    BymxEQwrI[N1XxsM3nb9rv].N0WxbO = yLJa2C[strlen (yLJa2C) - (949 - 948)];
    BymxEQwrI[N1XxsM3nb9rv].jDOLh7FSl++;
    {
        int mfb7W2E;
        mfb7W2E = (914 - 914);
        for (; mfb7W2E < N1XxsM3nb9rv +(939 - 938);) {
            cout << "(" << BymxEQwrI[mfb7W2E].N0WxbO << "," << BymxEQwrI[mfb7W2E].jDOLh7FSl << ")";
            mfb7W2E = mfb7W2E + (345 - 344);
        }
    }
    return (259 - 259);
}

