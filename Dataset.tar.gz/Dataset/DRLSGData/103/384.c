int main () {
    char H6NvkHnbFsJ [(1848 - 847)];
    gets (H6NvkHnbFsJ);
    int GtaFJ8P;
    int NGqU4cHvtE;
    NGqU4cHvtE = (390 - 390);
    {
        GtaFJ8P = (341 - 341);
        for (; H6NvkHnbFsJ[GtaFJ8P] != '\0';) {
            if (H6NvkHnbFsJ[GtaFJ8P] != H6NvkHnbFsJ[GtaFJ8P +(159 - 158)] && (H6NvkHnbFsJ[GtaFJ8P] - H6NvkHnbFsJ[GtaFJ8P +(410 - 409)] != 'A' - 'a' && H6NvkHnbFsJ[GtaFJ8P] - H6NvkHnbFsJ[GtaFJ8P +(654 - 653)] != -'A' + 'a')) {
                if ('a' <= H6NvkHnbFsJ[GtaFJ8P]) {
                    printf ("(%c,%d)", H6NvkHnbFsJ[GtaFJ8P] - 'a' + 'A', NGqU4cHvtE +(420 - 419));
                }
                else {
                    printf ("(%c,%d)", H6NvkHnbFsJ[GtaFJ8P], NGqU4cHvtE +(902 - 901));
                }
                NGqU4cHvtE = (670 - 670);
            }
            else {
                NGqU4cHvtE = NGqU4cHvtE +(639 - 638);
            }
            GtaFJ8P = GtaFJ8P +(925 - 924);
        }
    }
    return (387 - 387);
}

