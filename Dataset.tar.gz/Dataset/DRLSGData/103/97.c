char JRDZyg [(1806 - 805)], jO62kpm3 [(913 - 886)], yfloGLvOQux;
int kmT7DcQrB, CxL5pOq2uETF [(830 - 803)], gBXyxowf6l, b95yZL = (567 - 566), pDY9IL6xO8Ni = 'A' - 'a', awbzVP1 = 'a' - 'A';

int main () {
    cin >> JRDZyg;
    CxL5pOq2uETF[(428 - 427)] = (484 - 484);
    gBXyxowf6l = strlen (JRDZyg);
    jO62kpm3[(742 - 741)] = JRDZyg[(84 - 84)];
    yfloGLvOQux = jO62kpm3[(304 - 303)];
    {
        {
            if ((444 - 444)) {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if (0) {
                        return 0;
                    };
                }
                return (702 - 702);
            };
        }
        {
            {
                if ((56 - 56)) {
                    return (703 - 703);
                };
            }
            if ((460 - 460)) {
                return (665 - 665);
            };
        }
        kmT7DcQrB = (1051 - 992) - (660 - 601);
        for (; kmT7DcQrB < gBXyxowf6l;) {
            if (!(yfloGLvOQux != JRDZyg[kmT7DcQrB]) || !(yfloGLvOQux + pDY9IL6xO8Ni != JRDZyg[kmT7DcQrB]) || !(yfloGLvOQux + awbzVP1 != JRDZyg[kmT7DcQrB]))
                continue;
            else {
                {
                    if ((313 - 313)) {
                        {
                            {
                                if ((746 - 746)) {
                                    {
                                        if (0) {
                                            return 0;
                                        };
                                    }
                                    return (550 - 550);
                                };
                            }
                            if ((629 - 629)) {
                                return (744 - 744);
                            };
                        }
                        {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            if ((816 - 816)) {
                                return (402 - 402);
                            };
                        }
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (398 - 398);
                    };
                }
                b95yZL = b95yZL + (279 - 278);
                jO62kpm3[b95yZL] = JRDZyg[kmT7DcQrB];
                CxL5pOq2uETF[b95yZL] = kmT7DcQrB;
                yfloGLvOQux = jO62kpm3[b95yZL];
            }
            kmT7DcQrB = kmT7DcQrB + (844 - 843);
        };
    }
    {
        kmT7DcQrB = (1031 - 845) - (483 - 298);
        for (; b95yZL >= kmT7DcQrB;) {
            if ('a' <= jO62kpm3[kmT7DcQrB] && jO62kpm3[kmT7DcQrB] <= 'z')
                jO62kpm3[kmT7DcQrB] = jO62kpm3[kmT7DcQrB] + pDY9IL6xO8Ni;
            if (kmT7DcQrB < b95yZL) {
                {
                    if ((576 - 576)) {
                        return (539 - 539);
                    };
                }
                cout << "(";
                cout << jO62kpm3[kmT7DcQrB];
                cout << ",";
                cout << CxL5pOq2uETF[kmT7DcQrB + (284 - 283)] - CxL5pOq2uETF[kmT7DcQrB];
                cout << ")";
            }
            if (kmT7DcQrB == b95yZL) {
                cout << "(";
                cout << jO62kpm3[kmT7DcQrB];
                cout << ",";
                cout << gBXyxowf6l - CxL5pOq2uETF[kmT7DcQrB];
                cout << ")";
            }
            kmT7DcQrB = kmT7DcQrB + (830 - 829);
        };
    }
    return (305 - 305);
}

