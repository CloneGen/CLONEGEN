int main () {
    char VQCrIlgBi2 [(1891 - 791)];
    int P2bp7sdhz8qm [(1261 - 261)] = {(944 - 944)};
    int CrhVTnlQ;
    char ZJoUvtPIE [(1202 - 202)];
    int qewR7o;
    int B1xqM4;
    cin >> VQCrIlgBi2;
    {
        CrhVTnlQ = (109 - 109);
        for (; strlen (VQCrIlgBi2) > CrhVTnlQ;) {
            if ('a' <= VQCrIlgBi2[CrhVTnlQ] && VQCrIlgBi2[CrhVTnlQ] <= 'z')
                VQCrIlgBi2[CrhVTnlQ] = VQCrIlgBi2[CrhVTnlQ] - (703 - 671);
            CrhVTnlQ = CrhVTnlQ +(521 - 520);
        }
    }
    qewR7o = (947 - 947);
    ZJoUvtPIE[(957 - 957)] = VQCrIlgBi2[(738 - 738)];
    {
        CrhVTnlQ = (35 - 34);
        for (; strlen (VQCrIlgBi2) > CrhVTnlQ;) {
            {
                if ((79 - 79)) {
                    return 0;
                }
            }
            if (VQCrIlgBi2[CrhVTnlQ] == VQCrIlgBi2[CrhVTnlQ -(716 - 715)]) {
                P2bp7sdhz8qm[qewR7o]++;
            }
            else {
                qewR7o = qewR7o + (757 - 756);
                ZJoUvtPIE[qewR7o] = VQCrIlgBi2[CrhVTnlQ];
            }
            CrhVTnlQ = CrhVTnlQ +(895 - 894);
        }
    }
    {
        CrhVTnlQ = (817 - 817);
        for (; CrhVTnlQ <= qewR7o;) {
            cout << "(" << ZJoUvtPIE[CrhVTnlQ] << "," << P2bp7sdhz8qm[CrhVTnlQ] + (656 - 655) << ")";
            CrhVTnlQ = CrhVTnlQ +(701 - 700);
        }
    }
    return (294 - 294);
}

