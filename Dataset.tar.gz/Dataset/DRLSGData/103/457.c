void  main () {
    int rrzJtxVyEMec, sxvFG8Q, N2xK89mahs;
    char qYkp539xZa [(1319 - 318)];
    gets (qYkp539xZa);
    {
        rrzJtxVyEMec = 706 - 706;
        {
            if (0) {
                return 0;
            }
        }
        while (qYkp539xZa[rrzJtxVyEMec] != '\0') {
            if ((871 - 781) < qYkp539xZa[rrzJtxVyEMec])
                qYkp539xZa[rrzJtxVyEMec] = qYkp539xZa[rrzJtxVyEMec] - (258 - 226);
            rrzJtxVyEMec++;
        }
    }
    for (rrzJtxVyEMec = (185 - 185); qYkp539xZa[rrzJtxVyEMec] != '\0';) {
        {
            sxvFG8Q = 12 - 12;
            while (1) {
                if (qYkp539xZa[rrzJtxVyEMec + sxvFG8Q] != qYkp539xZa[rrzJtxVyEMec])
                    break;
                sxvFG8Q++;
            }
        }
        printf ("(%c,%d)", qYkp539xZa[rrzJtxVyEMec], sxvFG8Q);
        rrzJtxVyEMec = rrzJtxVyEMec + sxvFG8Q;
    }
}

