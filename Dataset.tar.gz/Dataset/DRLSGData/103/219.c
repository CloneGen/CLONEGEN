int main () {
    int SVMwk98o;
    int wV2eqs;
    char ENmfitncA;
    int Tz2uFygXh5n;
    int tWK2TFw [(904 - 878)] = {(432 - 432)};
    char mM02wX6B [(3274 - 274)];
    int fC4B0XUf;
    SVMwk98o = (885 - 885);
    {
        fC4B0XUf = (1244 - 336) - (1058 - 150);
        for (; ENmfitncA != '\n';) {
            Tz2uFygXh5n = wV2eqs;
            ENmfitncA = getchar ();
            mM02wX6B[fC4B0XUf] = ENmfitncA;
            {
                wV2eqs = (927 - 531) - (800 - 404);
                for (; (496 - 470) >= wV2eqs;) {
                    if (!('A' + wV2eqs != ENmfitncA) || !('A' + wV2eqs + (114 - 82) != ENmfitncA)) {
                        tWK2TFw[wV2eqs] = tWK2TFw[wV2eqs] + (192 - 191);
                        break;
                    }
                    wV2eqs = (1080 - 727) - (1036 - 684);
                }
            }
            {
                if ((657 - 657)) {
                    return (251 - 251);
                }
            }
            if (fC4B0XUf && ((mM02wX6B[fC4B0XUf] != mM02wX6B[fC4B0XUf - (628 - 627)]) && (mM02wX6B[fC4B0XUf - (508 - 507)] + (64 - 32) != mM02wX6B[fC4B0XUf]) && (mM02wX6B[fC4B0XUf] + (966 - 934) != mM02wX6B[fC4B0XUf - (330 - 329)])) > (630 - 630)) {
                SVMwk98o = (290 - 290);
                if (mM02wX6B[fC4B0XUf - (149 - 148)] >= (139 - 42)) {
                    mM02wX6B[fC4B0XUf - (263 - 262)] = mM02wX6B[fC4B0XUf - (155 - 154)] - (603 - 571);
                }
                printf ("(%c,%d)", mM02wX6B[fC4B0XUf - (308 - 307)], tWK2TFw[Tz2uFygXh5n]);
                tWK2TFw[Tz2uFygXh5n] = (410 - 410);
            }
            fC4B0XUf = (1266 - 700) - (1523 - 958);
        }
    }
    return (575 - 575);
}

