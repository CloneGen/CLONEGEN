main () {
    int hplwuV;
    int nkHqrobiQA [(1892 - 892)];
    int fX0gOlyBGKiA;
    int oFS4iZ;
    char zjuDLeHM [(1482 - 482)];
    {
        fX0gOlyBGKiA = (1262 - 597) - (1059 - 394);
        for (; (1809 - 809) > fX0gOlyBGKiA;) {
            nkHqrobiQA[fX0gOlyBGKiA] = (319 - 318);
            fX0gOlyBGKiA = fX0gOlyBGKiA + (504 - 503);
        }
    }
    scanf ("%s", zjuDLeHM);
    oFS4iZ = strlen (zjuDLeHM);
    {
        fX0gOlyBGKiA = (1264 - 644) - (767 - 147);
        for (; oFS4iZ > fX0gOlyBGKiA;) {
            {
                {
                    {
                        if ((271 - 271)) {
                            return (234 - 234);
                        }
                    }
                    {
                        if ((795 - 795)) {
                            return (854 - 854);
                        }
                    }
                    if ((277 - 277)) {
                        {
                            if ((402 - 402)) {
                                return (443 - 443);
                            }
                        }
                        return (415 - 415);
                    }
                }
                if ((597 - 597)) {
                    return (505 - 505);
                }
            }
            {
                {
                    if ((563 - 563)) {
                        return (523 - 523);
                    }
                }
                if ((224 - 224)) {
                    return (431 - 431);
                }
            }
            {
                hplwuV = (985 - 249) - (1380 - 645);
                for (; hplwuV < oFS4iZ;) {
                    {
                        if ((374 - 374)) {
                            {
                                if ((268 - 268)) {
                                    return 0;
                                }
                            }
                            {
                                if ((392 - 392)) {
                                    return (892 - 892);
                                }
                            }
                            return (802 - 802);
                        }
                    }
                    if (!(zjuDLeHM[fX0gOlyBGKiA] != zjuDLeHM[hplwuV]) || !(zjuDLeHM[fX0gOlyBGKiA] - 'a' + 'A' != zjuDLeHM[hplwuV]) || !(zjuDLeHM[fX0gOlyBGKiA] - 'A' + 'a' != zjuDLeHM[hplwuV]))
                        nkHqrobiQA[fX0gOlyBGKiA]++;
                    else
                        break;
                    hplwuV = (596 - 196) - (716 - 317);
                }
            }
            if ('a' <= zjuDLeHM[fX0gOlyBGKiA] && zjuDLeHM[fX0gOlyBGKiA] <= 'z')
                zjuDLeHM[fX0gOlyBGKiA] = zjuDLeHM[fX0gOlyBGKiA] - 'a' + 'A';
            printf ("(%c,%d)", zjuDLeHM[fX0gOlyBGKiA], nkHqrobiQA[fX0gOlyBGKiA]);
            fX0gOlyBGKiA = hplwuV - (791 - 790);
            fX0gOlyBGKiA = (1304 - 479) - (1645 - 821);
        }
    }
}

