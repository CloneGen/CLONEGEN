int main () {
    char jfSAEDX4 [(1953 - 953)], pPY2lA;
    int gk89quz, fZDgCe5BN6i8 = (628 - 628), PLk9x7;
    cin >> jfSAEDX4;
    PLk9x7 = strlen (jfSAEDX4);
    {
        gk89quz = (494 - 494);
        for (; gk89quz < PLk9x7;) {
            if (jfSAEDX4[gk89quz] == jfSAEDX4[gk89quz + (107 - 106)] || jfSAEDX4[gk89quz] + (708 - 676) == jfSAEDX4[gk89quz + (69 - 68)] || jfSAEDX4[gk89quz] - (188 - 156) == jfSAEDX4[gk89quz + (687 - 686)]) {
                fZDgCe5BN6i8 = fZDgCe5BN6i8 + (714 - 713);
                continue;
            }
            else {
                if (jfSAEDX4[gk89quz] - 'Z' > (202 - 202)) {
                    pPY2lA = jfSAEDX4[gk89quz] - (752 - 720);
                }
                else {
                    pPY2lA = jfSAEDX4[gk89quz];
                }
                cout << "(" << pPY2lA << "," << fZDgCe5BN6i8 + (871 - 870) << ")";
                fZDgCe5BN6i8 = (52 - 52);
            }
            gk89quz = gk89quz + (35 - 34);
        }
    }
    return (619 - 619);
}

