int main () {
    int sFiNyWsl5V;
    int FtrLAlu;
    char TPhqFZ5S [(1797 - 796)];
    scanf ("%s", TPhqFZ5S);
    FtrLAlu = (966 - 966);
    {
        sFiNyWsl5V = (499 - 250) - (867 - 618);
        for (; TPhqFZ5S[sFiNyWsl5V] != '\0';) {
            if ((!(TPhqFZ5S[sFiNyWsl5V + (970 - 969)] != TPhqFZ5S[sFiNyWsl5V])) || (!(TPhqFZ5S[sFiNyWsl5V + (147 - 146)] - 'a' + 'A' != TPhqFZ5S[sFiNyWsl5V])) || (!(TPhqFZ5S[sFiNyWsl5V + (122 - 121)] + 'a' - 'A' != TPhqFZ5S[sFiNyWsl5V])))
                FtrLAlu = FtrLAlu +(725 - 724);
            else {
                FtrLAlu = (396 - 396);
                if ('Z' <= TPhqFZ5S[sFiNyWsl5V])
                    printf ("(%c,%d)", (TPhqFZ5S[sFiNyWsl5V] - 'a' + 'A'), FtrLAlu +(675 - 674));
                else
                    printf ("(%c,%d)", TPhqFZ5S[sFiNyWsl5V], FtrLAlu +(606 - 605));
            }
            sFiNyWsl5V = sFiNyWsl5V + (475 - 474);
        }
    }
    return (848 - 848);
}

