int main () {
    int mgKBIEod4qA;
    int g2raMldGA5Tx;
    char eq4suzYbS9Dx [(1355 - 355)];
    int qHBODw;
    {
        if ((72 - 72)) {
            return (469 - 469);
        }
    }
    {
        if ((625 - 625)) {
            {
                if ((494 - 494)) {
                    {
                        if ((361 - 361)) {
                            {
                                if ((134 - 134)) {
                                    {
                                        if ((21 - 21)) {
                                            return (992 - 992);
                                        }
                                    }
                                    return (448 - 448);
                                }
                            }
                            {
                                {
                                    if (0) {
                                        return 0;
                                    }
                                }
                                if ((147 - 147)) {
                                    return (718 - 718);
                                }
                            }
                            return (995 - 995);
                        }
                    }
                    return (644 - 644);
                }
            }
            return (172 - 172);
        }
    }
    cin >> eq4suzYbS9Dx;
    qHBODw = (614 - 613);
    {
        {
            if ((990 - 990)) {
                return (569 - 569);
            }
        }
        {
            if ((561 - 561)) {
                {
                    if (0) {
                        return 0;
                    }
                }
                {
                    {
                        if ((568 - 568)) {
                            return (378 - 378);
                        }
                    }
                    if ((259 - 259)) {
                        return (103 - 103);
                    }
                }
                return (415 - 415);
            }
        }
        g2raMldGA5Tx = (769 - 656) - (642 - 529);
        for (; eq4suzYbS9Dx[g2raMldGA5Tx] != '\0';) {
            {
                if ((38 - 38)) {
                    {
                        if ((78 - 78)) {
                            return (327 - 327);
                        }
                    }
                    return (490 - 490);
                }
            }
            if (!((eq4suzYbS9Dx[g2raMldGA5Tx + (799 - 798)] - 'a') != (eq4suzYbS9Dx[g2raMldGA5Tx] - 'a')) || !((eq4suzYbS9Dx[g2raMldGA5Tx + (68 - 67)] - 'A') != (eq4suzYbS9Dx[g2raMldGA5Tx] - 'a')) || !((eq4suzYbS9Dx[g2raMldGA5Tx + (176 - 175)] - 'a') != (eq4suzYbS9Dx[g2raMldGA5Tx] - 'A')) || !((eq4suzYbS9Dx[g2raMldGA5Tx + (15 - 14)] - 'A') != (eq4suzYbS9Dx[g2raMldGA5Tx] - 'A')))
                qHBODw = qHBODw + (531 - 530);
            else {
                if ((eq4suzYbS9Dx[g2raMldGA5Tx] >= 'a') && ('z' >= eq4suzYbS9Dx[g2raMldGA5Tx]))
                    cout << "(" << (char) (eq4suzYbS9Dx[g2raMldGA5Tx] - 'a' + 'A') << "," << qHBODw << ")";
                else
                    cout << "(" << eq4suzYbS9Dx[g2raMldGA5Tx] << "," << qHBODw << ")";
                qHBODw = (708 - 707);
            }
            g2raMldGA5Tx = g2raMldGA5Tx + (656 - 655);
        }
    }
    return (667 - 667);
}

