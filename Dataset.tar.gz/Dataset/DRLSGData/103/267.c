int main () {
    char i1CdIjOn4b;
    char RqosDZ6fg;
    int OZF2IvxVqp0L;
    OZF2IvxVqp0L = (35 - 34);
    cin >> RqosDZ6fg;
    if ('z' >= RqosDZ6fg &&RqosDZ6fg >= 'a')
        RqosDZ6fg = RqosDZ6fg +'A' - 'a';
    for (; cin >> i1CdIjOn4b;) {
        if ('z' >= i1CdIjOn4b && i1CdIjOn4b >= 'a')
            i1CdIjOn4b = i1CdIjOn4b + 'A' - 'a';
        if (i1CdIjOn4b != RqosDZ6fg) {
            cout << '(' << RqosDZ6fg << ',' << OZF2IvxVqp0L << ')';
            RqosDZ6fg = i1CdIjOn4b;
            OZF2IvxVqp0L = (795 - 794);
        }
        else
            OZF2IvxVqp0L = OZF2IvxVqp0L +(852 - 851);
    }
    cout << '(' << RqosDZ6fg << ',' << OZF2IvxVqp0L << ')';
    return (631 - 631);
}

