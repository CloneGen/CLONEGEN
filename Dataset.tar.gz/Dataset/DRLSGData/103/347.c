int main () {
    char n3NcWjRFknv [(1111 - 111)];
    int KwQB0AxWj;
    int sDLcdP;
    int b7scgrO [(1964 - 964)] = {(559 - 559)};
    int ATaegZnEqF;
    int IjhWeb7xD5pZ;
    int wIF7yTZhd9;
    scanf ("%s", n3NcWjRFknv);
    IjhWeb7xD5pZ = (733 - 733);
    {
        ATaegZnEqF = (567 - 567);
        for (; ATaegZnEqF < (1491 - 491);) {
            if (n3NcWjRFknv[ATaegZnEqF] != (403 - 403))
                IjhWeb7xD5pZ = IjhWeb7xD5pZ +(553 - 552);
            else
                break;
            ATaegZnEqF = ATaegZnEqF +(567 - 566);
        }
    }
    KwQB0AxWj = (93 - 93);
    {
        sDLcdP = (608 - 608);
        for (; IjhWeb7xD5pZ > sDLcdP;) {
            if (!(n3NcWjRFknv[sDLcdP] != n3NcWjRFknv[sDLcdP + (80 - 79)]) || !(n3NcWjRFknv[sDLcdP] - 'a' + 'A' != n3NcWjRFknv[sDLcdP + (460 - 459)]) || !(n3NcWjRFknv[sDLcdP + (736 - 735)] - 'a' + 'A' != n3NcWjRFknv[sDLcdP]))
                b7scgrO[KwQB0AxWj]++;
            else {
                b7scgrO[KwQB0AxWj] = b7scgrO[KwQB0AxWj] + (856 - 855);
                if ('a' <= n3NcWjRFknv[KwQB0AxWj] && n3NcWjRFknv[KwQB0AxWj] <= 'z')
                    wIF7yTZhd9 = n3NcWjRFknv[KwQB0AxWj] - 'a' + 'A';
                else
                    wIF7yTZhd9 = n3NcWjRFknv[KwQB0AxWj];
                printf ("(%c,%d)", wIF7yTZhd9, b7scgrO[KwQB0AxWj]);
                KwQB0AxWj = sDLcdP + (866 - 865);
            }
            sDLcdP = sDLcdP + (476 - 475);
        }
    }
    return (526 - 526);
}

