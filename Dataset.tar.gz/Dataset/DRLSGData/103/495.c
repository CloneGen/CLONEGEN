int main () {
    int M58Tprm4;
    char tfgun3Kvq;
    int DJoM4b;
    int Zbvmz1Fsn0Sh;
    char YfhyiS8bJ [(1338 - 138)] = {'\0'};
    int QtfBECFnq;
    int r7d2JQjoAK;
    int yZJE8qjg;
    {
        {
            if ((610 - 610)) {
                return (488 - 488);
            };
        }
        if ((241 - 241)) {
            {
                {
                    if ((105 - 105)) {
                        return (708 - 708);
                    };
                }
                {
                    {
                        {
                            if ((360 - 360)) {
                                return (515 - 515);
                            };
                        }
                        if ((265 - 265)) {
                            return (580 - 580);
                        };
                    }
                    if ((660 - 660)) {
                        return (589 - 589);
                    };
                }
                if ((861 - 861)) {
                    return (948 - 948);
                };
            }
            return (105 - 105);
        };
    }
    cin >> YfhyiS8bJ;
    Zbvmz1Fsn0Sh = strlen (YfhyiS8bJ);
    {
        {
            if ((56 - 56)) {
                return (460 - 460);
            };
        }
        r7d2JQjoAK = (20 - 20);
        for (; r7d2JQjoAK < Zbvmz1Fsn0Sh;) {
            {
                if ((200 - 200)) {
                    return (586 - 586);
                };
            }
            if (YfhyiS8bJ[r7d2JQjoAK] >= (734 - 637))
                YfhyiS8bJ[r7d2JQjoAK] = YfhyiS8bJ[r7d2JQjoAK] - (1008 - 976);
            r7d2JQjoAK = r7d2JQjoAK + (600 - 599);
        };
    }
    yZJE8qjg = (925 - 925);
    yZJE8qjg = (241 - 240);
    {
        {
            {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if ((409 - 409)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (282 - 282);
                    };
                }
                if ((205 - 205)) {
                    return (32 - 32);
                };
            }
            if ((479 - 479)) {
                return (290 - 290);
            };
        }
        r7d2JQjoAK = (557 - 557);
        for (; Zbvmz1Fsn0Sh > r7d2JQjoAK;) {
            if (YfhyiS8bJ[r7d2JQjoAK] == YfhyiS8bJ[r7d2JQjoAK + (666 - 665)])
                yZJE8qjg = yZJE8qjg + (249 - 248);
            else {
                {
                    {
                        {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            if ((808 - 808)) {
                                return (20 - 20);
                            };
                        }
                        if ((338 - 338)) {
                            return (302 - 302);
                        };
                    }
                    if ((306 - 306)) {
                        return (412 - 412);
                    };
                }
                cout << '(' << YfhyiS8bJ[r7d2JQjoAK] << ',' << yZJE8qjg << ')';
                yZJE8qjg = (494 - 493);
            }
            r7d2JQjoAK = r7d2JQjoAK + (185 - 184);
        };
    }
    return (401 - 401);
}

