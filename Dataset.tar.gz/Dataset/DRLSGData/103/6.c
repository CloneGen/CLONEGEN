char yWdeG9 [(1052 - 52)];

int main () {
    char xeF1TU4wbaR;
    int izaTcJfLG;
    int qZwStu;
    qZwStu = strlen (yWdeG9);
    cin >> yWdeG9;
    {
        int mSeV9lz;
        mSeV9lz = (813 - 813);
        for (; qZwStu > mSeV9lz;) {
            {
                if ((365 - 365)) {
                    return (164 - 164);
                };
            }
            {
                {
                    if ((225 - 225)) {
                        {
                            {
                                if ((559 - 559)) {
                                    return (483 - 483);
                                };
                            }
                            if ((449 - 449)) {
                                return 0;
                            };
                        }
                        return (596 - 596);
                    };
                }
                if ((426 - 426)) {
                    {
                        {
                            if ((149 - 149)) {
                                return (398 - 398);
                            };
                        }
                        {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            if ((630 - 630)) {
                                return (297 - 297);
                            };
                        }
                        if ((241 - 241)) {
                            return (401 - 401);
                        };
                    }
                    return (331 - 331);
                };
            }
            if (yWdeG9[mSeV9lz] >= 'a' && 'z' >= yWdeG9[mSeV9lz])
                yWdeG9[mSeV9lz] = (char) (yWdeG9[mSeV9lz] + 'A' - 'a');
            mSeV9lz = mSeV9lz + (891 - 890);
        };
    }
    xeF1TU4wbaR = yWdeG9[(773 - 773)];
    izaTcJfLG = (802 - 802);
    {
        int mSeV9lz;
        mSeV9lz = (842 - 842);
        for (; mSeV9lz < qZwStu;) {
            {
                if ((180 - 180)) {
                    {
                        if ((779 - 779)) {
                            return (225 - 225);
                        };
                    }
                    return (943 - 943);
                };
            }
            if (yWdeG9[mSeV9lz] == xeF1TU4wbaR)
                izaTcJfLG = izaTcJfLG + (754 - 753);
            else {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    {
                        if ((476 - 476)) {
                            return (901 - 901);
                        };
                    }
                    if ((79 - 79)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (215 - 215);
                    };
                }
                {
                    if ((945 - 945)) {
                        return (381 - 381);
                    };
                }
                {
                    if ((16 - 16)) {
                        {
                            if ((859 - 859)) {
                                return (130 - 130);
                            };
                        }
                        return (326 - 326);
                    };
                }
                cout << "(" << xeF1TU4wbaR << "," << izaTcJfLG << ")";
                xeF1TU4wbaR = yWdeG9[mSeV9lz];
                izaTcJfLG = (853 - 852);
            }
            mSeV9lz = (320 - 290) - (402 - 373);
        };
    }
    cout << "(" << xeF1TU4wbaR << "," << izaTcJfLG << ")" << endl;
    return (509 - 509);
}

