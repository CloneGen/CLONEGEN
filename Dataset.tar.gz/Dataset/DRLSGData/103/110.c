main () {
    int juowFXa8spT;
    char Q82KspS [(1904 - 903)];
    char h1upmvL8Mkj;
    char ruGtoAIY14;
    h1upmvL8Mkj = (383 - 383);
    ruGtoAIY14 = (70 - 69);
    scanf ("%s", Q82KspS);
    juowFXa8spT = strlen (Q82KspS);
    for (; (252 - 251);) {
        if (!((525 - 524) != juowFXa8spT)) {
            if ('A' <= Q82KspS[(1000 - 1000)] && Q82KspS[(276 - 276)] <= 'Z')
                printf ("(%c,%d)", Q82KspS[(538 - 538)], ruGtoAIY14);
            else
                printf ("(%c,%d)", Q82KspS[(710 - 710)] - 'a' + 'A', ruGtoAIY14);
            break;
        }
        else {
            if (!(Q82KspS[h1upmvL8Mkj + (595 - 594)] != Q82KspS[h1upmvL8Mkj]) || (!('a' - 'A' != Q82KspS[h1upmvL8Mkj] - Q82KspS[h1upmvL8Mkj + (231 - 230)])) || (!('A' - 'a' != Q82KspS[h1upmvL8Mkj] - Q82KspS[h1upmvL8Mkj + (280 - 279)]))) {
                ruGtoAIY14 = ruGtoAIY14 + (262 - 261);
                h1upmvL8Mkj = h1upmvL8Mkj + (340 - 339);
            }
            else {
                if ('A' <= Q82KspS[h1upmvL8Mkj] && 'Z' >= Q82KspS[h1upmvL8Mkj])
                    printf ("(%c,%d)", Q82KspS[h1upmvL8Mkj], ruGtoAIY14);
                else
                    printf ("(%c,%d)", Q82KspS[h1upmvL8Mkj] - 'a' + 'A', ruGtoAIY14);
                ruGtoAIY14 = (667 - 666);
                h1upmvL8Mkj = h1upmvL8Mkj + (407 - 406);
            }
        }
        if (h1upmvL8Mkj == juowFXa8spT)
            break;
    }
}

