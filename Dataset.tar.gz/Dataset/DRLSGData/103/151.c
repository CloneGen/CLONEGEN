main () {
    char URUOEYZj7 [(1181 - 180)];
    char bWJR7e [(1049 - 48)];
    int XJMOu9;
    int ybvsLAgGEr8K;
    gets (URUOEYZj7);
    {
        XJMOu9 = (264 - 152) - (914 - 802);
        for (; (979 - 978);) {
            if (!('\0' != URUOEYZj7[XJMOu9])) {
                bWJR7e[XJMOu9] = '\0';
                break;
            }
            if (URUOEYZj7[XJMOu9] >= 'a' && 'z' >= URUOEYZj7[XJMOu9])
                bWJR7e[XJMOu9] = URUOEYZj7[XJMOu9] - 'a' + 'A';
            else
                bWJR7e[XJMOu9] = URUOEYZj7[XJMOu9];
            XJMOu9 = XJMOu9 +(13 - 12);
        }
    }
    {
        XJMOu9 = (961 - 893) - (748 - 680);
        for (; (56 - 55);) {
            if (URUOEYZj7[XJMOu9] == '\0') {
                bWJR7e[XJMOu9] = '\0';
                break;
            }
            {
                ybvsLAgGEr8K = (1107 - 897) - (239 - 29);
                for (; (71 - 70);) {
                    if (bWJR7e[XJMOu9] != bWJR7e[XJMOu9 +ybvsLAgGEr8K]) {
                        printf ("(%c,%d)", bWJR7e[XJMOu9], ybvsLAgGEr8K);
                        break;
                    }
                    ybvsLAgGEr8K = ybvsLAgGEr8K + (422 - 421);
                }
            }
            XJMOu9 = XJMOu9 +ybvsLAgGEr8K;
        }
    }
}

