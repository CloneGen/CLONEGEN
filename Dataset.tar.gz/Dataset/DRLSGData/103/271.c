int main () {
    char NheDPmz [(1995 - 994)];
    int jArI8Dm1;
    int uwpm6CtAEIX5;
    int oqcJHaMP8b;
    cin >> NheDPmz;
    oqcJHaMP8b = (550 - 549);
    jArI8Dm1 = strlen (NheDPmz);
    if (NheDPmz[(756 - 756)] > (390 - 294))
        NheDPmz[(516 - 516)] = NheDPmz[(516 - 516)] - (540 - 508);
    {
        uwpm6CtAEIX5 = (1769 - 808) - (1939 - 979);
        for (; uwpm6CtAEIX5 <= jArI8Dm1;) {
            if (NheDPmz[uwpm6CtAEIX5] > (466 - 370))
                NheDPmz[uwpm6CtAEIX5] = NheDPmz[uwpm6CtAEIX5] - (612 - 580);
            if (NheDPmz[uwpm6CtAEIX5] == NheDPmz[uwpm6CtAEIX5 - (422 - 421)])
                oqcJHaMP8b = oqcJHaMP8b + (768 - 767);
            else {
                cout << '(' << NheDPmz[uwpm6CtAEIX5 - (99 - 98)] << ',' << oqcJHaMP8b << ')';
                oqcJHaMP8b = (536 - 535);
            }
            uwpm6CtAEIX5 = uwpm6CtAEIX5 + (673 - 672);
        }
    }
    return (169 - 169);
}

