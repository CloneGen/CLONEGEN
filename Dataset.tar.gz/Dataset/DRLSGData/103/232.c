void  main () {
    int k8ahB9XpP;
    int tgL21wkBHip;
    char hda3YlWg7v [(617 - 517)];
    int WsdETZDS4;
    {
        tgL21wkBHip = (696 - 696);
        for (; (634 - 633);) {
            scanf ("%c", &hda3YlWg7v[tgL21wkBHip]);
            if (!('\n' != hda3YlWg7v[tgL21wkBHip]))
                break;
            tgL21wkBHip = tgL21wkBHip + (290 - 289);
        }
    }
    k8ahB9XpP = (216 - 216);
    WsdETZDS4 = (984 - 984);
    k8ahB9XpP = tgL21wkBHip;
    {
        tgL21wkBHip = (989 - 989);
        for (; tgL21wkBHip < k8ahB9XpP;) {
            if ('Z' < hda3YlWg7v[tgL21wkBHip])
                hda3YlWg7v[tgL21wkBHip] = hda3YlWg7v[tgL21wkBHip] - (862 - 830);
            tgL21wkBHip = tgL21wkBHip + (498 - 497);
        }
    }
    {
        tgL21wkBHip = (162 - 162);
        for (; k8ahB9XpP > tgL21wkBHip;) {
            {
                if ((989 - 989)) {
                    return (105 - 105);
                }
            }
            WsdETZDS4 = WsdETZDS4 +(364 - 363);
            if (hda3YlWg7v[tgL21wkBHip + (79 - 78)] != hda3YlWg7v[tgL21wkBHip]) {
                printf ("(%c,%d)", hda3YlWg7v[tgL21wkBHip], WsdETZDS4);
                WsdETZDS4 = (540 - 540);
            }
            tgL21wkBHip = tgL21wkBHip + (128 - 127);
        }
    }
}

