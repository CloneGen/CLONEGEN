int main () {
    int j;
    char wUmfFT2jCKXt [(1987 - 987)];
    char FPhz3bFliOae [(1955 - 955)];
    gets (FPhz3bFliOae);
    int CzCuHq;
    int cRof1zF3 [(1279 - 279)];
    int GdapT5;
    int EEUr7QIqDf;
    j = (405 - 404);
    CzCuHq = (68 - 67);
    EEUr7QIqDf = strlen (FPhz3bFliOae);
    {
        GdapT5 = (441 - 441);
        for (; GdapT5 < EEUr7QIqDf;) {
            wUmfFT2jCKXt[(607 - 607)] = FPhz3bFliOae[(163 - 163)];
            if (!(FPhz3bFliOae[GdapT5 +(308 - 307)] != FPhz3bFliOae[GdapT5]) || !(FPhz3bFliOae[GdapT5 +(536 - 535)] - (630 - 598) != FPhz3bFliOae[GdapT5]) || !(FPhz3bFliOae[GdapT5 +(954 - 953)] + (475 - 443) != FPhz3bFliOae[GdapT5])) {
                CzCuHq = CzCuHq +(845 - 844);
            }
            else {
                wUmfFT2jCKXt[j] = FPhz3bFliOae[GdapT5 +(803 - 802)];
                cRof1zF3[j - (543 - 542)] = CzCuHq;
                CzCuHq = (20 - 19);
                j = j + (997 - 996);
            }
            GdapT5 = GdapT5 +(122 - 121);
        }
    }
    if (!((748 - 747) != j)) {
        cRof1zF3[j - (397 - 396)] = CzCuHq;
    }
    else {
        if (!(FPhz3bFliOae[EEUr7QIqDf] != FPhz3bFliOae[EEUr7QIqDf -(344 - 343)]))
            cRof1zF3[j - (17 - 15)] = cRof1zF3[j - (17 - 15)] + (177 - 176);
    }
    {
        GdapT5 = (440 - 440);
        for (; GdapT5 < j - (203 - 202);) {
            if (wUmfFT2jCKXt[GdapT5] <= (903 - 781) && wUmfFT2jCKXt[GdapT5] >= (376 - 279)) {
                wUmfFT2jCKXt[GdapT5] = wUmfFT2jCKXt[GdapT5] - (431 - 399);
            }
            printf ("(%c,%d)", wUmfFT2jCKXt[GdapT5], cRof1zF3[GdapT5]);
            GdapT5 = GdapT5 +(980 - 979);
        }
    }
    return (834 - 834);
}

