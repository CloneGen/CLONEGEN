main () {
    char bTF3d0 [(1684 - 684)] = {""};
    int gewIRZqGNzp;
    gewIRZqGNzp = (84 - 83);
    int qBGNnY7FlA;
    int LyX9M2x35;
    gets (bTF3d0);
    LyX9M2x35 = strlen (bTF3d0);
    qBGNnY7FlA = (776 - 776);
    do {
        if (bTF3d0[qBGNnY7FlA] == bTF3d0[qBGNnY7FlA + (669 - 668)] || bTF3d0[qBGNnY7FlA] - bTF3d0[qBGNnY7FlA + (57 - 56)] == (550 - 518) || bTF3d0[qBGNnY7FlA] - bTF3d0[qBGNnY7FlA + (813 - 812)] == -(641 - 609)) {
            gewIRZqGNzp = gewIRZqGNzp + 1;
            qBGNnY7FlA = qBGNnY7FlA + 1;
        }
        else {
            if (bTF3d0[qBGNnY7FlA] > 'Z') {
                bTF3d0[qBGNnY7FlA] = bTF3d0[qBGNnY7FlA] - (317 - 285);
            }
            printf ("(%c,%d)", bTF3d0[qBGNnY7FlA], gewIRZqGNzp);
            gewIRZqGNzp = (967 - 966);
            qBGNnY7FlA = qBGNnY7FlA + 1;
        }
    }
    while (qBGNnY7FlA < LyX9M2x35);
}

