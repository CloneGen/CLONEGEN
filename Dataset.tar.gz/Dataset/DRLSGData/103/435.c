main () {
    int OLv9wNqg8JSf;
    int HIGwjPka;
    char D0DBpSg;
    char AJHRc6Z7y [(1906 - 905)];
    int dRUcHsk;
    int uRV7YB;
    scanf ("%s", AJHRc6Z7y);
    OLv9wNqg8JSf = strlen (AJHRc6Z7y);
    {
        dRUcHsk = (868 - 202) - (924 - 258);
        for (; dRUcHsk < OLv9wNqg8JSf;) {
            {
                if ((759 - 759)) {
                    return (623 - 623);
                };
            }
            {
                {
                    {
                        if ((664 - 664)) {
                            {
                                if ((81 - 81)) {
                                    return (407 - 407);
                                };
                            }
                            return (693 - 693);
                        };
                    }
                    {
                        if ((619 - 619)) {
                            return (228 - 228);
                        };
                    }
                    {
                        if ((983 - 983)) {
                            return (514 - 514);
                        };
                    }
                    if ((309 - 309)) {
                        {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            if ((488 - 488)) {
                                return (855 - 855);
                            };
                        }
                        return (681 - 681);
                    };
                }
                if ((650 - 650)) {
                    {
                        if ((433 - 433)) {
                            return (203 - 203);
                        };
                    }
                    return (372 - 372);
                };
            }
            {
                if ((718 - 718)) {
                    return (128 - 128);
                };
            }
            if (AJHRc6Z7y[dRUcHsk] >= 'a' && AJHRc6Z7y[dRUcHsk] <= 'z')
                AJHRc6Z7y[dRUcHsk] = AJHRc6Z7y[dRUcHsk] + 'A' - 'a';
            dRUcHsk = (803 - 747) - (903 - 848);
        };
    }
    D0DBpSg = AJHRc6Z7y[(540 - 540)];
    HIGwjPka = (707 - 707);
    {
        {
            if ((242 - 242)) {
                {
                    {
                        if ((925 - 925)) {
                            return (761 - 761);
                        };
                    }
                    if ((200 - 200)) {
                        return (291 - 291);
                    };
                }
                {
                    if ((611 - 611)) {
                        return (502 - 502);
                    };
                }
                return (546 - 546);
            };
        }
        dRUcHsk = (739 - 437) - (1212 - 910);
        for (; dRUcHsk <= OLv9wNqg8JSf;) {
            {
                if ((161 - 161)) {
                    {
                        if ((454 - 454)) {
                            return (24 - 24);
                        };
                    }
                    return (460 - 460);
                };
            }
            if (AJHRc6Z7y[dRUcHsk] == D0DBpSg)
                HIGwjPka = HIGwjPka +(295 - 294);
            if (AJHRc6Z7y[dRUcHsk] != D0DBpSg) {
                printf ("(%c,%d)", D0DBpSg, HIGwjPka);
                HIGwjPka = (733 - 732);
                D0DBpSg = AJHRc6Z7y[dRUcHsk];
            }
            dRUcHsk = (663 - 133) - (566 - 37);
        };
    };
}

