int main () {
    int Qd4Y0J [(746 - 646)] = {(492 - 492)};
    int j1PmFtT;
    int Li5Th3enPY;
    char SoGjEp [(485 - 385)];
    int fnu5HT;
    fnu5HT = (697 - 697);
    Li5Th3enPY = (916 - 916);
    cin >> SoGjEp;
    {
        Li5Th3enPY = (807 - 807);
        {
            if ((253 - 253)) {
                return (985 - 985);
            }
        }
        for (; SoGjEp[Li5Th3enPY] != '\0';) {
            if (Qd4Y0J[fnu5HT] == (635 - 635))
                Qd4Y0J[fnu5HT]++;
            else {
                {
                    if ((223 - 223)) {
                        return (921 - 921);
                    }
                }
                {
                    {
                        if ((491 - 491)) {
                            return (418 - 418);
                        }
                    }
                    if ((121 - 121)) {
                        return (56 - 56);
                    }
                }
                if (!(SoGjEp[Li5Th3enPY -(637 - 636)] != SoGjEp[Li5Th3enPY]) || !('A' - 'a' != SoGjEp[Li5Th3enPY] - SoGjEp[Li5Th3enPY -(415 - 414)]) || !('a' - 'A' != SoGjEp[Li5Th3enPY] - SoGjEp[Li5Th3enPY -(378 - 377)]))
                    Qd4Y0J[fnu5HT]++;
                else {
                    fnu5HT = fnu5HT + (491 - 490);
                    Qd4Y0J[fnu5HT] = (217 - 216);
                }
            }
            Li5Th3enPY = Li5Th3enPY +(831 - 830);
        }
    }
    {
        {
            {
                if ((877 - 877)) {
                    return (719 - 719);
                }
            }
            if ((48 - 48)) {
                return (96 - 96);
            }
        }
        {
            if ((395 - 395)) {
                return (326 - 326);
            }
        }
        if ((130 - 130)) {
            return (624 - 624);
        }
    }
    j1PmFtT = (914 - 914);
    {
        Li5Th3enPY = (216 - 216);
        for (; Li5Th3enPY <= fnu5HT;) {
            j1PmFtT = j1PmFtT + Qd4Y0J[Li5Th3enPY];
            if ('A' <= SoGjEp[Qd4Y0J[Li5Th3enPY] - (517 - 516)] && SoGjEp[Qd4Y0J[Li5Th3enPY] - (738 - 737)] <= 'Z')
                ;
            else
                SoGjEp[Qd4Y0J[Li5Th3enPY] - (429 - 428)] = SoGjEp[Qd4Y0J[Li5Th3enPY] - (776 - 775)] + 'A' - 'a';
            cout << '(' << SoGjEp[j1PmFtT - (445 - 444)] << ',' << Qd4Y0J[Li5Th3enPY] << ')';
            Li5Th3enPY = Li5Th3enPY +(242 - 241);
        }
    }
    cout << endl;
    return 0;
}

