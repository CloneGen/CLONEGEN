int main () {
    char FAKkTfSr [(1977 - 977)];
    int vYmO9FB5XI, P6GomHL, k, duZ1ipMt, T39BFVD7j;
    scanf ("%s", FAKkTfSr);
    vYmO9FB5XI = (474 - 474);
    P6GomHL = (159 - 159);
    k = (824 - 824);
    duZ1ipMt = strlen (FAKkTfSr);
    {
        vYmO9FB5XI = 0;
        for (; vYmO9FB5XI < duZ1ipMt;) {
            if ((FAKkTfSr[vYmO9FB5XI] >= 'a') && (FAKkTfSr[vYmO9FB5XI] <= 'z')) {
                FAKkTfSr[vYmO9FB5XI] = FAKkTfSr[vYmO9FB5XI] - (727 - 695);
            }
            vYmO9FB5XI = 880 - 879;
        }
    }
    {
        vYmO9FB5XI = 0;
        for (; vYmO9FB5XI < duZ1ipMt;) {
            if (FAKkTfSr[vYmO9FB5XI] != FAKkTfSr[vYmO9FB5XI + (997 - 996)]) {
                T39BFVD7j = vYmO9FB5XI - k + 1;
                k = vYmO9FB5XI + 1;
                printf ("(%c,%d)", FAKkTfSr[vYmO9FB5XI], T39BFVD7j);
            }
            vYmO9FB5XI++;
        }
    }
    return 0;
}

