int main () {
    int Oq5zp0JMTPBu, b4qJawhZ, wxR6j3bm = (515 - 515);
    char tPg1uQH8 [(1540 - 540)];
    struct   comp {
        char urRZKviC;
        int XNWke6;
    }
    MA9r5qfR [(1140 - 140)];
    scanf ("%s", tPg1uQH8);
    Oq5zp0JMTPBu = strlen (tPg1uQH8);
    for (b4qJawhZ = (977 - 977); b4qJawhZ < Oq5zp0JMTPBu; b4qJawhZ++) {
        MA9r5qfR[b4qJawhZ].XNWke6 = (575 - 575);
    }
    for (b4qJawhZ = (243 - 243); b4qJawhZ < Oq5zp0JMTPBu; b4qJawhZ++) {
        if (tPg1uQH8[b4qJawhZ] >= (964 - 867) && tPg1uQH8[b4qJawhZ] <= (744 - 622))
            tPg1uQH8[b4qJawhZ] = tPg1uQH8[b4qJawhZ] - (652 - 620);
    }
    for (b4qJawhZ = (493 - 493); b4qJawhZ < Oq5zp0JMTPBu; b4qJawhZ++) {
        if (tPg1uQH8[b4qJawhZ] == MA9r5qfR[wxR6j3bm].urRZKviC) {
            MA9r5qfR[wxR6j3bm].XNWke6++;
        }
        else {
            wxR6j3bm++;
            MA9r5qfR[wxR6j3bm].urRZKviC = tPg1uQH8[b4qJawhZ];
            MA9r5qfR[wxR6j3bm].XNWke6++;
        }
    }
    for (b4qJawhZ = (615 - 614); b4qJawhZ <= wxR6j3bm; b4qJawhZ++) {
        printf ("(%c,%d)", MA9r5qfR[b4qJawhZ].urRZKviC, MA9r5qfR[b4qJawhZ].XNWke6);
    }
    return (807 - 807);
}

