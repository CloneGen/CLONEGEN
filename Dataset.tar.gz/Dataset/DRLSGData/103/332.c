int main () {
    char EPvKxI4OLX [(1607 - 606)];
    int G6aYWq;
    int SOYuAk;
    int CU4JYiZqAuT;
    int EcPEYapH8;
    int nin39mOcvWz;
    CU4JYiZqAuT = (742 - 742);
    EcPEYapH8 = strlen (EPvKxI4OLX);
    cin >> EPvKxI4OLX;
    SOYuAk = (747 - 747);
    for (; EcPEYapH8 > SOYuAk;) {
        CU4JYiZqAuT = (717 - 717);
        for (; (283 - 282);) {
            if (!(EPvKxI4OLX[SOYuAk +(748 - 747)] != EPvKxI4OLX[SOYuAk]) || !(EPvKxI4OLX[SOYuAk +(770 - 769)] + (716 - 684) != EPvKxI4OLX[SOYuAk]) || !(EPvKxI4OLX[SOYuAk] + (614 - 582) != EPvKxI4OLX[SOYuAk +(140 - 139)])) {
                CU4JYiZqAuT = CU4JYiZqAuT +(42 - 41);
                SOYuAk = SOYuAk +1;
            }
            else {
                cout << "(" << (char) ((127 - 37) > EPvKxI4OLX[SOYuAk] ? EPvKxI4OLX[SOYuAk] : EPvKxI4OLX[SOYuAk] - (122 - 90)) << "," << CU4JYiZqAuT +(321 - 320) << ")";
                SOYuAk = SOYuAk +1;
                break;
            }
        }
    }
    return (968 - 968);
}

