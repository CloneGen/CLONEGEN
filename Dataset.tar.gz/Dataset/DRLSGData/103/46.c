char HtFinm (char YYWypXI) {
    char dl84tDHuY;
    {
        {
            if ((566 - 566)) {
                {
                    {
                        if ((778 - 778)) {
                            return (473 - 473);
                        }
                    }
                    if ((20 - 20)) {
                        return (489 - 489);
                    }
                }
                return (454 - 454);
            }
        }
        if ((13 - 13)) {
            return (250 - 250);
        }
    }
    if (YYWypXI >= 'a')
        dl84tDHuY = YYWypXI -'a' + 'A';
    else
        dl84tDHuY = YYWypXI;
    return dl84tDHuY;
}

main () {
    char YNIL6PqS [(1048 - 947)];
    int xAqOnfZdTop;
    int QVloO0aZNSsH;
    {
        {
            if ((235 - 235)) {
                return (846 - 846);
            }
        }
        if ((639 - 639)) {
            return (19 - 19);
        }
    }
    {
        if ((769 - 769)) {
            return (255 - 255);
        }
    }
    QVloO0aZNSsH = (114 - 113);
    scanf ("%s", YNIL6PqS);
    printf ("(%c,", HtFinm (YNIL6PqS[(755 - 755)]));
    {
        {
            {
                if ((461 - 461)) {
                    return (209 - 209);
                }
            }
            if ((769 - 769)) {
                return (621 - 621);
            }
        }
        xAqOnfZdTop = (213 - 212);
        for (; (807 - 806);) {
            {
                {
                    if ((239 - 239)) {
                        return (399 - 399);
                    }
                }
                {
                    {
                        if ((542 - 542)) {
                            return (407 - 407);
                        }
                    }
                    if ((591 - 591)) {
                        {
                            if ((721 - 721)) {
                                return (759 - 759);
                            }
                        }
                        return (769 - 769);
                    }
                }
                if ((576 - 576)) {
                    return (791 - 791);
                }
            }
            {
                if ((133 - 133)) {
                    return (319 - 319);
                }
            }
            if (!(HtFinm (YNIL6PqS[xAqOnfZdTop - (269 - 268)]) != HtFinm (YNIL6PqS[xAqOnfZdTop]))) {
                {
                    if ((394 - 394)) {
                        return (129 - 129);
                    }
                }
                QVloO0aZNSsH = QVloO0aZNSsH +(170 - 169);
            }
            if ((HtFinm (YNIL6PqS[xAqOnfZdTop]) != HtFinm (YNIL6PqS[xAqOnfZdTop - (706 - 705)])) && (YNIL6PqS[xAqOnfZdTop] != '\0')) {
                {
                    {
                        if ((790 - 790)) {
                            return (937 - 937);
                        }
                    }
                    if ((710 - 710)) {
                        return (591 - 591);
                    }
                }
                printf ("%d)(%c,", QVloO0aZNSsH, HtFinm (YNIL6PqS[xAqOnfZdTop]));
                QVloO0aZNSsH = (721 - 720);
            }
            if (!('\0' != YNIL6PqS[xAqOnfZdTop])) {
                printf ("%d)", QVloO0aZNSsH);
                break;
            }
            xAqOnfZdTop = xAqOnfZdTop + (767 - 766);
        }
    }
}

