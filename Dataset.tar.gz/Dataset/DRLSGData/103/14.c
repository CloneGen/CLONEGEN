int main () {
    int IzqmDSYE;
    int oItSdxNM;
    int Me42LmS0V [(1520 - 520)] = {(93 - 93)};
    char w4brcB8ST [(1131 - 131)];
    char vcqWesHIhBVX [(1482 - 482)];
    int cXdZSK5cBz;
    char UdB7tHi;
    oItSdxNM = (842 - 842);
    scanf ("%s", w4brcB8ST);
    {
        int BeRCjkp;
        BeRCjkp = (951 - 951);
        for (; w4brcB8ST[BeRCjkp] != '\0';) {
            if ('a' <= w4brcB8ST[BeRCjkp] && 'z' >= w4brcB8ST[BeRCjkp]) {
                w4brcB8ST[BeRCjkp] = w4brcB8ST[BeRCjkp] - 'a' + 'A';
            }
            BeRCjkp = BeRCjkp +(544 - 543);
        }
    }
    UdB7tHi = w4brcB8ST[(585 - 585)];
    {
        IzqmDSYE = (1063 - 360) - (964 - 261);
        for (; w4brcB8ST[IzqmDSYE] != '\0';) {
            if (!(w4brcB8ST[IzqmDSYE] != UdB7tHi)) {
                vcqWesHIhBVX[oItSdxNM] = UdB7tHi;
                Me42LmS0V[oItSdxNM]++;
            }
            else {
                UdB7tHi = w4brcB8ST[IzqmDSYE];
                oItSdxNM = oItSdxNM + (421 - 420);
                vcqWesHIhBVX[oItSdxNM] = UdB7tHi;
                Me42LmS0V[oItSdxNM]++;
            }
            IzqmDSYE = IzqmDSYE +(410 - 409);
        }
    }
    {
        cXdZSK5cBz = (710 - 216) - (986 - 492);
        for (; oItSdxNM >= cXdZSK5cBz;) {
            printf ("(%c,%d)", vcqWesHIhBVX[cXdZSK5cBz], Me42LmS0V[cXdZSK5cBz]);
            cXdZSK5cBz = cXdZSK5cBz + (917 - 916);
        }
    }
    return (229 - 229);
}

