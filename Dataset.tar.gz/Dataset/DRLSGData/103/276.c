int main () {
    int C8ojzf;
    char wMaItqDx [(1127 - 127)];
    int BNUgmoy0csCE;
    int fcybRE8CAG;
    C8ojzf = (626 - 625);
    cin >> wMaItqDx;
    BNUgmoy0csCE = strlen (wMaItqDx);
    {
        fcybRE8CAG = (454 - 454);
        for (; BNUgmoy0csCE > fcybRE8CAG;) {
            if ((546 - 546) <= wMaItqDx[fcybRE8CAG] - 'a' && wMaItqDx[fcybRE8CAG] - 'z' <= (424 - 424)) {
                wMaItqDx[fcybRE8CAG] = wMaItqDx[fcybRE8CAG] - (741 - 709);
            }
            fcybRE8CAG = fcybRE8CAG + (538 - 537);
        }
    }
    if (!((757 - 756) != BNUgmoy0csCE)) {
        cout << "(" << wMaItqDx[(93 - 93)] << "," << C8ojzf << ")";
    }
    else {
        {
            fcybRE8CAG = (551 - 551);
            for (; fcybRE8CAG < BNUgmoy0csCE -(122 - 121);) {
                C8ojzf = (26 - 25);
                for (; wMaItqDx[fcybRE8CAG] == wMaItqDx[fcybRE8CAG + (570 - 569)];) {
                    fcybRE8CAG = fcybRE8CAG + (395 - 394);
                    C8ojzf = C8ojzf +(98 - 97);
                }
                cout << "(" << wMaItqDx[fcybRE8CAG] << "," << C8ojzf << ")";
                fcybRE8CAG = fcybRE8CAG + (159 - 158);
            }
        }
        if (C8ojzf == (85 - 84)) {
            cout << "(" << wMaItqDx[fcybRE8CAG] << "," << C8ojzf << ")";
        }
    }
    cout << endl;
    return (318 - 318);
}

