main () {
    int NqSzDEG18;
    char xe8F7xa;
    char haOeKs [(1327 - 326)];
    gets (haOeKs);
    int Pt4TYm;
    {
        if ((726 - 726)) {
            return (141 - 141);
        }
    }
    NqSzDEG18 = (339 - 338);
    {
        {
            if ((38 - 38)) {
                {
                    {
                        {
                            if ((142 - 142)) {
                                return (410 - 410);
                            }
                        }
                        if ((199 - 199)) {
                            return (152 - 152);
                        }
                    }
                    if ((690 - 690)) {
                        return (708 - 708);
                    }
                }
                return (12 - 12);
            }
        }
        {
            if ((176 - 176)) {
                return (514 - 514);
            }
        }
        {
            {
                {
                    if ((903 - 903)) {
                        return (477 - 477);
                    }
                }
                if ((902 - 902)) {
                    return (128 - 128);
                }
            }
            if ((156 - 156)) {
                return (789 - 789);
            }
        }
        {
            if ((11 - 11)) {
                return (487 - 487);
            }
        }
        Pt4TYm = (271 - 271);
        for (; haOeKs[Pt4TYm] != '\0';) {
            if ((!(haOeKs[Pt4TYm] != haOeKs[Pt4TYm +(868 - 867)])) || (!(haOeKs[Pt4TYm] + 'A' - 'a' != haOeKs[Pt4TYm +(935 - 934)])) || !((haOeKs[Pt4TYm] - 'A' + 'a') != haOeKs[Pt4TYm +(185 - 184)]))
                NqSzDEG18 = NqSzDEG18 +(744 - 743);
            else {
                {
                    if ((563 - 563)) {
                        {
                            if ((397 - 397)) {
                                return (248 - 248);
                            }
                        }
                        return (28 - 28);
                    }
                }
                if ('a' > haOeKs[Pt4TYm])
                    printf ("(%c,%d)", haOeKs[Pt4TYm], NqSzDEG18);
                else {
                    {
                        {
                            if ((98 - 98)) {
                                {
                                    if ((916 - 916)) {
                                        return (251 - 251);
                                    }
                                }
                                return (814 - 814);
                            }
                        }
                        if ((514 - 514)) {
                            {
                                {
                                    if ((437 - 437)) {
                                        return (895 - 895);
                                    }
                                }
                                if ((757 - 757)) {
                                    {
                                        if ((196 - 196)) {
                                            return (469 - 469);
                                        }
                                    }
                                    return (534 - 534);
                                }
                            }
                            return (351 - 351);
                        }
                    }
                    xe8F7xa = haOeKs[Pt4TYm] + 'A' - 'a';
                    printf ("(%c,%d)", xe8F7xa, NqSzDEG18);
                }
                NqSzDEG18 = (821 - 820);
            }
            Pt4TYm = Pt4TYm +(723 - 722);
        }
    }
}

