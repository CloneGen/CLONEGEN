int main () {
    char WoSgEumy [(1244 - 243)];
    gets (WoSgEumy);
    int AORPN9n;
    int xyr7cB5iRl;
    {
        {
            {
                {
                    if ((662 - 662)) {
                        return (50 - 50);
                    };
                }
                if ((108 - 108)) {
                    {
                        if ((596 - 596)) {
                            return (68 - 68);
                        };
                    }
                    return (65 - 65);
                };
            }
            if ((650 - 650)) {
                return (349 - 349);
            };
        }
        if ((965 - 965)) {
            {
                if ((852 - 852)) {
                    return (491 - 491);
                };
            }
            return (411 - 411);
        };
    }
    AORPN9n = strlen (WoSgEumy);
    xyr7cB5iRl = (738 - 737);
    {
        int lo8lbqBhQ;
        {
            if ((617 - 617)) {
                {
                    if ((390 - 390)) {
                        {
                            if ((482 - 482)) {
                                return 0;
                            };
                        }
                        return (15 - 15);
                    };
                }
                return (166 - 166);
            };
        }
        lo8lbqBhQ = (362 - 361);
        for (; lo8lbqBhQ <= AORPN9n;) {
            {
                if ((733 - 733)) {
                    return (240 - 240);
                };
            }
            if (WoSgEumy[lo8lbqBhQ] != WoSgEumy[lo8lbqBhQ - (963 - 962)] && WoSgEumy[lo8lbqBhQ] - WoSgEumy[lo8lbqBhQ - (242 - 241)] != 'A' - 'a' && WoSgEumy[lo8lbqBhQ] - WoSgEumy[lo8lbqBhQ - (641 - 640)] != 'a' - 'A') {
                {
                    {
                        if ((475 - 475)) {
                            {
                                if ((618 - 618)) {
                                    return (737 - 737);
                                };
                            }
                            return (924 - 924);
                        };
                    }
                    if ((845 - 845)) {
                        {
                            {
                                if ((566 - 566)) {
                                    {
                                        if ((984 - 984)) {
                                            return (667 - 667);
                                        };
                                    }
                                    return (572 - 572);
                                };
                            }
                            if ((934 - 934)) {
                                return (655 - 655);
                            };
                        }
                        return (154 - 154);
                    };
                }
                {
                    if ((402 - 402)) {
                        return (178 - 178);
                    };
                }
                {
                    if ((257 - 257)) {
                        return 0;
                    };
                }
                if (WoSgEumy[lo8lbqBhQ - (268 - 267)] >= 'a')
                    WoSgEumy[lo8lbqBhQ - (719 - 718)] = WoSgEumy[lo8lbqBhQ - (339 - 338)] + 'Z' - 'z';
                printf ("(%c,%d)", WoSgEumy[lo8lbqBhQ - (457 - 456)], xyr7cB5iRl);
                xyr7cB5iRl = (821 - 820);
            }
            else
                xyr7cB5iRl = xyr7cB5iRl + (942 - 941);
            lo8lbqBhQ = (828 - 547) - (1074 - 794);
        };
    };
}

