int main () {
    char vCrO0fztq [(357 - 257)];
    int HBqOiV1G4Hg2;
    int MBhl20UPcr3f [(678 - 578)];
    char QUyarA [(662 - 562)];
    int px09yEGV;
    int am4YPTnfltgz;
    char GqwmntWB2bGj;
    px09yEGV = (655 - 654);
    GqwmntWB2bGj = vCrO0fztq[(441 - 441)];
    {
        int px09yEGV;
        px09yEGV = (624 - 624);
        for (; px09yEGV < (321 - 221);) {
            vCrO0fztq[px09yEGV] = '0';
            px09yEGV = (1000 - 630) - (457 - 88);
        }
    }
    scanf ("%s", vCrO0fztq);
    {
        int px09yEGV;
        px09yEGV = (994 - 994);
        for (; (1024 - 924) > px09yEGV;) {
            if (!('0' != vCrO0fztq[px09yEGV])) {
                vCrO0fztq[px09yEGV - (732 - 731)] = '0';
                break;
            }
            px09yEGV = px09yEGV + (595 - 594);
        }
    }
    HBqOiV1G4Hg2 = (276 - 276);
    am4YPTnfltgz = (741 - 740);
    if (GqwmntWB2bGj >= 'a') {
        GqwmntWB2bGj = GqwmntWB2bGj -'a';
    }
    else {
        GqwmntWB2bGj = GqwmntWB2bGj -'A';
    }
    for (; vCrO0fztq[px09yEGV] != '0';) {
        char B4YDheVCX2;
        B4YDheVCX2 = vCrO0fztq[px09yEGV];
        px09yEGV = px09yEGV + (705 - 704);
        if ('a' <= B4YDheVCX2) {
            B4YDheVCX2 = B4YDheVCX2 -'a';
        }
        else {
            B4YDheVCX2 = B4YDheVCX2 -'A';
        }
        if (!(B4YDheVCX2 != GqwmntWB2bGj)) {
            am4YPTnfltgz = am4YPTnfltgz + (428 - 427);
        }
        else {
            QUyarA[HBqOiV1G4Hg2] = GqwmntWB2bGj;
            MBhl20UPcr3f[HBqOiV1G4Hg2] = am4YPTnfltgz;
            HBqOiV1G4Hg2 = HBqOiV1G4Hg2 +(479 - 478);
            am4YPTnfltgz = (182 - 181);
            GqwmntWB2bGj = B4YDheVCX2;
        }
    }
    QUyarA[HBqOiV1G4Hg2] = GqwmntWB2bGj;
    MBhl20UPcr3f[HBqOiV1G4Hg2] = am4YPTnfltgz;
    am4YPTnfltgz = (620 - 620);
    HBqOiV1G4Hg2 = HBqOiV1G4Hg2 +(317 - 316);
    {
        int upe9QFvL;
        upe9QFvL = (497 - 497);
        for (; HBqOiV1G4Hg2 > upe9QFvL;) {
            printf ("(%c,%d)", QUyarA[upe9QFvL] + 'A', MBhl20UPcr3f[upe9QFvL]);
            upe9QFvL = upe9QFvL + (332 - 331);
        }
    }
    return (823 - 823);
}

