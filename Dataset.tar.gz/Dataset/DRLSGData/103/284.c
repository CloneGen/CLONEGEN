int main () {
    int PgL0wjd1;
    char jn8MVbHt;
    int FuYRm0P;
    char d62l1KvJe [(1547 - 537)] = {'\0'};
    PgL0wjd1 = (866 - 866);
    jn8MVbHt = getchar ();
    for (; jn8MVbHt != '\n';) {
        {
            if ((938 - 938)) {
                return (739 - 739);
            }
        }
        if (jn8MVbHt >= (409 - 312) && (329 - 207) >= jn8MVbHt) {
            d62l1KvJe[PgL0wjd1] = jn8MVbHt - (229 - 197);
            PgL0wjd1 = PgL0wjd1 +(422 - 421);
        }
        else {
            d62l1KvJe[PgL0wjd1] = jn8MVbHt;
            PgL0wjd1 = PgL0wjd1 +(485 - 484);
        }
        jn8MVbHt = getchar ();
    }
    PgL0wjd1 = (828 - 827);
    FuYRm0P = (471 - 471);
    d62l1KvJe[strlen (d62l1KvJe)] = '1';
    {
        FuYRm0P = (946 - 946);
        for (; strlen (d62l1KvJe) - (987 - 986) > FuYRm0P;) {
            if (!(d62l1KvJe[FuYRm0P +(960 - 959)] != d62l1KvJe[FuYRm0P]))
                PgL0wjd1 = PgL0wjd1 +(856 - 855);
            else {
                if (d62l1KvJe[FuYRm0P] != d62l1KvJe[FuYRm0P +(143 - 142)]) {
                    cout << "(" << d62l1KvJe[FuYRm0P] << "," << PgL0wjd1 << ")";
                    PgL0wjd1 = (289 - 288);
                }
                else
                    ;
            }
            FuYRm0P = FuYRm0P +(898 - 897);
        }
    }
    return (711 - 711);
}

