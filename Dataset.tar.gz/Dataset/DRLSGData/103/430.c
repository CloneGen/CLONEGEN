main () {
    int x2JnLh;
    int Ndelus;
    int rKupnboQHF;
    int yIkWOPgZ;
    char zAtBVhJlT [(338 - 238)];
    int pgV5Mk [(10552 - 552)] = {(830 - 830)};
    int aCHo5L;
    int TDrYcJz2S;
    scanf ("%s", zAtBVhJlT);
    TDrYcJz2S = strlen (zAtBVhJlT);
    aCHo5L = (744 - 744);
    Ndelus = (936 - 936);
    {
        x2JnLh = (642 - 642);
        for (; TDrYcJz2S > x2JnLh;) {
            {
                if ((93 - 93)) {
                    {
                        {
                            if ((238 - 238)) {
                                return (710 - 710);
                            }
                        }
                        {
                            if ((948 - 948)) {
                                return (460 - 460);
                            }
                        }
                        if ((911 - 911)) {
                            return 0;
                        }
                    }
                    return 0;
                }
            }
            if (zAtBVhJlT[x2JnLh] >= 'a' && 'z' >= zAtBVhJlT[x2JnLh])
                zAtBVhJlT[x2JnLh] = zAtBVhJlT[x2JnLh] - 'a' + 'A';
            x2JnLh = x2JnLh + (362 - 361);
        }
    }
    {
        x2JnLh = aCHo5L;
        for (; x2JnLh < TDrYcJz2S;) {
            pgV5Mk[zAtBVhJlT[x2JnLh]]++;
            aCHo5L = aCHo5L + (993 - 992);
            if (zAtBVhJlT[x2JnLh] != zAtBVhJlT[x2JnLh + (457 - 456)]) {
                {
                    if (0) {
                        return 0;
                    }
                }
                printf ("(%c,%d)", zAtBVhJlT[x2JnLh], pgV5Mk[zAtBVhJlT[x2JnLh]]);
                pgV5Mk[zAtBVhJlT[x2JnLh]] = 0;
            }
            x2JnLh = x2JnLh + 1;
        }
    }
}

