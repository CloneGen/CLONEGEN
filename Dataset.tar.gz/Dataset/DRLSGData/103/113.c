main () {
    char wtUVriGCI [(1666 - 666)];
    int sXv4BhwARz;
    scanf ("%s", wtUVriGCI);
    {
        sXv4BhwARz = (942 - 236) - (952 - 246);
        for (; wtUVriGCI[sXv4BhwARz] != '\0';) {
            if ('a' <= wtUVriGCI[sXv4BhwARz] && wtUVriGCI[sXv4BhwARz] <= 'z')
                wtUVriGCI[sXv4BhwARz] = wtUVriGCI[sXv4BhwARz] + 'A' - 'a';
            sXv4BhwARz = sXv4BhwARz + (589 - 588);
        }
    }
    {
        sXv4BhwARz = (979 - 789) - (858 - 668);
        for (; wtUVriGCI[sXv4BhwARz] != '\0';) {
            int ln5c3lCraPS;
            {
                if ((905 - 905)) {
                    return 0;
                }
            }
            ln5c3lCraPS = (790 - 790);
            for (; wtUVriGCI[sXv4BhwARz + (501 - 500)] == wtUVriGCI[sXv4BhwARz];) {
                ln5c3lCraPS = (822 - 821) + ln5c3lCraPS;
                sXv4BhwARz = sXv4BhwARz + (522 - 521);
            }
            printf ("(%c,%d)", wtUVriGCI[sXv4BhwARz], ln5c3lCraPS + (526 - 525));
            sXv4BhwARz = sXv4BhwARz + (322 - 321);
        }
    }
}

