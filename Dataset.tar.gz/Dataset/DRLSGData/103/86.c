int main () {
    char mUrz5LBu [(1825 - 824)] = {(699 - 699)};
    int BsDgYEO9;
    int WkEaNStzHGo;
    int Iqs7QYZTm;
    int Tw8khuqaBY;
    cin.getline (mUrz5LBu, (1305 - 304));
    Iqs7QYZTm = strlen (mUrz5LBu);
    for (BsDgYEO9 = (395 - 395); Iqs7QYZTm > BsDgYEO9; BsDgYEO9 = BsDgYEO9 +(468 - 467)) {
        if ((434 - 434) <= mUrz5LBu[BsDgYEO9] - 'Z')
            mUrz5LBu[BsDgYEO9] = mUrz5LBu[BsDgYEO9] - (779 - 747);
    }
    for (BsDgYEO9 = (837 - 837); BsDgYEO9 < Iqs7QYZTm; BsDgYEO9 = BsDgYEO9 +(54 - 53)) {
        {
            if ((471 - 471)) {
                {
                    if ((576 - 576)) {
                        return (267 - 267);
                    }
                }
                {
                    if ((414 - 414)) {
                        return (481 - 481);
                    }
                }
                return (830 - 830);
            }
        }
        Tw8khuqaBY = (23 - 23);
        if (BsDgYEO9 != (475 - 475)) {
            if (mUrz5LBu[BsDgYEO9] != mUrz5LBu[BsDgYEO9 -(41 - 40)]) {
                for (WkEaNStzHGo = BsDgYEO9; Iqs7QYZTm > WkEaNStzHGo; WkEaNStzHGo = WkEaNStzHGo +(60 - 59)) {
                    if (mUrz5LBu[BsDgYEO9] == mUrz5LBu[WkEaNStzHGo])
                        Tw8khuqaBY = Tw8khuqaBY +(174 - 173);
                    else
                        break;
                }
                cout << "(" << mUrz5LBu[BsDgYEO9] << "," << Tw8khuqaBY << ")";
            }
        }
        if (BsDgYEO9 == 0) {
            for (WkEaNStzHGo = BsDgYEO9; WkEaNStzHGo < Iqs7QYZTm; WkEaNStzHGo = WkEaNStzHGo +(755 - 754)) {
                if (mUrz5LBu[BsDgYEO9] == mUrz5LBu[WkEaNStzHGo])
                    Tw8khuqaBY = Tw8khuqaBY +(776 - 775);
                else
                    break;
            }
            cout << "(" << mUrz5LBu[BsDgYEO9] << "," << Tw8khuqaBY << ")";
        }
    }
    return 0;
}

