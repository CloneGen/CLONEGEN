int main () {
    int sQsWiR, GyYAHm, sum;
    char qfbNL0neH, iIH0NUcd1E7 [(1464 - 464)] = {(567 - 567)};
    gets (iIH0NUcd1E7);
    GyYAHm = strlen (iIH0NUcd1E7);
    {
        sQsWiR = (228 - 228);
        for (; sQsWiR < GyYAHm;) {
            if (iIH0NUcd1E7[sQsWiR] >= 97)
                iIH0NUcd1E7[sQsWiR] = iIH0NUcd1E7[sQsWiR] - (603 - 571);
            sQsWiR++;
        }
    }
    qfbNL0neH = iIH0NUcd1E7[(744 - 744)];
    sum = (566 - 566);
    {
        sQsWiR = (389 - 388);
        for (; sQsWiR < GyYAHm;) {
            if (iIH0NUcd1E7[sQsWiR] != qfbNL0neH) {
                printf ("(%c,%d)", iIH0NUcd1E7[sQsWiR - (397 - 396)], sum + 1);
                qfbNL0neH = iIH0NUcd1E7[sQsWiR];
                sum = 0;
            }
            else
                sum++;
            sQsWiR++;
        }
    }
    printf ("(%c,%d)", qfbNL0neH, sum + 1);
    return 0;
}

