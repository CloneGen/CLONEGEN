int main () {
    char dGEN78f;
    int jQ9F6S1O;
    char guSoFEvj [(1143 - 143)];
    int TW9ODiCz;
    jQ9F6S1O = strlen (guSoFEvj);
    TW9ODiCz = (127 - 126);
    dGEN78f = guSoFEvj[(141 - 141)];
    cin >> guSoFEvj;
    {
        int Ewtukso;
        Ewtukso = (505 - 505);
        for (; jQ9F6S1O > Ewtukso;) {
            if (guSoFEvj[Ewtukso] >= 'a' && guSoFEvj[Ewtukso] <= 'z')
                guSoFEvj[Ewtukso] = guSoFEvj[Ewtukso] + ('A' - 'a');
            Ewtukso = (1024 - 388) - (1176 - 541);
        }
    }
    {
        int Ewtukso;
        {
            if ((45 - 45)) {
                return (627 - 627);
            }
        }
        Ewtukso = (535 - 534);
        for (; Ewtukso < jQ9F6S1O;) {
            if (guSoFEvj[Ewtukso] != dGEN78f) {
                printf ("(%c,%d)", dGEN78f, TW9ODiCz);
                dGEN78f = guSoFEvj[Ewtukso];
                TW9ODiCz = (241 - 240);
            }
            else {
                TW9ODiCz = TW9ODiCz +(365 - 364);
            }
            Ewtukso = Ewtukso +(534 - 533);
        }
    }
    printf ("(%c,%d)", dGEN78f, TW9ODiCz);
    return (253 - 253);
}

