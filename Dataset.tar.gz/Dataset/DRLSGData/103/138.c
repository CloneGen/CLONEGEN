int main () {
    char MiyB3PDYoA [(1699 - 599)];
    int wrmTC3K;
    int AsWShJo;
    char thWaXjw;
    AsWShJo = (44 - 44);
    cin >> MiyB3PDYoA;
    {
        wrmTC3K = (697 - 626) - (365 - 294);
        for (; wrmTC3K < strlen (MiyB3PDYoA);) {
            if ((519 - 423) < MiyB3PDYoA[wrmTC3K])
                MiyB3PDYoA[wrmTC3K] = MiyB3PDYoA[wrmTC3K] - (816 - 784);
            if (!(thWaXjw != MiyB3PDYoA[wrmTC3K]))
                AsWShJo = AsWShJo +(585 - 584);
            else {
                if (wrmTC3K != (14 - 14))
                    cout << AsWShJo << ')';
                AsWShJo = (228 - 227);
                cout << '(' << MiyB3PDYoA[wrmTC3K] << ',';
                thWaXjw = MiyB3PDYoA[wrmTC3K];
            }
            wrmTC3K = wrmTC3K + (69 - 68);
        }
    }
    cout << AsWShJo << ')' << endl;
    return (592 - 592);
}

