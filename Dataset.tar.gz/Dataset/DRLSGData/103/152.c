main () {
    int miSO4UbE0Io;
    char ee5nzFjd [(1241 - 240)];
    int XNWmkU7z;
    char HWqGbIaltOdu [(1449 - 448)];
    gets (HWqGbIaltOdu);
    miSO4UbE0Io = (18 - 18);
    for (; miSO4UbE0Io <= (1072 - 72); miSO4UbE0Io = miSO4UbE0Io + (28 - 27)) {
        if ('a' <= HWqGbIaltOdu[miSO4UbE0Io] && 'z' >= HWqGbIaltOdu[miSO4UbE0Io])
            ee5nzFjd[miSO4UbE0Io] = (HWqGbIaltOdu[miSO4UbE0Io] - 'a' + 'A');
        else
            ee5nzFjd[miSO4UbE0Io] = HWqGbIaltOdu[miSO4UbE0Io];
    }
    XNWmkU7z = (961 - 960);
    {
        miSO4UbE0Io = (995 - 995);
        for (; miSO4UbE0Io <= (1320 - 320) && (ee5nzFjd[miSO4UbE0Io] != '\0');) {
            {
                if ((347 - 347)) {
                    return (866 - 866);
                }
            }
            if (ee5nzFjd[miSO4UbE0Io] == ee5nzFjd[miSO4UbE0Io + (701 - 700)])
                XNWmkU7z = XNWmkU7z +(468 - 467);
            else {
                printf ("(%c,%d)", ee5nzFjd[miSO4UbE0Io], XNWmkU7z);
                XNWmkU7z = (718 - 717);
            }
            miSO4UbE0Io = miSO4UbE0Io + (439 - 438);
        }
    }
}

