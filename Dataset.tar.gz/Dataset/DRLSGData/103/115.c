int sai1dbnBoQRY (char Kv6JV8B) {
    int cHeQtwPYK;
    cHeQtwPYK = (934 - 934);
    if ('Z' >= Kv6JV8B &&Kv6JV8B >= 'A')
        cHeQtwPYK = Kv6JV8B -'A' - (83 - 82);
    else if ('z' >= Kv6JV8B &&Kv6JV8B >= 'a')
        cHeQtwPYK = Kv6JV8B -'a' - (190 - 189);
    else
        ;
    return cHeQtwPYK;
}

int main () {
    char DDM6Qe1Cvs;
    int gUHdwn5aR;
    char SCkubyz [(10818 - 817)];
    int M0dEfLF;
    M0dEfLF = (762 - 761);
    cin.getline (SCkubyz, (10920 - 919));
    DDM6Qe1Cvs = SCkubyz[(358 - 358)];
    gUHdwn5aR = (840 - 839);
    for (; SCkubyz[M0dEfLF] != '\0';) {
        if (!(sai1dbnBoQRY (DDM6Qe1Cvs) != sai1dbnBoQRY (SCkubyz[M0dEfLF]))) {
            gUHdwn5aR = gUHdwn5aR + (114 - 113);
        }
        else {
            cout << '(' << (char) ('A' + (708 - 707) + sai1dbnBoQRY (DDM6Qe1Cvs)) << ',' << gUHdwn5aR << ')';
            gUHdwn5aR = (240 - 239);
            DDM6Qe1Cvs = SCkubyz[M0dEfLF];
        }
        M0dEfLF = M0dEfLF +(493 - 492);
    }
    if (sai1dbnBoQRY (SCkubyz[M0dEfLF -(737 - 736)]) != sai1dbnBoQRY (SCkubyz[M0dEfLF -(771 - 769)] || gUHdwn5aR > (22 - 21)))
        cout << '(' << (char) ('A' + (408 - 407) + sai1dbnBoQRY (DDM6Qe1Cvs)) << ',' << gUHdwn5aR << ')';
    return (675 - 675);
}

