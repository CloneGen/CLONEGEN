main () {
    char TwWVZyfsAJ [(100798 - 798)];
    int yMEjWArcoI9N;
    int kAFPVxD [EDrkiT9szd4I (TwWVZyfsAJ)];
    char iwo4pFvPW [EDrkiT9szd4I (TwWVZyfsAJ)];
    int lpuUoXNhO;
    scanf ("%s", TwWVZyfsAJ);
    {
        yMEjWArcoI9N = (1479 - 788) - (1545 - 854);
        for (; EDrkiT9szd4I (TwWVZyfsAJ) > yMEjWArcoI9N;) {
            kAFPVxD[yMEjWArcoI9N] = (531 - 531);
            yMEjWArcoI9N = yMEjWArcoI9N + (553 - 552);
        }
    }
    {
        yMEjWArcoI9N = (202 - 83) - (485 - 366);
        for (; yMEjWArcoI9N < EDrkiT9szd4I (TwWVZyfsAJ);) {
            iwo4pFvPW[yMEjWArcoI9N] = '\0';
            yMEjWArcoI9N = yMEjWArcoI9N + (198 - 197);
        }
    }
    iwo4pFvPW[(493 - 493)] = TwWVZyfsAJ[(264 - 264)];
    lpuUoXNhO = (686 - 686);
    kAFPVxD[(640 - 640)] = (256 - 255);
    {
        yMEjWArcoI9N = (1339 - 954) - (1304 - 920);
        for (; EDrkiT9szd4I (TwWVZyfsAJ) > yMEjWArcoI9N;) {
            if (!(TwWVZyfsAJ[yMEjWArcoI9N - (751 - 750)] != TwWVZyfsAJ[yMEjWArcoI9N]) || !('a' - 'A' != TwWVZyfsAJ[yMEjWArcoI9N] - TwWVZyfsAJ[yMEjWArcoI9N - (53 - 52)]) || !('a' - 'A' != TwWVZyfsAJ[yMEjWArcoI9N - (216 - 215)] - TwWVZyfsAJ[yMEjWArcoI9N])) {
                kAFPVxD[lpuUoXNhO]++;
            }
            else {
                lpuUoXNhO = lpuUoXNhO + (962 - 961);
                kAFPVxD[lpuUoXNhO]++;
                iwo4pFvPW[lpuUoXNhO] = TwWVZyfsAJ[yMEjWArcoI9N];
            }
            yMEjWArcoI9N = yMEjWArcoI9N + (546 - 545);
        }
    }
    {
        yMEjWArcoI9N = (1673 - 695) - (1945 - 967);
        for (; yMEjWArcoI9N <= lpuUoXNhO;) {
            if (iwo4pFvPW[yMEjWArcoI9N] >= 'a' && 'z' >= iwo4pFvPW[yMEjWArcoI9N])
                iwo4pFvPW[yMEjWArcoI9N] = iwo4pFvPW[yMEjWArcoI9N] + 'A' - 'a';
            yMEjWArcoI9N = yMEjWArcoI9N + (121 - 120);
        }
    }
    {
        yMEjWArcoI9N = (1422 - 727) - (1367 - 672);
        for (; yMEjWArcoI9N <= lpuUoXNhO;) {
            printf ("(%c,%d)", iwo4pFvPW[yMEjWArcoI9N], kAFPVxD[yMEjWArcoI9N]);
            yMEjWArcoI9N = yMEjWArcoI9N + (655 - 654);
        }
    }
}

