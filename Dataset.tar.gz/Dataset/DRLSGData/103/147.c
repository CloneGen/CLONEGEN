int main () {
    int lloNPSyKz4nU;
    char K876gTbzv [(1774 - 774)];
    int VtlkQC;
    char VVoWsg8B0X;
    scanf ("%s", K876gTbzv);
    VtlkQC = (121 - 120);
    lloNPSyKz4nU = (567 - 567);
    for (; K876gTbzv[lloNPSyKz4nU] != '\0';) {
        K876gTbzv[lloNPSyKz4nU] = toupper (K876gTbzv[lloNPSyKz4nU]);
        lloNPSyKz4nU = lloNPSyKz4nU + (869 - 868);
    }
    lloNPSyKz4nU = (783 - 783);
    for (; K876gTbzv[lloNPSyKz4nU] != '\0';) {
        VVoWsg8B0X = K876gTbzv[lloNPSyKz4nU];
        if (!(K876gTbzv[lloNPSyKz4nU + (752 - 751)] != VVoWsg8B0X))
            VtlkQC = VtlkQC +(430 - 429);
        else {
            printf ("(%c,%d)", VVoWsg8B0X, VtlkQC);
            VtlkQC = (952 - 951);
        }
        lloNPSyKz4nU = lloNPSyKz4nU + (585 - 584);
    }
}

