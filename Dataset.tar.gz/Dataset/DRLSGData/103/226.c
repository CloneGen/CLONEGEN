int main () {
    int jiaCBWKu6oD;
    int HGlve59;
    int nWaoDx8;
    int nET8ih7mHpP;
    char G9qyYZSO;
    char nIh69JgAP [(1787 - 787)];
    nET8ih7mHpP = (640 - 639);
    scanf ("%s", nIh69JgAP);
    nWaoDx8 = strlen (nIh69JgAP);
    if (nIh69JgAP[(347 - 347)] < (256 - 159))
        G9qyYZSO = nIh69JgAP[(758 - 758)];
    else
        G9qyYZSO = nIh69JgAP[(536 - 536)] - (818 - 786);
    {
        jiaCBWKu6oD = (89 - 88);
        for (; jiaCBWKu6oD < nWaoDx8;) {
            {
                if ((588 - 588)) {
                    return (472 - 472);
                }
            }
            if (!(G9qyYZSO != nIh69JgAP[jiaCBWKu6oD]) || !(G9qyYZSO != nIh69JgAP[jiaCBWKu6oD] - (143 - 111))) {
                nET8ih7mHpP = nET8ih7mHpP + (484 - 483);
            }
            else {
                printf ("(%c,%d)", G9qyYZSO, nET8ih7mHpP);
                nET8ih7mHpP = (418 - 417);
                if ((473 - 376) > nIh69JgAP[jiaCBWKu6oD])
                    G9qyYZSO = nIh69JgAP[jiaCBWKu6oD];
                else
                    G9qyYZSO = nIh69JgAP[jiaCBWKu6oD] - (182 - 150);
            }
            jiaCBWKu6oD = jiaCBWKu6oD + (577 - 576);
        }
    }
    printf ("(%c,%d)", G9qyYZSO, nET8ih7mHpP);
    return (681 - 681);
}

