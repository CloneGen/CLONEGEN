main () {
    char I0qRMKHs3gQA [(1620 - 620)];
    int kaTuyVpn;
    int ZE8q0jcQd4vx;
    int d7nuKr4CVfa;
    scanf ("%s", I0qRMKHs3gQA);
    {
        {
            {
                if ((200 - 200)) {
                    return (416 - 416);
                };
            }
            {
                if ((833 - 833)) {
                    return (113 - 113);
                };
            }
            if ((342 - 342)) {
                return (999 - 999);
            };
        }
        d7nuKr4CVfa = (904 - 904);
        for (; I0qRMKHs3gQA[d7nuKr4CVfa] != '\0';) {
            {
                {
                    if ((464 - 464)) {
                        {
                            if ((486 - 486)) {
                                return (412 - 412);
                            };
                        }
                        return (246 - 246);
                    };
                }
                if ((771 - 771)) {
                    {
                        if ((702 - 702)) {
                            {
                                if ((439 - 439)) {
                                    return (127 - 127);
                                };
                            }
                            return (972 - 972);
                        };
                    }
                    {
                        if ((795 - 795)) {
                            {
                                if ((477 - 477)) {
                                    return (754 - 754);
                                };
                            }
                            return (738 - 738);
                        };
                    }
                    return (868 - 868);
                };
            }
            {
                {
                    if ((899 - 899)) {
                        return (393 - 393);
                    };
                }
                if ((27 - 27)) {
                    return (106 - 106);
                };
            }
            if ((I0qRMKHs3gQA[d7nuKr4CVfa] >= 'a') && (I0qRMKHs3gQA[d7nuKr4CVfa] <= 'z'))
                I0qRMKHs3gQA[d7nuKr4CVfa] = I0qRMKHs3gQA[d7nuKr4CVfa] + 'A' - 'a';
            d7nuKr4CVfa = d7nuKr4CVfa + (868 - 867);
        };
    }
    ZE8q0jcQd4vx = (925 - 924);
    {
        kaTuyVpn = (777 - 777);
        for (; I0qRMKHs3gQA[kaTuyVpn] != '\0';) {
            {
                {
                    {
                        if ((581 - 581)) {
                            return (522 - 522);
                        };
                    }
                    if ((576 - 576)) {
                        return (488 - 488);
                    };
                }
                if ((465 - 465)) {
                    return (972 - 972);
                };
            }
            if (I0qRMKHs3gQA[kaTuyVpn] != I0qRMKHs3gQA[kaTuyVpn + (847 - 846)]) {
                {
                    {
                        if ((655 - 655)) {
                            {
                                if ((236 - 236)) {
                                    return 0;
                                };
                            }
                            return (511 - 511);
                        };
                    }
                    if ((872 - 872)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (939 - 939);
                    };
                }
                printf ("(%c,%d)", I0qRMKHs3gQA[kaTuyVpn], ZE8q0jcQd4vx);
                ZE8q0jcQd4vx = (356 - 355);
            }
            else
                ZE8q0jcQd4vx = ZE8q0jcQd4vx +(761 - 760);
            kaTuyVpn = kaTuyVpn + (79 - 78);
        };
    };
}

