int main () {
    int svBXS6WozJhV [(536 - 436)] [(904 - 804)];
    int ZzXCsSg;
    int rJLWrsuw;
    int tMrgeN2Xh;
    int h0cdIjZ3ES;
    int vOAHC0q;
    int wEV7HRN3a;
    int QipUYwMDh;
    int FaRBWKyeAhk;
    int NGi2pbK;
    char xnFxSjpJtm9Y [(10322 - 322)];
    int fHM4fToqt;
    scanf ("%s", xnFxSjpJtm9Y);
    {
        rJLWrsuw = (48 - 48);
        for (; xnFxSjpJtm9Y[rJLWrsuw];) {
            if ('z' >= xnFxSjpJtm9Y[rJLWrsuw] && xnFxSjpJtm9Y[rJLWrsuw] >= 'a')
                xnFxSjpJtm9Y[rJLWrsuw] = xnFxSjpJtm9Y[rJLWrsuw] + 'A' - 'a';
            rJLWrsuw = rJLWrsuw + (733 - 732);
        }
    }
    FaRBWKyeAhk = (538 - 537);
    {
        rJLWrsuw = (976 - 976);
        for (; xnFxSjpJtm9Y[rJLWrsuw];) {
            if (xnFxSjpJtm9Y[rJLWrsuw] == xnFxSjpJtm9Y[rJLWrsuw + (972 - 971)])
                FaRBWKyeAhk = FaRBWKyeAhk +(740 - 739);
            else {
                printf ("(%c,%d)", xnFxSjpJtm9Y[rJLWrsuw], FaRBWKyeAhk);
                FaRBWKyeAhk = (445 - 444);
            }
            rJLWrsuw = rJLWrsuw + (277 - 276);
        }
    }
    return (530 - 530);
}

