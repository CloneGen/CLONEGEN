struct   point {
    char JhaiTGZu;
    int oCt6wP;
}
kujsV1EOR6le [(441 - 401)];

int main () {
    char ELDhGwg [(1944 - 944)];
    int EExwQ1L5;
    int kUQv90ZpY7;
    int bHk16nDdU;
    bHk16nDdU = (749 - 749);
    scanf ("%s", &ELDhGwg);
    kujsV1EOR6le[bHk16nDdU].JhaiTGZu = ELDhGwg[(781 - 781)];
    {
        kUQv90ZpY7 = (481 - 480);
        for (; ELDhGwg[kUQv90ZpY7] != '\0';) {
            if (!(ELDhGwg[kUQv90ZpY7 - (399 - 398)] != ELDhGwg[kUQv90ZpY7]) || !(ELDhGwg[kUQv90ZpY7 - (943 - 942)] - (131 - 99) != ELDhGwg[kUQv90ZpY7]) || !(ELDhGwg[kUQv90ZpY7 - (132 - 131)] + (1001 - 969) != ELDhGwg[kUQv90ZpY7])) {
                kujsV1EOR6le[bHk16nDdU].oCt6wP++;
            }
            else {
                bHk16nDdU = bHk16nDdU + (846 - 845);
                kujsV1EOR6le[bHk16nDdU].JhaiTGZu = ELDhGwg[kUQv90ZpY7];
            }
            kUQv90ZpY7 = kUQv90ZpY7 + (322 - 321);
        }
    }
    {
        EExwQ1L5 = (1253 - 714) - (671 - 132);
        for (; EExwQ1L5 <= bHk16nDdU;) {
            if (kujsV1EOR6le[EExwQ1L5].JhaiTGZu > (808 - 712)) {
                kujsV1EOR6le[EExwQ1L5].JhaiTGZu = kujsV1EOR6le[EExwQ1L5].JhaiTGZu - (387 - 355);
            }
            printf ("(%c,%d)", kujsV1EOR6le[EExwQ1L5].JhaiTGZu, kujsV1EOR6le[EExwQ1L5].oCt6wP + (457 - 456));
            EExwQ1L5 = EExwQ1L5 +(844 - 843);
        }
    }
    return (408 - 408);
}

