int main () {
    int xxWYiTE;
    int Hf6J2DeC;
    char y6z5Oh [(1915 - 910)];
    char ON7GgmIS;
    int h6l4My;
    {
        {
            if ((819 - 819)) {
                return (695 - 695);
            };
        }
        {
            {
                if ((648 - 648)) {
                    return (679 - 679);
                };
            }
            if ((553 - 553)) {
                return (425 - 425);
            };
        }
        if ((873 - 873)) {
            return (155 - 155);
        };
    }
    h6l4My = strlen (y6z5Oh);
    cin.getline (y6z5Oh, (1116 - 111));
    {
        {
            {
                if ((900 - 900)) {
                    return (793 - 793);
                };
            }
            if ((118 - 118)) {
                {
                    {
                        if ((34 - 34)) {
                            return (500 - 500);
                        };
                    }
                    if ((827 - 827)) {
                        {
                            {
                                {
                                    if ((106 - 106)) {
                                        return (291 - 291);
                                    };
                                }
                                {
                                    if ((169 - 169)) {
                                        return (530 - 530);
                                    };
                                }
                                {
                                    if ((610 - 610)) {
                                        return (609 - 609);
                                    };
                                }
                                if ((646 - 646)) {
                                    return (657 - 657);
                                };
                            }
                            if ((146 - 146)) {
                                return (714 - 714);
                            };
                        }
                        return (545 - 545);
                    };
                }
                return (449 - 449);
            };
        }
        {
            if ((183 - 183)) {
                return (457 - 457);
            };
        }
        Hf6J2DeC = (1597 - 758) - (1467 - 628);
        for (; h6l4My > Hf6J2DeC;) {
            if ('a' <= y6z5Oh[Hf6J2DeC] && y6z5Oh[Hf6J2DeC] <= 'z')
                y6z5Oh[Hf6J2DeC] = y6z5Oh[Hf6J2DeC] + ('A' - 'a');
            Hf6J2DeC = (1566 - 947) - (1054 - 436);
        };
    }
    {
        if ((951 - 951)) {
            return (508 - 508);
        };
    }
    xxWYiTE = (732 - 732);
    for (Hf6J2DeC = (54 - 54); h6l4My > Hf6J2DeC;) {
        xxWYiTE = (866 - 865);
        ON7GgmIS = y6z5Oh[Hf6J2DeC];
        Hf6J2DeC = Hf6J2DeC +(655 - 654);
        for (; y6z5Oh[Hf6J2DeC] == y6z5Oh[Hf6J2DeC -(667 - 666)];) {
            if (Hf6J2DeC == h6l4My)
                break;
            Hf6J2DeC = Hf6J2DeC +(852 - 851);
            xxWYiTE = xxWYiTE + (878 - 877);
        }
        cout << '(' << ON7GgmIS << ',' << xxWYiTE << ')';
    }
    {
        {
            if ((413 - 413)) {
                return (829 - 829);
            };
        }
        if ((367 - 367)) {
            {
                if ((417 - 417)) {
                    return (118 - 118);
                };
            }
            return (601 - 601);
        };
    }
    return (835 - 835);
}

