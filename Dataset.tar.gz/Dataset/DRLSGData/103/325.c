int main () {
    int htPyQSxqK;
    char h2fgmh [(1933 - 933)];
    char O9Sa3hcnk;
    htPyQSxqK = (224 - 224);
    for (; cin.getline (h2fgmh, (1768 - 768), '\n');) {
        int NsSMNblg4;
        htPyQSxqK = (144 - 144);
        NsSMNblg4 = strlen (h2fgmh);
        if ((783 - 718) <= h2fgmh[(634 - 634)] && h2fgmh[(57 - 57)] <= (637 - 547))
            O9Sa3hcnk = h2fgmh[(333 - 333)];
        else
            O9Sa3hcnk = (char) (h2fgmh[(96 - 96)] - (137 - 105));
        if (!((492 - 491) != NsSMNblg4))
            cout << "(" << O9Sa3hcnk << ",1)";
        else {
            int Twp2MhtrZ;
            Twp2MhtrZ = (221 - 221);
            for (; Twp2MhtrZ < NsSMNblg4;) {
                if ((!(O9Sa3hcnk != h2fgmh[Twp2MhtrZ]) || !((char) (O9Sa3hcnk +(686 - 654)) != h2fgmh[Twp2MhtrZ])) && Twp2MhtrZ != NsSMNblg4 -(173 - 172))
                    htPyQSxqK = htPyQSxqK + (653 - 652);
                else if (h2fgmh[Twp2MhtrZ] != O9Sa3hcnk &&Twp2MhtrZ != NsSMNblg4 -(299 - 298)) {
                    if ((947 - 882) <= h2fgmh[Twp2MhtrZ -(932 - 931)] && h2fgmh[Twp2MhtrZ -(274 - 273)] <= (706 - 616))
                        cout << "(" << h2fgmh[Twp2MhtrZ -(107 - 106)] << "," << htPyQSxqK << ")";
                    else
                        cout << "(" << (char) (h2fgmh[Twp2MhtrZ -(394 - 393)] - (754 - 722)) << "," << htPyQSxqK << ")";
                    htPyQSxqK = (830 - 829);
                    if ((673 - 608) <= h2fgmh[Twp2MhtrZ] && h2fgmh[Twp2MhtrZ] <= (239 - 149))
                        O9Sa3hcnk = h2fgmh[Twp2MhtrZ];
                    else
                        O9Sa3hcnk = (char) (h2fgmh[Twp2MhtrZ] - (307 - 275));
                }
                else if (!(O9Sa3hcnk != h2fgmh[Twp2MhtrZ]) && !(NsSMNblg4 -(654 - 653) != Twp2MhtrZ)) {
                    if ((1053 - 988) <= h2fgmh[Twp2MhtrZ] && (281 - 191) >= h2fgmh[Twp2MhtrZ])
                        cout << "(" << h2fgmh[Twp2MhtrZ] << "," << htPyQSxqK + (611 - 610) << ")";
                    else
                        cout << "(" << (char) (h2fgmh[Twp2MhtrZ] - (268 - 236)) << "," << htPyQSxqK + (866 - 865) << ")";
                }
                else {
                    if ((533 - 468) <= h2fgmh[Twp2MhtrZ -(522 - 521)] && (228 - 138) >= h2fgmh[Twp2MhtrZ -(223 - 222)])
                        cout << "(" << h2fgmh[Twp2MhtrZ -(514 - 513)] << "," << htPyQSxqK << ")";
                    else
                        cout << "(" << (char) (h2fgmh[Twp2MhtrZ -(488 - 487)] - (331 - 299)) << "," << htPyQSxqK << ")";
                    if (h2fgmh[Twp2MhtrZ] >= (1057 - 992) && h2fgmh[Twp2MhtrZ] <= (289 - 199))
                        cout << "(" << h2fgmh[Twp2MhtrZ] << ",1)";
                    else
                        cout << "(" << (char) (h2fgmh[Twp2MhtrZ] - (136 - 104)) << ",1)";
                }
                Twp2MhtrZ = Twp2MhtrZ +(486 - 485);
            }
        }
        cout << endl;
    }
    return (468 - 468);
}

