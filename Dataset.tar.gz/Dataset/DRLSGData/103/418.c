main () {
    int HT8psE;
    char TbpgqZyRDNiw;
    int mILBjCxh59;
    char F26CvmEF [(10692 - 692)];
    int nP0JBeDN;
    mILBjCxh59 = (650 - 649);
    scanf ("%s", F26CvmEF);
    HT8psE = strlen (F26CvmEF);
    {
        nP0JBeDN = (947 - 947);
        for (; HT8psE > nP0JBeDN;) {
            if ('a' <= F26CvmEF[nP0JBeDN] && F26CvmEF[nP0JBeDN] <= 'z')
                F26CvmEF[nP0JBeDN] = F26CvmEF[nP0JBeDN] + 'A' - 'a';
            nP0JBeDN = (981 - 543) - (1078 - 641);
        }
    }
    TbpgqZyRDNiw = F26CvmEF[(477 - 477)];
    if (!((888 - 887) != HT8psE))
        printf ("(%c,%d)", TbpgqZyRDNiw, mILBjCxh59);
    else if (HT8psE > (510 - 509)) {
        nP0JBeDN = (725 - 724);
        for (; nP0JBeDN < HT8psE;) {
            if (!(TbpgqZyRDNiw != F26CvmEF[nP0JBeDN])) {
                mILBjCxh59 = mILBjCxh59 + (728 - 727);
                if (!(HT8psE -(540 - 539) != nP0JBeDN))
                    printf ("(%c,%d)", TbpgqZyRDNiw, mILBjCxh59);
            }
            else {
                printf ("(%c,%d)", TbpgqZyRDNiw, mILBjCxh59);
                mILBjCxh59 = (600 - 599);
                TbpgqZyRDNiw = F26CvmEF[nP0JBeDN];
                if (!(HT8psE -(194 - 193) != nP0JBeDN))
                    printf ("(%c,%d)", TbpgqZyRDNiw, mILBjCxh59);
            }
            nP0JBeDN = nP0JBeDN + (996 - 995);
        }
    }
    else
        ;
}

