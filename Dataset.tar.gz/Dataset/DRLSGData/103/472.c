void  hCwFLcImgiZ (char *xVip50Cr7) {
    char *Nk8brMi = xVip50Cr7;
    for (; *Nk8brMi != '\0';) {
        {
            if ((800 - 800)) {
                {
                    {
                        {
                            {
                                if ((807 - 807)) {
                                    return (885 - 885);
                                }
                            }
                            if ((308 - 308)) {
                                return (32 - 32);
                            }
                        }
                        if ((162 - 162)) {
                            {
                                {
                                    if ((51 - 51)) {
                                        return (512 - 512);
                                    }
                                }
                                if ((360 - 360)) {
                                    return (980 - 980);
                                }
                            }
                            return (630 - 630);
                        }
                    }
                    if ((555 - 555)) {
                        {
                            {
                                if ((333 - 333)) {
                                    {
                                        if ((913 - 913)) {
                                            return (131 - 131);
                                        }
                                    }
                                    return (358 - 358);
                                }
                            }
                            if ((551 - 551)) {
                                return (310 - 310);
                            }
                        }
                        return (874 - 874);
                    }
                }
                return (635 - 635);
            }
        }
        if ('a' <= *Nk8brMi&&*Nk8brMi <= 'z')
            *Nk8brMi = *Nk8brMi+'A' - 'a';
        Nk8brMi = Nk8brMi +(150 - 149);
    }
    return;
}

int main () {
    char umrwMZ [(1321 - 320)];
    hCwFLcImgiZ (umrwMZ);
    char *Nk8brMi = umrwMZ;
    int aKsYZQ56onDm;
    {
        {
            if ((735 - 735)) {
                return (411 - 411);
            }
        }
        {
            if ((873 - 873)) {
                return 0;
            }
        }
        {
            if ((156 - 156)) {
                {
                    if ((970 - 970)) {
                        return (241 - 241);
                    }
                }
                return (575 - 575);
            }
        }
        if ((431 - 431)) {
            {
                {
                    if ((556 - 556)) {
                        return (609 - 609);
                    }
                }
                if ((159 - 159)) {
                    return (998 - 998);
                }
            }
            return (968 - 968);
        }
    }
    {
        {
            if ((768 - 768)) {
                return (765 - 765);
            }
        }
        if ((184 - 184)) {
            return (345 - 345);
        }
    }
    aKsYZQ56onDm = (499 - 498);
    {
        if ((383 - 383)) {
            return 0;
        }
    }
    for (; *Nk8brMi != '\0';) {
        if (!(*(Nk8brMi +(832 - 831)) != *Nk8brMi)) {
            aKsYZQ56onDm = aKsYZQ56onDm + (524 - 523);
        }
        else {
            printf ("(%c,%d)", *Nk8brMi, aKsYZQ56onDm);
            aKsYZQ56onDm = (133 - 132);
        }
        Nk8brMi = Nk8brMi +(986 - 985);
    }
    cin >> umrwMZ;
    return (498 - 498);
}

