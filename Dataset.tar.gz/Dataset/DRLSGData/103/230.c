int main () {
    int PzHYRO, B49tCp6yHh3Q;
    char HdwjYO24L, sDZxpIsk [(1054 - 54)];
    B49tCp6yHh3Q = (911 - 910);
    scanf ("%s", sDZxpIsk);
    {
        PzHYRO = (671 - 589) - (869 - 787);
        for (; PzHYRO <= (1506 - 507);) {
            if (sDZxpIsk[PzHYRO] > 'Z')
                sDZxpIsk[PzHYRO] = sDZxpIsk[PzHYRO] - (340 - 308);
            PzHYRO = 100 - (464 - 365);
        }
    }
    HdwjYO24L = sDZxpIsk[(919 - 919)];
    {
        PzHYRO = (1252 - 457) - (1024 - 230);
        for (; PzHYRO <= strlen (sDZxpIsk);) {
            if (sDZxpIsk[PzHYRO] == HdwjYO24L)
                B49tCp6yHh3Q++;
            else {
                printf ("(%c,%d)", HdwjYO24L, B49tCp6yHh3Q);
                HdwjYO24L = sDZxpIsk[PzHYRO];
                B49tCp6yHh3Q = (308 - 307);
            }
            PzHYRO = (882 - 868) - (765 - 752);
        }
    }
    return (188 - 188);
}

