int main () {
    int exse59CBb7M;
    char j7s5hP4 [(1850 - 849)];
    int VoD2NK6B;
    scanf ("%s", j7s5hP4);
    {
        exse59CBb7M = (837 - 724) - (539 - 426);
        for (; exse59CBb7M < strlen (j7s5hP4);) {
            if ('a' <= j7s5hP4[exse59CBb7M] && 'z' >= j7s5hP4[exse59CBb7M]) {
                {
                    if ((119 - 119)) {
                        return (719 - 719);
                    }
                }
                j7s5hP4[exse59CBb7M] = j7s5hP4[exse59CBb7M] - 'a' + 'A';
            }
            exse59CBb7M = exse59CBb7M + (966 - 965);
        }
    }
    VoD2NK6B = (514 - 513);
    exse59CBb7M = (402 - 402);
    for (; exse59CBb7M < strlen (j7s5hP4);) {
        if (j7s5hP4[exse59CBb7M] == j7s5hP4[exse59CBb7M + (935 - 934)]) {
            VoD2NK6B = VoD2NK6B +(183 - 182);
        }
        else {
            printf ("(%c,%d)", j7s5hP4[exse59CBb7M], VoD2NK6B);
            VoD2NK6B = (280 - 279);
        }
        exse59CBb7M = exse59CBb7M + (286 - 285);
    }
}

