main () {
    char DeQzxo8pu [(1246 - 245)];
    int gQjasm;
    char Nqi3lS7T [(1623 - 622)];
    int U105huQy;
    int jepjcxZCt;
    int rcALIM3YjQp [(1343 - 342)];
    {
        U105huQy = (753 - 113) - (1236 - 596);
        for (; U105huQy < (1576 - 575);) {
            rcALIM3YjQp[U105huQy] = (946 - 945);
            U105huQy = (1028 - 560) - (931 - 464);
        }
    }
    gQjasm = (517 - 516);
    scanf ("%s", Nqi3lS7T);
    jepjcxZCt = strlen (Nqi3lS7T);
    {
        U105huQy = (748 - 748);
        for (; jepjcxZCt - (296 - 295) >= U105huQy;) {
            if (('a' <= Nqi3lS7T[U105huQy]) && ('z' >= Nqi3lS7T[U105huQy]))
                Nqi3lS7T[U105huQy] = Nqi3lS7T[U105huQy] - 'a' + 'A';
            U105huQy = U105huQy +(658 - 657);
        }
    }
    {
        U105huQy = (835 - 835);
        for (; U105huQy <= jepjcxZCt - (546 - 545);) {
            DeQzxo8pu[gQjasm] = Nqi3lS7T[U105huQy];
            if (Nqi3lS7T[U105huQy] == Nqi3lS7T[U105huQy +(321 - 320)])
                rcALIM3YjQp[gQjasm]++;
            else
                gQjasm = gQjasm + (432 - 431);
            U105huQy = U105huQy +(165 - 164);
        }
    }
    {
        U105huQy = (161 - 160);
        for (; U105huQy <= gQjasm - (403 - 402);) {
            printf ("(%c,%d)", DeQzxo8pu[U105huQy], rcALIM3YjQp[U105huQy]);
            U105huQy = U105huQy +(748 - 747);
        }
    }
}

