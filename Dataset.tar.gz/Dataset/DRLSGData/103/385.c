int main () {
    int XYSbeA6ztX1Q;
    int mIScBgZ;
    char govbxyifYrnc [(1167 - 166)];
    int fDEvPCz9Q;
    mIScBgZ = (436 - 436);
    cin >> govbxyifYrnc;
    fDEvPCz9Q = strlen (govbxyifYrnc);
    {
        XYSbeA6ztX1Q = (1856 - 883) - (1364 - 391);
        for (; fDEvPCz9Q > XYSbeA6ztX1Q;) {
            if ((958 - 866) < (int) govbxyifYrnc[XYSbeA6ztX1Q])
                govbxyifYrnc[XYSbeA6ztX1Q] = (char) ((int) govbxyifYrnc[XYSbeA6ztX1Q] - (547 - 515));
            XYSbeA6ztX1Q = XYSbeA6ztX1Q +(432 - 431);
        }
    }
    {
        XYSbeA6ztX1Q = (597 - 271) - (1098 - 773);
        for (; fDEvPCz9Q > XYSbeA6ztX1Q;) {
            if (govbxyifYrnc[XYSbeA6ztX1Q] != govbxyifYrnc[XYSbeA6ztX1Q -(647 - 646)]) {
                cout << '(' << govbxyifYrnc[XYSbeA6ztX1Q -(682 - 681)] << ',' << XYSbeA6ztX1Q -mIScBgZ << ')';
                mIScBgZ = XYSbeA6ztX1Q;
            }
            XYSbeA6ztX1Q = (877 - 245) - (692 - 61);
        }
    }
    cout << '(' << govbxyifYrnc[fDEvPCz9Q - (350 - 349)] << ',' << fDEvPCz9Q - mIScBgZ << ')' << endl;
    return (701 - 701);
}

