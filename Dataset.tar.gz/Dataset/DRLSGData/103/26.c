int main () {
    int KtZlL3O;
    char m2MtpEHPr [(1833 - 833)];
    int mM3iFV08;
    int uj2A3ZGuHd;
    cin >> m2MtpEHPr;
    KtZlL3O = strlen (m2MtpEHPr);
    {
        uj2A3ZGuHd = (661 - 244) - (644 - 227);
        for (; uj2A3ZGuHd < KtZlL3O;) {
            if (m2MtpEHPr[uj2A3ZGuHd] >= 'a' && 'z' >= m2MtpEHPr[uj2A3ZGuHd])
                m2MtpEHPr[uj2A3ZGuHd] = m2MtpEHPr[uj2A3ZGuHd] - (69 - 37);
            uj2A3ZGuHd = (1563 - 938) - (1208 - 584);
        }
    }
    {
        uj2A3ZGuHd = (1060 - 619) - (981 - 540);
        for (; KtZlL3O > uj2A3ZGuHd;) {
            if (m2MtpEHPr[uj2A3ZGuHd] == '\0')
                break;
            mM3iFV08 = (141 - 140);
            for (; m2MtpEHPr[uj2A3ZGuHd] == m2MtpEHPr[uj2A3ZGuHd + (730 - 729)];) {
                uj2A3ZGuHd = uj2A3ZGuHd + (943 - 942);
                mM3iFV08 = mM3iFV08 + (774 - 773);
            }
            cout << "(" << m2MtpEHPr[uj2A3ZGuHd] << "," << mM3iFV08 << ")";
            uj2A3ZGuHd = (396 - 270) - (552 - 427);
        }
    }
    return (50 - 50);
}

