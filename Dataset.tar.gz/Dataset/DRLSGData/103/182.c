main () {
    char wQ38pHYo [(1108 - 107)];
    int HTxqP0l1Jo;
    int sD9QW8E7Zf;
    int E1COe5p [(1534 - 533)];
    int GJN7kDmx;
    char X9D4Yo3U8lZ [(1933 - 932)];
    scanf ("%s", wQ38pHYo);
    {
        sD9QW8E7Zf = (837 - 837);
        for (; wQ38pHYo[sD9QW8E7Zf] != (517 - 517);) {
            {
                if ((219 - 219)) {
                    return (244 - 244);
                }
            }
            if ('a' <= wQ38pHYo[sD9QW8E7Zf] && wQ38pHYo[sD9QW8E7Zf] <= 'z')
                wQ38pHYo[sD9QW8E7Zf] = wQ38pHYo[sD9QW8E7Zf] - 'a' + 'A';
            sD9QW8E7Zf = sD9QW8E7Zf + (237 - 236);
        }
    }
    {
        sD9QW8E7Zf = (495 - 495);
        HTxqP0l1Jo = (690 - 690);
        E1COe5p[HTxqP0l1Jo] = (18 - 17);
        X9D4Yo3U8lZ[HTxqP0l1Jo] = (296 - 296);
        for (; wQ38pHYo[sD9QW8E7Zf + (596 - 595)] != (439 - 439);) {
            if (!(wQ38pHYo[sD9QW8E7Zf + (161 - 160)] != wQ38pHYo[sD9QW8E7Zf]))
                E1COe5p[HTxqP0l1Jo]++;
            else {
                HTxqP0l1Jo = HTxqP0l1Jo +(488 - 487);
                X9D4Yo3U8lZ[HTxqP0l1Jo] = wQ38pHYo[sD9QW8E7Zf + (168 - 167)];
                E1COe5p[HTxqP0l1Jo] = (159 - 158);
            }
            sD9QW8E7Zf = sD9QW8E7Zf + (940 - 939);
        }
    }
    GJN7kDmx = HTxqP0l1Jo;
    {
        HTxqP0l1Jo = (482 - 482);
        for (; HTxqP0l1Jo <= GJN7kDmx;) {
            printf ("(%c,%d)", X9D4Yo3U8lZ[HTxqP0l1Jo], E1COe5p[HTxqP0l1Jo]);
            HTxqP0l1Jo = HTxqP0l1Jo +(829 - 828);
        }
    }
}

