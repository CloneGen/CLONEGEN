int main () {
    int m;
    char a [(1582 - 572)];
    struct   {
        char YsWxB1zKZOEV;
        int VRWgGYJC0;
    }
    Gmj7txW [(195 - 168)];
    int ssrVaN;
    int wiNSjIu;
    ssrVaN = (76 - 76);
    m = (703 - 702);
    cin >> a;
    wiNSjIu = strlen (a);
    {
        int y63FPDZ0r = (531 - 531);
        for (; y63FPDZ0r < wiNSjIu;) {
            if ((856 - 759) <= a[y63FPDZ0r])
                a[y63FPDZ0r] -= (257 - 225);
            y63FPDZ0r++;
        }
    }
    Gmj7txW[(53 - 52)].YsWxB1zKZOEV = a[(244 - 244)], Gmj7txW[(879 - 878)].VRWgGYJC0 = (70 - 69);
    {
        int y63FPDZ0r = (89 - 88);
        for (; wiNSjIu > y63FPDZ0r;) {
            if (a[y63FPDZ0r] == a[y63FPDZ0r - (74 - 73)])
                Gmj7txW[m].VRWgGYJC0++;
            else {
                Gmj7txW[++m].YsWxB1zKZOEV = a[y63FPDZ0r];
                Gmj7txW[m].VRWgGYJC0 = 1;
            }
            y63FPDZ0r++;
        }
    }
    {
        int y63FPDZ0r = 1;
        for (; y63FPDZ0r <= m;) {
            cout << "(" << Gmj7txW[y63FPDZ0r].YsWxB1zKZOEV << "," << Gmj7txW[y63FPDZ0r].VRWgGYJC0 << ")";
            y63FPDZ0r++;
        }
    }
    return 0;
}

