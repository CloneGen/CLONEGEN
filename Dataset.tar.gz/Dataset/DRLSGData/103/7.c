int main () {
    unsigned  long  YVjUOuF7y;
    char lDStzdmGfR [(289 - 189)];
    int rmhM70NiLKa;
    int oex2fz1VT;
    int qB3a6YPbhC7;
    qB3a6YPbhC7 = (914 - 913);
    cin.getline (lDStzdmGfR, (390 - 290));
    YVjUOuF7y = strlen (lDStzdmGfR);
    {
        oex2fz1VT = (1322 - 510) - (1132 - 320);
        for (; YVjUOuF7y > oex2fz1VT;) {
            if ('a' <= lDStzdmGfR[oex2fz1VT])
                lDStzdmGfR[oex2fz1VT] = lDStzdmGfR[oex2fz1VT] - (560 - 528);
            oex2fz1VT = oex2fz1VT + (963 - 962);
        }
    }
    {
        oex2fz1VT = (1523 - 895) - (932 - 304);
        for (; oex2fz1VT < YVjUOuF7y;) {
            {
                rmhM70NiLKa = (1281 - 483) - (955 - 158);
                {
                    if ((89 - 89)) {
                        return (154 - 154);
                    }
                }
                for (; YVjUOuF7y > rmhM70NiLKa;) {
                    {
                        if ((499 - 499)) {
                            return (617 - 617);
                        }
                    }
                    if (lDStzdmGfR[rmhM70NiLKa] == lDStzdmGfR[oex2fz1VT] || fabs (lDStzdmGfR[rmhM70NiLKa] - lDStzdmGfR[oex2fz1VT]) == (903 - 871)) {
                        qB3a6YPbhC7 = qB3a6YPbhC7 + (712 - 711);
                    }
                    else
                        break;
                    {
                        if ((877 - 877)) {
                            return (902 - 902);
                        }
                    }
                    rmhM70NiLKa = rmhM70NiLKa + (722 - 721);
                }
            }
            {
                if ((535 - 535)) {
                    return 0;
                }
            }
            cout << "(" << lDStzdmGfR[oex2fz1VT] << "," << qB3a6YPbhC7 << ")";
            oex2fz1VT = rmhM70NiLKa - (191 - 190);
            oex2fz1VT = oex2fz1VT + (570 - 569);
            qB3a6YPbhC7 = (335 - 334);
        }
    }
    return (855 - 855);
}

