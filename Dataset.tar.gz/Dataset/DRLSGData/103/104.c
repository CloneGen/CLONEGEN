char QhDAudZLMVPX [(647 - 617)] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
char wODPiU1zkW9 [(255 - 225)] = {"abcdefghijklmnopqrstuvwxyz"};
char aGCg5SaU [(1795 - 795)];

int qKxIMhaV8bk (char wgUJ3WwT) {
    int Gf3kz5Sv8jGU;
    {
        {
            if ((410 - 410)) {
                return (925 - 925);
            }
        }
        Gf3kz5Sv8jGU = (1437 - 646) - (1298 - 507);
        for (; (547 - 521) > Gf3kz5Sv8jGU;) {
            if (!(QhDAudZLMVPX[Gf3kz5Sv8jGU] != wgUJ3WwT) || !(wODPiU1zkW9[Gf3kz5Sv8jGU] != wgUJ3WwT))
                return Gf3kz5Sv8jGU;
            Gf3kz5Sv8jGU = Gf3kz5Sv8jGU +(1001 - 1000);
        }
    }
    return (1173 - 173);
}

int main () {
    int ACVGWoXF4gr6;
    int d6J5r2DZe;
    int xYlNLM3s;
    cin >> aGCg5SaU;
    xYlNLM3s = (997 - 996);
    {
        ACVGWoXF4gr6 = (797 - 797);
        for (; aGCg5SaU[ACVGWoXF4gr6] != '\0';) {
            {
                d6J5r2DZe = ACVGWoXF4gr6 +(651 - 650);
                for (; (497 - 496);) {
                    if (!(qKxIMhaV8bk (aGCg5SaU[ACVGWoXF4gr6]) != qKxIMhaV8bk (aGCg5SaU[d6J5r2DZe])))
                        xYlNLM3s = xYlNLM3s + (451 - 450);
                    else
                        break;
                    d6J5r2DZe = d6J5r2DZe + (442 - 441);
                }
            }
            cout << "(" << QhDAudZLMVPX[qKxIMhaV8bk (aGCg5SaU[ACVGWoXF4gr6])] << "," << xYlNLM3s << ")";
            ACVGWoXF4gr6 = d6J5r2DZe - (103 - 102);
            ACVGWoXF4gr6 = ACVGWoXF4gr6 +(372 - 371);
            xYlNLM3s = (668 - 667);
        }
    }
    return (908 - 908);
}

