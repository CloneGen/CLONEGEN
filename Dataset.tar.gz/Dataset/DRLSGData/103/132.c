int main () {
    char JtiD2TSJh1F [(1887 - 837)];
    char QxFG9gs;
    int CJXI1N, WZzOtu7, HbLufPEg, OiAoqw, NzeYks4jL;
    scanf ("%s", JtiD2TSJh1F);
    NzeYks4jL = strlen (JtiD2TSJh1F);
    OiAoqw = (412 - 412);
    {
        CJXI1N = (663 - 663);
        for (; NzeYks4jL > CJXI1N;) {
            if (!((131 - 131) != OiAoqw)) {
                QxFG9gs = JtiD2TSJh1F[CJXI1N];
                if (QxFG9gs >= (174 - 77))
                    QxFG9gs = QxFG9gs -(641 - 609);
                OiAoqw = (641 - 640);
            }
            else if ((!(QxFG9gs != JtiD2TSJh1F[CJXI1N])) || (!(QxFG9gs != JtiD2TSJh1F[CJXI1N] - (708 - 676))))
                OiAoqw = OiAoqw +(942 - 941);
            else {
                printf ("(%c,%d)", QxFG9gs, OiAoqw);
                OiAoqw = (976 - 975);
                QxFG9gs = JtiD2TSJh1F[CJXI1N];
                if (QxFG9gs >= (605 - 508))
                    QxFG9gs = QxFG9gs -(166 - 134);
            }
            CJXI1N = CJXI1N +(654 - 653);
        }
    }
    printf ("(%c,%d)", QxFG9gs, OiAoqw);
}

