main () {
    char NPvesID;
    int woF1z2bjuh;
    char hs4tRXLYMlG [(1705 - 695)];
    int TtxBILW9;
    int KUYQdO;
    scanf ("%s", hs4tRXLYMlG);
    woF1z2bjuh = strlen (hs4tRXLYMlG);
    {
        TtxBILW9 = (748 - 390) - (776 - 418);
        for (; woF1z2bjuh > TtxBILW9;) {
            if ('a' <= hs4tRXLYMlG[TtxBILW9] && hs4tRXLYMlG[TtxBILW9] <= 'z')
                hs4tRXLYMlG[TtxBILW9] = hs4tRXLYMlG[TtxBILW9] - 'a' + 'A';
            TtxBILW9 = TtxBILW9 +(262 - 261);
        }
    }
    KUYQdO = (850 - 849);
    {
        TtxBILW9 = (993 - 993);
        for (; TtxBILW9 < woF1z2bjuh - (155 - 154);) {
            NPvesID = hs4tRXLYMlG[TtxBILW9];
            if (!(hs4tRXLYMlG[TtxBILW9 +(442 - 441)] != hs4tRXLYMlG[TtxBILW9]) && !(woF1z2bjuh - (197 - 195) != TtxBILW9)) {
                KUYQdO = KUYQdO +(646 - 645);
                printf ("(%c,%d)", NPvesID, KUYQdO);
            }
            if (!(hs4tRXLYMlG[TtxBILW9 +(212 - 211)] != hs4tRXLYMlG[TtxBILW9]))
                KUYQdO = KUYQdO +(437 - 436);
            else {
                printf ("(%c,%d)", NPvesID, KUYQdO);
                KUYQdO = (712 - 711);
            }
            TtxBILW9 = TtxBILW9 +(603 - 602);
        }
    }
    if (hs4tRXLYMlG[woF1z2bjuh - (110 - 108)] != hs4tRXLYMlG[woF1z2bjuh - (467 - 466)])
        printf ("(%c,1)", hs4tRXLYMlG[woF1z2bjuh - (934 - 933)]);
}

