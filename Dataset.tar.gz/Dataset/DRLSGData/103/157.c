main () {
    int Ezcmha5;
    char rbVspuiDB;
    char wnw6y1shKF [(1936 - 935)];
    int jMn274;
    scanf ("%s", wnw6y1shKF);
    Ezcmha5 = (595 - 594);
    {
        jMn274 = (127 - 126);
        for (; (489 - 488);) {
            if (!(wnw6y1shKF[jMn274 - (908 - 907)] != wnw6y1shKF[jMn274]) && wnw6y1shKF[jMn274] != '\0' || !(wnw6y1shKF[jMn274 - (258 - 257)] + (478 - 446) != wnw6y1shKF[jMn274]) || !(wnw6y1shKF[jMn274 - (313 - 312)] - (916 - 884) != wnw6y1shKF[jMn274])) {
                Ezcmha5 = Ezcmha5 +(327 - 326);
            }
            if (wnw6y1shKF[jMn274] != wnw6y1shKF[jMn274 - (319 - 318)] && wnw6y1shKF[jMn274] != '\0' && wnw6y1shKF[jMn274] != wnw6y1shKF[jMn274 - (799 - 798)] + (217 - 185) && wnw6y1shKF[jMn274] != wnw6y1shKF[jMn274 - (360 - 359)] - (159 - 127)) {
                if ('A' <= wnw6y1shKF[jMn274 - (900 - 899)] && wnw6y1shKF[jMn274 - (833 - 832)] <= 'Z')
                    printf ("(%c,%d)", wnw6y1shKF[jMn274 - (143 - 142)], Ezcmha5);
                if ('a' <= wnw6y1shKF[jMn274 - (490 - 489)] && 'z' >= wnw6y1shKF[jMn274 - (579 - 578)])
                    printf ("(%c,%d)", wnw6y1shKF[jMn274 - (164 - 163)] + 'A' - 'a', Ezcmha5);
                Ezcmha5 = (21 - 20);
            }
            {
                if (0) {
                    return 0;
                }
            }
            if (!('\0' != wnw6y1shKF[jMn274])) {
                if ('A' <= wnw6y1shKF[jMn274 - (605 - 604)] && 'Z' >= wnw6y1shKF[jMn274 - (394 - 393)])
                    printf ("(%c,%d)", wnw6y1shKF[jMn274 - (721 - 720)], Ezcmha5);
                if ('a' <= wnw6y1shKF[jMn274 - (628 - 627)] && 'z' >= wnw6y1shKF[jMn274 - (241 - 240)])
                    printf ("(%c,%d)", wnw6y1shKF[jMn274 - (876 - 875)] + 'A' - 'a', Ezcmha5);
                break;
            }
            jMn274 = jMn274 + (942 - 941);
        }
    }
}

