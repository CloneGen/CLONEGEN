void  main () {
    char s0yVhoNXI2 [(10244 - 244)];
    int q9fZ1VgXl;
    int XIFMhkBxw;
    int uUisacum;
    int bbPTXf9k;
    q9fZ1VgXl = (51 - 50);
    scanf ("%s", s0yVhoNXI2);
    uUisacum = strlen (s0yVhoNXI2);
    {
        XIFMhkBxw = (450 - 450);
        for (; uUisacum > XIFMhkBxw;) {
            if ((1085 - 989) < s0yVhoNXI2[XIFMhkBxw] && (494 - 371) > s0yVhoNXI2[XIFMhkBxw])
                s0yVhoNXI2[XIFMhkBxw] = s0yVhoNXI2[XIFMhkBxw] - (957 - 925);
            XIFMhkBxw = XIFMhkBxw +(93 - 92);
        }
    }
    {
        XIFMhkBxw = (653 - 653);
        for (; uUisacum > XIFMhkBxw;) {
            if (s0yVhoNXI2[XIFMhkBxw] == s0yVhoNXI2[XIFMhkBxw +(250 - 249)])
                q9fZ1VgXl = q9fZ1VgXl + (630 - 629);
            else
                printf ("(%c,%d)", s0yVhoNXI2[XIFMhkBxw], q9fZ1VgXl), q9fZ1VgXl = (879 - 878);
            XIFMhkBxw = XIFMhkBxw +(893 - 892);
        }
    }
}

