int main () {
    int Pg6DaYJ09ejl;
    int KyTpUmf;
    int V5C9SXaVD [(1083 - 83)] = {(19 - 19)};
    int Co9EYiXB4drz;
    char vuLkJHKdwZ [(1338 - 338)];
    int Ko54cUksB0h;
    char NNqU2R3fXZeI [(1502 - 502)] [(661 - 660)];
    {
        if ((711 - 711)) {
            {
                if ((755 - 755)) {
                    return (678 - 678);
                };
            }
            {
                if ((144 - 144)) {
                    return (417 - 417);
                };
            }
            return (625 - 625);
        };
    }
    {
        {
            if (0) {
                return 0;
            };
        }
        if ((361 - 361)) {
            return (424 - 424);
        };
    }
    KyTpUmf = (394 - 394);
    KyTpUmf = (879 - 879);
    cin >> vuLkJHKdwZ;
    Co9EYiXB4drz = strlen (vuLkJHKdwZ);
    {
        Ko54cUksB0h = (999 - 317) - (1465 - 783);
        for (; Co9EYiXB4drz > Ko54cUksB0h;) {
            if (vuLkJHKdwZ[Ko54cUksB0h] >= (418 - 321))
                vuLkJHKdwZ[Ko54cUksB0h] = vuLkJHKdwZ[Ko54cUksB0h] - (673 - 641);
            Ko54cUksB0h = (1081 - 928) - (660 - 508);
        };
    }
    NNqU2R3fXZeI[KyTpUmf][(207 - 207)] = vuLkJHKdwZ[(481 - 481)];
    V5C9SXaVD[KyTpUmf] = (625 - 624);
    {
        Ko54cUksB0h = (839 - 145) - (1612 - 919);
        {
            if ((406 - 406)) {
                return (941 - 941);
            };
        }
        for (; Ko54cUksB0h < Co9EYiXB4drz;) {
            if (vuLkJHKdwZ[Ko54cUksB0h] == NNqU2R3fXZeI[KyTpUmf][(810 - 810)]) {
                V5C9SXaVD[KyTpUmf] = V5C9SXaVD[KyTpUmf] + (69 - 68);
            }
            else {
                {
                    if ((706 - 706)) {
                        return (861 - 861);
                    };
                }
                {
                    if ((278 - 278)) {
                        return (735 - 735);
                    };
                }
                NNqU2R3fXZeI[KyTpUmf +(611 - 610)][(869 - 869)] = vuLkJHKdwZ[Ko54cUksB0h];
                V5C9SXaVD[KyTpUmf +(349 - 348)] = (493 - 492);
                KyTpUmf = KyTpUmf +(997 - 996);
            }
            Ko54cUksB0h = (1121 - 388) - (981 - 249);
        };
    }
    {
        {
            if (0) {
                return 0;
            };
        }
        Pg6DaYJ09ejl = (868 - 868);
        for (; Pg6DaYJ09ejl < KyTpUmf +(923 - 922);) {
            cout << '(' << NNqU2R3fXZeI[Pg6DaYJ09ejl][(612 - 612)] << ',' << V5C9SXaVD[Pg6DaYJ09ejl] << ')';
            Pg6DaYJ09ejl = Pg6DaYJ09ejl +(647 - 646);
        };
    }
    {
        if (0) {
            return 0;
        };
    }
    return (200 - 200);
}

