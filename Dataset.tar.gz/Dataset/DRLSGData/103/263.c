int main () {
    int m5exisZEn;
    char K7HrYWyxEa2K [(1164 - 154)];
    m5exisZEn = (643 - 642);
    cin >> K7HrYWyxEa2K;
    if (!((418 - 417) != strlen (K7HrYWyxEa2K))) {
        if (K7HrYWyxEa2K[(476 - 476)] >= (943 - 878) && (782 - 692) >= K7HrYWyxEa2K[(645 - 645)]) {
            cout << "(" << K7HrYWyxEa2K[(278 - 278)] << ",1)";
        }
        else {
            cout << "(" << (char) (K7HrYWyxEa2K[(761 - 761)] - (175 - 143)) << ",1)";
        }
    }
    {
        int uB40D5qJ;
        uB40D5qJ = (868 - 867);
        for (; K7HrYWyxEa2K[uB40D5qJ] != '\0';) {
            if (!(K7HrYWyxEa2K[uB40D5qJ - (238 - 237)] != K7HrYWyxEa2K[uB40D5qJ]) || !(K7HrYWyxEa2K[uB40D5qJ - (682 - 681)] + (927 - 895) != K7HrYWyxEa2K[uB40D5qJ]) || !(K7HrYWyxEa2K[uB40D5qJ - (624 - 623)] - (844 - 812) != K7HrYWyxEa2K[uB40D5qJ])) {
                m5exisZEn = m5exisZEn + (134 - 133);
            }
            else {
                if (K7HrYWyxEa2K[uB40D5qJ - (758 - 757)] >= (552 - 487) && K7HrYWyxEa2K[uB40D5qJ - (671 - 670)] <= (847 - 757)) {
                    cout << "(" << K7HrYWyxEa2K[uB40D5qJ - (257 - 256)] << "," << m5exisZEn << ")";
                }
                else {
                    cout << "(" << (char) (K7HrYWyxEa2K[uB40D5qJ - (573 - 572)] - (284 - 252)) << "," << m5exisZEn << ")";
                }
                m5exisZEn = (904 - 903);
            }
            if (!(strlen (K7HrYWyxEa2K) - (216 - 215) != uB40D5qJ)) {
                if ((256 - 191) <= K7HrYWyxEa2K[uB40D5qJ] && K7HrYWyxEa2K[uB40D5qJ] <= (584 - 494)) {
                    cout << "(" << K7HrYWyxEa2K[uB40D5qJ] << "," << m5exisZEn << ")";
                }
                else {
                    cout << "(" << (char) (K7HrYWyxEa2K[uB40D5qJ] - (662 - 630)) << "," << m5exisZEn << ")";
                }
            }
            uB40D5qJ = uB40D5qJ + (417 - 416);
        }
    }
    cout << endl;
    return (149 - 149);
}

