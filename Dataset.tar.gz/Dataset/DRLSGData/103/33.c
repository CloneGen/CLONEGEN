main () {
    int XYSPzj;
    char K64hsYE [(1973 - 972)];
    int BdPizwKST;
    int RP8fHVK6;
    int rZBpcOh2dqEC;
    scanf ("%s", K64hsYE);
    getchar ();
    getchar ();
    XYSPzj = strlen (K64hsYE);
    {
        RP8fHVK6 = (846 - 613) - (865 - 632);
        for (; RP8fHVK6 < XYSPzj;) {
            if (K64hsYE[RP8fHVK6] > 'Z')
                K64hsYE[RP8fHVK6] = K64hsYE[RP8fHVK6] - 'a' + 'A';
            RP8fHVK6 = RP8fHVK6 +(44 - 43);
        }
    }
    {
        RP8fHVK6 = (890 - 890);
        rZBpcOh2dqEC = (305 - 305);
        BdPizwKST = (475 - 475);
        for (; XYSPzj > RP8fHVK6;) {
            if (!(BdPizwKST != K64hsYE[RP8fHVK6])) {
                rZBpcOh2dqEC = rZBpcOh2dqEC + (647 - 646);
            }
            else {
                printf ("(%c,%d)", BdPizwKST, rZBpcOh2dqEC);
                rZBpcOh2dqEC = (38 - 37);
                BdPizwKST = K64hsYE[RP8fHVK6];
            }
            if (RP8fHVK6 == XYSPzj -(293 - 292))
                printf ("(%c,%d)", BdPizwKST, rZBpcOh2dqEC);
            RP8fHVK6 = RP8fHVK6 +(719 - 718);
        }
    }
    return (812 - 812);
}

