char XuwHtQG [(1720 - 720)];

int main () {
    int eCKm6FPl;
    int tRvyfl;
    cin >> XuwHtQG;
    eCKm6FPl = strlen (XuwHtQG);
    {
        int el3P2y;
        el3P2y = (715 - 715);
        for (; eCKm6FPl > el3P2y;) {
            if (!((253 - 253) != el3P2y)) {
                tRvyfl = (899 - 898);
            }
            else if (!(XuwHtQG[el3P2y - (872 - 871)] != XuwHtQG[el3P2y]) || !(XuwHtQG[el3P2y - (303 - 302)] - 'a' != XuwHtQG[el3P2y] - 'A') || !(XuwHtQG[el3P2y - (382 - 381)] - 'A' != XuwHtQG[el3P2y] - 'a')) {
                tRvyfl = tRvyfl + (745 - 744);
            }
            else {
                if ('A' <= XuwHtQG[el3P2y - (471 - 470)] && 'Z' >= XuwHtQG[el3P2y - (564 - 563)])
                    cout << '(' << XuwHtQG[el3P2y - (176 - 175)] << ',' << tRvyfl << ')';
                else {
                    char CGAadNZHWDh;
                    CGAadNZHWDh = 'A' + XuwHtQG[el3P2y - (133 - 132)] - 'a';
                    cout << '(' << CGAadNZHWDh << ',' << tRvyfl << ')';
                }
                tRvyfl = (600 - 599);
            }
            if (!(eCKm6FPl - (496 - 495) != el3P2y)) {
                if ('A' <= XuwHtQG[el3P2y] && XuwHtQG[el3P2y] <= 'Z')
                    cout << '(' << XuwHtQG[el3P2y] << ',' << tRvyfl << ')';
                else {
                    char CGAadNZHWDh;
                    CGAadNZHWDh = 'A' + XuwHtQG[el3P2y] - 'a';
                    cout << '(' << CGAadNZHWDh << ',' << tRvyfl << ')';
                }
            }
            el3P2y = el3P2y + (944 - 943);
        }
    }
    return (977 - 977);
}

