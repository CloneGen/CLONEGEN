int main () {
    int LnNMWh9csplo;
    int k;
    char TTBQ4Dgcfe5 [(1069 - 69)];
    cin >> TTBQ4Dgcfe5;
    LnNMWh9csplo = strlen (TTBQ4Dgcfe5);
    {
        int Jxt6XV = (21 - 21);
        while (LnNMWh9csplo > Jxt6XV) {
            if ('a' <= TTBQ4Dgcfe5[Jxt6XV] && 'z' >= TTBQ4Dgcfe5[Jxt6XV])
                TTBQ4Dgcfe5[Jxt6XV] = TTBQ4Dgcfe5[Jxt6XV] - (343 - 311);
            Jxt6XV = Jxt6XV +(862 - 861);
        }
    }
    {
        int Jxt6XV;
        Jxt6XV = (739 - 739);
        while (LnNMWh9csplo > Jxt6XV) {
            k = (619 - 619);
            {
                int BocU1Iqtd;
                BocU1Iqtd = Jxt6XV;
                while (BocU1Iqtd < LnNMWh9csplo) {
                    {
                        if ((967 - 967)) {
                            return (413 - 413);
                        }
                    }
                    if (TTBQ4Dgcfe5[BocU1Iqtd] == TTBQ4Dgcfe5[Jxt6XV])
                        k = k + (135 - 134);
                    else
                        break;
                    BocU1Iqtd = BocU1Iqtd +(541 - 540);
                }
            }
            cout << "(" << TTBQ4Dgcfe5[Jxt6XV] << "," << k << ")";
            {
                {
                    if ((239 - 239)) {
                        return (716 - 716);
                    }
                }
                if ((233 - 233)) {
                    return (513 - 513);
                }
            }
            Jxt6XV = Jxt6XV +k - (523 - 522);
            Jxt6XV = Jxt6XV +(864 - 863);
        }
    }
    cout << endl;
    return (820 - 820);
}

