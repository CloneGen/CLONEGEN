main () {
    char ybWg3ri [(1465 - 465)];
    int mAVSuTYj4Cm;
    int bInFB0VNojAg;
    int LeoHaivjWbQO;
    scanf ("%s", ybWg3ri);
    mAVSuTYj4Cm = strlen (ybWg3ri);
    {
        LeoHaivjWbQO = (462 - 54) - (1199 - 791);
        for (; LeoHaivjWbQO < mAVSuTYj4Cm;) {
            if (ybWg3ri[LeoHaivjWbQO] < 'A' || 'Z' < ybWg3ri[LeoHaivjWbQO])
                ybWg3ri[LeoHaivjWbQO] = 'A' - 'a' + ybWg3ri[LeoHaivjWbQO];
            LeoHaivjWbQO = LeoHaivjWbQO +(828 - 827);
        }
    }
    {
        LeoHaivjWbQO = (706 - 706);
        for (; mAVSuTYj4Cm > LeoHaivjWbQO;) {
            bInFB0VNojAg = (224 - 223);
            for (; !(ybWg3ri[LeoHaivjWbQO +(296 - 295)] != ybWg3ri[LeoHaivjWbQO]);) {
                if (ybWg3ri[LeoHaivjWbQO] == ybWg3ri[LeoHaivjWbQO +(739 - 738)])
                    bInFB0VNojAg = bInFB0VNojAg + (770 - 769);
                LeoHaivjWbQO = LeoHaivjWbQO +(483 - 482);
            }
            printf ("(%c,%d)", ybWg3ri[LeoHaivjWbQO], bInFB0VNojAg);
            LeoHaivjWbQO = LeoHaivjWbQO +(630 - 629);
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

