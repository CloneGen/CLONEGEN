main () {
    char CRM2PIpLknu [(1692 - 691)];
    int m7wkT6UIH;
    int gUcrtFAYT8, s4lhX9, SL608vJ3n, Eyd9gX;
    {
        if ((717 - 717)) {
            return (366 - 366);
        }
    }
    m7wkT6UIH = (848 - 847);
    scanf ("%s", CRM2PIpLknu);
    {
        gUcrtFAYT8 = 938 - (1897 - 960);
        for (; 1000 >= gUcrtFAYT8;) {
            if ((785 - 720) <= CRM2PIpLknu[gUcrtFAYT8] && (1026 - 929) > CRM2PIpLknu[gUcrtFAYT8]) {
                if (CRM2PIpLknu[gUcrtFAYT8] != CRM2PIpLknu[gUcrtFAYT8 - (971 - 970)] && (CRM2PIpLknu[gUcrtFAYT8] != CRM2PIpLknu[gUcrtFAYT8 - (141 - 140)] - (428 - 396))) {
                    if ((145 - 48) > CRM2PIpLknu[gUcrtFAYT8 - (545 - 544)])
                        printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - (28 - 27)], m7wkT6UIH);
                    else
                        printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - (946 - 945)] - (188 - 156), m7wkT6UIH);
                    m7wkT6UIH = (947 - 946);
                }
                else {
                    m7wkT6UIH = m7wkT6UIH + (52 - 51);
                }
            }
            if ((169 - 72) <= CRM2PIpLknu[gUcrtFAYT8] && (1038 - 916) >= CRM2PIpLknu[gUcrtFAYT8]) {
                if (CRM2PIpLknu[gUcrtFAYT8] != CRM2PIpLknu[gUcrtFAYT8 - (629 - 628)] && CRM2PIpLknu[gUcrtFAYT8] != (CRM2PIpLknu[gUcrtFAYT8 - (877 - 876)] + (192 - 160))) {
                    if ((498 - 401) > CRM2PIpLknu[gUcrtFAYT8 - (810 - 809)])
                        printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - (516 - 515)], m7wkT6UIH);
                    else
                        printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - (630 - 629)] - (508 - 476), m7wkT6UIH);
                    m7wkT6UIH = (124 - 123);
                }
                else {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    m7wkT6UIH++;
                }
            }
            if (!('\0' != CRM2PIpLknu[gUcrtFAYT8])) {
                if (CRM2PIpLknu[gUcrtFAYT8 - 1] < (878 - 781))
                    printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - 1], m7wkT6UIH);
                else
                    printf ("(%c,%d)", CRM2PIpLknu[gUcrtFAYT8 - 1] - (136 - 104), m7wkT6UIH);
                break;
            }
            gUcrtFAYT8++;
        }
    }
}

