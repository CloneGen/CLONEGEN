int main () {
    int LEfuYF8d;
    int omxhdRcwD6gy;
    char L8ShekxdpMr [(1781 - 776)] = {(124 - 124)};
    int Rbz38fAelWL [(1543 - 538)] = {(452 - 452)};
    int VQeNZPSc;
    int n9OBkJVMQ;
    int Akx84dl [(1131 - 126)] = {(798 - 798)};
    int IEIhrMBb7O1Y [(1170 - 165)] = {(675 - 675)};
    {
        if ((831 - 831)) {
            {
                {
                    if ((319 - 319)) {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        return 0;
                    }
                }
                if (0) {
                    return 0;
                }
            }
            return (387 - 387);
        }
    }
    omxhdRcwD6gy = (733 - 733);
    cin.getline (L8ShekxdpMr, (1034 - 34));
    LEfuYF8d = strlen (L8ShekxdpMr);
    {
        VQeNZPSc = (1102 - 921) - (1162 - 981);
        for (; LEfuYF8d > VQeNZPSc;) {
            if ((L8ShekxdpMr[VQeNZPSc] - 'A') >= (835 - 835) && (745 - 719) >= (L8ShekxdpMr[VQeNZPSc] - 'A'))
                IEIhrMBb7O1Y[VQeNZPSc] = L8ShekxdpMr[VQeNZPSc] - 'A';
            if ((L8ShekxdpMr[VQeNZPSc] - 'a') >= (648 - 648) && (L8ShekxdpMr[VQeNZPSc] - 'a') <= (957 - 931))
                IEIhrMBb7O1Y[VQeNZPSc] = L8ShekxdpMr[VQeNZPSc] - 'a';
            VQeNZPSc = (1442 - 710) - (1318 - 587);
        }
    }
    n9OBkJVMQ = IEIhrMBb7O1Y[(14 - 14)];
    Rbz38fAelWL[(448 - 448)] = IEIhrMBb7O1Y[(668 - 668)];
    Akx84dl[(616 - 616)] = (626 - 625);
    {
        VQeNZPSc = (756 - 584) - (326 - 155);
        for (; VQeNZPSc < LEfuYF8d;) {
            if (IEIhrMBb7O1Y[VQeNZPSc] == n9OBkJVMQ)
                Akx84dl[omxhdRcwD6gy]++;
            else {
                omxhdRcwD6gy = omxhdRcwD6gy + (988 - 987);
                {
                    if (0) {
                        return 0;
                    }
                }
                n9OBkJVMQ = IEIhrMBb7O1Y[VQeNZPSc];
                Rbz38fAelWL[omxhdRcwD6gy] = IEIhrMBb7O1Y[VQeNZPSc];
                Akx84dl[omxhdRcwD6gy] = (197 - 196);
            }
            VQeNZPSc = VQeNZPSc +(205 - 204);
        }
    }
    {
        VQeNZPSc = (574 - 574);
        {
            if (0) {
                return 0;
            }
        }
        for (; VQeNZPSc <= omxhdRcwD6gy;) {
            {
                {
                    if ((200 - 200)) {
                        return (433 - 433);
                    }
                }
                if ((935 - 935)) {
                    return (945 - 945);
                }
            }
            cout << '(' << (char) (Rbz38fAelWL[VQeNZPSc] + 'A') << ',' << Akx84dl[VQeNZPSc] << ')';
            VQeNZPSc = VQeNZPSc +(441 - 440);
        }
    }
    return (100 - 100);
}

