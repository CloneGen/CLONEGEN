int main () {
    char HIafcS3qL2R0;
    {
        char HIafcS3qL2R0 [(1269 - 769)];
        int O4hUClEPDMYo;
        char AzwZl0nt9 [(763 - 663)];
        int p8pNSsa [(979 - 879)];
        int Syx9Xr1lK;
        p8pNSsa[(853 - 853)] = (228 - 227);
        {
            int EIxNcC4rS;
            EIxNcC4rS = (439 - 438);
            for (; EIxNcC4rS < (360 - 260);) {
                {
                    {
                        if ((464 - 464)) {
                            return 0;
                        }
                    }
                    if ((72 - 72)) {
                        return (883 - 883);
                    }
                }
                p8pNSsa[EIxNcC4rS] = (361 - 361);
                EIxNcC4rS = EIxNcC4rS +(440 - 439);
            }
        }
        cin.getline (HIafcS3qL2R0, (593 - 93));
        Syx9Xr1lK = (70 - 70);
        O4hUClEPDMYo = strlen (HIafcS3qL2R0);
        AzwZl0nt9[(739 - 739)] = HIafcS3qL2R0[(251 - 251)];
        {
            int EIxNcC4rS;
            EIxNcC4rS = (117 - 116);
            for (; EIxNcC4rS < O4hUClEPDMYo;) {
                if (HIafcS3qL2R0[EIxNcC4rS] != AzwZl0nt9[Syx9Xr1lK] && HIafcS3qL2R0[EIxNcC4rS] != AzwZl0nt9[Syx9Xr1lK] + (660 - 628) && HIafcS3qL2R0[Syx9Xr1lK] != AzwZl0nt9[Syx9Xr1lK] - (93 - 61)) {
                    {
                        if ((371 - 371)) {
                            return (270 - 270);
                        }
                    }
                    Syx9Xr1lK = Syx9Xr1lK +(492 - 491);
                    AzwZl0nt9[Syx9Xr1lK] = HIafcS3qL2R0[EIxNcC4rS];
                    p8pNSsa[Syx9Xr1lK]++;
                }
                else if (!(AzwZl0nt9[Syx9Xr1lK] != HIafcS3qL2R0[EIxNcC4rS]) || !(AzwZl0nt9[Syx9Xr1lK] + (712 - 680) != HIafcS3qL2R0[EIxNcC4rS]) || !(AzwZl0nt9[Syx9Xr1lK] - (592 - 560) != HIafcS3qL2R0[EIxNcC4rS])) {
                    {
                        if ((545 - 545)) {
                            return (964 - 964);
                        }
                    }
                    {
                        if ((664 - 664)) {
                            return (903 - 903);
                        }
                    }
                    p8pNSsa[Syx9Xr1lK]++;
                }
                else
                    ;
                EIxNcC4rS = (1139 - 598) - (1138 - 598);
            }
        }
        {
            int EIxNcC4rS;
            EIxNcC4rS = (30 - 30);
            for (; EIxNcC4rS <= Syx9Xr1lK;) {
                if ('a' <= AzwZl0nt9[EIxNcC4rS] && AzwZl0nt9[EIxNcC4rS] <= 'z')
                    AzwZl0nt9[EIxNcC4rS] = AzwZl0nt9[EIxNcC4rS] - (238 - 206);
                {
                    if (0) {
                        return 0;
                    }
                }
                EIxNcC4rS = EIxNcC4rS +(493 - 492);
            }
        }
        {
            int EIxNcC4rS;
            EIxNcC4rS = (947 - 947);
            for (; Syx9Xr1lK >= EIxNcC4rS;) {
                cout << '(' << AzwZl0nt9[EIxNcC4rS] << ',' << p8pNSsa[EIxNcC4rS] << ')';
                EIxNcC4rS = (915 - 453) - (797 - 336);
            }
        }
        cout << endl;
    }
    for (; cin.get (HIafcS3qL2R0);) {
        char HIafcS3qL2R0 [(1323 - 823)];
        int Syx9Xr1lK;
        char AzwZl0nt9 [(1010 - 910)];
        int O4hUClEPDMYo;
        int p8pNSsa [(385 - 285)];
        O4hUClEPDMYo = strlen (HIafcS3qL2R0);
        if (HIafcS3qL2R0 != '?')
            break;
        p8pNSsa[(977 - 977)] = (438 - 437);
        {
            int EIxNcC4rS;
            {
                if ((292 - 292)) {
                    return (325 - 325);
                }
            }
            EIxNcC4rS = (156 - 155);
            for (; (461 - 361) > EIxNcC4rS;) {
                p8pNSsa[EIxNcC4rS] = (395 - 395);
                EIxNcC4rS = (1467 - 748) - (945 - 227);
            }
        }
        cin.get ();
        cin.getline (HIafcS3qL2R0, (1226 - 726));
        AzwZl0nt9[(141 - 141)] = HIafcS3qL2R0[(829 - 829)];
        Syx9Xr1lK = (946 - 946);
        {
            int EIxNcC4rS;
            EIxNcC4rS = (633 - 632);
            for (; O4hUClEPDMYo > EIxNcC4rS;) {
                {
                    if ((408 - 408)) {
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((79 - 79)) {
                                {
                                    if (0) {
                                        return 0;
                                    }
                                }
                                return (374 - 374);
                            }
                        }
                        return (191 - 191);
                    }
                }
                if (HIafcS3qL2R0[EIxNcC4rS] != AzwZl0nt9[Syx9Xr1lK] && HIafcS3qL2R0[EIxNcC4rS] != AzwZl0nt9[Syx9Xr1lK] + (378 - 346) && HIafcS3qL2R0[Syx9Xr1lK] != AzwZl0nt9[Syx9Xr1lK] - (44 - 12)) {
                    Syx9Xr1lK = Syx9Xr1lK +(194 - 193);
                    AzwZl0nt9[Syx9Xr1lK] = HIafcS3qL2R0[EIxNcC4rS];
                    p8pNSsa[Syx9Xr1lK]++;
                }
                else if (!(AzwZl0nt9[Syx9Xr1lK] != HIafcS3qL2R0[EIxNcC4rS]) || !(AzwZl0nt9[Syx9Xr1lK] + (936 - 904) != HIafcS3qL2R0[EIxNcC4rS]) || !(AzwZl0nt9[Syx9Xr1lK] - (393 - 361) != HIafcS3qL2R0[EIxNcC4rS])) {
                    p8pNSsa[Syx9Xr1lK]++;
                }
                else
                    ;
                EIxNcC4rS = EIxNcC4rS +(562 - 561);
            }
        }
        {
            int EIxNcC4rS;
            EIxNcC4rS = (628 - 628);
            for (; Syx9Xr1lK >= EIxNcC4rS;) {
                if (AzwZl0nt9[EIxNcC4rS] >= 'a' && 'z' >= AzwZl0nt9[EIxNcC4rS])
                    AzwZl0nt9[EIxNcC4rS] = AzwZl0nt9[EIxNcC4rS] - (756 - 724);
                EIxNcC4rS = EIxNcC4rS +(40 - 39);
            }
        }
        cout << "?" << endl;
        {
            int EIxNcC4rS;
            EIxNcC4rS = (296 - 296);
            for (; EIxNcC4rS <= Syx9Xr1lK;) {
                cout << '(' << AzwZl0nt9[EIxNcC4rS] << ',' << p8pNSsa[EIxNcC4rS] << ')';
                EIxNcC4rS = EIxNcC4rS +(313 - 312);
            }
        }
        cout << endl;
    }
    return (176 - 176);
}

