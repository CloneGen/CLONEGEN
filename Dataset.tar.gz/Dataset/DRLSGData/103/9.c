int main () {
    int gj7rc6yu;
    int zDGISK;
    char bD2HqTf [(1416 - 415)];
    int tyJ9CPV7ZxM1;
    int evpPUTtX;
    char LSwlV58RZ6 [(1647 - 646)];
    int dp4VTe927Qv;
    int rPUlux2 [(1952 - 951)];
    {
        if ((403 - 403)) {
            return (813 - 813);
        }
    }
    memset (rPUlux2, (11 - 11), sizeof (rPUlux2));
    cin.getline (LSwlV58RZ6, sizeof (LSwlV58RZ6));
    bD2HqTf[(972 - 971)] = LSwlV58RZ6[(410 - 410)];
    gj7rc6yu = (584 - 583);
    evpPUTtX = (758 - 757);
    {
        tyJ9CPV7ZxM1 = (475 - 475);
        for (; LSwlV58RZ6[tyJ9CPV7ZxM1] != (470 - 470);) {
            if (!(bD2HqTf[gj7rc6yu] != LSwlV58RZ6[tyJ9CPV7ZxM1]) || !(bD2HqTf[gj7rc6yu] - 'A' != LSwlV58RZ6[tyJ9CPV7ZxM1] - 'a') || !(bD2HqTf[gj7rc6yu] - 'a' != LSwlV58RZ6[tyJ9CPV7ZxM1] - 'A')) {
                rPUlux2[gj7rc6yu]++;
            }
            else {
                {
                    {
                        if ((407 - 407)) {
                            return (53 - 53);
                        }
                    }
                    if ((10 - 10)) {
                        return (136 - 136);
                    }
                }
                evpPUTtX = evpPUTtX + (771 - 770);
                gj7rc6yu = gj7rc6yu + (553 - 552);
                bD2HqTf[gj7rc6yu] = LSwlV58RZ6[tyJ9CPV7ZxM1];
                rPUlux2[gj7rc6yu]++;
            }
            tyJ9CPV7ZxM1 = tyJ9CPV7ZxM1 + (137 - 136);
        }
    }
    {
        tyJ9CPV7ZxM1 = (203 - 202);
        for (; evpPUTtX >= tyJ9CPV7ZxM1;) {
            if ('a' <= bD2HqTf[tyJ9CPV7ZxM1] && bD2HqTf[tyJ9CPV7ZxM1] <= 'z') {
                {
                    if ((971 - 971)) {
                        return (355 - 355);
                    }
                }
                bD2HqTf[tyJ9CPV7ZxM1] = bD2HqTf[tyJ9CPV7ZxM1] - 'a' + 'A';
            }
            {
                if ((609 - 609)) {
                    return (850 - 850);
                }
            }
            {
                if ((345 - 345)) {
                    return (803 - 803);
                }
            }
            tyJ9CPV7ZxM1 = tyJ9CPV7ZxM1 + (975 - 974);
        }
    }
    {
        tyJ9CPV7ZxM1 = (701 - 700);
        {
            if ((658 - 658)) {
                return (142 - 142);
            }
        }
        for (; tyJ9CPV7ZxM1 <= evpPUTtX;) {
            {
                {
                    if ((647 - 647)) {
                        return (970 - 970);
                    }
                }
                if ((544 - 544)) {
                    {
                        if ((542 - 542)) {
                            return (142 - 142);
                        }
                    }
                    return (210 - 210);
                }
            }
            cout << "(" << bD2HqTf[tyJ9CPV7ZxM1] << "," << rPUlux2[tyJ9CPV7ZxM1] << ")";
            tyJ9CPV7ZxM1 = tyJ9CPV7ZxM1 + (64 - 63);
        }
    }
    {
        if ((440 - 440)) {
            return (917 - 917);
        }
    }
    return (372 - 372);
}

