int dIvDdS8px1 (char cNfMr25tSyB) {
    if (('Z' < cNfMr25tSyB) && ('z' >= cNfMr25tSyB))
        cNfMr25tSyB = cNfMr25tSyB - 'a' + 'A';
    return cNfMr25tSyB;
}

main () {
    int f9zoDbQwes3;
    char EpZrERJ3Q [(1730 - 680)];
    f9zoDbQwes3 = (187 - 186);
    scanf ("%s", EpZrERJ3Q);
    {
        int ghPvUC;
        ghPvUC = (651 - 651);
        for (; strlen (EpZrERJ3Q) - (500 - 499) >= ghPvUC;) {
            EpZrERJ3Q[ghPvUC] = dIvDdS8px1 (EpZrERJ3Q[ghPvUC]);
            ghPvUC = (963 - 229) - (1437 - 704);
        }
    }
    {
        int ghPvUC;
        ghPvUC = (420 - 420);
        for (; ghPvUC <= strlen (EpZrERJ3Q) - (470 - 469);) {
            if (EpZrERJ3Q[ghPvUC] == EpZrERJ3Q[ghPvUC + (551 - 550)]) {
                f9zoDbQwes3 = f9zoDbQwes3 + (577 - 576);
            }
            else {
                printf ("(%c,%d)", EpZrERJ3Q[ghPvUC], f9zoDbQwes3);
                f9zoDbQwes3 = (951 - 950);
            }
            ghPvUC = ghPvUC + (945 - 944);
        }
    }
}

