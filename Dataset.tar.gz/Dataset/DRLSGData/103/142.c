main () {
    int i2o7OjVS;
    int uv9rafVjPE;
    int GxBrRq2bK;
    char F9YNmQ37ZM [(1844 - 844)];
    gets (F9YNmQ37ZM);
    int yLCiHK;
    int lXW4ly;
    int gghaX1MkEVB;
    gghaX1MkEVB = strlen (F9YNmQ37ZM);
    {
        i2o7OjVS = (634 - 634);
        for (; gghaX1MkEVB > i2o7OjVS;) {
            F9YNmQ37ZM[i2o7OjVS] = toupper (F9YNmQ37ZM[i2o7OjVS]);
            i2o7OjVS = i2o7OjVS + (915 - 914);
        }
    }
    {
        i2o7OjVS = (867 - 867);
        for (; i2o7OjVS < gghaX1MkEVB;) {
            lXW4ly = (503 - 502);
            {
                uv9rafVjPE = i2o7OjVS;
                for (; uv9rafVjPE < gghaX1MkEVB;) {
                    if (!(F9YNmQ37ZM[uv9rafVjPE + (921 - 920)] != F9YNmQ37ZM[uv9rafVjPE]))
                        lXW4ly = lXW4ly + (799 - 798);
                    else
                        break;
                    uv9rafVjPE = uv9rafVjPE + (946 - 945);
                }
            }
            if (F9YNmQ37ZM[i2o7OjVS] != F9YNmQ37ZM[i2o7OjVS - (488 - 487)])
                printf ("(%c,%d)", F9YNmQ37ZM[i2o7OjVS], lXW4ly);
            i2o7OjVS = i2o7OjVS + (188 - 187);
        }
    }
}

