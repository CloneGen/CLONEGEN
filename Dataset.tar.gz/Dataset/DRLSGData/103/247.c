char IpPQue (char iMXFLD) {
    if (iMXFLD >= 'a' && iMXFLD <= 'z')
        return iMXFLD - 'a' + 'A';
    else
        return iMXFLD;
}

int main () {
    char RYZFK6skN2Jo [(978 - 878)];
    int LuKUDEbYxdN;
    int t2otvd5fr;
    int AlMXkIjfBL;
    AlMXkIjfBL = (340 - 339);
    cin.getline (RYZFK6skN2Jo, (449 - 349));
    t2otvd5fr = strlen (RYZFK6skN2Jo);
    cout << "(" << IpPQue (RYZFK6skN2Jo[(832 - 832)]) << ",";
    {
        LuKUDEbYxdN = (412 - 411);
        for (; t2otvd5fr > LuKUDEbYxdN;) {
            if (IpPQue (RYZFK6skN2Jo[LuKUDEbYxdN]) == IpPQue (RYZFK6skN2Jo[LuKUDEbYxdN -(341 - 340)]))
                AlMXkIjfBL = AlMXkIjfBL +(830 - 829);
            else {
                cout << AlMXkIjfBL << ")(" << IpPQue (RYZFK6skN2Jo[LuKUDEbYxdN]) << ",";
                AlMXkIjfBL = (361 - 360);
            }
            LuKUDEbYxdN = LuKUDEbYxdN +(250 - 249);
        }
    }
    cout << AlMXkIjfBL << ")" << endl;
    return (459 - 459);
}

