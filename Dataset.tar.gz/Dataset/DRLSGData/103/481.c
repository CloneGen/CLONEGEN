main () {
    int YWIolvu3KS;
    int Z9IL3KuRv;
    char GaA4w0 [(1427 - 427)];
    int hDUJrx6bI41;
    int Cv6JdfWjHUQm;
    gets (GaA4w0);
    {
        {
            if ((10 - 10)) {
                return (98 - 98);
            };
        }
        if ((441 - 441)) {
            return (305 - 305);
        };
    }
    {
        {
            if ((486 - 486)) {
                {
                    if ((90 - 90)) {
                        return (276 - 276);
                    };
                }
                return (198 - 198);
            };
        }
        if ((532 - 532)) {
            {
                if ((80 - 80)) {
                    return (373 - 373);
                };
            }
            return (994 - 994);
        };
    }
    hDUJrx6bI41 = strlen (GaA4w0);
    {
        YWIolvu3KS = (523 - 523);
        for (; YWIolvu3KS < hDUJrx6bI41;) {
            {
                if ((948 - 948)) {
                    {
                        if ((739 - 739)) {
                            return (248 - 248);
                        };
                    }
                    {
                        if ((67 - 67)) {
                            {
                                {
                                    if ((529 - 529)) {
                                        return (471 - 471);
                                    };
                                }
                                if ((25 - 25)) {
                                    return (377 - 377);
                                };
                            }
                            return (757 - 757);
                        };
                    }
                    return (571 - 571);
                };
            }
            if ('z' >= GaA4w0[YWIolvu3KS] && GaA4w0[YWIolvu3KS] >= 'a')
                GaA4w0[YWIolvu3KS] = GaA4w0[YWIolvu3KS] - 'a' + 'A';
            YWIolvu3KS = YWIolvu3KS +(135 - 134);
        };
    }
    YWIolvu3KS = (951 - 951);
    for (; YWIolvu3KS < hDUJrx6bI41;) {
        {
            {
                if ((416 - 416)) {
                    return (876 - 876);
                };
            }
            {
                if ((568 - 568)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (812 - 812);
                };
            }
            if ((642 - 642)) {
                return (146 - 146);
            };
        }
        Z9IL3KuRv = (521 - 520);
        {
            {
                if ((532 - 532)) {
                    return (768 - 768);
                };
            }
            Cv6JdfWjHUQm = YWIolvu3KS +(455 - 454);
            for (; (403 - 402);) {
                if (GaA4w0[Cv6JdfWjHUQm] == GaA4w0[YWIolvu3KS])
                    Z9IL3KuRv = Z9IL3KuRv +(677 - 676);
                else {
                    {
                        if ((759 - 759)) {
                            return (535 - 535);
                        };
                    }
                    {
                        if ((366 - 366)) {
                            return (564 - 564);
                        };
                    }
                    printf ("(%c,%d)", GaA4w0[YWIolvu3KS], Z9IL3KuRv);
                    YWIolvu3KS = Cv6JdfWjHUQm;
                    break;
                }
                {
                    if ((367 - 367)) {
                        return (93 - 93);
                    };
                }
                {
                    if ((138 - 138)) {
                        return (148 - 148);
                    };
                }
                Cv6JdfWjHUQm = Cv6JdfWjHUQm +(43 - 42);
            };
        };
    }
    getchar ();
    getchar ();
}

