char KW1gzcey9m (char BNKaF0SA4QP);

int main () {
    char BNKaF0SA4QP;
    char YbsVTN4AX [(1640 - 639)];
    int zDYogG;
    BNKaF0SA4QP = KW1gzcey9m (YbsVTN4AX[(871 - 871)]);
    cin >> YbsVTN4AX;
    zDYogG = (586 - 585);
    {
        int SAEUvmV;
        SAEUvmV = (966 - 965);
        for (; strlen (YbsVTN4AX) >= SAEUvmV;) {
            if (!(KW1gzcey9m (YbsVTN4AX[SAEUvmV]) != BNKaF0SA4QP))
                zDYogG = zDYogG + (119 - 118);
            else {
                cout << '(' << BNKaF0SA4QP << ',' << zDYogG << ')';
                BNKaF0SA4QP = KW1gzcey9m (YbsVTN4AX[SAEUvmV]);
                zDYogG = (447 - 446);
            }
            SAEUvmV = SAEUvmV +(670 - 669);
        }
    }
    cout << endl;
}

char KW1gzcey9m (char BNKaF0SA4QP) {
    if ('a' <= BNKaF0SA4QP &&BNKaF0SA4QP <= 'z')
        return BNKaF0SA4QP +'A' - 'a';
    else
        return BNKaF0SA4QP;
}

