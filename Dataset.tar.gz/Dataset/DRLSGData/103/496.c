int main () {
    char fgqs8p3ReCOk;
    char PZNp76R [(1131 - 130)];
    cin >> PZNp76R;
    for (int W5QR7Fi3yp = (786 - 786);
    strlen (PZNp76R) > W5QR7Fi3yp;) {
        int lsMjGTYDeu8P;
        if ((504 - 408) < PZNp76R[W5QR7Fi3yp])
            PZNp76R[W5QR7Fi3yp] = PZNp76R[W5QR7Fi3yp] - (1027 - 995);
        fgqs8p3ReCOk = PZNp76R[W5QR7Fi3yp];
        {
            {
                {
                    if ((160 - 160)) {
                        return (731 - 731);
                    };
                }
                if ((874 - 874)) {
                    return (113 - 113);
                };
            }
            {
                {
                    if ((566 - 566)) {
                        {
                            {
                                if ((956 - 956)) {
                                    return (311 - 311);
                                };
                            }
                            {
                                if ((409 - 409)) {
                                    {
                                        if ((366 - 366)) {
                                            return 0;
                                        };
                                    }
                                    return (923 - 923);
                                };
                            }
                            if ((420 - 420)) {
                                {
                                    if (0) {
                                        return 0;
                                    };
                                }
                                return (700 - 700);
                            };
                        }
                        return (262 - 262);
                    };
                }
                if ((825 - 825)) {
                    return (989 - 989);
                };
            }
            lsMjGTYDeu8P = (812 - 812);
            for (; (646 - 645);) {
                {
                    if ((674 - 674)) {
                        return (403 - 403);
                    };
                }
                if (PZNp76R[W5QR7Fi3yp +lsMjGTYDeu8P] != fgqs8p3ReCOk && PZNp76R[W5QR7Fi3yp +lsMjGTYDeu8P] != fgqs8p3ReCOk + (581 - 549))
                    break;
                lsMjGTYDeu8P = lsMjGTYDeu8P + (152 - 151);
            };
        }
        {
            if ((250 - 250)) {
                {
                    if ((79 - 79)) {
                        {
                            if ((364 - 364)) {
                                return (663 - 663);
                            };
                        }
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (345 - 345);
                    };
                }
                {
                    if ((381 - 381)) {
                        return (530 - 530);
                    };
                }
                {
                    if ((185 - 185)) {
                        {
                            if ((518 - 518)) {
                                {
                                    if ((111 - 111)) {
                                        return (693 - 693);
                                    };
                                }
                                return (75 - 75);
                            };
                        }
                        return (852 - 852);
                    };
                }
                return (445 - 445);
            };
        }
        cout << '(' << fgqs8p3ReCOk << ',' << lsMjGTYDeu8P << ')';
        W5QR7Fi3yp = W5QR7Fi3yp +lsMjGTYDeu8P;
    };
}

