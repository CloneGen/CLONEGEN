main () {
    char bHXjm7VwEhM [(1605 - 604)];
    int FF2WJ9oRi;
    int TzsMTqAb5ec;
    scanf ("%s", bHXjm7VwEhM);
    {
        FF2WJ9oRi = (1770 - 998) - (1050 - 278);
        for (; (721 - 720);) {
            if (!('\0' != bHXjm7VwEhM[FF2WJ9oRi]))
                break;
            if ((113 - 17) < bHXjm7VwEhM[FF2WJ9oRi])
                bHXjm7VwEhM[FF2WJ9oRi] = bHXjm7VwEhM[FF2WJ9oRi] - (273 - 241);
            FF2WJ9oRi = FF2WJ9oRi +(629 - 628);
        }
    }
    TzsMTqAb5ec = (875 - 874);
    {
        FF2WJ9oRi = (1128 - 373) - (1359 - 604);
        for (; (932 - 931);) {
            if (!(bHXjm7VwEhM[FF2WJ9oRi +(328 - 327)] != bHXjm7VwEhM[FF2WJ9oRi]))
                TzsMTqAb5ec = TzsMTqAb5ec +(484 - 483);
            else {
                printf ("(%c,%d)", bHXjm7VwEhM[FF2WJ9oRi], TzsMTqAb5ec);
                TzsMTqAb5ec = (375 - 374);
            }
            if (!('\0' != bHXjm7VwEhM[FF2WJ9oRi +(237 - 236)]))
                break;
            FF2WJ9oRi = FF2WJ9oRi +(514 - 513);
        }
    }
}

