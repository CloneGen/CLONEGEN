int gBey0HbRYm (char w7gObF6cGElH [(1671 - 670)], int NU3Vi6) {
    char BOdMTL3Sgj;
    int BfANsSy;
    int xJY9hNd5oK;
    int qjHRW5S;
    xJY9hNd5oK = (632 - 632);
    qjHRW5S = w7gObF6cGElH[NU3Vi6];
    BfANsSy = w7gObF6cGElH[NU3Vi6];
    for (; w7gObF6cGElH[NU3Vi6] != '\0' && (!(BfANsSy != qjHRW5S) || !(BfANsSy != (qjHRW5S - (440 - 408))) || !((BfANsSy -(294 - 262)) != qjHRW5S));) {
        NU3Vi6 = NU3Vi6 +(120 - 119);
        xJY9hNd5oK = xJY9hNd5oK + (65 - 64);
        BfANsSy = w7gObF6cGElH[NU3Vi6];
    }
    if (qjHRW5S >= (668 - 571)) {
        BOdMTL3Sgj = qjHRW5S - (782 - 750);
        cout << "(" << BOdMTL3Sgj << "," << xJY9hNd5oK << ")";
    }
    else {
        BOdMTL3Sgj = qjHRW5S;
        cout << "(" << BOdMTL3Sgj << "," << xJY9hNd5oK << ")";
    }
    return xJY9hNd5oK;
}

int main () {
    int qjHRW5S;
    int mG8cF7;
    char w7gObF6cGElH [(1207 - 206)];
    int xJY9hNd5oK;
    int qp0kHAIFw;
    qp0kHAIFw = (627 - 627);
    cin >> w7gObF6cGElH;
    for (; w7gObF6cGElH[qp0kHAIFw] != '\0';) {
        qp0kHAIFw = qp0kHAIFw + (429 - 428);
    }
    xJY9hNd5oK = (479 - 479);
    for (; xJY9hNd5oK < qp0kHAIFw;) {
        mG8cF7 = gBey0HbRYm (w7gObF6cGElH, xJY9hNd5oK);
        xJY9hNd5oK = xJY9hNd5oK + mG8cF7;
    }
    return (934 - 934);
}

