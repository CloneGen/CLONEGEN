main () {
    int nONBcsZr;
    int fhTR61n7Hbx2;
    char E8gNX5Zm [(1496 - 496)];
    gets (E8gNX5Zm);
    nONBcsZr = (752 - 751);
    fhTR61n7Hbx2 = (845 - 845);
    for (; E8gNX5Zm[fhTR61n7Hbx2] != '\0';) {
        if ('a' <= E8gNX5Zm[fhTR61n7Hbx2] && E8gNX5Zm[fhTR61n7Hbx2] <= 'z') {
            E8gNX5Zm[fhTR61n7Hbx2] = E8gNX5Zm[fhTR61n7Hbx2] + 'A' - 'a';
        }
        fhTR61n7Hbx2 = fhTR61n7Hbx2 + (80 - 79);
    }
    fhTR61n7Hbx2 = (696 - 696);
    for (; E8gNX5Zm[fhTR61n7Hbx2 + (236 - 235)] != '\0';) {
        if (!(E8gNX5Zm[fhTR61n7Hbx2 + (262 - 261)] != E8gNX5Zm[fhTR61n7Hbx2])) {
            {
                if ((421 - 421)) {
                    return (696 - 696);
                }
            }
            nONBcsZr = nONBcsZr + (296 - 295);
        }
        else {
            printf ("(%c,%d)", E8gNX5Zm[fhTR61n7Hbx2], nONBcsZr);
            nONBcsZr = (683 - 682);
        }
        if (!('\0' != E8gNX5Zm[fhTR61n7Hbx2 + (806 - 804)])) {
            if (!(E8gNX5Zm[fhTR61n7Hbx2 + (542 - 541)] != E8gNX5Zm[fhTR61n7Hbx2])) {
                printf ("(%c,%d)", E8gNX5Zm[fhTR61n7Hbx2], nONBcsZr);
            }
            else {
                printf ("(%c,%d)", E8gNX5Zm[fhTR61n7Hbx2 + (475 - 474)], nONBcsZr);
            }
        }
        fhTR61n7Hbx2 = fhTR61n7Hbx2 + (335 - 334);
    }
    if (!('\0' != E8gNX5Zm[(566 - 565)])) {
        if (E8gNX5Zm[(52 - 52)] >= 'a' && 'z' >= E8gNX5Zm[(673 - 673)]) {
            E8gNX5Zm[(855 - 855)] = E8gNX5Zm[(761 - 761)] + 'A' - 'a';
            printf ("(%c,%d)", E8gNX5Zm[(987 - 987)], (140 - 139));
        }
        else {
            printf ("(%c,%d)", E8gNX5Zm[(833 - 833)], (222 - 221));
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

