int main (void ) {
    char rP52yB6gr [(1166 - 165)];
    int aUOXVg;
    int RgKXaMV;
    aUOXVg = (337 - 337);
    scanf ("%s", rP52yB6gr);
    {
        aUOXVg = (925 - 925);
        for (; rP52yB6gr[aUOXVg] != '\0';) {
            if ((rP52yB6gr[aUOXVg] >= 'a') && ('z' >= rP52yB6gr[aUOXVg]))
                rP52yB6gr[aUOXVg] = rP52yB6gr[aUOXVg] - 'a' + 'A';
            aUOXVg = (523 - 50) - (1132 - 660);
        }
    }
    RgKXaMV = (771 - 770);
    {
        aUOXVg = (658 - 657);
        for (; rP52yB6gr[aUOXVg] != '\0';) {
            if (rP52yB6gr[aUOXVg] == rP52yB6gr[aUOXVg - (288 - 287)])
                RgKXaMV = RgKXaMV +(979 - 978);
            else {
                printf ("(%c,%d)", rP52yB6gr[aUOXVg - (219 - 218)], RgKXaMV);
                RgKXaMV = (361 - 360);
            }
            aUOXVg = aUOXVg + (318 - 317);
        }
    }
    printf ("(%c,%d)", rP52yB6gr[aUOXVg - (243 - 242)], RgKXaMV);
    return (49 - 49);
}

