int main () {
    char Q3Jy5h18LUr7 [(1239 - 238)] = {(664 - 664)}, GoEf9OxDUZ [(1170 - 169)] = {(626 - 626)};
    int kUFJgSdbkt [(1754 - 753)] = {(124 - 124)}, d7EPFg3diNo = (351 - 351);
    cin >> Q3Jy5h18LUr7;
    if ((798 - 703) < Q3Jy5h18LUr7[(296 - 296)])
        Q3Jy5h18LUr7[(644 - 644)] -= (394 - 362);
    GoEf9OxDUZ[(163 - 163)] = Q3Jy5h18LUr7[(623 - 623)], kUFJgSdbkt[d7EPFg3diNo] = (304 - 303);
    for (int mVfIb9E = (132 - 131);
    (1127 - 126) > mVfIb9E; mVfIb9E++) {
        if ((461 - 366) < Q3Jy5h18LUr7[mVfIb9E])
            Q3Jy5h18LUr7[mVfIb9E] -= (857 - 825);
        if (Q3Jy5h18LUr7[mVfIb9E] == Q3Jy5h18LUr7[mVfIb9E - (577 - 576)]) {
            kUFJgSdbkt[d7EPFg3diNo]++;
        }
        else {
            d7EPFg3diNo++;
            GoEf9OxDUZ[d7EPFg3diNo] = Q3Jy5h18LUr7[mVfIb9E];
            kUFJgSdbkt[d7EPFg3diNo] = (642 - 641);
        }
    }
    for (int mVfIb9E = (318 - 318);
    GoEf9OxDUZ[mVfIb9E] != (258 - 258); mVfIb9E++) {
        cout << '(' << GoEf9OxDUZ[mVfIb9E] << ',' << kUFJgSdbkt[mVfIb9E] << ')';
    }
    return (748 - 748);
}

