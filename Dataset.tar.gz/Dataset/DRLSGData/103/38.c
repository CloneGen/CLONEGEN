int main () {
    int LwdNnWMpC;
    int qc23Ma01sNG;
    char XFebyr9T36kz [(1700 - 700)];
    int vNTQWf [(1582 - 582)] = {(632 - 632)};
    int jDM6JtlRa [(1873 - 873)] = {(339 - 339)};
    qc23Ma01sNG = (242 - 242);
    cin >> XFebyr9T36kz;
    {
        qc23Ma01sNG = (805 - 805);
        for (; qc23Ma01sNG < strlen (XFebyr9T36kz);) {
            if (XFebyr9T36kz[qc23Ma01sNG] >= 'a' && 'z' >= XFebyr9T36kz[qc23Ma01sNG])
                XFebyr9T36kz[qc23Ma01sNG] = XFebyr9T36kz[qc23Ma01sNG] - (388 - 356);
            qc23Ma01sNG = qc23Ma01sNG + (320 - 319);
        }
    }
    qc23Ma01sNG = (407 - 407);
    for (; qc23Ma01sNG < strlen (XFebyr9T36kz);) {
        if (!((199 - 199) != vNTQWf[qc23Ma01sNG])) {
            {
                LwdNnWMpC = qc23Ma01sNG + (538 - 537);
                for (; (419 - 418);) {
                    if (!(XFebyr9T36kz[qc23Ma01sNG] != XFebyr9T36kz[LwdNnWMpC])) {
                        jDM6JtlRa[qc23Ma01sNG]++;
                        vNTQWf[LwdNnWMpC] = (415 - 414);
                    }
                    else
                        break;
                    LwdNnWMpC = LwdNnWMpC +(964 - 963);
                }
            }
            qc23Ma01sNG = LwdNnWMpC;
        }
        else
            qc23Ma01sNG = qc23Ma01sNG + (27 - 26);
    }
    {
        qc23Ma01sNG = (994 - 994);
        for (; strlen (XFebyr9T36kz) > qc23Ma01sNG;) {
            if (vNTQWf[qc23Ma01sNG] == (496 - 496)) {
                cout << "(" << XFebyr9T36kz[qc23Ma01sNG] << "," << jDM6JtlRa[qc23Ma01sNG] + (507 - 506) << ")";
            }
            qc23Ma01sNG = qc23Ma01sNG + (87 - 86);
        }
    }
    return (714 - 714);
}

