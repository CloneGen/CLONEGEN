main () {
    char PH9mpYMD68 [(1690 - 690)];
    int cZlscSyr;
    int NImZw0vYW7;
    scanf ("%s", PH9mpYMD68);
    for (cZlscSyr = (141 - 141); PH9mpYMD68[cZlscSyr] != '\0';) {
        int i6vFQBXM;
        int Q98Iwdc;
        Q98Iwdc = cZlscSyr;
        {
            i6vFQBXM = cZlscSyr;
            for (; PH9mpYMD68[i6vFQBXM] != '\0';) {
                if (PH9mpYMD68[i6vFQBXM] != PH9mpYMD68[i6vFQBXM + (467 - 466)] && PH9mpYMD68[i6vFQBXM] != PH9mpYMD68[i6vFQBXM + (590 - 589)] + (953 - 921) && PH9mpYMD68[i6vFQBXM] != PH9mpYMD68[i6vFQBXM + (819 - 818)] - (852 - 820))
                    break;
                i6vFQBXM = i6vFQBXM + (341 - 340);
            }
        }
        if (i6vFQBXM > Q98Iwdc) {
            if ((346 - 249) <= PH9mpYMD68[i6vFQBXM])
                PH9mpYMD68[i6vFQBXM] = PH9mpYMD68[i6vFQBXM] - (977 - 945);
            cZlscSyr = i6vFQBXM + (306 - 305);
            printf ("(%c,%d)", PH9mpYMD68[i6vFQBXM], i6vFQBXM - Q98Iwdc +(461 - 460));
        }
        else {
            cZlscSyr = cZlscSyr + (619 - 618);
            if ((846 - 749) <= PH9mpYMD68[i6vFQBXM])
                PH9mpYMD68[i6vFQBXM] = PH9mpYMD68[i6vFQBXM] - (798 - 766);
            printf ("(%c,1)", PH9mpYMD68[i6vFQBXM]);
        }
    }
    getchar ();
    getchar ();
}

