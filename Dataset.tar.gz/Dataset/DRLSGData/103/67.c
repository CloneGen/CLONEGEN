int main () {
    char peNXyJWqS [(2027 - 27)];
    int ke9xGUy;
    int J4KZUPxy;
    char ee1vp2lb5o;
    J4KZUPxy = (391 - 391);
    cin.getline (peNXyJWqS, (2969 - 969));
    {
        {
            {
                {
                    {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if (0) {
                            return 0;
                        };
                    }
                    if ((566 - 566)) {
                        return (892 - 892);
                    };
                }
                if ((94 - 94)) {
                    {
                        if ((932 - 932)) {
                            return (807 - 807);
                        };
                    }
                    return (980 - 980);
                };
            }
            {
                if ((351 - 351)) {
                    return (357 - 357);
                };
            }
            {
                if ((991 - 991)) {
                    {
                        if ((646 - 646)) {
                            return (241 - 241);
                        };
                    }
                    {
                        if ((812 - 812)) {
                            {
                                if ((940 - 940)) {
                                    {
                                        if (0) {
                                            return 0;
                                        };
                                    }
                                    return (215 - 215);
                                };
                            }
                            return (572 - 572);
                        };
                    }
                    return (175 - 175);
                };
            }
            if ((791 - 791)) {
                return (18 - 18);
            };
        }
        ke9xGUy = (511 - 114) - (1280 - 883);
        for (; peNXyJWqS[ke9xGUy] != '\0';) {
            if (!((116 - 116) != peNXyJWqS[ke9xGUy + (521 - 520)] - peNXyJWqS[ke9xGUy]) || !('a' - 'A' != peNXyJWqS[ke9xGUy + (515 - 514)] - peNXyJWqS[ke9xGUy]) || !('A' - 'a' != peNXyJWqS[ke9xGUy + (522 - 521)] - peNXyJWqS[ke9xGUy]))
                J4KZUPxy = J4KZUPxy +(22 - 21);
            else {
                if ('a' <= peNXyJWqS[ke9xGUy] && 'z' >= peNXyJWqS[ke9xGUy]) {
                    {
                        {
                            if ((313 - 313)) {
                                {
                                    if ((973 - 973)) {
                                        return (600 - 600);
                                    };
                                }
                                return (387 - 387);
                            };
                        }
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        if ((854 - 854)) {
                            {
                                if ((101 - 101)) {
                                    return (846 - 846);
                                };
                            }
                            return (723 - 723);
                        };
                    }
                    {
                        if ((65 - 65)) {
                            return (489 - 489);
                        };
                    }
                    ee1vp2lb5o = peNXyJWqS[ke9xGUy] - (246 - 214);
                    cout << "(" << ee1vp2lb5o << "," << J4KZUPxy +(20 - 19) << ")";
                }
                else {
                    ee1vp2lb5o = peNXyJWqS[ke9xGUy];
                    cout << "(" << ee1vp2lb5o << "," << J4KZUPxy +(240 - 239) << ")";
                }
                {
                    if (0) {
                        return 0;
                    };
                }
                J4KZUPxy = (151 - 151);
            }
            ke9xGUy = ke9xGUy + (507 - 506);
        };
    }
    {
        if ((887 - 887)) {
            return (548 - 548);
        };
    }
    {
        {
            {
                if ((430 - 430)) {
                    return (56 - 56);
                };
            }
            {
                if ((814 - 814)) {
                    return (850 - 850);
                };
            }
            if ((789 - 789)) {
                return (636 - 636);
            };
        }
        if ((87 - 87)) {
            {
                if ((721 - 721)) {
                    return (688 - 688);
                };
            }
            return (948 - 948);
        };
    }
    {
        {
            if ((743 - 743)) {
                return (938 - 938);
            };
        }
        if ((22 - 22)) {
            return (535 - 535);
        };
    }
    return (847 - 847);
}

