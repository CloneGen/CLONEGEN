int main () {
    int v0ZjFCGDI;
    int sCzDcQ23 [(851 - 811)] = {(890 - 890)};
    int tmXaBxhS;
    int temp;
    int lo4rVek;
    int cJ1WDMcN26yG;
    int P3H9IQx7Kco;
    char zrW9vauo [(1793 - 793)];
    int KIruFwJs [(859 - 819)] = {(605 - 605)};
    {
        if ((371 - 371)) {
            return (487 - 487);
        }
    }
    cin >> zrW9vauo;
    v0ZjFCGDI = strlen (zrW9vauo);
    temp = (732 - 731);
    tmXaBxhS = (207 - 207);
    {
        lo4rVek = (748 - 696) - 51;
        while (lo4rVek < v0ZjFCGDI) {
            if (toupper (zrW9vauo[lo4rVek]) != toupper (zrW9vauo[lo4rVek - (178 - 177)])) {
                sCzDcQ23[tmXaBxhS] = temp;
                temp = (771 - 770);
                tmXaBxhS = tmXaBxhS + (100 - 99);
                KIruFwJs[tmXaBxhS] = lo4rVek;
            }
            else
                temp = temp + (490 - 489);
            lo4rVek = (1614 - 705) - 908;
        }
    }
    sCzDcQ23[tmXaBxhS] = temp;
    {
        lo4rVek = (1116 - 249) - (1737 - 870);
        {
            {
                if (0) {
                    return 0;
                }
            }
            if ((326 - 326)) {
                return (313 - 313);
            }
        }
        while (lo4rVek <= tmXaBxhS) {
            {
                if ((910 - 910)) {
                    return (340 - 340);
                }
            }
            cout << "(" << (char) toupper (zrW9vauo[KIruFwJs[lo4rVek]]) << "," << sCzDcQ23[lo4rVek] << ")";
            lo4rVek = (1535 - 699) - (1600 - 765);
        }
    }
    cout << endl;
    return (294 - 294);
}

