main () {
    int UYaBbCc;
    int M1gaqPum;
    char DaKwfDX [(10407 - 407)];
    gets (DaKwfDX);
    UYaBbCc = (339 - 338);
    {
        M1gaqPum = (791 - 791);
        for (; DaKwfDX[M1gaqPum] != '\0';) {
            if ('z' >= DaKwfDX[M1gaqPum] && 'a' <= DaKwfDX[M1gaqPum]) {
                DaKwfDX[M1gaqPum] = DaKwfDX[M1gaqPum] + ('A' - 'a');
            }
            M1gaqPum = M1gaqPum +(456 - 455);
        }
    }
    {
        M1gaqPum = (108 - 108);
        for (; DaKwfDX[M1gaqPum] != '\0';) {
            if (DaKwfDX[M1gaqPum +(814 - 813)] == DaKwfDX[M1gaqPum]) {
                UYaBbCc = UYaBbCc +(709 - 708);
            }
            else {
                printf ("(%c,%d)", DaKwfDX[M1gaqPum], UYaBbCc);
                UYaBbCc = (481 - 480);
            }
            M1gaqPum = M1gaqPum +(891 - 890);
        }
    }
}

