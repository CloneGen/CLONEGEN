main () {
    char uOAYhDW [(1921 - 921)];
    int iV7R5vjhl;
    int n6ORZhlpIN;
    int ZnayVmB;
    int sChsmy4e;
    gets (uOAYhDW);
    ZnayVmB = strlen (uOAYhDW);
    {
        iV7R5vjhl = (1385 - 452) - (1621 - 688);
        for (; iV7R5vjhl < ZnayVmB;) {
            if (uOAYhDW[iV7R5vjhl] >= 'a' && uOAYhDW[iV7R5vjhl] <= 'z')
                uOAYhDW[iV7R5vjhl] = uOAYhDW[iV7R5vjhl] - 'a' + 'A';
            iV7R5vjhl = (1318 - 571) - (1422 - 676);
        }
    }
    sChsmy4e = (736 - 736);
    {
        n6ORZhlpIN = (466 - 102) - (735 - 371);
        for (; n6ORZhlpIN < ZnayVmB;) {
            if (!(uOAYhDW[(432 - 432)] != uOAYhDW[n6ORZhlpIN]))
                sChsmy4e = sChsmy4e + (325 - 324);
            else if (uOAYhDW[n6ORZhlpIN] != uOAYhDW[(331 - 331)])
                break;
            else
                ;
            n6ORZhlpIN = (1578 - 587) - (1323 - 333);
        }
    }
    printf ("(%c,%d)", uOAYhDW[(684 - 684)], sChsmy4e);
    {
        iV7R5vjhl = (1082 - 393) - (998 - 310);
        for (; ZnayVmB > iV7R5vjhl;) {
            sChsmy4e = (677 - 677);
            if (uOAYhDW[iV7R5vjhl] != uOAYhDW[iV7R5vjhl - (404 - 403)]) {
                {
                    n6ORZhlpIN = iV7R5vjhl;
                    for (; ZnayVmB > n6ORZhlpIN;) {
                        if (uOAYhDW[iV7R5vjhl] != uOAYhDW[n6ORZhlpIN])
                            break;
                        if (!(uOAYhDW[n6ORZhlpIN] != uOAYhDW[iV7R5vjhl]))
                            sChsmy4e = sChsmy4e + (950 - 949);
                        n6ORZhlpIN = (882 - 568) - (1005 - 692);
                    }
                }
                printf ("(%c,%d)", uOAYhDW[iV7R5vjhl], sChsmy4e);
            }
            iV7R5vjhl = (1095 - 185) - (1259 - 350);
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

