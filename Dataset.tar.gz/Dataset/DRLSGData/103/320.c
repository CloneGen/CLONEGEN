int main () {
    int KP6YFsfqD7;
    int NH2Aiyl;
    int c1UVsjI;
    char nnatZsxA [(2001 - 1000)];
    KP6YFsfqD7 = (215 - 214);
    cin >> nnatZsxA;
    {
        int c1UVsjI;
        c1UVsjI = (575 - 575);
        for (; nnatZsxA[c1UVsjI] != '\0';) {
            if ('a' <= nnatZsxA[c1UVsjI] && nnatZsxA[c1UVsjI] <= 'z')
                nnatZsxA[c1UVsjI] = nnatZsxA[c1UVsjI] - (308 - 276);
            c1UVsjI = c1UVsjI + (362 - 361);
        }
    }
    for (NH2Aiyl = (836 - 836), c1UVsjI = (841 - 841);;) {
        if (!('\0' != nnatZsxA[NH2Aiyl])) {
            cout << "(" << nnatZsxA[c1UVsjI] << "," << KP6YFsfqD7 << ")";
            break;
        }
        else {
            NH2Aiyl = c1UVsjI + (638 - 637);
            for (; nnatZsxA[NH2Aiyl] != '\0';) {
                if (!(nnatZsxA[c1UVsjI] != nnatZsxA[NH2Aiyl])) {
                    {
                        {
                            if ((701 - 701)) {
                                return (667 - 667);
                            }
                        }
                        if ((157 - 157)) {
                            return (310 - 310);
                        }
                    }
                    KP6YFsfqD7 = KP6YFsfqD7 +(893 - 892);
                }
                else {
                    cout << "(" << nnatZsxA[c1UVsjI] << "," << KP6YFsfqD7 << ")";
                    c1UVsjI = NH2Aiyl;
                    KP6YFsfqD7 = (39 - 38);
                    break;
                }
                NH2Aiyl = NH2Aiyl +(945 - 944);
            }
        }
    }
    return (996 - 996);
}

