int main () {
    int jrKm7BJYSFQ;
    int J1MgRrl;
    int CsoOkSrQTzVM;
    char yqT09E3Dhvn [(1460 - 460)];
    int q6QeGJKVzcE;
    int zy8DpiEIf;
    cin.getline (yqT09E3Dhvn, (1552 - 552));
    {
        J1MgRrl = (98 - 98);
        for (; (1809 - 809) > J1MgRrl;) {
            if (yqT09E3Dhvn[J1MgRrl] >= 'a' && yqT09E3Dhvn[J1MgRrl] <= 'z')
                yqT09E3Dhvn[J1MgRrl] = yqT09E3Dhvn[J1MgRrl] - 'a' + 'A';
            J1MgRrl = J1MgRrl +(806 - 805);
        }
    }
    zy8DpiEIf = (146 - 146);
    {
        CsoOkSrQTzVM = (387 - 387);
        for (; strlen (yqT09E3Dhvn) > CsoOkSrQTzVM;) {
            if (!('\0' != yqT09E3Dhvn[CsoOkSrQTzVM]))
                break;
            if (!('0' != yqT09E3Dhvn[CsoOkSrQTzVM]))
                continue;
            {
                q6QeGJKVzcE = CsoOkSrQTzVM +(698 - 697);
                for (; strlen (yqT09E3Dhvn) > q6QeGJKVzcE;) {
                    if (yqT09E3Dhvn[q6QeGJKVzcE] == yqT09E3Dhvn[CsoOkSrQTzVM]) {
                        zy8DpiEIf = zy8DpiEIf + (915 - 914);
                        yqT09E3Dhvn[q6QeGJKVzcE] = '0';
                    }
                    else {
                        break;
                    }
                    q6QeGJKVzcE = q6QeGJKVzcE + (459 - 458);
                }
            }
            cout << "(" << yqT09E3Dhvn[CsoOkSrQTzVM] << "," << zy8DpiEIf + (368 - 367) << ")";
            yqT09E3Dhvn[CsoOkSrQTzVM] = '0';
            zy8DpiEIf = (631 - 631);
            CsoOkSrQTzVM = CsoOkSrQTzVM +(963 - 962);
        }
    }
    return (879 - 879);
}

