int main () {
    int Mcor2HuPiqbU;
    int ImHJu7h8lMTA;
    char HoKCn1 [(584 - 484)];
    int jGqOJc;
    int BJL48D9UZ;
    {
        if ((458 - 458)) {
            return (480 - 480);
        }
    }
    ImHJu7h8lMTA = (597 - 597);
    cin >> HoKCn1;
    {
        BJL48D9UZ = (1299 - 730) - (1418 - 849);
        for (; BJL48D9UZ < strlen (HoKCn1);) {
            if (HoKCn1[BJL48D9UZ] >= 'a' && 'z' >= HoKCn1[BJL48D9UZ])
                HoKCn1[BJL48D9UZ] = HoKCn1[BJL48D9UZ] - (436 - 404);
            BJL48D9UZ = BJL48D9UZ +(753 - 752);
        }
    }
    jGqOJc = (748 - 748);
    for (; (521 - 520);) {
        Mcor2HuPiqbU = 'A';
        {
            BJL48D9UZ = Mcor2HuPiqbU;
            for (; 'Z' >= BJL48D9UZ;) {
                if (BJL48D9UZ == HoKCn1[jGqOJc]) {
                    for (; BJL48D9UZ == HoKCn1[jGqOJc];) {
                        ImHJu7h8lMTA = ImHJu7h8lMTA +(907 - 906);
                        jGqOJc = jGqOJc + (451 - 450);
                    }
                    cout << '(' << (char) BJL48D9UZ << ',' << ImHJu7h8lMTA << ')';
                    Mcor2HuPiqbU = 'A';
                    ImHJu7h8lMTA = (239 - 239);
                }
                BJL48D9UZ = BJL48D9UZ +(944 - 943);
            }
        }
        if (jGqOJc == strlen (HoKCn1))
            break;
    }
    return (213 - 213);
}

