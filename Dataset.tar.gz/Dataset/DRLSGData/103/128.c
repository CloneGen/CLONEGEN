int main () {
    int oU6WRSdXr;
    int d9WAYfkmgoK;
    char zgpemoA;
    char vnSOhMV0 [(1726 - 724)] = {(258 - 258)};
    int bAiGNcIQ;
    int mitZQChLcsa;
    bAiGNcIQ = (759 - 759);
    d9WAYfkmgoK = strlen (vnSOhMV0);
    scanf ("%s", vnSOhMV0);
    mitZQChLcsa = 'A' - 'a';
    {
        oU6WRSdXr = (582 - 206) - (1304 - 928);
        for (; oU6WRSdXr < d9WAYfkmgoK;) {
            if ('a' <= vnSOhMV0[oU6WRSdXr] && vnSOhMV0[oU6WRSdXr] <= 'z') {
                vnSOhMV0[oU6WRSdXr] = vnSOhMV0[oU6WRSdXr] + mitZQChLcsa;
            }
            oU6WRSdXr = (986 - 539) - (854 - 408);
        }
    }
    zgpemoA = vnSOhMV0[(507 - 507)];
    {
        oU6WRSdXr = (1689 - 757) - (1244 - 312);
        for (; oU6WRSdXr <= d9WAYfkmgoK;) {
            if (vnSOhMV0[oU6WRSdXr] != zgpemoA) {
                printf ("(%c,%d)", zgpemoA, bAiGNcIQ);
                zgpemoA = vnSOhMV0[oU6WRSdXr];
                bAiGNcIQ = (690 - 689);
            }
            else {
                bAiGNcIQ = bAiGNcIQ + (719 - 718);
            }
            oU6WRSdXr = (1679 - 702) - (1079 - 103);
        }
    }
    return (668 - 668);
}

