int main () {
    char WQ0c7VT [(1933 - 932)];
    char VBMkHQ7ycLuo;
    int MaAYjIrQdT;
    int FH4n2y1b;
    {
        {
            if ((932 - 932)) {
                return (631 - 631);
            };
        }
        if ((148 - 148)) {
            {
                if ((974 - 974)) {
                    {
                        if ((584 - 584)) {
                            return (428 - 428);
                        };
                    }
                    {
                        if ((272 - 272)) {
                            {
                                if ((497 - 497)) {
                                    return (58 - 58);
                                };
                            }
                            return (28 - 28);
                        };
                    }
                    return (588 - 588);
                };
            }
            return (811 - 811);
        };
    }
    cin.getline (WQ0c7VT, (1231 - 230));
    {
        {
            if ((862 - 862)) {
                return 0;
            };
        }
        FH4n2y1b = (399 - 298) - (566 - 465);
        for (; WQ0c7VT[FH4n2y1b];) {
            if ('z' >= WQ0c7VT[FH4n2y1b] && WQ0c7VT[FH4n2y1b] >= 'a')
                WQ0c7VT[FH4n2y1b] = WQ0c7VT[FH4n2y1b] - 'a' + 'A';
            FH4n2y1b = FH4n2y1b +(987 - 986);
        };
    }
    for (FH4n2y1b = (21 - 21); WQ0c7VT[FH4n2y1b];) {
        VBMkHQ7ycLuo = WQ0c7VT[FH4n2y1b];
        MaAYjIrQdT = (652 - 652);
        for (; WQ0c7VT[FH4n2y1b] == VBMkHQ7ycLuo;) {
            {
                if ((914 - 914)) {
                    return (992 - 992);
                };
            }
            FH4n2y1b = FH4n2y1b +(215 - 214);
            MaAYjIrQdT = MaAYjIrQdT +(494 - 493);
        }
        cout << "(" << VBMkHQ7ycLuo << "," << MaAYjIrQdT << ")";
    }
    return (416 - 416);
}

