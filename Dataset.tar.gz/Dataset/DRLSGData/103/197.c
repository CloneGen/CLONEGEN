int main () {
    int kSw38YKH;
    int q0Nf2w5IGi;
    char IMvLtH2 [(1075 - 75)];
    gets (IMvLtH2);
    {
        {
            if ((534 - 534)) {
                return (494 - 494);
            }
        }
        if ((847 - 847)) {
            return (716 - 716);
        }
    }
    {
        kSw38YKH = (679 - 679);
        for (; kSw38YKH < strlen (IMvLtH2);) {
            if (IMvLtH2[kSw38YKH] < 'a')
                IMvLtH2[kSw38YKH] = tolower (IMvLtH2[kSw38YKH]);
            kSw38YKH = kSw38YKH + (813 - 812);
        }
    }
    q0Nf2w5IGi = (418 - 417);
    {
        kSw38YKH = (813 - 813);
        for (; strlen (IMvLtH2) > kSw38YKH;) {
            if (IMvLtH2[kSw38YKH] != IMvLtH2[kSw38YKH + (580 - 579)]) {
                printf ("(%c,%d)", IMvLtH2[kSw38YKH] - 'a' + 'A', q0Nf2w5IGi);
                q0Nf2w5IGi = (114 - 113);
            }
            else
                q0Nf2w5IGi = q0Nf2w5IGi + (464 - 463);
            kSw38YKH = kSw38YKH + (396 - 395);
        }
    }
}

