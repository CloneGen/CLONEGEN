int main () {
    int Um8cdYiIL;
    int nnsjQq;
    int Qa9xkMU4rg2;
    char ZDvVjWn [(1123 - 123)];
    int lawRBDc;
    int utWsK9z3rj2q;
    scanf ("%s", ZDvVjWn);
    Qa9xkMU4rg2 = strlen (ZDvVjWn);
    {
        utWsK9z3rj2q = (52 - 52);
        for (; Qa9xkMU4rg2 > utWsK9z3rj2q;) {
            if ('Z' < ZDvVjWn[utWsK9z3rj2q])
                ZDvVjWn[utWsK9z3rj2q] = ZDvVjWn[utWsK9z3rj2q] - 'a' + 'A';
            utWsK9z3rj2q = utWsK9z3rj2q + (278 - 277);
        }
    }
    for (nnsjQq = (546 - 546); nnsjQq < Qa9xkMU4rg2;) {
        lawRBDc = (847 - 846);
        {
            Um8cdYiIL = nnsjQq + (233 - 232);
            for (; Qa9xkMU4rg2 > Um8cdYiIL;) {
                if (ZDvVjWn[nnsjQq] == ZDvVjWn[Um8cdYiIL])
                    lawRBDc = lawRBDc + (740 - 739);
                else {
                    printf ("(%c,%d)", ZDvVjWn[nnsjQq], lawRBDc);
                    nnsjQq = Um8cdYiIL;
                    break;
                }
                Um8cdYiIL = Um8cdYiIL +(198 - 197);
            }
        }
        nnsjQq = Um8cdYiIL;
    }
    printf ("(%c,%d)", ZDvVjWn[nnsjQq - (511 - 510)], lawRBDc);
    return (765 - 765);
}

