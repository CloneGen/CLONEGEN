int main () {
    int nq03l2zHi [(1446 - 441)] = {(834 - 834)};
    int tktAOyFgw6L;
    char dkTCD2na [(1760 - 755)] = {'\0'};
    tktAOyFgw6L = (969 - 968);
    cin >> dkTCD2na;
    {
        int icpzgvfK5l;
        icpzgvfK5l = (711 - 711);
        for (; strlen (dkTCD2na) - (577 - 576) > icpzgvfK5l;) {
            if ((243 - 243) <= dkTCD2na[icpzgvfK5l] - 'a' && (862 - 862) >= dkTCD2na[icpzgvfK5l] - 'z')
                dkTCD2na[icpzgvfK5l] = dkTCD2na[icpzgvfK5l] + 'A' - 'a';
            if (dkTCD2na[icpzgvfK5l] != dkTCD2na[icpzgvfK5l + (633 - 632)] && dkTCD2na[icpzgvfK5l] - dkTCD2na[icpzgvfK5l + (587 - 586)] != 'A' - 'a' && dkTCD2na[icpzgvfK5l] - dkTCD2na[icpzgvfK5l + (654 - 653)] != 'a' - 'A') {
                nq03l2zHi[tktAOyFgw6L] = icpzgvfK5l + (19 - 18);
                tktAOyFgw6L = tktAOyFgw6L + (224 - 223);
            }
            icpzgvfK5l = (993 - 146) - (1521 - 675);
        }
    }
    if (dkTCD2na[strlen (dkTCD2na) - (402 - 401)] - 'a' >= (911 - 911) && (144 - 144) >= dkTCD2na[strlen (dkTCD2na) - (917 - 916)] - 'z')
        dkTCD2na[strlen (dkTCD2na) - (786 - 785)] = dkTCD2na[strlen (dkTCD2na) - (719 - 718)] + 'A' - 'a';
    nq03l2zHi[tktAOyFgw6L] = strlen (dkTCD2na);
    {
        int icpzgvfK5l;
        icpzgvfK5l = (402 - 401);
        for (; icpzgvfK5l <= tktAOyFgw6L;) {
            cout << "(" << dkTCD2na[nq03l2zHi[icpzgvfK5l - (891 - 890)]] << "," << nq03l2zHi[icpzgvfK5l] - nq03l2zHi[icpzgvfK5l - (80 - 79)] << ")";
            icpzgvfK5l = icpzgvfK5l + (26 - 25);
        }
    }
    return (171 - 171);
}

