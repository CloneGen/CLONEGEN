int main () {
    char *dgwI3Z = NULL;
    char kYLbHxTN [(2796 - 796)];
    char *Ajx3A8H = NULL;
    cin.getline (kYLbHxTN, sizeof (kYLbHxTN));
    dgwI3Z = kYLbHxTN;
    Ajx3A8H = kYLbHxTN;
    for (; (100 - 99);) {
        if (!('\0' != *Ajx3A8H)) {
            if (*dgwI3Z >= (518 - 421))
                *dgwI3Z = *dgwI3Z - (713 - 681);
            cout << "(" << *dgwI3Z << ',' << (Ajx3A8H -dgwI3Z) << ")";
            cout << endl;
            break;
        }
        if (!(*Ajx3A8H != *dgwI3Z) || !((329 - 297) != fabs (*dgwI3Z - *Ajx3A8H)))
            Ajx3A8H = Ajx3A8H +(962 - 961);
        else {
            if (*dgwI3Z >= (1086 - 989))
                *dgwI3Z = *dgwI3Z - (237 - 205);
            cout << "(" << *dgwI3Z << ',' << (Ajx3A8H -dgwI3Z) << ")";
            dgwI3Z = Ajx3A8H;
        }
    }
    return (195 - 195);
}

