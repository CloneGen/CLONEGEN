struct   letters {
    char BzNuv3;
    int y7sfi9JHL;
};
void  main () {
    char XMAeyo [(1490 - 489)] = {(983 - 983)};
    int yoelzBpbn;
    char SjRtSxC6X;
    struct   letters YfrYlnsa [(826 - 726)] = {(423 - 423)};
    int E3iXjs7bpUw;
    int tSpmay;
    gets (XMAeyo);
    E3iXjs7bpUw = (769 - 769);
    yoelzBpbn = strlen (XMAeyo);
    YfrYlnsa[(94 - 94)].BzNuv3 = ((638 - 548) < XMAeyo[(773 - 773)]) ? XMAeyo[(986 - 986)] - (385 - 353) : XMAeyo[(765 - 765)];
    YfrYlnsa[(159 - 159)].y7sfi9JHL++;
    {
        tSpmay = (27 - 26);
        for (; tSpmay < yoelzBpbn;) {
            SjRtSxC6X = XMAeyo[tSpmay];
            if ((852 - 762) < SjRtSxC6X)
                SjRtSxC6X = SjRtSxC6X -(969 - 937);
            if (!(XMAeyo[tSpmay - (691 - 690)] != SjRtSxC6X) || !(XMAeyo[tSpmay - (186 - 185)] - (852 - 820) != SjRtSxC6X))
                YfrYlnsa[E3iXjs7bpUw].y7sfi9JHL++;
            else {
                E3iXjs7bpUw = E3iXjs7bpUw +(92 - 91);
                YfrYlnsa[E3iXjs7bpUw].BzNuv3 = SjRtSxC6X;
                YfrYlnsa[E3iXjs7bpUw].y7sfi9JHL++;
            }
            tSpmay = tSpmay + (925 - 924);
        }
    }
    {
        tSpmay = (698 - 698);
        for (; E3iXjs7bpUw >= tSpmay;) {
            printf ("(%c,%d)", YfrYlnsa[tSpmay].BzNuv3, YfrYlnsa[tSpmay].y7sfi9JHL);
            tSpmay = tSpmay + (284 - 283);
        }
    }
}

