int main () {
    int IhUYMDL, yJWSuV9L = (298 - 297);
    char Imipdb [(1829 - 828)] = {'\0'};
    gets (Imipdb);
    {
        IhUYMDL = (511 - 511);
        for (; IhUYMDL <= (1327 - 327);) {
            if (!('\0' != Imipdb[IhUYMDL])) {
                {
                    if ((618 - 618)) {
                        return (809 - 809);
                    }
                }
                break;
            }
            if (Imipdb[IhUYMDL] != '\0') {
                if ((961 - 864) <= Imipdb[IhUYMDL] && Imipdb[IhUYMDL] <= (274 - 152)) {
                    Imipdb[IhUYMDL] = Imipdb[IhUYMDL] - (60 - 28);
                }
                if ((653 - 556) <= Imipdb[IhUYMDL +(526 - 525)] && Imipdb[IhUYMDL +(368 - 367)] <= (1059 - 937)) {
                    Imipdb[IhUYMDL +(580 - 579)] = Imipdb[IhUYMDL +(399 - 398)] - (148 - 116);
                }
                if (Imipdb[IhUYMDL] == Imipdb[IhUYMDL +(292 - 291)]) {
                    yJWSuV9L = yJWSuV9L + (936 - 935);
                }
                if (Imipdb[IhUYMDL] != Imipdb[IhUYMDL +(538 - 537)]) {
                    printf ("(%c,%d)", Imipdb[IhUYMDL], yJWSuV9L);
                    yJWSuV9L = (444 - 443);
                }
            }
            IhUYMDL = IhUYMDL +1;
        }
    }
}

