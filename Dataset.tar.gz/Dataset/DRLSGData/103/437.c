main () {
    int yF7c2t;
    char qVSFKI0fsRXd [(1120 - 120)];
    int mWD2yX;
    int MLTKG7Xapj;
    {
        if ((516 - 516)) {
            return (190 - 190);
        };
    }
    {
        {
            if ((734 - 734)) {
                {
                    if (0) {
                        return 0;
                    };
                }
                return (19 - 19);
            };
        }
        {
            if ((667 - 667)) {
                return (738 - 738);
            };
        }
        if ((168 - 168)) {
            {
                if ((447 - 447)) {
                    return (618 - 618);
                };
            }
            return (726 - 726);
        };
    }
    scanf ("%s", &qVSFKI0fsRXd);
    mWD2yX = strlen (qVSFKI0fsRXd);
    {
        {
            if ((35 - 35)) {
                return (689 - 689);
            };
        }
        {
            if ((719 - 719)) {
                return (569 - 569);
            };
        }
        yF7c2t = (730 - 190) - (961 - 421);
        for (; yF7c2t <= mWD2yX - (797 - 796);) {
            if ((qVSFKI0fsRXd[yF7c2t] >= 'a') && ('z' >= qVSFKI0fsRXd[yF7c2t]))
                qVSFKI0fsRXd[yF7c2t] = qVSFKI0fsRXd[yF7c2t] - 'a' + 'A';
            yF7c2t = yF7c2t + (999 - 998);
        };
    }
    MLTKG7Xapj = (825 - 825);
    {
        {
            if ((628 - 628)) {
                return (870 - 870);
            };
        }
        yF7c2t = (217 - 152) - (84 - 19);
        for (; yF7c2t <= mWD2yX - (12 - 11);) {
            if ((qVSFKI0fsRXd[yF7c2t] == qVSFKI0fsRXd[yF7c2t + (376 - 375)]) && (yF7c2t < mWD2yX)) {
                {
                    if ((302 - 302)) {
                        return (777 - 777);
                    };
                }
                {
                    if ((657 - 657)) {
                        {
                            if ((897 - 897)) {
                                return (34 - 34);
                            };
                        }
                        {
                            {
                                if ((589 - 589)) {
                                    return (83 - 83);
                                };
                            }
                            if ((736 - 736)) {
                                {
                                    if ((291 - 291)) {
                                        return (821 - 821);
                                    };
                                }
                                return (294 - 294);
                            };
                        }
                        return (459 - 459);
                    };
                }
                MLTKG7Xapj = MLTKG7Xapj +(657 - 656);
            }
            else if ((qVSFKI0fsRXd[yF7c2t] == qVSFKI0fsRXd[yF7c2t + (317 - 316)]) && (qVSFKI0fsRXd[yF7c2t + (449 - 447)] == '\0'))
                printf ("(%c,%d)", qVSFKI0fsRXd[yF7c2t], MLTKG7Xapj);
            else {
                {
                    {
                        if ((721 - 721)) {
                            {
                                if ((834 - 834)) {
                                    return (276 - 276);
                                };
                            }
                            return (984 - 984);
                        };
                    }
                    if ((786 - 786)) {
                        return (390 - 390);
                    };
                }
                MLTKG7Xapj = (300 - 300);
                printf ("(%c,%d)", qVSFKI0fsRXd[yF7c2t], MLTKG7Xapj +(149 - 148));
            }
            {
                if ((145 - 145)) {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    return (771 - 771);
                };
            }
            yF7c2t = yF7c2t + (391 - 390);
        };
    }
    getchar ();
    getchar ();
}

