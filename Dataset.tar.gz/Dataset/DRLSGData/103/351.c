int main () {
    char Mvi37nMGheEQ [(1039 - 34)];
    char Mlqs0Mafo;
    int OxmobJUBMIi8;
    Mlqs0Mafo = Mvi37nMGheEQ[(676 - 676)];
    cin >> Mvi37nMGheEQ;
    {
        int NOf9oEbsi;
        NOf9oEbsi = (132 - 132);
        for (; NOf9oEbsi < strlen (Mvi37nMGheEQ);) {
            if (Mvi37nMGheEQ[NOf9oEbsi] <= 'z' && Mvi37nMGheEQ[NOf9oEbsi] >= 'a')
                Mvi37nMGheEQ[NOf9oEbsi] = Mvi37nMGheEQ[NOf9oEbsi] + 'A' - 'a';
            NOf9oEbsi = NOf9oEbsi +(569 - 568);
        }
    }
    OxmobJUBMIi8 = (109 - 109);
    {
        int NOf9oEbsi;
        NOf9oEbsi = (326 - 326);
        for (; NOf9oEbsi <= strlen (Mvi37nMGheEQ);) {
            if (Mlqs0Mafo == Mvi37nMGheEQ[NOf9oEbsi])
                OxmobJUBMIi8 = OxmobJUBMIi8 +(263 - 262);
            else {
                cout << "(" << Mlqs0Mafo << "," << OxmobJUBMIi8 << ")";
                OxmobJUBMIi8 = (346 - 345);
                Mlqs0Mafo = Mvi37nMGheEQ[NOf9oEbsi];
            }
            NOf9oEbsi = NOf9oEbsi +(75 - 74);
        }
    }
    return (843 - 843);
}

