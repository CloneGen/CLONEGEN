main () {
    int JELuklY8Xb;
    char eWOcE9Je [(1191 - 192)];
    int sEYsSi;
    int XuSDma5;
    char Of1rDHqCTP [(1271 - 272)];
    int SadWlHJPyr;
    scanf ("%s", eWOcE9Je);
    SadWlHJPyr = strlen (eWOcE9Je);
    {
        XuSDma5 = (148 - 148);
        for (; XuSDma5 <= SadWlHJPyr -(498 - 497);) {
            {
                if ((462 - 462)) {
                    return (670 - 670);
                }
            }
            if (eWOcE9Je[XuSDma5] >= 'a' && eWOcE9Je[XuSDma5] <= 'z')
                Of1rDHqCTP[XuSDma5] = eWOcE9Je[XuSDma5] - 'a' + 'A';
            else
                Of1rDHqCTP[XuSDma5] = eWOcE9Je[XuSDma5];
            XuSDma5 = XuSDma5 +(906 - 905);
        }
    }
    JELuklY8Xb = (195 - 194);
    {
        sEYsSi = (727 - 727);
        for (; sEYsSi <= SadWlHJPyr -(69 - 68);) {
            if (Of1rDHqCTP[sEYsSi] == Of1rDHqCTP[sEYsSi + (127 - 126)])
                JELuklY8Xb = JELuklY8Xb +(555 - 554);
            else {
                printf ("(%c,%d)", Of1rDHqCTP[sEYsSi], JELuklY8Xb);
                JELuklY8Xb = (204 - 203);
            }
            sEYsSi = sEYsSi + (68 - 67);
        }
    }
}

