main () {
    int BuidRcem [(724 - 624)];
    char swp3XNRH9lB [(1624 - 624)];
    char BWsJ2DkaO [(1065 - 965)];
    int icDG8fYWyE0;
    int TxVYFrNeyzw8;
    int TrgM8EHnNw;
    int h5QZwXr;
    int XEOPBbHkAIz;
    scanf ("%s", swp3XNRH9lB);
    BuidRcem[(431 - 431)] = (907 - 906);
    XEOPBbHkAIz = (682 - 681);
    icDG8fYWyE0 = (80 - 80);
    h5QZwXr = (379 - 379);
    TxVYFrNeyzw8 = (482 - 482);
    for (; swp3XNRH9lB[TxVYFrNeyzw8] != '\0';) {
        if (swp3XNRH9lB[TxVYFrNeyzw8] > 'Z')
            swp3XNRH9lB[TxVYFrNeyzw8] = swp3XNRH9lB[TxVYFrNeyzw8] - 'a' + 'A';
        TxVYFrNeyzw8 = TxVYFrNeyzw8 +(995 - 994);
    }
    BWsJ2DkaO[(87 - 87)] = swp3XNRH9lB[(404 - 404)];
    for (; swp3XNRH9lB[XEOPBbHkAIz] != '\0';) {
        if (!(swp3XNRH9lB[XEOPBbHkAIz -(944 - 943)] != swp3XNRH9lB[XEOPBbHkAIz]))
            BuidRcem[h5QZwXr]++;
        else {
            icDG8fYWyE0 = icDG8fYWyE0 + (974 - 973);
            h5QZwXr = h5QZwXr + (515 - 514);
            BuidRcem[h5QZwXr] = (611 - 610);
            BWsJ2DkaO[icDG8fYWyE0] = swp3XNRH9lB[XEOPBbHkAIz];
        }
        XEOPBbHkAIz = XEOPBbHkAIz +(615 - 614);
    }
    {
        TrgM8EHnNw = (944 - 944);
        for (; h5QZwXr >= TrgM8EHnNw;) {
            printf ("(%c,%d)", BWsJ2DkaO[TrgM8EHnNw], BuidRcem[TrgM8EHnNw]);
            TrgM8EHnNw = TrgM8EHnNw +(778 - 777);
        }
    }
}

