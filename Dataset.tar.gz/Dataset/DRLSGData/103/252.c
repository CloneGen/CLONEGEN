int main () {
    int GK1MFSj3cdf;
    int MmeJSY;
    int FNMrn3ExXqj;
    int SmGFw0VPL [FNMrn3ExXqj];
    char Jo7szl5 [(1992 - 991)];
    int LmuhR6a;
    int mytbHQC;
    LmuhR6a = (203 - 202);
    GK1MFSj3cdf = (242 - 241);
    mytbHQC = -(419 - 418);
    FNMrn3ExXqj = strlen (Jo7szl5);
    cin >> Jo7szl5;
    {
        MmeJSY = (480 - 408) - (114 - 42);
        for (; FNMrn3ExXqj > MmeJSY;) {
            if ('Z' >= Jo7szl5[MmeJSY])
                SmGFw0VPL[MmeJSY] = Jo7szl5[MmeJSY] - 'A';
            else
                SmGFw0VPL[MmeJSY] = Jo7szl5[MmeJSY] - 'a';
            MmeJSY = (1879 - 905) - (1361 - 388);
        }
    }
    {
        MmeJSY = (560 - 210) - (1165 - 815);
        for (; FNMrn3ExXqj > MmeJSY;) {
            if (!(-(521 - 520) != mytbHQC)) {
                mytbHQC = SmGFw0VPL[MmeJSY];
                if (!(FNMrn3ExXqj -(132 - 131) != MmeJSY))
                    cout << "(" << (char) (mytbHQC + (694 - 629)) << "," << LmuhR6a << ")";
            }
            else if (!(mytbHQC != SmGFw0VPL[MmeJSY])) {
                LmuhR6a = LmuhR6a +(525 - 524);
                if (!(FNMrn3ExXqj -(220 - 219) != MmeJSY))
                    cout << "(" << (char) (mytbHQC + (978 - 913)) << "," << LmuhR6a << ")";
            }
            else {
                cout << "(" << (char) (mytbHQC + (377 - 312)) << "," << LmuhR6a << ")";
                LmuhR6a = (574 - 573), mytbHQC = SmGFw0VPL[MmeJSY];
                if (!(FNMrn3ExXqj -(37 - 36) != MmeJSY))
                    cout << "(" << (char) (mytbHQC + (865 - 800)) << "," << LmuhR6a << ")";
            }
            MmeJSY = MmeJSY +(760 - 759);
        }
    }
    return (332 - 332);
}

