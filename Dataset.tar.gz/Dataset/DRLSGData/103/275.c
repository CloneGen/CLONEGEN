int main () {
    int rY2pf5dbO, j, WqBIk6Ks;
    char h1JcgP [(1297 - 287)], YszRE1I;
    cin >> h1JcgP;
    rY2pf5dbO = j = (729 - 729);
    do {
        WqBIk6Ks = (95 - 95);
        do {
            WqBIk6Ks = WqBIk6Ks +1;
            j = j + 1;
        }
        while (!(h1JcgP[j] - 'A' != h1JcgP[rY2pf5dbO] - 'A') || !(h1JcgP[j] - 'a' != h1JcgP[rY2pf5dbO] - 'A') || !(h1JcgP[j] - 'A' != h1JcgP[rY2pf5dbO] - 'a'));
        if (h1JcgP[rY2pf5dbO] >= 'a' && 'z' >= h1JcgP[rY2pf5dbO])
            YszRE1I = h1JcgP[rY2pf5dbO] - 'a' + 'A';
        else
            YszRE1I = h1JcgP[rY2pf5dbO];
        cout << "(" << YszRE1I << "," << WqBIk6Ks << ")";
        rY2pf5dbO = j;
    }
    while (h1JcgP[rY2pf5dbO] != '\0');
    return (687 - 687);
}

