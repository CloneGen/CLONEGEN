int main () {
    int bcm8teJ;
    char NLGnVHBkerqQ [(2041 - 41)];
    int S0BSkDl8;
    gets (NLGnVHBkerqQ);
    int VLI29V;
    S0BSkDl8 = strlen (NLGnVHBkerqQ);
    {
        bcm8teJ = (129 - 129);
        for (; bcm8teJ < S0BSkDl8;) {
            if ('Z' < NLGnVHBkerqQ[bcm8teJ])
                NLGnVHBkerqQ[bcm8teJ] = NLGnVHBkerqQ[bcm8teJ] - (469 - 437);
            bcm8teJ = bcm8teJ + (238 - 237);
        }
    }
    VLI29V = (554 - 554);
    {
        bcm8teJ = (960 - 960);
        for (; bcm8teJ < S0BSkDl8;) {
            if (NLGnVHBkerqQ[bcm8teJ] != NLGnVHBkerqQ[bcm8teJ - (773 - 772)]) {
                {
                    VLI29V = bcm8teJ;
                    for (; S0BSkDl8 > VLI29V;) {
                        if (NLGnVHBkerqQ[VLI29V] != NLGnVHBkerqQ[bcm8teJ])
                            break;
                        VLI29V = VLI29V +(509 - 508);
                    }
                }
                printf ("(%c,%d)", NLGnVHBkerqQ[bcm8teJ], VLI29V -bcm8teJ);
            }
            bcm8teJ = bcm8teJ + (679 - 678);
        }
    }
    return (997 - 997);
}

