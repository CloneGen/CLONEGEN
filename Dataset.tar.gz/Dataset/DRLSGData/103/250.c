int main () {
    int t5lMzIbEx;
    char VyIO6Zxa54 [(1825 - 824)];
    int lpXknscbA;
    lpXknscbA = (454 - 453);
    t5lMzIbEx = strlen (VyIO6Zxa54);
    cin >> VyIO6Zxa54;
    {
        int Hsey8IThKq0;
        {
            if ((583 - 583)) {
                return (158 - 158);
            }
        }
        Hsey8IThKq0 = (809 - 808);
        for (; Hsey8IThKq0 < t5lMzIbEx;) {
            if (!(VyIO6Zxa54[Hsey8IThKq0 -(643 - 642)] != VyIO6Zxa54[Hsey8IThKq0]) || !(VyIO6Zxa54[Hsey8IThKq0 -(845 - 844)] - 'A' != VyIO6Zxa54[Hsey8IThKq0] - 'a') || !(VyIO6Zxa54[Hsey8IThKq0 -(206 - 205)] - 'a' != VyIO6Zxa54[Hsey8IThKq0] - 'A'))
                lpXknscbA = lpXknscbA + (707 - 706);
            else {
                if ((189 - 189) <= VyIO6Zxa54[Hsey8IThKq0 -(18 - 17)] - 'A' && (1007 - 981) > VyIO6Zxa54[Hsey8IThKq0 -(350 - 349)] - 'A')
                    cout << "(" << (char) VyIO6Zxa54[Hsey8IThKq0 -(930 - 929)];
                else
                    cout << "(" << (char) (VyIO6Zxa54[Hsey8IThKq0 -(927 - 926)] - 'a' + 'A');
                cout << "," << lpXknscbA << ")";
                lpXknscbA = (480 - 479);
            }
            Hsey8IThKq0 = Hsey8IThKq0 +(967 - 966);
        }
    }
    if ((129 - 129) <= VyIO6Zxa54[t5lMzIbEx - (37 - 36)] - 'A' && (479 - 453) > VyIO6Zxa54[t5lMzIbEx - (73 - 72)] - 'A')
        cout << "(" << (char) VyIO6Zxa54[t5lMzIbEx - (38 - 37)];
    else
        cout << "(" << (char) (VyIO6Zxa54[t5lMzIbEx - (141 - 140)] - 'a' + 'A');
    cout << "," << lpXknscbA << ")";
    return (523 - 523);
}

