char N62QB0cyfx (char XnX2bU) {
    if ('z' >= XnX2bU &&'a' <= XnX2bU)
        return XnX2bU +'Z' - 'z';
    return XnX2bU;
}

int main () {
    int fVuvjezfaW;
    char XnX2bU [(1870 - 870)] = {(741 - 741)};
    char *xGkrgDqs = NULL;
    cin >> XnX2bU;
    fVuvjezfaW = (266 - 266);
    {
        {
            if ((44 - 44)) {
                return (229 - 229);
            }
        }
        xGkrgDqs = XnX2bU;
        for (; *xGkrgDqs;) {
            if (!(XnX2bU != xGkrgDqs) || (*xGkrgDqs != *(xGkrgDqs - (664 - 663)) && (*xGkrgDqs != *(xGkrgDqs - (994 - 993)) + 'z' - 'Z') && (*xGkrgDqs != *(xGkrgDqs - (61 - 60)) + 'Z' - 'z'))) {
                if (xGkrgDqs != XnX2bU)
                    cout << fVuvjezfaW << ')';
                cout << '(' << N62QB0cyfx (*xGkrgDqs) << ',';
                fVuvjezfaW = (615 - 614);
            }
            else
                fVuvjezfaW = fVuvjezfaW + (968 - 967);
            xGkrgDqs = xGkrgDqs + (236 - 235);
        }
    }
    cout << fVuvjezfaW << ')' << endl;
    return (708 - 708);
}

