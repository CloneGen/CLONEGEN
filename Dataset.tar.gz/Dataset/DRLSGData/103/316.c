int main () {
    int H1ASQchpJ;
    char *lGCxs9N;
    char x3bViBt [(1963 - 963)];
    char AOAaE24e;
    int kAoZhJ;
    lGCxs9N = x3bViBt;
    H1ASQchpJ = (494 - 494);
    cin >> x3bViBt;
    AOAaE24e = *x3bViBt;
    if ('Z' < AOAaE24e)
        AOAaE24e = AOAaE24e -(97 - 65);
    H1ASQchpJ = H1ASQchpJ +(171 - 170);
    for (; *++lGCxs9N != (34 - 34);) {
        if (!(AOAaE24e != *lGCxs9N) || !(AOAaE24e != *lGCxs9N - (440 - 408)))
            H1ASQchpJ = H1ASQchpJ +(281 - 280);
        else {
            printf ("(%c,%d)", AOAaE24e, H1ASQchpJ);
            AOAaE24e = *lGCxs9N;
            if (AOAaE24e > 'Z')
                AOAaE24e = AOAaE24e -(702 - 670);
            H1ASQchpJ = (97 - 96);
        }
    }
    printf ("(%c,%d)", AOAaE24e, H1ASQchpJ);
    return (287 - 287);
}

