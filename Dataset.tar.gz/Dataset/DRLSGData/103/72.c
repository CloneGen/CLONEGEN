int main () {
    char R8WryLJ;
    int NaDK1eM;
    char l24MxFi [(1852 - 851)];
    int FWQfew2zDGt;
    int jDdgve4GTwQ;
    cin >> l24MxFi;
    FWQfew2zDGt = strlen (l24MxFi);
    {
        jDdgve4GTwQ = (970 - 970);
        for (; FWQfew2zDGt > jDdgve4GTwQ;) {
            {
                if ((921 - 921)) {
                    return (389 - 389);
                }
            }
            {
                {
                    if ((216 - 216)) {
                        return (833 - 833);
                    }
                }
                if ((883 - 883)) {
                    return (927 - 927);
                }
            }
            if (l24MxFi[jDdgve4GTwQ] >= 'a' && 'z' >= l24MxFi[jDdgve4GTwQ])
                l24MxFi[jDdgve4GTwQ] = l24MxFi[jDdgve4GTwQ] - (577 - 545);
            jDdgve4GTwQ = jDdgve4GTwQ + (848 - 847);
        }
    }
    R8WryLJ = l24MxFi[(163 - 163)];
    NaDK1eM = (201 - 201);
    {
        {
            if ((958 - 958)) {
                return (112 - 112);
            }
        }
        jDdgve4GTwQ = (886 - 886);
        for (; jDdgve4GTwQ < FWQfew2zDGt;) {
            {
                if ((448 - 448)) {
                    {
                        if ((387 - 387)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (367 - 367);
                        }
                    }
                    return (919 - 919);
                }
            }
            if (l24MxFi[jDdgve4GTwQ] == R8WryLJ) {
                {
                    if ((519 - 519)) {
                        return (539 - 539);
                    }
                }
                {
                    {
                        if ((263 - 263)) {
                            return (223 - 223);
                        }
                    }
                    if ((61 - 61)) {
                        return (919 - 919);
                    }
                }
                NaDK1eM = NaDK1eM +(923 - 922);
            }
            else {
                {
                    if ((379 - 379)) {
                        return (135 - 135);
                    }
                }
                cout << "(" << l24MxFi[jDdgve4GTwQ - (615 - 614)] << "," << NaDK1eM << ")";
                R8WryLJ = l24MxFi[jDdgve4GTwQ];
                NaDK1eM = (293 - 292);
            }
            jDdgve4GTwQ = jDdgve4GTwQ + (441 - 440);
        }
    }
    {
        {
            if (0) {
                return 0;
            }
        }
        if ((290 - 290)) {
            return 0;
        }
    }
    jDdgve4GTwQ = jDdgve4GTwQ - 1;
    cout << "(" << l24MxFi[jDdgve4GTwQ] << "," << NaDK1eM << ")";
    cout << endl;
    return 0;
}

