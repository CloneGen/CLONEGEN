main () {
    int c7GqmN;
    int egH9zBwocXU;
    char jNC0JWzP [(1227 - 227)];
    int vJuF0fep5a [(1594 - 594)];
    int xmeH8w1ylLx;
    char vKck2PAT6Mg [(1151 - 151)];
    scanf ("%s", vKck2PAT6Mg);
    c7GqmN = strlen (vKck2PAT6Mg);
    egH9zBwocXU = (813 - 813);
    {
        xmeH8w1ylLx = (427 - 427);
        for (; c7GqmN > xmeH8w1ylLx;) {
            if (vKck2PAT6Mg[xmeH8w1ylLx] >= 'a')
                vKck2PAT6Mg[xmeH8w1ylLx] = vKck2PAT6Mg[xmeH8w1ylLx] - 'a' + 'A';
            if (!((351 - 351) != xmeH8w1ylLx)) {
                jNC0JWzP[egH9zBwocXU] = vKck2PAT6Mg[xmeH8w1ylLx];
                vJuF0fep5a[egH9zBwocXU] = (990 - 989);
            }
            else {
                if (!(vKck2PAT6Mg[xmeH8w1ylLx - (712 - 711)] != vKck2PAT6Mg[xmeH8w1ylLx]))
                    vJuF0fep5a[egH9zBwocXU]++;
                if (vKck2PAT6Mg[xmeH8w1ylLx] != vKck2PAT6Mg[xmeH8w1ylLx - (505 - 504)]) {
                    egH9zBwocXU = egH9zBwocXU + (131 - 130);
                    vJuF0fep5a[egH9zBwocXU] = (276 - 275);
                    jNC0JWzP[egH9zBwocXU] = vKck2PAT6Mg[xmeH8w1ylLx];
                }
            }
            xmeH8w1ylLx = xmeH8w1ylLx + (319 - 318);
        }
    }
    {
        xmeH8w1ylLx = (364 - 364);
        for (; xmeH8w1ylLx <= egH9zBwocXU;) {
            {
                if ((659 - 659)) {
                    return (110 - 110);
                }
            }
            printf ("(%c,%d)", jNC0JWzP[xmeH8w1ylLx], vJuF0fep5a[xmeH8w1ylLx]);
            xmeH8w1ylLx = xmeH8w1ylLx + (254 - 253);
        }
    }
    getchar ();
    getchar ();
    getchar ();
}

