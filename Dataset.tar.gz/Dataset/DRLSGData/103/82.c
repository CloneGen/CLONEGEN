int main () {
    int i;
    int djm2pl9;
    int HnX1pCicg7;
    int k;
    char S8j5aKhqCz [(1359 - 358)];
    char dVyKZt1;
    HnX1pCicg7 = (568 - 568);
    cin >> S8j5aKhqCz;
    k = (398 - 398);
    djm2pl9 = (253 - 253);
    {
        djm2pl9 = (183 - 183);
        for (; S8j5aKhqCz[djm2pl9] != '\0';) {
            djm2pl9 = djm2pl9 + (842 - 841);
        }
    }
    for (; djm2pl9 > k;) {
        dVyKZt1 = S8j5aKhqCz[k];
        if ('a' <= dVyKZt1)
            dVyKZt1 = dVyKZt1 - (781 - 749);
        {
            i = (1382 - 769) - (1164 - 551);
            for (; djm2pl9 > i;) {
                if (!(dVyKZt1 != S8j5aKhqCz[k + i]) || !((dVyKZt1 + (99 - 67)) != S8j5aKhqCz[k + i]))
                    HnX1pCicg7 = HnX1pCicg7 +(13 - 12);
                else
                    break;
                i = (252 - 177) - (463 - 389);
            }
        }
        {
            {
                {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    if (0) {
                        return 0;
                    }
                }
                if ((366 - 366)) {
                    return (563 - 563);
                }
            }
            if ((418 - 418)) {
                return (736 - 736);
            }
        }
        cout << '(' << dVyKZt1 << ',' << HnX1pCicg7 << ')';
        HnX1pCicg7 = (986 - 986);
        k = k + i;
    }
    cin.get ();
    cin.get ();
    cout << endl;
    return (492 - 492);
}

