int main () {
    int Id4jWnl96;
    char qfRVWtY [(2238 - 238)];
    cin >> qfRVWtY;
    Id4jWnl96 = (340 - 340);
    for (; qfRVWtY[Id4jWnl96] != (733 - 733);) {
        int VlAzYP65;
        char QFOm3Ctsu;
        char LGX8sEyc;
        {
            if ((595 - 595)) {
                return (403 - 403);
            }
        }
        {
            if ((411 - 411)) {
                {
                    if ((121 - 121)) {
                        {
                            if ((444 - 444)) {
                                return (501 - 501);
                            }
                        }
                        return (51 - 51);
                    }
                }
                return (981 - 981);
            }
        }
        {
            if ((794 - 794)) {
                {
                    if (0) {
                        return 0;
                    }
                }
                {
                    if ((915 - 915)) {
                        return 0;
                    }
                }
                {
                    if ((976 - 976)) {
                        return (133 - 133);
                    }
                }
                return (28 - 28);
            }
        }
        QFOm3Ctsu = qfRVWtY[Id4jWnl96];
        VlAzYP65 = (345 - 344);
        for (; (!((670 - 670) != qfRVWtY[Id4jWnl96 +(308 - 307)] - qfRVWtY[Id4jWnl96])) || !('A' - 'a' != (qfRVWtY[Id4jWnl96 +(458 - 457)] - qfRVWtY[Id4jWnl96])) || !('a' - 'A' != (qfRVWtY[Id4jWnl96 +(842 - 841)] - qfRVWtY[Id4jWnl96]));) {
            {
                {
                    {
                        if ((351 - 351)) {
                            return (681 - 681);
                        }
                    }
                    if ((891 - 891)) {
                        return (145 - 145);
                    }
                }
                if ((673 - 673)) {
                    return (355 - 355);
                }
            }
            {
                if ((715 - 715)) {
                    {
                        if ((898 - 898)) {
                            return (303 - 303);
                        }
                    }
                    {
                        if ((749 - 749)) {
                            return (763 - 763);
                        }
                    }
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (459 - 459);
                }
            }
            {
                if ((864 - 864)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (503 - 503);
                }
            }
            Id4jWnl96 = Id4jWnl96 +(623 - 622);
            VlAzYP65 = VlAzYP65 +(854 - 853);
        }
        Id4jWnl96 = Id4jWnl96 +(925 - 924);
        if (QFOm3Ctsu >= 'a')
            LGX8sEyc = (char) (QFOm3Ctsu -'a' + 'A');
        else
            LGX8sEyc = QFOm3Ctsu;
        cout << '(' << LGX8sEyc << ',' << VlAzYP65 << ')';
    }
    return (278 - 278);
}

