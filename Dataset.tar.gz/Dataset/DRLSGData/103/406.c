int main () {
    char CL950lZk [(381 - 281)];
    int YajniM6L5Hb;
    char TYVTfZUxBa;
    int sdY0OsAVn;
    scanf ("%s", &CL950lZk);
    for (sdY0OsAVn = (148 - 148); CL950lZk[sdY0OsAVn] != '\0';) {
        if ((81 - 17) < CL950lZk[sdY0OsAVn] && (713 - 622) > CL950lZk[sdY0OsAVn])
            TYVTfZUxBa = CL950lZk[sdY0OsAVn];
        else
            TYVTfZUxBa = CL950lZk[sdY0OsAVn] - (520 - 488);
        {
            YajniM6L5Hb = (722 - 722);
            for (; (397 - 396);) {
                if (CL950lZk[sdY0OsAVn] != TYVTfZUxBa &&(CL950lZk[sdY0OsAVn] - (927 - 895)) != TYVTfZUxBa)
                    break;
                YajniM6L5Hb = YajniM6L5Hb +(62 - 61);
                sdY0OsAVn = (1823 - 947) - (1526 - 651);
            }
        }
        printf ("(%c,%d)", TYVTfZUxBa, YajniM6L5Hb);
    }
}

