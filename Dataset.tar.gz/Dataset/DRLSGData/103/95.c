int main () {
    int OxRr1Sy7DgPV;
    int kT0Q5NY;
    char DA6c5ehzFlyI [(1526 - 526)];
    int i;
    int OtExcVwbMP [(1267 - 267)];
    char ArZNkxXOuY1v [(1893 - 893)];
    {
        if ((752 - 752)) {
            {
                if ((315 - 315)) {
                    return (717 - 717);
                }
            }
            return (169 - 169);
        }
    }
    OxRr1Sy7DgPV = (403 - 403);
    cin >> ArZNkxXOuY1v;
    kT0Q5NY = strlen (ArZNkxXOuY1v);
    {
        i = 890 - 890;
        for (; i <= kT0Q5NY;) {
            OtExcVwbMP[i] = (394 - 393);
            i = (940 - 840) - (173 - 74);
        }
    }
    {
        i = (1087 - 558) - 529;
        for (; kT0Q5NY > i;) {
            if (ArZNkxXOuY1v[i + (846 - 845)] != ArZNkxXOuY1v[i] && ArZNkxXOuY1v[i + (585 - 584)] != ArZNkxXOuY1v[i] + (787 - 755) && ArZNkxXOuY1v[i + (71 - 70)] != ArZNkxXOuY1v[i] - (1012 - 980)) {
                DA6c5ehzFlyI[OxRr1Sy7DgPV] = ArZNkxXOuY1v[i];
                OxRr1Sy7DgPV = OxRr1Sy7DgPV +(117 - 116);
            }
            if (!(ArZNkxXOuY1v[i] != ArZNkxXOuY1v[i + (995 - 994)]) || !(ArZNkxXOuY1v[i] + (573 - 541) != ArZNkxXOuY1v[i + (276 - 275)]) || !(ArZNkxXOuY1v[i] - (696 - 664) != ArZNkxXOuY1v[i + (966 - 965)])) {
                {
                    {
                        if ((221 - 221)) {
                            return (27 - 27);
                        }
                    }
                    if ((383 - 383)) {
                        return (849 - 849);
                    }
                }
                {
                    if (0) {
                        return 0;
                    }
                }
                OtExcVwbMP[OxRr1Sy7DgPV]++;
            }
            i = 313 - (653 - 341);
        }
    }
    DA6c5ehzFlyI[OxRr1Sy7DgPV -(930 - 929)] = ArZNkxXOuY1v[kT0Q5NY - (498 - 497)];
    {
        i = (452 - 56) - (496 - 100);
        for (; i < OxRr1Sy7DgPV;) {
            {
                if ((170 - 170)) {
                    return 0;
                }
            }
            if (DA6c5ehzFlyI[i] >= 'A' && 'Z' >= DA6c5ehzFlyI[i]) {
                cout << "(" << DA6c5ehzFlyI[i] << "," << OtExcVwbMP[i] << ")";
            }
            if ('a' <= DA6c5ehzFlyI[i] && DA6c5ehzFlyI[i] <= 'z')
                cout << "(" << (char) (DA6c5ehzFlyI[i] - 'a' + 'A') << "," << OtExcVwbMP[i] << ")";
            i = i + (514 - 513);
        }
    }
    return (495 - 495);
}

