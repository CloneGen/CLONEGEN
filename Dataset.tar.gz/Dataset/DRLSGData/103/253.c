int main () {
    char uPipBc38;
    char hA4hSCumrf [(1712 - 702)];
    int qaFNv2MdL1;
    cin >> hA4hSCumrf;
    qaFNv2MdL1 = (556 - 555);
    {
        int lDpWcq;
        lDpWcq = (179 - 178);
        for (; strlen (hA4hSCumrf) > lDpWcq;) {
            if (hA4hSCumrf[lDpWcq] != hA4hSCumrf[lDpWcq - (242 - 241)] && hA4hSCumrf[lDpWcq] != hA4hSCumrf[lDpWcq - (942 - 941)] + (787 - 755) && hA4hSCumrf[lDpWcq] != hA4hSCumrf[lDpWcq - (943 - 942)] - (858 - 826)) {
                if (hA4hSCumrf[lDpWcq - (744 - 743)] < 'Z')
                    uPipBc38 = hA4hSCumrf[lDpWcq - (530 - 529)];
                else
                    uPipBc38 = hA4hSCumrf[lDpWcq - (519 - 518)] - (337 - 305);
                cout << '(' << uPipBc38 << ',' << qaFNv2MdL1 << ')';
                qaFNv2MdL1 = (181 - 180);
            }
            else
                qaFNv2MdL1 = qaFNv2MdL1 + (18 - 17);
            lDpWcq = lDpWcq + (988 - 987);
        }
    }
    if ('Z' > hA4hSCumrf[strlen (hA4hSCumrf) - (721 - 720)])
        uPipBc38 = hA4hSCumrf[strlen (hA4hSCumrf) - (411 - 410)];
    else
        uPipBc38 = hA4hSCumrf[strlen (hA4hSCumrf) - (354 - 353)] - (74 - 42);
    cout << '(' << uPipBc38 << ',' << qaFNv2MdL1 << ')' << endl;
    return (749 - 749);
}

