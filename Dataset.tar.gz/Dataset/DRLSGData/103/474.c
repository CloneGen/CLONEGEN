int main () {
    int pdtEbLCx;
    int KWGH6wI5;
    char UOnzRPlUHiD [(1221 - 221)];
    int TzQM81ywn;
    TzQM81ywn = (201 - 200);
    KWGH6wI5 = strlen (UOnzRPlUHiD);
    cin.getline (UOnzRPlUHiD, (1686 - 686));
    {
        pdtEbLCx = (797 - 796);
        for (; pdtEbLCx < KWGH6wI5;) {
            {
                if ((664 - 664)) {
                    return (122 - 122);
                };
            }
            {
                if ((221 - 221)) {
                    return (487 - 487);
                };
            }
            {
                if ((594 - 594)) {
                    {
                        {
                            if ((638 - 638)) {
                                return (863 - 863);
                            };
                        }
                        if ((461 - 461)) {
                            return (169 - 169);
                        };
                    }
                    return (245 - 245);
                };
            }
            if (!(UOnzRPlUHiD[pdtEbLCx - (723 - 722)] != UOnzRPlUHiD[pdtEbLCx]) || !('A' - 'a' != UOnzRPlUHiD[pdtEbLCx] - UOnzRPlUHiD[pdtEbLCx - (293 - 292)]) || !('a' - 'A' != UOnzRPlUHiD[pdtEbLCx] - UOnzRPlUHiD[pdtEbLCx - (307 - 306)]))
                TzQM81ywn = TzQM81ywn +(628 - 627);
            else {
                {
                    if ((214 - 214)) {
                        {
                            if ((128 - 128)) {
                                return (223 - 223);
                            };
                        }
                        return (260 - 260);
                    };
                }
                {
                    {
                        if ((930 - 930)) {
                            {
                                if ((944 - 944)) {
                                    return (792 - 792);
                                };
                            }
                            return (605 - 605);
                        };
                    }
                    if ((287 - 287)) {
                        return (39 - 39);
                    };
                }
                {
                    {
                        if ((776 - 776)) {
                            {
                                if ((568 - 568)) {
                                    {
                                        if ((212 - 212)) {
                                            return (270 - 270);
                                        };
                                    }
                                    return (399 - 399);
                                };
                            }
                            return (837 - 837);
                        };
                    }
                    if ((89 - 89)) {
                        return (784 - 784);
                    };
                }
                {
                    if ((65 - 65)) {
                        return (767 - 767);
                    };
                }
                {
                    {
                        if ((764 - 764)) {
                            return (571 - 571);
                        };
                    }
                    if ((895 - 895)) {
                        return (344 - 344);
                    };
                }
                cout << "(" << (char) toupper (UOnzRPlUHiD[pdtEbLCx - (309 - 308)]) << "," << TzQM81ywn << ")";
                TzQM81ywn = (97 - 96);
            }
            pdtEbLCx = pdtEbLCx + (349 - 348);
        };
    }
    cout << "(" << (char) toupper (UOnzRPlUHiD[KWGH6wI5 -(550 - 549)]) << "," << TzQM81ywn << ")";
    return (119 - 119);
}

