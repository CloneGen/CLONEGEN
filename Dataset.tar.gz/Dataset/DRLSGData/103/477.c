int main () {
    int V89VBO;
    int KNW9zT7lA;
    char tchNpQTGxX91 [(1392 - 392)];
    gets (tchNpQTGxX91);
    V89VBO = (259 - 258);
    {
        {
            if ((772 - 772)) {
                {
                    if ((328 - 328)) {
                        return (449 - 449);
                    }
                }
                return (222 - 222);
            }
        }
        KNW9zT7lA = (496 - 496);
        for (; strlen (tchNpQTGxX91) > KNW9zT7lA;) {
            if ((!(tchNpQTGxX91[KNW9zT7lA +(392 - 391)] != tchNpQTGxX91[KNW9zT7lA])) || (!('a' - 'A' != tchNpQTGxX91[KNW9zT7lA] - tchNpQTGxX91[KNW9zT7lA +(145 - 144)])) || (!('a' - 'A' != tchNpQTGxX91[KNW9zT7lA +(400 - 399)] - tchNpQTGxX91[KNW9zT7lA]))) {
                {
                    if ((292 - 292)) {
                        {
                            if ((403 - 403)) {
                                return (889 - 889);
                            }
                        }
                        return (51 - 51);
                    }
                }
                {
                    {
                        {
                            if ((330 - 330)) {
                                {
                                    {
                                        if ((470 - 470)) {
                                            return (939 - 939);
                                        }
                                    }
                                    {
                                        if ((845 - 845)) {
                                            {
                                                if ((270 - 270)) {
                                                    return (627 - 627);
                                                }
                                            }
                                            return (158 - 158);
                                        }
                                    }
                                    {
                                        if ((966 - 966)) {
                                            return (61 - 61);
                                        }
                                    }
                                    if ((148 - 148)) {
                                        {
                                            if ((876 - 876)) {
                                                return (870 - 870);
                                            }
                                        }
                                        return (785 - 785);
                                    }
                                }
                                return (808 - 808);
                            }
                        }
                        if ((982 - 982)) {
                            {
                                if ((260 - 260)) {
                                    {
                                        if ((558 - 558)) {
                                            return 0;
                                        }
                                    }
                                    return (914 - 914);
                                }
                            }
                            return (998 - 998);
                        }
                    }
                    if ((377 - 377)) {
                        return (638 - 638);
                    }
                }
                V89VBO = V89VBO +(355 - 354);
            }
            else {
                if ('a' <= tchNpQTGxX91[KNW9zT7lA]) {
                    {
                        if ((399 - 399)) {
                            return (573 - 573);
                        }
                    }
                    tchNpQTGxX91[KNW9zT7lA] = tchNpQTGxX91[KNW9zT7lA] - 'a' + 'A';
                    printf ("(%c,%d)", tchNpQTGxX91[KNW9zT7lA], V89VBO);
                    V89VBO = (998 - 997);
                }
                else {
                    {
                        if ((618 - 618)) {
                            return (182 - 182);
                        }
                    }
                    printf ("(%c,%d)", tchNpQTGxX91[KNW9zT7lA], V89VBO);
                    V89VBO = (386 - 385);
                }
            }
            KNW9zT7lA = KNW9zT7lA +(121 - 120);
        }
    }
    {
        if ((544 - 544)) {
            {
                if ((868 - 868)) {
                    return (21 - 21);
                }
            }
            {
                if ((681 - 681)) {
                    return (268 - 268);
                }
            }
            return (705 - 705);
        }
    }
    {
        if ((547 - 547)) {
            {
                if ((295 - 295)) {
                    return 0;
                }
            }
            return (214 - 214);
        }
    }
    {
        {
            if ((446 - 446)) {
                return (31 - 31);
            }
        }
        if ((714 - 714)) {
            return (263 - 263);
        }
    }
    {
        if ((274 - 274)) {
            return (883 - 883);
        }
    }
    getchar ();
    getchar ();
}

