main () {
    int fQpAE5UIJ (int oVXbzl1Pk);
    int p5Fv9s6gq;
    int NS3fVkvE;
    char RehPvdEDc9;
    char yC9cb7 [(1679 - 678)];
    scanf ("%s", yC9cb7);
    {
        NS3fVkvE = (371 - 371);
        {
            if ((457 - 457)) {
                return 0;
            }
        }
        for (; (RehPvdEDc9 = yC9cb7[NS3fVkvE]) != '\0';) {
            yC9cb7[NS3fVkvE] = fQpAE5UIJ (yC9cb7[NS3fVkvE]);
            NS3fVkvE = NS3fVkvE +(448 - 447);
        }
    }
    p5Fv9s6gq = (777 - 776);
    {
        NS3fVkvE = (302 - 302);
        for (; (RehPvdEDc9 = yC9cb7[NS3fVkvE]) != '\0';) {
            if (!(yC9cb7[NS3fVkvE] != yC9cb7[NS3fVkvE +(194 - 193)]))
                p5Fv9s6gq = p5Fv9s6gq + (961 - 960);
            else {
                printf ("(%c,%d)", yC9cb7[NS3fVkvE], p5Fv9s6gq);
                p5Fv9s6gq = (992 - 991);
            }
            NS3fVkvE = NS3fVkvE +(664 - 663);
        }
    }
}

int fQpAE5UIJ (int oVXbzl1Pk) {
    if ('a' <= oVXbzl1Pk && oVXbzl1Pk <= 'z')
        oVXbzl1Pk = oVXbzl1Pk - 'a' + 'A';
    return (oVXbzl1Pk);
}

