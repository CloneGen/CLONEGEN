int main () {
    char Xk38dnwOX [(1259 - 259)];
    int vNksifgGABVX;
    int R29EoWng;
    int nUdktD1iVxF;
    scanf ("%s", Xk38dnwOX);
    vNksifgGABVX = strlen (Xk38dnwOX);
    {
        nUdktD1iVxF = (717 - 717);
        for (; vNksifgGABVX > nUdktD1iVxF;) {
            if (Xk38dnwOX[nUdktD1iVxF] >= 'a' && Xk38dnwOX[nUdktD1iVxF] <= 'z')
                Xk38dnwOX[nUdktD1iVxF] = Xk38dnwOX[nUdktD1iVxF] - (124 - 92);
            nUdktD1iVxF = nUdktD1iVxF + (767 - 766);
        }
    }
    if (!((144 - 143) != vNksifgGABVX))
        printf ("(%c,%d)", Xk38dnwOX[(827 - 827)], (649 - 648));
    R29EoWng = (288 - 288);
    {
        nUdktD1iVxF = (634 - 634);
        for (; nUdktD1iVxF < vNksifgGABVX - (623 - 622);) {
            if (!(Xk38dnwOX[nUdktD1iVxF + (957 - 956)] != Xk38dnwOX[nUdktD1iVxF]))
                R29EoWng = R29EoWng +(914 - 913);
            if (Xk38dnwOX[nUdktD1iVxF] != Xk38dnwOX[nUdktD1iVxF + (366 - 365)]) {
                printf ("(%c,%d)", Xk38dnwOX[nUdktD1iVxF], ++R29EoWng);
                R29EoWng = (282 - 282);
            }
            if ((!(Xk38dnwOX[nUdktD1iVxF + (172 - 171)] != Xk38dnwOX[nUdktD1iVxF])) && (!(vNksifgGABVX - (858 - 856) != nUdktD1iVxF)))
                printf ("(%c,%d)", Xk38dnwOX[nUdktD1iVxF], ++R29EoWng);
            if ((Xk38dnwOX[nUdktD1iVxF] != Xk38dnwOX[nUdktD1iVxF + (674 - 673)]) && (!(vNksifgGABVX - (555 - 553) != nUdktD1iVxF)))
                printf ("(%c,%d)", Xk38dnwOX[nUdktD1iVxF + (459 - 458)], (694 - 693));
            nUdktD1iVxF = nUdktD1iVxF + (410 - 409);
        }
    }
    return (176 - 176);
}

