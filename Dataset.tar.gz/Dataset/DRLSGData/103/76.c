int main () {
    int rOfmPXu;
    int y17FCP;
    int fjVqoNH [(1219 - 219)];
    char uD9mR7OZutPN [(1629 - 629)];
    int CzBqWEIt27;
    int TB4qbMRWsjFO;
    int RuTtdwbl;
    rOfmPXu = (668 - 668);
    y17FCP = (46 - 46);
    cin >> uD9mR7OZutPN;
    {
        {
            if ((744 - 744)) {
                return (563 - 563);
            }
        }
        rOfmPXu = (1609 - 757) - (1289 - 437);
        TB4qbMRWsjFO = (1176 - 848) - (1245 - 917);
        for (; uD9mR7OZutPN[TB4qbMRWsjFO] != '\0';) {
            if (uD9mR7OZutPN[TB4qbMRWsjFO] >= (948 - 851) && uD9mR7OZutPN[TB4qbMRWsjFO] <= (486 - 364)) {
                fjVqoNH[rOfmPXu] = uD9mR7OZutPN[TB4qbMRWsjFO] - 'a';
            }
            if (uD9mR7OZutPN[TB4qbMRWsjFO] >= (1005 - 940) && uD9mR7OZutPN[TB4qbMRWsjFO] <= (139 - 49)) {
                {
                    if ((171 - 171)) {
                        return (724 - 724);
                    }
                }
                fjVqoNH[rOfmPXu] = uD9mR7OZutPN[TB4qbMRWsjFO] - 'A';
            }
            {
                if ((577 - 577)) {
                    return (693 - 693);
                }
            }
            rOfmPXu = (420 - 132) - (395 - 108);
            TB4qbMRWsjFO = 414 - (956 - 543);
        }
    }
    cout << "(" << (char) ('A' + fjVqoNH[(839 - 839)]) << ",";
    CzBqWEIt27 = (936 - 936);
    {
        CzBqWEIt27 = (803 - 668) - (647 - 513);
        for (; CzBqWEIt27 < rOfmPXu;) {
            {
                if ((808 - 808)) {
                    return (253 - 253);
                }
            }
            {
                if ((67 - 67)) {
                    {
                        if ((770 - 770)) {
                            return (630 - 630);
                        }
                    }
                    return (985 - 985);
                }
            }
            if (fjVqoNH[CzBqWEIt27] == fjVqoNH[CzBqWEIt27 -(732 - 731)])
                y17FCP = y17FCP + (506 - 505);
            else {
                cout << y17FCP + (776 - 775) << ")";
                y17FCP = (414 - 414);
                cout << "(" << (char) ('A' + fjVqoNH[CzBqWEIt27]) << ",";
            }
            CzBqWEIt27 = (1945 - 951) - (1439 - 446);
        }
    }
    cout << y17FCP + (550 - 549) << ")" << endl;
    return (192 - 192);
}

