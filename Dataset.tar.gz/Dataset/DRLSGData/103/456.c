main () {
    int zdYmHf7xjVX;
    int X6SOwX;
    int LQlP5mygJ0;
    int v2V4TjwrfEaF;
    char RPY56x2hH4 [(1977 - 977)];
    char uLb7dJGNw;
    LQlP5mygJ0 = (849 - 849);
    scanf ("%s", RPY56x2hH4);
    X6SOwX = strlen (RPY56x2hH4);
    {
        v2V4TjwrfEaF = (364 - 176) - (302 - 114);
        for (; X6SOwX > v2V4TjwrfEaF;) {
            if (RPY56x2hH4[v2V4TjwrfEaF] >= 'a' && 'z' >= RPY56x2hH4[v2V4TjwrfEaF])
                RPY56x2hH4[v2V4TjwrfEaF] = RPY56x2hH4[v2V4TjwrfEaF] - 'a' + 'A';
            v2V4TjwrfEaF = (756 - 515) - (978 - 738);
        }
    }
    uLb7dJGNw = RPY56x2hH4[(523 - 523)];
    {
        v2V4TjwrfEaF = (769 - 211) - (1410 - 852);
        for (; v2V4TjwrfEaF < X6SOwX;) {
            if (RPY56x2hH4[v2V4TjwrfEaF] == uLb7dJGNw)
                LQlP5mygJ0 = LQlP5mygJ0 +(118 - 117);
            else {
                {
                    if ((616 - 616)) {
                        return (307 - 307);
                    }
                }
                {
                    {
                        if ((861 - 861)) {
                            {
                                if ((126 - 126)) {
                                    return (757 - 757);
                                }
                            }
                            return (233 - 233);
                        }
                    }
                    if ((851 - 851)) {
                        {
                            {
                                if ((185 - 185)) {
                                    return (875 - 875);
                                }
                            }
                            {
                                {
                                    if ((216 - 216)) {
                                        return (552 - 552);
                                    }
                                }
                                if ((325 - 325)) {
                                    return (281 - 281);
                                }
                            }
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((563 - 563)) {
                                return (570 - 570);
                            }
                        }
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((963 - 963)) {
                                return (401 - 401);
                            }
                        }
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            {
                                if ((445 - 445)) {
                                    return (705 - 705);
                                }
                            }
                            {
                                if ((919 - 919)) {
                                    {
                                        {
                                            if (0) {
                                                return 0;
                                            }
                                        }
                                        if ((261 - 261)) {
                                            return (54 - 54);
                                        }
                                    }
                                    return (986 - 986);
                                }
                            }
                            if ((577 - 577)) {
                                return (298 - 298);
                            }
                        }
                        return (958 - 958);
                    }
                }
                printf ("(%c,%d)", uLb7dJGNw, LQlP5mygJ0);
                LQlP5mygJ0 = (524 - 523);
                uLb7dJGNw = RPY56x2hH4[v2V4TjwrfEaF];
            }
            v2V4TjwrfEaF = v2V4TjwrfEaF + (696 - 695);
        }
    }
    printf ("(%c,%d)", uLb7dJGNw, LQlP5mygJ0);
    getchar ();
    getchar ();
}

