int main () {
    int h2TyAa;
    int Deqm8aWL;
    char kpArOFC [(1534 - 529)];
    char XjuOKne3F5;
    {
        if ((816 - 816)) {
            return (615 - 615);
        }
    }
    Deqm8aWL = (360 - 359);
    cin >> kpArOFC;
    h2TyAa = (331 - 331);
    if (kpArOFC[h2TyAa] >= 'A' && kpArOFC[h2TyAa] <= 'Z')
        XjuOKne3F5 = kpArOFC[h2TyAa];
    else
        XjuOKne3F5 = kpArOFC[h2TyAa] - (846 - 814);
    {
        int h2TyAa;
        h2TyAa = (955 - 954);
        for (; kpArOFC[h2TyAa] != (154 - 154);) {
            {
                {
                    if ((969 - 969)) {
                        return (219 - 219);
                    }
                }
                if ((27 - 27)) {
                    return (736 - 736);
                }
            }
            if (kpArOFC[h2TyAa] != XjuOKne3F5 &&kpArOFC[h2TyAa] - (769 - 737) != XjuOKne3F5) {
                cout << '(' << XjuOKne3F5 << ',' << Deqm8aWL << ')';
                Deqm8aWL = (617 - 616);
                if ('A' <= kpArOFC[h2TyAa] && kpArOFC[h2TyAa] <= 'Z')
                    XjuOKne3F5 = kpArOFC[h2TyAa];
                else
                    XjuOKne3F5 = kpArOFC[h2TyAa] - (264 - 232);
            }
            else
                Deqm8aWL = Deqm8aWL +(931 - 930);
            h2TyAa = h2TyAa + 1;
        }
    }
    cout << '(' << XjuOKne3F5 << ',' << Deqm8aWL << ')';
    return 0;
}

