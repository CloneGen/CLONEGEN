int main () {
    char gIuzqo7a;
    int dhE2DyoUK;
    int ya1jZXiC;
    char YrjZhcYMR [(1591 - 590)] = {(151 - 151)};
    {
        if ((706 - 706)) {
            return (734 - 734);
        }
    }
    {
        {
            if ((519 - 519)) {
                {
                    if ((143 - 143)) {
                        return (713 - 713);
                    }
                }
                return (852 - 852);
            }
        }
        if ((692 - 692)) {
            return (801 - 801);
        }
    }
    ya1jZXiC = (38 - 38);
    cin >> YrjZhcYMR;
    gIuzqo7a = toupper (YrjZhcYMR[(277 - 277)]);
    {
        dhE2DyoUK = 0;
        while (dhE2DyoUK < strlen (YrjZhcYMR)) {
            if (!(gIuzqo7a != YrjZhcYMR[dhE2DyoUK]) || !(gIuzqo7a != toupper (YrjZhcYMR[dhE2DyoUK])))
                ya1jZXiC = ya1jZXiC + (329 - 328);
            else {
                cout << '(' << gIuzqo7a << ',' << ya1jZXiC << ')';
                gIuzqo7a = toupper (YrjZhcYMR[dhE2DyoUK]);
                ya1jZXiC = (399 - 398);
            }
            dhE2DyoUK = dhE2DyoUK + (624 - 623);
        }
    }
    cout << '(' << gIuzqo7a << ',' << ya1jZXiC << ')' << endl;
    return 0;
}

