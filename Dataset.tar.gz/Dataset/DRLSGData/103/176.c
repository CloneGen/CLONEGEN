struct   cMJPn8RYwp {
    char hgWAKHSi;
    int NOEv8G3lg;
}
cMJPn8RYwp [(1376 - 376)];

main () {
    char YRkajx;
    char ciW297V [(1777 - 677)];
    char lLTnHAjJv;
    char CAedUI5Yncib;
    char LqKIzkCfmy;
    char pPSt3w5Jl6u;
    char GRKjFwBrH;
    GRKjFwBrH = (807 - 807);
    CAedUI5Yncib = (886 - 886);
    scanf ("%s", ciW297V);
    YRkajx = strlen (ciW297V);
    ciW297V[YRkajx] = '\0';
    {
        pPSt3w5Jl6u = (765 - 765);
        for (; YRkajx > pPSt3w5Jl6u;) {
            if ('a' <= ciW297V[pPSt3w5Jl6u] && 'z' >= ciW297V[pPSt3w5Jl6u])
                ciW297V[pPSt3w5Jl6u] = ciW297V[pPSt3w5Jl6u] - 'a' + 'A';
            pPSt3w5Jl6u = pPSt3w5Jl6u + (940 - 939);
        }
    }
    lLTnHAjJv = ciW297V[(184 - 184)];
    {
        pPSt3w5Jl6u = (892 - 151) - (1087 - 346);
        for (; YRkajx >= pPSt3w5Jl6u;) {
            if (!(lLTnHAjJv != ciW297V[pPSt3w5Jl6u])) {
                CAedUI5Yncib = CAedUI5Yncib +(425 - 424);
            }
            if (ciW297V[pPSt3w5Jl6u] != lLTnHAjJv && ciW297V[pPSt3w5Jl6u] != '\0') {
                cMJPn8RYwp[GRKjFwBrH].hgWAKHSi = ciW297V[pPSt3w5Jl6u - (111 - 110)];
                cMJPn8RYwp[GRKjFwBrH].NOEv8G3lg = CAedUI5Yncib;
                GRKjFwBrH = GRKjFwBrH +(276 - 275);
                CAedUI5Yncib = (199 - 198);
                lLTnHAjJv = ciW297V[pPSt3w5Jl6u];
            }
            if (!('\0' != ciW297V[pPSt3w5Jl6u]) && ciW297V[pPSt3w5Jl6u - (336 - 335)] != '\0' && ciW297V[pPSt3w5Jl6u] != lLTnHAjJv) {
                cMJPn8RYwp[GRKjFwBrH].hgWAKHSi = ciW297V[pPSt3w5Jl6u - (280 - 279)];
                cMJPn8RYwp[GRKjFwBrH].NOEv8G3lg = CAedUI5Yncib;
                GRKjFwBrH = GRKjFwBrH +(715 - 714);
                break;
            }
            pPSt3w5Jl6u = (1373 - 536) - (921 - 85);
        }
    }
    {
        pPSt3w5Jl6u = (396 - 152) - (751 - 507);
        for (; pPSt3w5Jl6u < GRKjFwBrH;) {
            printf ("(%c,%d)", cMJPn8RYwp[pPSt3w5Jl6u].hgWAKHSi, cMJPn8RYwp[pPSt3w5Jl6u].NOEv8G3lg);
            pPSt3w5Jl6u = pPSt3w5Jl6u + (419 - 418);
        }
    }
}

