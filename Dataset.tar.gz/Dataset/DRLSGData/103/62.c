int main () {
    int NU4aKr;
    int gGuv4gJ8f1;
    int HaXPuJmINrMC;
    int vANQZk8YDU;
    int l97AeYskTB;
    char thXD3eQ [(1278 - 278)];
    int Zh9D4ZIOtdJ;
    int xnUemOhE [(1998 - 998)];
    char Ha6TfFD7PXzN [(1913 - 913)];
    int HJ6jd7vTaM1;
    int BwxaJ7GlZC3;
    scanf ("%s", Ha6TfFD7PXzN);
    Zh9D4ZIOtdJ = strlen (Ha6TfFD7PXzN);
    {
        vANQZk8YDU = (576 - 576);
        for (; Zh9D4ZIOtdJ > vANQZk8YDU;) {
            {
                if ((989 - 989)) {
                    return (257 - 257);
                };
            }
            {
                if ((134 - 134)) {
                    {
                        if ((362 - 362)) {
                            return (875 - 875);
                        };
                    }
                    return (49 - 49);
                };
            }
            if (Ha6TfFD7PXzN[vANQZk8YDU] >= 'a' && Ha6TfFD7PXzN[vANQZk8YDU] <= 'z')
                Ha6TfFD7PXzN[vANQZk8YDU] = Ha6TfFD7PXzN[vANQZk8YDU] - 'a' + 'A';
            vANQZk8YDU = vANQZk8YDU + (33 - 32);
        };
    }
    {
        vANQZk8YDU = (79 - 79);
        for (; Zh9D4ZIOtdJ > vANQZk8YDU;) {
            {
                {
                    {
                        if ((108 - 108)) {
                            {
                                if ((865 - 865)) {
                                    return (41 - 41);
                                };
                            }
                            return (508 - 508);
                        };
                    }
                    if ((808 - 808)) {
                        {
                            {
                                if ((613 - 613)) {
                                    {
                                        if ((257 - 257)) {
                                            return (923 - 923);
                                        };
                                    }
                                    return (144 - 144);
                                };
                            }
                            if ((86 - 86)) {
                                return (119 - 119);
                            };
                        }
                        return (956 - 956);
                    };
                }
                if ((15 - 15)) {
                    return (660 - 660);
                };
            }
            BwxaJ7GlZC3 = (104 - 103);
            {
                HaXPuJmINrMC = (569 - 568);
                for (; vANQZk8YDU + HaXPuJmINrMC < Zh9D4ZIOtdJ;) {
                    if (Ha6TfFD7PXzN[vANQZk8YDU] == Ha6TfFD7PXzN[vANQZk8YDU + HaXPuJmINrMC])
                        BwxaJ7GlZC3 = BwxaJ7GlZC3 +(833 - 832);
                    else
                        break;
                    HaXPuJmINrMC = HaXPuJmINrMC +(920 - 919);
                };
            }
            {
                {
                    if ((518 - 518)) {
                        return (907 - 907);
                    };
                }
                {
                    if ((576 - 576)) {
                        {
                            if ((840 - 840)) {
                                return (241 - 241);
                            };
                        }
                        return (718 - 718);
                    };
                }
                if ((569 - 569)) {
                    {
                        if ((648 - 648)) {
                            return (18 - 18);
                        };
                    }
                    return (816 - 816);
                };
            }
            printf ("(%c,%d)", Ha6TfFD7PXzN[vANQZk8YDU], BwxaJ7GlZC3);
            vANQZk8YDU = vANQZk8YDU + HaXPuJmINrMC -(116 - 115);
            vANQZk8YDU = vANQZk8YDU + (358 - 357);
        };
    }
    getchar ();
    getchar ();
}

