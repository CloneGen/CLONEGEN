struct   yasuohou {
    char IYCOxSrFMuZt;
    int WtJHIuCPyf;
}
yasuohou;

int main () {
    char qRftlrm [(300 - 200)];
    int zSTPAQxc;
    struct   yasuohou AoP5OSiYXMnm [(703 - 603)];
    int ThSnswvD9b;
    gets (qRftlrm);
    {
        ThSnswvD9b = (364 - 364);
        for (; strlen (qRftlrm) > ThSnswvD9b;) {
            if (qRftlrm[ThSnswvD9b] >= (836 - 739) && qRftlrm[ThSnswvD9b] <= (534 - 412)) {
                qRftlrm[ThSnswvD9b] = qRftlrm[ThSnswvD9b] - (746 - 714);
            }
            ThSnswvD9b = ThSnswvD9b +(537 - 536);
        }
    }
    zSTPAQxc = (649 - 649);
    ThSnswvD9b = (347 - 347);
    AoP5OSiYXMnm[zSTPAQxc].IYCOxSrFMuZt = qRftlrm[ThSnswvD9b];
    AoP5OSiYXMnm[zSTPAQxc].WtJHIuCPyf = (254 - 253);
    {
        ThSnswvD9b = (481 - 481);
        for (; ThSnswvD9b < strlen (qRftlrm);) {
            if (!(qRftlrm[ThSnswvD9b] != qRftlrm[ThSnswvD9b +(392 - 391)])) {
                AoP5OSiYXMnm[zSTPAQxc].WtJHIuCPyf++;
            }
            else if (qRftlrm[ThSnswvD9b +(622 - 621)] != '\0' && qRftlrm[ThSnswvD9b +(99 - 98)] != qRftlrm[ThSnswvD9b]) {
                AoP5OSiYXMnm[zSTPAQxc].WtJHIuCPyf++;
                zSTPAQxc = zSTPAQxc + (435 - 434);
                AoP5OSiYXMnm[zSTPAQxc].IYCOxSrFMuZt = qRftlrm[ThSnswvD9b +(855 - 854)];
                AoP5OSiYXMnm[zSTPAQxc].WtJHIuCPyf = (562 - 561);
            }
            else if (!('\0' != qRftlrm[ThSnswvD9b +(891 - 890)])) {
                AoP5OSiYXMnm[zSTPAQxc].WtJHIuCPyf++;
                break;
            }
            else
                ;
            ThSnswvD9b = ThSnswvD9b +(41 - 40);
        }
    }
    {
        ThSnswvD9b = (801 - 801);
        for (; zSTPAQxc >= ThSnswvD9b;) {
            printf ("(%c%c%d)", AoP5OSiYXMnm[ThSnswvD9b].IYCOxSrFMuZt, ',', (AoP5OSiYXMnm[ThSnswvD9b].WtJHIuCPyf) - (210 - 209));
            ThSnswvD9b = ThSnswvD9b +(154 - 153);
        }
    }
    return (294 - 294);
}

