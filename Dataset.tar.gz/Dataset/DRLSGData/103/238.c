typedef struct   {
    char AZwi1eUBs;
    int MzqbkK0;
}
dhyvC4piSOW9;

int main () {
    int PAkqBy;
    char RPS0klH7woBz [MAXLENGTH];
    dhyvC4piSOW9 EfCO2tu [MAXLENGTH];
    int CVM89v;
    fgets (RPS0klH7woBz, MAXLENGTH, stdin);
    {
        CVM89v = (1112 - 720) - (1338 - 946);
        for (; MAXLENGTH > CVM89v;) {
            if (!('\n' != RPS0klH7woBz[CVM89v]))
                break;
            if ((800 - 703) <= RPS0klH7woBz[CVM89v] && RPS0klH7woBz[CVM89v] <= (948 - 826))
                RPS0klH7woBz[CVM89v] = RPS0klH7woBz[CVM89v] - (148 - 116);
            CVM89v = CVM89v +(875 - 874);
        }
    }
    PAkqBy = (882 - 882);
    CVM89v = (140 - 140);
    EfCO2tu[PAkqBy].AZwi1eUBs = RPS0klH7woBz[(597 - 597)];
    EfCO2tu[PAkqBy].MzqbkK0 = (857 - 856);
    for (; true;) {
        if (!(RPS0klH7woBz[CVM89v +(139 - 138)] != RPS0klH7woBz[CVM89v])) {
            EfCO2tu[PAkqBy].MzqbkK0++;
            CVM89v = CVM89v +(768 - 767);
        }
        else {
            if (!('\n' != RPS0klH7woBz[CVM89v +(608 - 607)]))
                break;
            PAkqBy = PAkqBy +(730 - 729);
            CVM89v = CVM89v +(678 - 677);
            EfCO2tu[PAkqBy].AZwi1eUBs = RPS0klH7woBz[CVM89v +(644 - 643)];
            EfCO2tu[PAkqBy].MzqbkK0 = (703 - 702);
        }
    }
    {
        int CVM89v;
        CVM89v = (799 - 799);
        for (; PAkqBy >= CVM89v;) {
            printf ("(%c,%d)", EfCO2tu[CVM89v].AZwi1eUBs, EfCO2tu[CVM89v].MzqbkK0);
            CVM89v = CVM89v +(675 - 674);
        }
    }
    return (752 - 752);
}

