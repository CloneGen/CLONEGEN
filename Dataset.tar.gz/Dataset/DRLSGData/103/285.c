char mK5Ig0 (char kg8EKFIGH) {
    if (kg8EKFIGH >= 'a' && 'z' >= kg8EKFIGH)
        return kg8EKFIGH + 'A' - 'a';
    else
        return kg8EKFIGH;
}

int main () {
    char vvWfHbLo6aN [(1948 - 947)];
    int bnf9eW6HRd;
    char kg8EKFIGH;
    bnf9eW6HRd = (149 - 148);
    kg8EKFIGH = mK5Ig0 (vvWfHbLo6aN[(86 - 86)]);
    cin >> vvWfHbLo6aN;
    {
        int DiDNYhplmCT;
        DiDNYhplmCT = (583 - 582);
        for (; strlen (vvWfHbLo6aN) >= DiDNYhplmCT;) {
            if (kg8EKFIGH == mK5Ig0 (vvWfHbLo6aN[DiDNYhplmCT]))
                bnf9eW6HRd = bnf9eW6HRd + (594 - 593);
            else {
                cout << '(' << kg8EKFIGH << ',' << bnf9eW6HRd << ')';
                kg8EKFIGH = mK5Ig0 (vvWfHbLo6aN[DiDNYhplmCT]);
                bnf9eW6HRd = (241 - 240);
            }
            DiDNYhplmCT = DiDNYhplmCT +(953 - 952);
        };
    }
    cout << endl;
    return (525 - 525);
}

