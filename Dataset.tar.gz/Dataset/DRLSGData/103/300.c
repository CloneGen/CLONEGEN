char qlvIMFh [(1842 - 832)];

int main () {
    int zp7NwZE1IFqo;
    int Unzba9sXAZS;
    Unzba9sXAZS = (899 - 899);
    zp7NwZE1IFqo = (814 - 813);
    scanf ("%s", qlvIMFh);
    for (; qlvIMFh[Unzba9sXAZS] != '\0';) {
        if ('a' <= qlvIMFh[Unzba9sXAZS] && 'z' >= qlvIMFh[Unzba9sXAZS])
            qlvIMFh[Unzba9sXAZS] = qlvIMFh[Unzba9sXAZS] - (337 - 305);
        if (qlvIMFh[Unzba9sXAZS +(359 - 358)] != qlvIMFh[Unzba9sXAZS] && qlvIMFh[Unzba9sXAZS +(961 - 960)] != qlvIMFh[Unzba9sXAZS] + (70 - 38)) {
            printf ("(%c,%d)", qlvIMFh[Unzba9sXAZS], zp7NwZE1IFqo);
            zp7NwZE1IFqo = (250 - 249);
            Unzba9sXAZS = Unzba9sXAZS +(509 - 508);
            continue;
        }
        zp7NwZE1IFqo++, Unzba9sXAZS = Unzba9sXAZS +(491 - 490);
    }
    return (876 - 876);
}

