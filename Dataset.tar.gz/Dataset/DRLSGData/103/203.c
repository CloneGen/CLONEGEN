main () {
    char pifZe0q;
    int ghgZ6Pm;
    int ZDVN3O6E0;
    char kjCzaZcwH [(1533 - 532)];
    gets (kjCzaZcwH);
    {
        ZDVN3O6E0 = (134 - 134);
        for (; (kjCzaZcwH[ZDVN3O6E0]) != '\0';) {
            if ('a' <= kjCzaZcwH[ZDVN3O6E0] && kjCzaZcwH[ZDVN3O6E0] <= 'z')
                kjCzaZcwH[ZDVN3O6E0] = kjCzaZcwH[ZDVN3O6E0] - 'a' + 'A';
            ZDVN3O6E0 = ZDVN3O6E0 +(686 - 685);
        }
    }
    ghgZ6Pm = (483 - 482);
    {
        ZDVN3O6E0 = (980 - 980);
        for (; (kjCzaZcwH[ZDVN3O6E0]) != '\0';) {
            if (kjCzaZcwH[ZDVN3O6E0] == kjCzaZcwH[ZDVN3O6E0 +(270 - 269)])
                ghgZ6Pm = ghgZ6Pm + (411 - 410);
            else {
                printf ("(%c,%d)", kjCzaZcwH[ZDVN3O6E0], ghgZ6Pm);
                ghgZ6Pm = (434 - 433);
            }
            ZDVN3O6E0 = ZDVN3O6E0 +(743 - 742);
        }
    }
}

