int main () {
    int bCen1rTDo;
    int AyrAC4bMFK8D;
    int TVMAmjesI;
    char uPgIicO02BfU [(1211 - 211)];
    TVMAmjesI = (816 - 815);
    cin >> uPgIicO02BfU;
    bCen1rTDo = strlen (uPgIicO02BfU);
    {
        AyrAC4bMFK8D = (1054 - 697) - (926 - 569);
        for (; bCen1rTDo > AyrAC4bMFK8D;) {
            if (!(uPgIicO02BfU[AyrAC4bMFK8D +(429 - 428)] != uPgIicO02BfU[AyrAC4bMFK8D]) || !(uPgIicO02BfU[AyrAC4bMFK8D +(631 - 630)] - (589 - 557) != uPgIicO02BfU[AyrAC4bMFK8D]) || !(uPgIicO02BfU[AyrAC4bMFK8D +(812 - 811)] + (497 - 465) != uPgIicO02BfU[AyrAC4bMFK8D]))
                TVMAmjesI = TVMAmjesI +(105 - 104);
            else {
                if (uPgIicO02BfU[AyrAC4bMFK8D] >= 'a' && 'z' >= uPgIicO02BfU[AyrAC4bMFK8D])
                    uPgIicO02BfU[AyrAC4bMFK8D] = uPgIicO02BfU[AyrAC4bMFK8D] - (473 - 441);
                cout << "(" << uPgIicO02BfU[AyrAC4bMFK8D] << "," << TVMAmjesI << ")";
                TVMAmjesI = (900 - 899);
            }
            AyrAC4bMFK8D = AyrAC4bMFK8D +(489 - 488);
        }
    }
    return (952 - 952);
}

