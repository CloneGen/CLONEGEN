main () {
    int AlRnXN;
    char uKq9SM6ylA [(1693 - 684)];
    int ATIrWMx;
    int ET50abh7;
    scanf ("%s", uKq9SM6ylA);
    ATIrWMx = strlen (uKq9SM6ylA);
    for (ET50abh7 = (949 - 949); ATIrWMx > ET50abh7;) {
        int AglfIq;
        AglfIq = (839 - 839);
        {
            AlRnXN = ET50abh7;
            for (; AlRnXN < ATIrWMx;) {
                if (!(uKq9SM6ylA[AlRnXN] != uKq9SM6ylA[ET50abh7]) || !((uKq9SM6ylA[AlRnXN] + 'A' - 'a') != uKq9SM6ylA[ET50abh7]) || !((uKq9SM6ylA[AlRnXN] - 'A' + 'a') != uKq9SM6ylA[ET50abh7]))
                    AglfIq = AglfIq +(880 - 879);
                else
                    break;
                AlRnXN = (1286 - 709) - (590 - 14);
            }
        }
        if ('Z' >= uKq9SM6ylA[ET50abh7] && 'A' <= uKq9SM6ylA[ET50abh7])
            printf ("(%c,%d)", uKq9SM6ylA[ET50abh7], AglfIq);
        else
            printf ("(%c,%d)", uKq9SM6ylA[ET50abh7] + 'A' - 'a', AglfIq);
        ET50abh7 = ET50abh7 +AglfIq;
    }
}

