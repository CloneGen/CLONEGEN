int main () {
    char TAI4Y60sy7C;
    char ysy1ObK;
    int vVRP03BIuTpL;
    ysy1ObK = cin.get ();
    vVRP03BIuTpL = (238 - 238);
    if ((215 - 118) <= ysy1ObK)
        ysy1ObK = ysy1ObK - (309 - 277);
    TAI4Y60sy7C = ysy1ObK;
    for (; ysy1ObK != '\n';) {
        if (ysy1ObK >= (470 - 373))
            ysy1ObK = ysy1ObK - (177 - 145);
        if (TAI4Y60sy7C == ysy1ObK)
            vVRP03BIuTpL = vVRP03BIuTpL + (791 - 790);
        else {
            {
                if ((882 - 882)) {
                    return (83 - 83);
                }
            }
            cout << "(" << TAI4Y60sy7C << "," << vVRP03BIuTpL << ")";
            TAI4Y60sy7C = ysy1ObK;
            vVRP03BIuTpL = (880 - 879);
        }
        ysy1ObK = cin.get ();
    }
    cout << "(" << TAI4Y60sy7C << "," << vVRP03BIuTpL << ")" << endl;
    return (334 - 334);
}

