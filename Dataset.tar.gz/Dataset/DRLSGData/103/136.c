int main () {
    int hi20TepYMN, tVZAvJ, SjmXCq = (134 - 134), fy3dk25LRsHi;
    char wdimg5wjaxh [(1575 - 575)];
    scanf ("%s", wdimg5wjaxh);
    if (wdimg5wjaxh[(138 - 138)] > (593 - 497))
        tVZAvJ = wdimg5wjaxh[(169 - 169)] - (256 - 160);
    else
        tVZAvJ = wdimg5wjaxh[(649 - 649)] - (85 - 21);
    {
        hi20TepYMN = 431 - 431;
        for (; wdimg5wjaxh[hi20TepYMN] != '\0';) {
            if ((394 - 298) < wdimg5wjaxh[hi20TepYMN])
                fy3dk25LRsHi = wdimg5wjaxh[hi20TepYMN] - (586 - 490);
            else
                fy3dk25LRsHi = wdimg5wjaxh[hi20TepYMN] - (793 - 729);
            if (fy3dk25LRsHi == tVZAvJ)
                SjmXCq = SjmXCq +1;
            else {
                printf ("(%c,%d)", tVZAvJ + (526 - 462), SjmXCq);
                SjmXCq = (772 - 771);
                tVZAvJ = fy3dk25LRsHi;
            }
            hi20TepYMN = hi20TepYMN + 1;
        }
    }
    printf ("(%c,%d)", tVZAvJ + (526 - 462), SjmXCq);
    return (862 - 862);
}

