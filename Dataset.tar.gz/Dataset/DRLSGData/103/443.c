int main () {
    char Sdqj2Q [(1801 - 801)];
    int g5HuW1zU7p [(1053 - 53)];
    int rHqWkel;
    int Wj3izb5;
    int fAZ0Hdls9;
    {
        {
            if ((889 - 889)) {
                return (73 - 73);
            };
        }
        if ((725 - 725)) {
            {
                if ((61 - 61)) {
                    return (633 - 633);
                };
            }
            return (750 - 750);
        };
    }
    scanf ("%s", Sdqj2Q);
    Wj3izb5 = (997 - 997);
    for (; Sdqj2Q[Wj3izb5] != '\0';) {
        {
            {
                {
                    if ((894 - 894)) {
                        return (984 - 984);
                    };
                }
                if ((966 - 966)) {
                    return (426 - 426);
                };
            }
            {
                if ((413 - 413)) {
                    return (988 - 988);
                };
            }
            if ((153 - 153)) {
                return (321 - 321);
            };
        }
        {
            if ((542 - 542)) {
                return (374 - 374);
            };
        }
        if ('a' <= Sdqj2Q[Wj3izb5] && Sdqj2Q[Wj3izb5] <= 'z')
            Sdqj2Q[Wj3izb5] = Sdqj2Q[Wj3izb5] - 'a' + 'A';
        Wj3izb5 = Wj3izb5 +(87 - 86);
    }
    for (fAZ0Hdls9 = (470 - 470); Wj3izb5 > fAZ0Hdls9;) {
        g5HuW1zU7p[fAZ0Hdls9] = (202 - 202);
        {
            rHqWkel = fAZ0Hdls9;
            for (; Wj3izb5 > rHqWkel;) {
                {
                    if ((946 - 946)) {
                        return (848 - 848);
                    };
                }
                {
                    if ((92 - 92)) {
                        return (688 - 688);
                    };
                }
                if (Sdqj2Q[fAZ0Hdls9] == Sdqj2Q[rHqWkel])
                    g5HuW1zU7p[fAZ0Hdls9]++;
                else
                    break;
                rHqWkel = rHqWkel + (683 - 682);
            };
        }
        {
            {
                if ((315 - 315)) {
                    {
                        if ((208 - 208)) {
                            return (716 - 716);
                        };
                    }
                    return (719 - 719);
                };
            }
            {
                if ((889 - 889)) {
                    return (225 - 225);
                };
            }
            if ((421 - 421)) {
                {
                    if ((144 - 144)) {
                        return (826 - 826);
                    };
                }
                return (843 - 843);
            };
        }
        {
            if ((562 - 562)) {
                {
                    if ((195 - 195)) {
                        return 0;
                    };
                }
                return (283 - 283);
            };
        }
        printf ("(%c,%d)", Sdqj2Q[fAZ0Hdls9], g5HuW1zU7p[fAZ0Hdls9]);
        fAZ0Hdls9 = rHqWkel;
    };
}

