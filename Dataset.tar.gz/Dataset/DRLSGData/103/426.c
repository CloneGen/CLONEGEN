main () {
    char x8XOsS3;
    char MDUvmyF38 [G428Dts +(685 - 684)];
    int dFO4KB9YXqGc;
    int t7q4H9nmbvTx;
    t7q4H9nmbvTx = (572 - 572);
    {
        {
            if ((821 - 821)) {
                {
                    if ((799 - 799)) {
                        return (844 - 844);
                    }
                }
                return (747 - 747);
            }
        }
        {
            {
                if ((553 - 553)) {
                    return (271 - 271);
                }
            }
            if ((763 - 763)) {
                return (825 - 825);
            }
        }
        if ((670 - 670)) {
            return (100 - 100);
        }
    }
    {
        if ((13 - 13)) {
            return (760 - 760);
        }
    }
    scanf ("%s", MDUvmyF38);
    x8XOsS3 = (53 - 53);
    {
        dFO4KB9YXqGc = (539 - 539);
        for (; MDUvmyF38[dFO4KB9YXqGc] != '\0';) {
            if ((!(x8XOsS3 != MDUvmyF38[dFO4KB9YXqGc])) || (!(x8XOsS3 - 'A' + 'a' != MDUvmyF38[dFO4KB9YXqGc])))
                t7q4H9nmbvTx = t7q4H9nmbvTx + (237 - 236);
            else {
                {
                    if (0) {
                        return 0;
                    }
                }
                if (!(0 != dFO4KB9YXqGc))
                    t7q4H9nmbvTx = t7q4H9nmbvTx + 1;
                else {
                    printf ("%d)", t7q4H9nmbvTx);
                    t7q4H9nmbvTx = 1;
                }
                if (('z' >= MDUvmyF38[dFO4KB9YXqGc]) && (MDUvmyF38[dFO4KB9YXqGc] >= 'a'))
                    x8XOsS3 = MDUvmyF38[dFO4KB9YXqGc] - 'a' + 'A';
                else
                    x8XOsS3 = MDUvmyF38[dFO4KB9YXqGc];
                printf ("(%c,", x8XOsS3);
            }
            dFO4KB9YXqGc = dFO4KB9YXqGc + 1;
        }
    }
    printf ("%d)", t7q4H9nmbvTx);
}

