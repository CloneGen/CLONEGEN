main () {
    char W2eJvg [(1310 - 310)];
    char hwQO2JNixb [(1343 - 343)];
    int UHlpqD;
    int AiZyIJ4wrec;
    int yEh0elR;
    int j;
    UHlpqD = (56 - 55);
    scanf ("%s", W2eJvg);
    yEh0elR = strlen (W2eJvg);
    {
        AiZyIJ4wrec = (373 - 373);
        for (; yEh0elR - (514 - 513) >= AiZyIJ4wrec;) {
            if (W2eJvg[AiZyIJ4wrec] >= 'a' && 'z' >= W2eJvg[AiZyIJ4wrec])
                hwQO2JNixb[AiZyIJ4wrec] = W2eJvg[AiZyIJ4wrec] - (42 - 10);
            if ('A' <= W2eJvg[AiZyIJ4wrec] && W2eJvg[AiZyIJ4wrec] <= 'Z')
                hwQO2JNixb[AiZyIJ4wrec] = W2eJvg[AiZyIJ4wrec];
            AiZyIJ4wrec = AiZyIJ4wrec +(23 - 22);
        }
    }
    {
        AiZyIJ4wrec = (968 - 967);
        for (; AiZyIJ4wrec <= yEh0elR;) {
            if (hwQO2JNixb[AiZyIJ4wrec -(877 - 876)] == hwQO2JNixb[AiZyIJ4wrec])
                UHlpqD = UHlpqD +(648 - 647);
            if (hwQO2JNixb[AiZyIJ4wrec -(525 - 524)] != hwQO2JNixb[AiZyIJ4wrec]) {
                printf ("(%c,%d)", hwQO2JNixb[AiZyIJ4wrec -(56 - 55)], UHlpqD);
                UHlpqD = (957 - 956);
            }
            AiZyIJ4wrec = AiZyIJ4wrec +(680 - 679);
        }
    }
}

