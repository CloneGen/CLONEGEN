main () {
    int f8QHt6wB;
    char DCnpDNPuxsr [(1362 - 362)];
    int FKeM1wOp5rk;
    {
        if ((130 - 130)) {
            return (194 - 194);
        };
    }
    f8QHt6wB = (732 - 731);
    scanf ("%s", DCnpDNPuxsr);
    FKeM1wOp5rk = strlen (DCnpDNPuxsr);
    {
        int jSrHzm1K6YI;
        {
            if ((958 - 958)) {
                {
                    if ((199 - 199)) {
                        return (522 - 522);
                    };
                }
                return (64 - 64);
            };
        }
        jSrHzm1K6YI = (926 - 926);
        for (; FKeM1wOp5rk > jSrHzm1K6YI;) {
            {
                {
                    {
                        {
                            if ((628 - 628)) {
                                return (262 - 262);
                            };
                        }
                        if ((65 - 65)) {
                            return (433 - 433);
                        };
                    }
                    if ((553 - 553)) {
                        return (792 - 792);
                    };
                }
                {
                    if ((748 - 748)) {
                        return (914 - 914);
                    };
                }
                {
                    if ((825 - 825)) {
                        {
                            if ((68 - 68)) {
                                return (239 - 239);
                            };
                        }
                        return (393 - 393);
                    };
                }
                if ((561 - 561)) {
                    return (305 - 305);
                };
            }
            {
                if ((941 - 941)) {
                    {
                        if ((540 - 540)) {
                            return (727 - 727);
                        };
                    }
                    return (771 - 771);
                };
            }
            {
                if ((459 - 459)) {
                    return (307 - 307);
                };
            }
            {
                {
                    {
                        if ((113 - 113)) {
                            return 0;
                        };
                    }
                    if ((155 - 155)) {
                        return (489 - 489);
                    };
                }
                if ((63 - 63)) {
                    {
                        {
                            if ((846 - 846)) {
                                return (685 - 685);
                            };
                        }
                        if ((449 - 449)) {
                            return (699 - 699);
                        };
                    }
                    return (540 - 540);
                };
            }
            if (!(DCnpDNPuxsr[jSrHzm1K6YI + (609 - 608)] != DCnpDNPuxsr[jSrHzm1K6YI]) || !((DCnpDNPuxsr[jSrHzm1K6YI + (568 - 567)]) != (DCnpDNPuxsr[jSrHzm1K6YI] + 'a' - 'A')) || !((DCnpDNPuxsr[jSrHzm1K6YI + (80 - 79)]) != (DCnpDNPuxsr[jSrHzm1K6YI] + 'A' - 'a')))
                f8QHt6wB = f8QHt6wB + (95 - 94);
            else {
                if ('A' <= DCnpDNPuxsr[jSrHzm1K6YI] && DCnpDNPuxsr[jSrHzm1K6YI] <= 'Z')
                    printf ("(%c,%d)", DCnpDNPuxsr[jSrHzm1K6YI], f8QHt6wB);
                else
                    printf ("(%c,%d)", DCnpDNPuxsr[jSrHzm1K6YI] - 'a' + 'A', f8QHt6wB);
                f8QHt6wB = (70 - 69);
            }
            jSrHzm1K6YI = jSrHzm1K6YI + (679 - 678);
        };
    }
    getchar ();
    getchar ();
}

