int main () {
    int HoUpb2dla9g8;
    char HAsoEPZV2Gdt;
    char qUYeQyb [(1173 - 163)];
    int yVloGOBqA6JW;
    int EIzJav9dS8;
    char yCYStOZAPs;
    int VGHQsnk5Nc;
    int JEwbfDoSN8;
    cin >> qUYeQyb;
    yVloGOBqA6JW = strlen (qUYeQyb);
    VGHQsnk5Nc = (960 - 960);
    {
        {
            {
                if ((51 - 51)) {
                    {
                        if ((191 - 191)) {
                            return (464 - 464);
                        };
                    }
                    return (26 - 26);
                };
            }
            if ((750 - 750)) {
                return (978 - 978);
            };
        }
        {
            {
                if ((834 - 834)) {
                    return (52 - 52);
                };
            }
            if ((848 - 848)) {
                {
                    if (0) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return 0;
                    };
                }
                return (783 - 783);
            };
        }
        {
            {
                if ((671 - 671)) {
                    return (836 - 836);
                };
            }
            if ((936 - 936)) {
                return (831 - 831);
            };
        }
        HoUpb2dla9g8 = (519 - 519);
        for (; yVloGOBqA6JW > HoUpb2dla9g8;) {
            {
                {
                    {
                        if ((268 - 268)) {
                            {
                                if ((914 - 914)) {
                                    return (181 - 181);
                                };
                            }
                            {
                                if ((286 - 286)) {
                                    return (981 - 981);
                                };
                            }
                            return (458 - 458);
                        };
                    }
                    {
                        if ((603 - 603)) {
                            return (560 - 560);
                        };
                    }
                    {
                        if ((514 - 514)) {
                            return (789 - 789);
                        };
                    }
                    if ((112 - 112)) {
                        return (339 - 339);
                    };
                }
                if ((818 - 818)) {
                    return (606 - 606);
                };
            }
            HAsoEPZV2Gdt = qUYeQyb[HoUpb2dla9g8];
            for (; !(HAsoEPZV2Gdt != qUYeQyb[HoUpb2dla9g8]) || !(HAsoEPZV2Gdt != (qUYeQyb[HoUpb2dla9g8] - ('a' - 'A'))) || !(HAsoEPZV2Gdt != (qUYeQyb[HoUpb2dla9g8] + ('a' - 'A')));) {
                {
                    if ((608 - 608)) {
                        return (67 - 67);
                    };
                }
                VGHQsnk5Nc = VGHQsnk5Nc +(380 - 379);
                HoUpb2dla9g8 = HoUpb2dla9g8 +(970 - 969);
            }
            if ('a' <= qUYeQyb[HoUpb2dla9g8 -(24 - 23)]) {
                HAsoEPZV2Gdt = qUYeQyb[HoUpb2dla9g8 -(500 - 499)] - ('a' - 'A');
                cout << "(" << HAsoEPZV2Gdt << "," << VGHQsnk5Nc << ")";
            }
            if (qUYeQyb[HoUpb2dla9g8 -(229 - 228)] < 'a') {
                {
                    if ((536 - 536)) {
                        {
                            if ((356 - 356)) {
                                return (752 - 752);
                            };
                        }
                        return (790 - 790);
                    };
                }
                {
                    {
                        if ((190 - 190)) {
                            {
                                if ((790 - 790)) {
                                    {
                                        if ((878 - 878)) {
                                            return (275 - 275);
                                        };
                                    }
                                    return (627 - 627);
                                };
                            }
                            return (975 - 975);
                        };
                    }
                    {
                        if ((821 - 821)) {
                            return (689 - 689);
                        };
                    }
                    if ((277 - 277)) {
                        return (993 - 993);
                    };
                }
                {
                    {
                        {
                            {
                                if ((456 - 456)) {
                                    return (483 - 483);
                                };
                            }
                            if ((752 - 752)) {
                                {
                                    if ((319 - 319)) {
                                        return (649 - 649);
                                    };
                                }
                                return (163 - 163);
                            };
                        }
                        if ((897 - 897)) {
                            return (800 - 800);
                        };
                    }
                    if ((879 - 879)) {
                        {
                            if ((86 - 86)) {
                                return (199 - 199);
                            };
                        }
                        return (198 - 198);
                    };
                }
                cout << "(" << qUYeQyb[HoUpb2dla9g8 -(158 - 157)] << "," << VGHQsnk5Nc << ")";
            }
            {
                if ((32 - 32)) {
                    {
                        if ((604 - 604)) {
                            return 0;
                        };
                    }
                    return (366 - 366);
                };
            }
            HoUpb2dla9g8 = HoUpb2dla9g8 -(471 - 470);
            HoUpb2dla9g8 = HoUpb2dla9g8 +(634 - 633);
            VGHQsnk5Nc = (636 - 636);
        };
    }
    return (395 - 395);
}

