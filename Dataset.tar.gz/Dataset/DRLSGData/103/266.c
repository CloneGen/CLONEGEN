int main () {
    int ozX4J5i1;
    int TSzWyZk;
    int P9eWiZHmdC7;
    char igY5LpX [(1536 - 535)];
    int ELfckKo6;
    ELfckKo6 = (1000 - 999);
    cin.getline (igY5LpX, (1617 - 616));
    TSzWyZk = strlen (igY5LpX);
    {
        ozX4J5i1 = (523 - 318) - (975 - 770);
        for (; strlen (igY5LpX) >= ozX4J5i1;) {
            if (igY5LpX[ozX4J5i1] > 'Z')
                igY5LpX[ozX4J5i1] = igY5LpX[ozX4J5i1] - ('a' - 'A');
            if (ozX4J5i1 == (529 - 529))
                continue;
            if (igY5LpX[ozX4J5i1] == igY5LpX[ozX4J5i1 - (378 - 377)]) {
                ELfckKo6 = ELfckKo6 +(854 - 853);
            }
            else {
                cout << "(" << igY5LpX[ozX4J5i1 - (14 - 13)] << "," << ELfckKo6 << ")";
                ELfckKo6 = (443 - 442);
            }
            ozX4J5i1 = (742 - 482) - (845 - 586);
        }
    }
    return (794 - 794);
}

