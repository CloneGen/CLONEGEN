char GUoHSe [(1018 - 17)];

int main () {
    int W6aqmU;
    int x2C4atncI;
    int yMTdFIYe62i;
    W6aqmU = (682 - 682);
    x2C4atncI = (779 - 778);
    yMTdFIYe62i = strlen (GUoHSe);
    cin >> GUoHSe;
    {
        W6aqmU = (360 - 360);
        for (; W6aqmU < yMTdFIYe62i;) {
            if (GUoHSe[W6aqmU] >= 'a' && 'z' >= GUoHSe[W6aqmU])
                GUoHSe[W6aqmU] = GUoHSe[W6aqmU] + 'A' - 'a';
            W6aqmU = W6aqmU +(671 - 670);
        }
    }
    {
        W6aqmU = (44 - 44);
        for (; yMTdFIYe62i > W6aqmU;) {
            if (GUoHSe[W6aqmU +(129 - 128)] == GUoHSe[W6aqmU]) {
                x2C4atncI = x2C4atncI + (597 - 596);
            }
            if (GUoHSe[W6aqmU +(452 - 451)] != GUoHSe[W6aqmU]) {
                cout << "(" << GUoHSe[W6aqmU] << "," << x2C4atncI << ")";
                x2C4atncI = (489 - 488);
            }
            W6aqmU = W6aqmU +(391 - 390);
        }
    }
    return (131 - 131);
}

