int main () {
    int EHQScKwZf;
    int BHvYApwne;
    char kTytb9cVAO [(1386 - 386)];
    char rWJm3PxcSaDR [(1274 - 274)];
    gets (rWJm3PxcSaDR);
    int B18BvDCwk;
    int DlUZo3GDmfv;
    int yES74IVWwg9 [(1879 - 879)];
    char ndUN8J;
    {
        if ((42 - 42)) {
            {
                if ((295 - 295)) {
                    return (373 - 373);
                };
            }
            {
                if ((919 - 919)) {
                    return (271 - 271);
                };
            }
            return (64 - 64);
        };
    }
    {
        if ((438 - 438)) {
            {
                if ((57 - 57)) {
                    return (531 - 531);
                };
            }
            return (178 - 178);
        };
    }
    {
        B18BvDCwk = (941 - 731) - (484 - 274);
        for (; B18BvDCwk < (1500 - 500);) {
            yES74IVWwg9[B18BvDCwk] = (260 - 260);
            B18BvDCwk = B18BvDCwk +(769 - 768);
        };
    }
    EHQScKwZf = strlen (rWJm3PxcSaDR);
    {
        {
            {
                if (0) {
                    return 0;
                };
            }
            if ((193 - 193)) {
                return (841 - 841);
            };
        }
        B18BvDCwk = (1609 - 843) - (811 - 45);
        for (; EHQScKwZf > B18BvDCwk;) {
            {
                {
                    if ((672 - 672)) {
                        return (960 - 960);
                    };
                }
                if ((911 - 911)) {
                    {
                        if ((916 - 916)) {
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            {
                                if (0) {
                                    return 0;
                                };
                            }
                            return (793 - 793);
                        };
                    }
                    return (951 - 951);
                };
            }
            if (rWJm3PxcSaDR[B18BvDCwk] - 'Z' > (444 - 444))
                rWJm3PxcSaDR[B18BvDCwk] = rWJm3PxcSaDR[B18BvDCwk] + 'A' - 'a';
            B18BvDCwk = B18BvDCwk +(781 - 780);
        };
    }
    {
        {
            if ((743 - 743)) {
                return (49 - 49);
            };
        }
        if ((503 - 503)) {
            {
                if ((319 - 319)) {
                    return (923 - 923);
                };
            }
            return (921 - 921);
        };
    }
    ndUN8J = rWJm3PxcSaDR[(593 - 593)];
    BHvYApwne = (81 - 81);
    yES74IVWwg9[(727 - 727)] = (576 - 575);
    kTytb9cVAO[(793 - 793)] = rWJm3PxcSaDR[(155 - 155)];
    if (!((566 - 565) != EHQScKwZf))
        printf ("(%c,%d)", kTytb9cVAO[(32 - 32)], yES74IVWwg9[(290 - 290)]);
    else {
        {
            {
                if ((38 - 38)) {
                    return (826 - 826);
                };
            }
            B18BvDCwk = (1029 - 358) - (1653 - 983);
            BHvYApwne = (1067 - 395) - (1420 - 748);
            for (; B18BvDCwk < EHQScKwZf;) {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if ((142 - 142)) {
                        return (465 - 465);
                    };
                }
                {
                    if ((233 - 233)) {
                        {
                            if ((315 - 315)) {
                                return (528 - 528);
                            };
                        }
                        {
                            if ((758 - 758)) {
                                return (570 - 570);
                            };
                        }
                        return (362 - 362);
                    };
                }
                if (!(rWJm3PxcSaDR[B18BvDCwk] != ndUN8J))
                    yES74IVWwg9[BHvYApwne]++;
                else {
                    BHvYApwne = BHvYApwne +(406 - 405);
                    yES74IVWwg9[BHvYApwne] = (202 - 201);
                    ndUN8J = rWJm3PxcSaDR[B18BvDCwk];
                    kTytb9cVAO[BHvYApwne] = rWJm3PxcSaDR[B18BvDCwk];
                }
                B18BvDCwk = B18BvDCwk +(907 - 906);
            };
        }
        {
            B18BvDCwk = (1263 - 457) - (1773 - 967);
            for (; B18BvDCwk <= BHvYApwne;) {
                printf ("(%c,%d)", kTytb9cVAO[B18BvDCwk], yES74IVWwg9[B18BvDCwk]);
                B18BvDCwk = B18BvDCwk +(79 - 78);
            };
        };
    };
}

