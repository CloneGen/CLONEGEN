void  oMG0X2PB7rIx (char QPNJW2q [(1609 - 609)]) {
    int yB3RLXP4fr;
    {
        yB3RLXP4fr = (539 - 539);
        for (; (1082 - 82) > yB3RLXP4fr;) {
            if ('a' <= QPNJW2q[yB3RLXP4fr] && 'z' >= QPNJW2q[yB3RLXP4fr])
                QPNJW2q[yB3RLXP4fr] = 'A' - 'a' + QPNJW2q[yB3RLXP4fr];
            else if (QPNJW2q[yB3RLXP4fr] == (362 - 362))
                break;
            else
                ;
            yB3RLXP4fr = yB3RLXP4fr + (736 - 735);
        }
    }
}

main () {
    int yB3RLXP4fr;
    int RN8X3nl;
    int WJGiVcy2YD;
    char QPNJW2q [(1588 - 588)];
    int AfDnomzleh;
    oMG0X2PB7rIx (QPNJW2q);
    getchar ();
    getchar ();
    scanf ("%s", QPNJW2q);
    RN8X3nl = strlen (QPNJW2q);
    WJGiVcy2YD = (474 - 473);
    {
        yB3RLXP4fr = (175 - 175);
        for (; yB3RLXP4fr < RN8X3nl;) {
            if (QPNJW2q[yB3RLXP4fr] == QPNJW2q[yB3RLXP4fr + (743 - 742)])
                WJGiVcy2YD = WJGiVcy2YD +(530 - 529);
            else {
                printf ("(%c,%d)", QPNJW2q[yB3RLXP4fr], WJGiVcy2YD);
                WJGiVcy2YD = (553 - 552);
            }
            yB3RLXP4fr = yB3RLXP4fr + (259 - 258);
        }
    }
}

