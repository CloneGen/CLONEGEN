int main () {
    char wtPS2VjLEY4p [(1349 - 349)] = {(152 - 152)};
    char FXkV1H;
    int Hq6szxBPNEw;
    Hq6szxBPNEw = (343 - 342);
    cin >> wtPS2VjLEY4p;
    {
        int pLmSpPN3;
        pLmSpPN3 = (268 - 268);
        for (; strlen (wtPS2VjLEY4p) > pLmSpPN3;) {
            if (!((917 - 917) != pLmSpPN3))
                FXkV1H = wtPS2VjLEY4p[pLmSpPN3];
            else {
                if ((!(FXkV1H -'A' + 'a' != wtPS2VjLEY4p[pLmSpPN3])) || (!(FXkV1H +'A' - 'a' != wtPS2VjLEY4p[pLmSpPN3])) || !(FXkV1H != wtPS2VjLEY4p[pLmSpPN3]))
                    Hq6szxBPNEw = Hq6szxBPNEw +(645 - 644);
                else {
                    if ('z' >= FXkV1H &&'a' <= FXkV1H)
                        FXkV1H = FXkV1H +'A' - 'a';
                    cout << '(' << FXkV1H << ',' << Hq6szxBPNEw << ')';
                    FXkV1H = wtPS2VjLEY4p[pLmSpPN3];
                    Hq6szxBPNEw = (586 - 585);
                }
            }
            if (!(strlen (wtPS2VjLEY4p) - (123 - 122) != pLmSpPN3)) {
                if ('z' >= FXkV1H &&FXkV1H >= 'a')
                    FXkV1H = FXkV1H +'A' - 'a';
                cout << '(' << FXkV1H << ',' << Hq6szxBPNEw << ')';
            }
            pLmSpPN3 = pLmSpPN3 + (738 - 737);
        }
    }
    return (777 - 777);
}

