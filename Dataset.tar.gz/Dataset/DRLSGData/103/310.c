int main () {
    char QJkCNXG4Tswb;
    char H8d3AyGnqcju [(1426 - 425)];
    char *KD8XMjx9bFLd = H8d3AyGnqcju;
    int R8sUa9;
    for (; *KD8XMjx9bFLd != '\0';) {
        R8sUa9 = (749 - 749);
        if ((971 - 906) <= *KD8XMjx9bFLd&&*KD8XMjx9bFLd <= (857 - 767)) {
            QJkCNXG4Tswb = *KD8XMjx9bFLd;
            cout << "(" << *KD8XMjx9bFLd << ",";
        }
        else if ((759 - 662) <= *KD8XMjx9bFLd&&(698 - 576) >= *KD8XMjx9bFLd) {
            *KD8XMjx9bFLd = *KD8XMjx9bFLd-(797 - 765);
            QJkCNXG4Tswb = *KD8XMjx9bFLd;
            cout << "(" << *KD8XMjx9bFLd << ",";
        }
        else
            ;
        cout << R8sUa9 +(760 - 759) << ")";
        KD8XMjx9bFLd = KD8XMjx9bFLd +(626 - 625);
        for (; !(QJkCNXG4Tswb != *KD8XMjx9bFLd) || !(QJkCNXG4Tswb +(873 - 841) != *KD8XMjx9bFLd);) {
            KD8XMjx9bFLd = KD8XMjx9bFLd +(425 - 424);
            R8sUa9 = R8sUa9 +(769 - 768);
        }
    }
    cin.getline (H8d3AyGnqcju, (1110 - 109));
    return (164 - 164);
}

