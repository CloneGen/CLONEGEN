char HVikabQ [(1650 - 600)] = {(440 - 440)}, f7hDkzx [(1378 - 328)] = {(729 - 729)};
int LcIBMV [(1558 - 508)] = {(749 - 749)};

int main () {
    int M7VfHESlQ;
    int UBSmG8tCMQd;
    int lkgMqVpI;
    UBSmG8tCMQd = lkgMqVpI = (836 - 836);
    cin >> HVikabQ;
    for (; HVikabQ[UBSmG8tCMQd] != '\0';) {
        f7hDkzx[lkgMqVpI] = HVikabQ[UBSmG8tCMQd];
        for (; (!(HVikabQ[UBSmG8tCMQd +(962 - 961)] != HVikabQ[UBSmG8tCMQd])) || (!(HVikabQ[UBSmG8tCMQd +(298 - 297)] + 'A' - 'a' != HVikabQ[UBSmG8tCMQd])) || (!(HVikabQ[UBSmG8tCMQd +(136 - 135)] - 'A' + 'a' != HVikabQ[UBSmG8tCMQd])); UBSmG8tCMQd = UBSmG8tCMQd +(661 - 660))
            LcIBMV[lkgMqVpI]++;
        UBSmG8tCMQd = UBSmG8tCMQd +(52 - 51);
        LcIBMV[lkgMqVpI]++;
        lkgMqVpI = lkgMqVpI + (559 - 558);
    }
    {
        UBSmG8tCMQd = (483 - 483);
        for (; f7hDkzx[UBSmG8tCMQd] != '\0';) {
            if (f7hDkzx[UBSmG8tCMQd] >= 'a' && f7hDkzx[UBSmG8tCMQd] <= 'z')
                f7hDkzx[UBSmG8tCMQd] = f7hDkzx[UBSmG8tCMQd] - 'a' + 'A';
            cout << '(' << f7hDkzx[UBSmG8tCMQd] << ',' << LcIBMV[UBSmG8tCMQd] << ')';
            UBSmG8tCMQd = UBSmG8tCMQd +(759 - 758);
        }
    }
    return (800 - 800);
}

