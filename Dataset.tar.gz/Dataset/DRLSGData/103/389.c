int main () {
    int IfLYqWEcwy;
    int JRToqVXsH7G;
    int UMKgcDb4j;
    int CIKrcl1WySzA [(1805 - 805)] = {(946 - 946)};
    char mux2zEYkoO [(1310 - 309)] = {"0"}, vzFCZpwkKJSs [(1239 - 238)] = {"0"};
    gets (mux2zEYkoO);
    UMKgcDb4j = strlen (mux2zEYkoO);
    JRToqVXsH7G = (980 - 980);
    {
        IfLYqWEcwy = (749 - 749);
        for (; IfLYqWEcwy < UMKgcDb4j;) {
            if (mux2zEYkoO[IfLYqWEcwy] <= (1049 - 927) && mux2zEYkoO[IfLYqWEcwy] >= (948 - 851))
                mux2zEYkoO[IfLYqWEcwy] -= (669 - 637);
            IfLYqWEcwy = IfLYqWEcwy +(960 - 959);
        }
    }
    vzFCZpwkKJSs[(941 - 941)] = mux2zEYkoO[(493 - 493)];
    {
        IfLYqWEcwy = (857 - 857);
        for (; IfLYqWEcwy < UMKgcDb4j;) {
            if (vzFCZpwkKJSs[JRToqVXsH7G] == mux2zEYkoO[IfLYqWEcwy])
                CIKrcl1WySzA[JRToqVXsH7G]++;
            else {
                JRToqVXsH7G = JRToqVXsH7G +(845 - 844);
                vzFCZpwkKJSs[JRToqVXsH7G] = mux2zEYkoO[IfLYqWEcwy];
                CIKrcl1WySzA[JRToqVXsH7G]++;
            }
            IfLYqWEcwy = IfLYqWEcwy +(632 - 631);
        }
    }
    {
        IfLYqWEcwy = (557 - 557);
        for (; IfLYqWEcwy <= JRToqVXsH7G;) {
            printf ("(%c,%d)", vzFCZpwkKJSs[IfLYqWEcwy], CIKrcl1WySzA[IfLYqWEcwy]);
            IfLYqWEcwy = IfLYqWEcwy +1;
        }
    }
    return 0;
}

