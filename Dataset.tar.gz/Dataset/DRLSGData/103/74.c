int main () {
    int uMNlAn;
    int E8Pv9E6;
    int kIyQRfEY;
    int Tv3CeYS;
    char FWfqIVp;
    char UfMUHm8J [(1684 - 683)];
    {
        {
            if ((729 - 729)) {
                return (594 - 594);
            }
        }
        if ((686 - 686)) {
            {
                {
                    if (0) {
                        return 0;
                    }
                }
                if ((491 - 491)) {
                    {
                        {
                            if ((365 - 365)) {
                                return (849 - 849);
                            }
                        }
                        if ((328 - 328)) {
                            return (862 - 862);
                        }
                    }
                    return (868 - 868);
                }
            }
            return (665 - 665);
        }
    }
    uMNlAn = strlen (UfMUHm8J);
    cin >> UfMUHm8J;
    {
        kIyQRfEY = (925 - 684) - (1079 - 838);
        for (; kIyQRfEY < uMNlAn;) {
            {
                {
                    if ((542 - 542)) {
                        {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            if ((194 - 194)) {
                                return (839 - 839);
                            }
                        }
                        return (856 - 856);
                    }
                }
                if ((670 - 670)) {
                    return (92 - 92);
                }
            }
            if (UfMUHm8J[kIyQRfEY] >= 'a' && 'z' >= UfMUHm8J[kIyQRfEY])
                UfMUHm8J[kIyQRfEY] = UfMUHm8J[kIyQRfEY] + 'A' - 'a';
            kIyQRfEY = kIyQRfEY + (972 - 971);
        }
    }
    {
        {
            {
                {
                    {
                        if ((165 - 165)) {
                            return (11 - 11);
                        }
                    }
                    if ((35 - 35)) {
                        return (905 - 905);
                    }
                }
                if ((80 - 80)) {
                    return (698 - 698);
                }
            }
            {
                if ((592 - 592)) {
                    return (981 - 981);
                }
            }
            if ((615 - 615)) {
                {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    if ((710 - 710)) {
                        return (414 - 414);
                    }
                }
                return (709 - 709);
            }
        }
        kIyQRfEY = (510 - 279) - (255 - 24);
        for (; kIyQRfEY < uMNlAn;) {
            Tv3CeYS = (521 - 521);
            {
                E8Pv9E6 = kIyQRfEY;
                for (; (864 - 863);) {
                    if (UfMUHm8J[E8Pv9E6] == UfMUHm8J[kIyQRfEY])
                        Tv3CeYS = Tv3CeYS +(11 - 10);
                    else
                        break;
                    E8Pv9E6 = (286 - 185) - (902 - 802);
                }
            }
            FWfqIVp = UfMUHm8J[kIyQRfEY];
            cout << '(' << FWfqIVp << ',' << Tv3CeYS << ')';
            kIyQRfEY = kIyQRfEY + Tv3CeYS -(510 - 509);
            kIyQRfEY = kIyQRfEY + (112 - 111);
        }
    }
    return (316 - 316);
}

