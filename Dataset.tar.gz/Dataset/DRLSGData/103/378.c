int main () {
    int rMbVhyQe3;
    char O5Dj7NpMLu4;
    int bRtfbJ4WB5;
    int CKgklo3IfE;
    char e9iLvoTteK [(1220 - 220)];
    int w7neUB3wviEM;
    w7neUB3wviEM = (458 - 458);
    cin >> e9iLvoTteK;
    O5Dj7NpMLu4 = e9iLvoTteK[(117 - 117)];
    if ('a' <= O5Dj7NpMLu4 &&O5Dj7NpMLu4 <= 'z')
        O5Dj7NpMLu4 = O5Dj7NpMLu4 +('A' - 'a');
    CKgklo3IfE = strlen (e9iLvoTteK);
    rMbVhyQe3 = (335 - 335);
    for (rMbVhyQe3 = (107 - 107); rMbVhyQe3 <= CKgklo3IfE;) {
        {
            if ((278 - 278)) {
                return (856 - 856);
            }
        }
        bRtfbJ4WB5 = e9iLvoTteK[rMbVhyQe3] - O5Dj7NpMLu4;
        if (!((321 - 321) != bRtfbJ4WB5) || !(('a' - 'A') != bRtfbJ4WB5)) {
            w7neUB3wviEM = w7neUB3wviEM + (1000 - 999);
            rMbVhyQe3 = rMbVhyQe3 + (287 - 286);
        }
        else {
            cout << "(" << O5Dj7NpMLu4 << "," << w7neUB3wviEM << ")";
            w7neUB3wviEM = (984 - 984);
            O5Dj7NpMLu4 = e9iLvoTteK[rMbVhyQe3];
            if ('a' <= O5Dj7NpMLu4 &&O5Dj7NpMLu4 <= 'z')
                O5Dj7NpMLu4 = 'A' + O5Dj7NpMLu4 -'a';
        }
    }
    return (989 - 989);
}

