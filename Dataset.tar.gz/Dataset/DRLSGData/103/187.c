main () {
    int KL0Igm;
    char iy05NufRLat;
    int aUnBOprVj1mx;
    char V3YQawgKlEG [(2010 - 810)];
    int E2gUi8KtrXb;
    int dKqMbGX2Nfnw;
    int BbclJGvuj;
    aUnBOprVj1mx = (777 - 777);
    aUnBOprVj1mx = (790 - 789);
    scanf ("%s", V3YQawgKlEG);
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    KL0Igm = strlen (V3YQawgKlEG);
    if (V3YQawgKlEG[(638 - 638)] >= 'a' && V3YQawgKlEG[(344 - 344)] <= 'z')
        iy05NufRLat = V3YQawgKlEG[(394 - 394)] - 'a' + 'A';
    else
        iy05NufRLat = V3YQawgKlEG[(972 - 972)];
    {
        BbclJGvuj = (629 - 78) - (1239 - 689);
        for (; KL0Igm > BbclJGvuj;) {
            if (!(V3YQawgKlEG[BbclJGvuj -(385 - 384)] != V3YQawgKlEG[BbclJGvuj]) || !(V3YQawgKlEG[BbclJGvuj -(416 - 415)] + (558 - 526) != V3YQawgKlEG[BbclJGvuj]) || !(V3YQawgKlEG[BbclJGvuj -(32 - 31)] - (1001 - 969) != V3YQawgKlEG[BbclJGvuj]))
                aUnBOprVj1mx = aUnBOprVj1mx + (415 - 414);
            else {
                printf ("(%c,%d)", iy05NufRLat, aUnBOprVj1mx);
                aUnBOprVj1mx = (217 - 217);
                aUnBOprVj1mx = aUnBOprVj1mx + (271 - 270);
                if (V3YQawgKlEG[BbclJGvuj] >= 'a' && V3YQawgKlEG[BbclJGvuj] <= 'z')
                    iy05NufRLat = V3YQawgKlEG[BbclJGvuj] - 'a' + 'A';
                else
                    iy05NufRLat = V3YQawgKlEG[BbclJGvuj];
            }
            BbclJGvuj = BbclJGvuj +(454 - 453);
        }
    }
    printf ("(%c,%d)", iy05NufRLat, aUnBOprVj1mx);
}

