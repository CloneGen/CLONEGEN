int main () {
    char wLhZjyPzuI;
    int vF8DTUpvrn;
    int EvX7O2N;
    char CsEgz9cuCj;
    vF8DTUpvrn = (947 - 946);
    CsEgz9cuCj = '0';
    EvX7O2N = (348 - 347);
    for (; (wLhZjyPzuI = cin.get ()) != '\n';) {
        EvX7O2N = (539 - 538);
        if ('a' <= CsEgz9cuCj &&CsEgz9cuCj <= 'z')
            if (!(CsEgz9cuCj != wLhZjyPzuI) || !(CsEgz9cuCj -(865 - 833) != wLhZjyPzuI)) {
                EvX7O2N = (634 - 634);
                vF8DTUpvrn = vF8DTUpvrn + (11 - 10);
            }
        if ('A' <= CsEgz9cuCj &&CsEgz9cuCj <= 'Z')
            if (!(CsEgz9cuCj != wLhZjyPzuI) || !(CsEgz9cuCj +(901 - 869) != wLhZjyPzuI)) {
                EvX7O2N = (803 - 803);
                vF8DTUpvrn = vF8DTUpvrn + (846 - 845);
            }
        if (EvX7O2N) {
            if (CsEgz9cuCj != '0')
                cout << vF8DTUpvrn << ")";
            vF8DTUpvrn = (561 - 560);
            if (!('a' != wLhZjyPzuI)) {
                cout << "(A,";
            }
            else {
                if (!('A' != wLhZjyPzuI)) {
                    cout << "(A,";
                }
                else {
                    if (!('b' != wLhZjyPzuI)) {
                        cout << "(B,";
                    }
                    else {
                        if (!('B' != wLhZjyPzuI)) {
                            cout << "(B,";
                        }
                        else {
                            if (!('c' != wLhZjyPzuI)) {
                                cout << "(C,";
                            }
                            else {
                                if (!('C' != wLhZjyPzuI)) {
                                    cout << "(C,";
                                }
                                else {
                                    if (!('d' != wLhZjyPzuI)) {
                                        cout << "(D,";
                                    }
                                    else {
                                        if (!('D' != wLhZjyPzuI)) {
                                            cout << "(D,";
                                        }
                                        else {
                                            if (!('e' != wLhZjyPzuI)) {
                                                cout << "(E,";
                                            }
                                            else {
                                                if (!('E' != wLhZjyPzuI)) {
                                                    cout << "(E,";
                                                }
                                                else {
                                                    if (!('f' != wLhZjyPzuI)) {
                                                        cout << "(F,";
                                                    }
                                                    else {
                                                        if (!('F' != wLhZjyPzuI)) {
                                                            cout << "(F,";
                                                        }
                                                        else {
                                                            if (!('g' != wLhZjyPzuI)) {
                                                                cout << "(G,";
                                                            }
                                                            else {
                                                                if (!('G' != wLhZjyPzuI)) {
                                                                    cout << "(G,";
                                                                }
                                                                else {
                                                                    if (!('h' != wLhZjyPzuI)) {
                                                                        cout << "(H,";
                                                                    }
                                                                    else {
                                                                        if (!('H' != wLhZjyPzuI)) {
                                                                            cout << "(H,";
                                                                        }
                                                                        else {
                                                                            if (!('i' != wLhZjyPzuI)) {
                                                                                cout << "(I,";
                                                                            }
                                                                            else {
                                                                                if (!('I' != wLhZjyPzuI)) {
                                                                                    cout << "(I,";
                                                                                }
                                                                                else {
                                                                                    if (!('j' != wLhZjyPzuI)) {
                                                                                        cout << "(J,";
                                                                                    }
                                                                                    else {
                                                                                        if (!('J' != wLhZjyPzuI)) {
                                                                                            cout << "(J,";
                                                                                        }
                                                                                        else {
                                                                                            if (!('k' != wLhZjyPzuI)) {
                                                                                                cout << "(K,";
                                                                                            }
                                                                                            else {
                                                                                                if (!('K' != wLhZjyPzuI)) {
                                                                                                    cout << "(K,";
                                                                                                }
                                                                                                else {
                                                                                                    if (!('l' != wLhZjyPzuI)) {
                                                                                                        cout << "(L,";
                                                                                                    }
                                                                                                    else {
                                                                                                        if (!('L' != wLhZjyPzuI)) {
                                                                                                            cout << "(L,";
                                                                                                        }
                                                                                                        else if (!('m' != wLhZjyPzuI)) {
                                                                                                            cout << "(M,";
                                                                                                        }
                                                                                                        else {
                                                                                                            if (!('M' != wLhZjyPzuI)) {
                                                                                                                cout << "(M,";
                                                                                                            }
                                                                                                            else {
                                                                                                                if (!('n' != wLhZjyPzuI)) {
                                                                                                                    cout << "(N,";
                                                                                                                }
                                                                                                                else {
                                                                                                                    if (!('N' != wLhZjyPzuI)) {
                                                                                                                        cout << "(N,";
                                                                                                                    }
                                                                                                                    else {
                                                                                                                        if (!('o' != wLhZjyPzuI)) {
                                                                                                                            cout << "(O,";
                                                                                                                        }
                                                                                                                        else if (!('O' != wLhZjyPzuI)) {
                                                                                                                            cout << "(O,";
                                                                                                                        }
                                                                                                                        else if (!('p' != wLhZjyPzuI)) {
                                                                                                                            cout << "(P,";
                                                                                                                        }
                                                                                                                        else if (!('P' != wLhZjyPzuI)) {
                                                                                                                            cout << "(P,";
                                                                                                                        }
                                                                                                                        else if (!('q' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Q,";
                                                                                                                        }
                                                                                                                        else if (!('Q' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Q,";
                                                                                                                        }
                                                                                                                        else if (!('r' != wLhZjyPzuI)) {
                                                                                                                            cout << "(R,";
                                                                                                                        }
                                                                                                                        else if (!('R' != wLhZjyPzuI)) {
                                                                                                                            cout << "(R,";
                                                                                                                        }
                                                                                                                        else if (!('s' != wLhZjyPzuI)) {
                                                                                                                            cout << "(S,";
                                                                                                                        }
                                                                                                                        else if (!('S' != wLhZjyPzuI)) {
                                                                                                                            cout << "(S,";
                                                                                                                        }
                                                                                                                        else if (!('t' != wLhZjyPzuI)) {
                                                                                                                            cout << "(T,";
                                                                                                                        }
                                                                                                                        else if (!('T' != wLhZjyPzuI)) {
                                                                                                                            cout << "(T,";
                                                                                                                        }
                                                                                                                        else if (!('u' != wLhZjyPzuI)) {
                                                                                                                            cout << "(U,";
                                                                                                                        }
                                                                                                                        else if (!('U' != wLhZjyPzuI)) {
                                                                                                                            cout << "(U,";
                                                                                                                        }
                                                                                                                        else if (!('v' != wLhZjyPzuI)) {
                                                                                                                            cout << "(V,";
                                                                                                                        }
                                                                                                                        else if (!('V' != wLhZjyPzuI)) {
                                                                                                                            cout << "(V,";
                                                                                                                        }
                                                                                                                        else if (!('w' != wLhZjyPzuI)) {
                                                                                                                            cout << "(W,";
                                                                                                                        }
                                                                                                                        else if (!('W' != wLhZjyPzuI)) {
                                                                                                                            cout << "(W,";
                                                                                                                        }
                                                                                                                        else if (!('x' != wLhZjyPzuI)) {
                                                                                                                            cout << "(X,";
                                                                                                                        }
                                                                                                                        else if (!('X' != wLhZjyPzuI)) {
                                                                                                                            cout << "(X,";
                                                                                                                        }
                                                                                                                        else if (!('y' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Y,";
                                                                                                                        }
                                                                                                                        else if (!('Y' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Y,";
                                                                                                                        }
                                                                                                                        else if (!('z' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Z,";
                                                                                                                        }
                                                                                                                        else if (!('Z' != wLhZjyPzuI)) {
                                                                                                                            cout << "(Z,";
                                                                                                                        }
                                                                                                                        else {
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            CsEgz9cuCj = wLhZjyPzuI;
        }
    }
    cout << vF8DTUpvrn << ")" << endl;
    return (329 - 329);
}

