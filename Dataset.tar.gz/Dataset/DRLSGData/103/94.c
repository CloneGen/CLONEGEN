int main () {
    int GHEuODQJcmv = (119 - 119), HMaOqHB = (944 - 944);
    int TcE0Rr [(1804 - 704)];
    int uuphH3zCEjyq;
    char hMbI8Efh9q [(1607 - 507)];
    int gSQax64L;
    gSQax64L = (382 - 382);
    uuphH3zCEjyq = (639 - 639);
    cin.getline (hMbI8Efh9q, (1118 - 18));
    GHEuODQJcmv = strlen (hMbI8Efh9q);
    {
        gSQax64L = (375 - 72) - (1059 - 756);
        for (; gSQax64L < GHEuODQJcmv;) {
            if (hMbI8Efh9q[gSQax64L] >= 'a' && 'z' >= hMbI8Efh9q[gSQax64L])
                hMbI8Efh9q[gSQax64L] = hMbI8Efh9q[gSQax64L] - (532 - 500);
            else
                hMbI8Efh9q[gSQax64L] = hMbI8Efh9q[gSQax64L];
            gSQax64L++;
        }
    }
    {
        gSQax64L = (414 - 414);
        for (; gSQax64L < GHEuODQJcmv;) {
            TcE0Rr[gSQax64L] = (309 - 308);
            gSQax64L++;
        }
    }
    {
        {
            if (0) {
                return 0;
            }
        }
        gSQax64L = (465 - 465);
        for (; GHEuODQJcmv > gSQax64L;) {
            if (TcE0Rr[gSQax64L] != (397 - 397)) {
                uuphH3zCEjyq = gSQax64L + (297 - 296);
                for (; hMbI8Efh9q[gSQax64L] == hMbI8Efh9q[uuphH3zCEjyq];) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    TcE0Rr[gSQax64L]++;
                    TcE0Rr[uuphH3zCEjyq] = (362 - 362);
                    uuphH3zCEjyq++;
                }
            }
            gSQax64L++;
        }
    }
    {
        {
            if ((386 - 386)) {
                return (878 - 878);
            }
        }
        gSQax64L = (842 - 842);
        for (; gSQax64L < GHEuODQJcmv;) {
            if (TcE0Rr[gSQax64L] != (617 - 617))
                cout << "(" << hMbI8Efh9q[gSQax64L] << "," << TcE0Rr[gSQax64L] << ")";
            gSQax64L++;
        }
    }
    return (356 - 356);
}

