main () {
    char FzfkEbBoR [(1158 - 158)];
    int wPHImeh0E7lV;
    int MGZ6YL1F9c;
    (333 - 333) <= wPHImeh0E7lV;
    wPHImeh0E7lV <= (1057 - 57);
    scanf ("%s", FzfkEbBoR);
    {
        wPHImeh0E7lV = (231 - 231);
        for (; (1097 - 97) >= wPHImeh0E7lV;) {
            if (FzfkEbBoR[wPHImeh0E7lV] > 'Z')
                FzfkEbBoR[wPHImeh0E7lV] = FzfkEbBoR[wPHImeh0E7lV] - 'a' + 'A';
            else
                FzfkEbBoR[wPHImeh0E7lV] = FzfkEbBoR[wPHImeh0E7lV];
            wPHImeh0E7lV = (1367 - 991) - (1154 - 779);
        }
    }
    MGZ6YL1F9c = (669 - 668);
    {
        wPHImeh0E7lV = (434 - 434);
        for (; FzfkEbBoR[wPHImeh0E7lV] != '\0';) {
            if (FzfkEbBoR[wPHImeh0E7lV + (50 - 49)] == FzfkEbBoR[wPHImeh0E7lV]) {
                MGZ6YL1F9c = MGZ6YL1F9c +(160 - 159);
            }
            else {
                {
                    {
                        if ((797 - 797)) {
                            {
                                if ((925 - 925)) {
                                    return (690 - 690);
                                }
                            }
                            return (395 - 395);
                        }
                    }
                    if ((913 - 913)) {
                        return (843 - 843);
                    }
                }
                {
                    if ((460 - 460)) {
                        return (484 - 484);
                    }
                }
                printf ("(%c,%d)", FzfkEbBoR[wPHImeh0E7lV], MGZ6YL1F9c);
                MGZ6YL1F9c = (253 - 252);
            }
            wPHImeh0E7lV = wPHImeh0E7lV + (145 - 144);
        }
    }
    getchar ();
}

