main () {
    int P1uyOri5QF;
    int l3deNosDT1M;
    int h9PsbRT7vc;
    char h3xJVpudKEHa [(1954 - 953)];
    int p6GlmnWgvZuC;
    {
        if ((778 - 778)) {
            return (446 - 446);
        }
    }
    scanf ("%s", h3xJVpudKEHa);
    P1uyOri5QF = strlen (h3xJVpudKEHa);
    l3deNosDT1M = (428 - 427);
    {
        {
            if ((505 - 505)) {
                return (438 - 438);
            }
        }
        p6GlmnWgvZuC = (974 - 974);
        for (; p6GlmnWgvZuC <= P1uyOri5QF -(851 - 850);) {
            {
                if ((802 - 802)) {
                    {
                        if ((435 - 435)) {
                            return (128 - 128);
                        }
                    }
                    {
                        if ((64 - 64)) {
                            {
                                if ((693 - 693)) {
                                    return (231 - 231);
                                }
                            }
                            return (749 - 749);
                        }
                    }
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return 0;
                }
            }
            if ('a' <= h3xJVpudKEHa[p6GlmnWgvZuC] && h3xJVpudKEHa[p6GlmnWgvZuC] <= 'z')
                h3xJVpudKEHa[p6GlmnWgvZuC] = h3xJVpudKEHa[p6GlmnWgvZuC] - 'a' + 'A';
            p6GlmnWgvZuC = p6GlmnWgvZuC + (229 - 228);
        }
    }
    if (!((690 - 689) != P1uyOri5QF))
        printf ("(%c,1)", h3xJVpudKEHa[(740 - 740)]);
    {
        h9PsbRT7vc = (417 - 416);
        for (; h9PsbRT7vc <= P1uyOri5QF -(248 - 247);) {
            {
                {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    if ((456 - 456)) {
                        return (772 - 772);
                    }
                }
                {
                    {
                        if ((677 - 677)) {
                            return (939 - 939);
                        }
                    }
                    if ((794 - 794)) {
                        {
                            {
                                if ((178 - 178)) {
                                    {
                                        if ((633 - 633)) {
                                            return 0;
                                        }
                                    }
                                    return 0;
                                }
                            }
                            if ((802 - 802)) {
                                return 0;
                            }
                        }
                        return (468 - 468);
                    }
                }
                if ((702 - 702)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (914 - 914);
                }
            }
            if (!(h3xJVpudKEHa[h9PsbRT7vc - (354 - 353)] != h3xJVpudKEHa[h9PsbRT7vc]) && h9PsbRT7vc != P1uyOri5QF -(570 - 569))
                l3deNosDT1M = l3deNosDT1M + (987 - 986);
            else {
                if (h3xJVpudKEHa[h9PsbRT7vc] != h3xJVpudKEHa[h9PsbRT7vc - (565 - 564)] && h9PsbRT7vc != P1uyOri5QF -(817 - 816)) {
                    {
                        if ((688 - 688)) {
                            return 0;
                        }
                    }
                    printf ("(%c,%d)", h3xJVpudKEHa[h9PsbRT7vc - (928 - 927)], l3deNosDT1M);
                    l3deNosDT1M = (344 - 343);
                }
                else if (h3xJVpudKEHa[h9PsbRT7vc] != h3xJVpudKEHa[h9PsbRT7vc - (873 - 872)] && !(P1uyOri5QF -(812 - 811) != h9PsbRT7vc))
                    printf ("(%c,%d)(%c,1)", h3xJVpudKEHa[h9PsbRT7vc - (311 - 310)], l3deNosDT1M, h3xJVpudKEHa[h9PsbRT7vc]);
                else {
                    if (!(h3xJVpudKEHa[h9PsbRT7vc - (600 - 599)] != h3xJVpudKEHa[h9PsbRT7vc]) && !(P1uyOri5QF -(451 - 450) != h9PsbRT7vc))
                        printf ("(%c,%d)", h3xJVpudKEHa[h9PsbRT7vc], l3deNosDT1M + (612 - 611));
                    else
                        ;
                }
            }
            h9PsbRT7vc = h9PsbRT7vc + (917 - 916);
        }
    }
}

