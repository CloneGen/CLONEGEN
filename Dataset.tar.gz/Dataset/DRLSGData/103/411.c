int main () {
    char wEUsAW [(1106 - 96)] = {(880 - 880)};
    gets (wEUsAW);
    int AhlSDMzCy8e;
    AhlSDMzCy8e = strlen (wEUsAW);
    {
        int Dsk1hruTjnQ;
        Dsk1hruTjnQ = (171 - 171);
        for (; AhlSDMzCy8e > Dsk1hruTjnQ;) {
            wEUsAW[Dsk1hruTjnQ] = toupper (wEUsAW[Dsk1hruTjnQ]);
            Dsk1hruTjnQ = Dsk1hruTjnQ +(218 - 217);
        }
    }
    {
        int Dsk1hruTjnQ;
        Dsk1hruTjnQ = (618 - 618);
        for (; AhlSDMzCy8e > Dsk1hruTjnQ;) {
            int Rbfl84c;
            Rbfl84c = (214 - 213);
            {
                int VsYpdUDzQcfI;
                VsYpdUDzQcfI = Dsk1hruTjnQ +(715 - 714);
                for (; AhlSDMzCy8e > VsYpdUDzQcfI;) {
                    if (wEUsAW[VsYpdUDzQcfI] != wEUsAW[Dsk1hruTjnQ])
                        break;
                    else
                        Rbfl84c = Rbfl84c +(234 - 233);
                    VsYpdUDzQcfI = VsYpdUDzQcfI +(70 - 69);
                }
            }
            printf ("(%c,%d)", wEUsAW[Dsk1hruTjnQ], Rbfl84c);
            Dsk1hruTjnQ = Dsk1hruTjnQ +Rbfl84c-(723 - 722);
            Dsk1hruTjnQ = Dsk1hruTjnQ +(124 - 123);
        }
    }
}

