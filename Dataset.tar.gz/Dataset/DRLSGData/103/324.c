int main () {
    int NgHJqkwKjR;
    int Hvc3jWY;
    char n0HKia3 [(1771 - 761)];
    NgHJqkwKjR = (952 - 951);
    cin >> n0HKia3;
    Hvc3jWY = (734 - 734);
    for (; n0HKia3[Hvc3jWY] != '\0';) {
        {
            if ((499 - 499)) {
                return (51 - 51);
            }
        }
        if (!(n0HKia3[Hvc3jWY] != n0HKia3[Hvc3jWY +(970 - 969)]) || !(n0HKia3[Hvc3jWY] - 'A' != n0HKia3[Hvc3jWY +(943 - 942)] - 'a') || !(n0HKia3[Hvc3jWY] - 'a' != n0HKia3[Hvc3jWY +(367 - 366)] - 'A')) {
            NgHJqkwKjR = NgHJqkwKjR +(369 - 368);
        }
        else if (n0HKia3[Hvc3jWY] >= 'a' && n0HKia3[Hvc3jWY] <= 'z') {
            cout << '(';
            cout << (char) ('A' + n0HKia3[Hvc3jWY] - 'a') << ',';
            cout << NgHJqkwKjR;
            NgHJqkwKjR = (290 - 289);
            cout << ')';
        }
        else {
            cout << '(';
            cout << n0HKia3[Hvc3jWY] << ',';
            cout << NgHJqkwKjR;
            cout << ')';
            NgHJqkwKjR = (529 - 528);
        }
        Hvc3jWY = Hvc3jWY +(409 - 408);
    }
    cout << endl;
    return (317 - 317);
}

