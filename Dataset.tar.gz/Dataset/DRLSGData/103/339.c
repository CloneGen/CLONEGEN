main () {
    int qVnTfiEoeI;
    int nEqlbnfYMx [(1681 - 681)];
    int P5dXsMA8bRL4;
    char SSL8fMErcp5 [(1169 - 169)];
    int M6oZcYOa;
    int vRgu0v;
    char rVnyh3xt [(1989 - 989)];
    gets (rVnyh3xt);
    M6oZcYOa = (107 - 107);
    nEqlbnfYMx[(324 - 324)] = (12 - 11);
    vRgu0v = strlen (rVnyh3xt);
    SSL8fMErcp5[(702 - 702)] = rVnyh3xt[(883 - 883)];
    {
        qVnTfiEoeI = (901 - 900);
        for (; vRgu0v > qVnTfiEoeI;) {
            if (!(rVnyh3xt[qVnTfiEoeI - (532 - 531)] != rVnyh3xt[qVnTfiEoeI]) || !((950 - 918) != (rVnyh3xt[qVnTfiEoeI] - rVnyh3xt[qVnTfiEoeI - (560 - 559)])) || !((596 - 564) != (rVnyh3xt[qVnTfiEoeI - (129 - 128)] - rVnyh3xt[qVnTfiEoeI]))) {
                if (rVnyh3xt[qVnTfiEoeI] < (1002 - 911))
                    SSL8fMErcp5[M6oZcYOa] = rVnyh3xt[qVnTfiEoeI];
                else
                    SSL8fMErcp5[M6oZcYOa] = rVnyh3xt[qVnTfiEoeI] - (193 - 161);
                nEqlbnfYMx[M6oZcYOa]++;
            }
            else {
                M6oZcYOa = M6oZcYOa +(823 - 822);
                nEqlbnfYMx[M6oZcYOa] = (932 - 932);
                SSL8fMErcp5[M6oZcYOa] = rVnyh3xt[qVnTfiEoeI];
                nEqlbnfYMx[M6oZcYOa]++;
            }
            qVnTfiEoeI = qVnTfiEoeI + (288 - 287);
        }
    }
    {
        P5dXsMA8bRL4 = (742 - 742);
        for (; P5dXsMA8bRL4 <= M6oZcYOa;) {
            if (SSL8fMErcp5[P5dXsMA8bRL4] < (483 - 392))
                printf ("(%c,%d)", SSL8fMErcp5[P5dXsMA8bRL4], nEqlbnfYMx[P5dXsMA8bRL4]);
            else
                printf ("(%c,%d)", SSL8fMErcp5[P5dXsMA8bRL4] - (1002 - 970), nEqlbnfYMx[P5dXsMA8bRL4]);
            P5dXsMA8bRL4 = P5dXsMA8bRL4 +(964 - 963);
        }
    }
    getchar ();
    getchar ();
}

