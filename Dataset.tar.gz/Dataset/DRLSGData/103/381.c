int main () {
    int qF1Gf6v;
    char gAPZuvQJ;
    int cBTUYe4i;
    char ysi3tGzT [(1411 - 410)];
    qF1Gf6v = (531 - 530);
    cBTUYe4i = (77 - 77);
    cin >> ysi3tGzT;
    gAPZuvQJ = ysi3tGzT[(988 - 988)];
    for (; ysi3tGzT[cBTUYe4i++] != '\0';) {
        if (!(ysi3tGzT[cBTUYe4i - (96 - 95)] != ysi3tGzT[cBTUYe4i]) || !('a' - 'A' != fabs (ysi3tGzT[cBTUYe4i] - ysi3tGzT[cBTUYe4i - (197 - 196)]))) {
            qF1Gf6v = qF1Gf6v + (13 - 12);
        }
        else {
            if (ysi3tGzT[cBTUYe4i - (915 - 914)] >= 'a' && ysi3tGzT[cBTUYe4i - (994 - 993)] <= 'z')
                ysi3tGzT[cBTUYe4i - (840 - 839)] = ysi3tGzT[cBTUYe4i - (88 - 87)] + 'A' - 'a';
            cout << "(" << ysi3tGzT[cBTUYe4i - (178 - 177)] << "," << qF1Gf6v << ")";
            gAPZuvQJ = ysi3tGzT[cBTUYe4i];
            qF1Gf6v = (787 - 786);
        }
    }
    cout << endl;
    return (216 - 216);
}

