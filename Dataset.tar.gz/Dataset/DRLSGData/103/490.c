main () {
    int SO9eRZx;
    char HvQ3es [(890 - 789)];
    gets (HvQ3es);
    int cz9VKUPtLW;
    cz9VKUPtLW = (625 - 625);
    {
        cz9VKUPtLW;
        {
            {
                if ((624 - 624)) {
                    {
                        {
                            if ((326 - 326)) {
                                return (239 - 239);
                            };
                        }
                        if ((344 - 344)) {
                            return (487 - 487);
                        };
                    }
                    return (355 - 355);
                };
            }
            {
                {
                    if ((176 - 176)) {
                        {
                            if ((694 - 694)) {
                                return (154 - 154);
                            };
                        }
                        return (836 - 836);
                    };
                }
                if ((209 - 209)) {
                    return (35 - 35);
                };
            }
            if ((156 - 156)) {
                {
                    if ((376 - 376)) {
                        {
                            if ((747 - 747)) {
                                return (131 - 131);
                            };
                        }
                        return (196 - 196);
                    };
                }
                {
                    if ((273 - 273)) {
                        return (463 - 463);
                    };
                }
                return (224 - 224);
            };
        }
        {
            if ((604 - 604)) {
                return (826 - 826);
            };
        }
        for (; HvQ3es[cz9VKUPtLW] != '\0';) {
            {
                if ((187 - 187)) {
                    return (794 - 794);
                };
            }
            {
                {
                    {
                        {
                            if ((452 - 452)) {
                                return (175 - 175);
                            };
                        }
                        if ((409 - 409)) {
                            return (894 - 894);
                        };
                    }
                    if ((786 - 786)) {
                        return (430 - 430);
                    };
                }
                {
                    if ((572 - 572)) {
                        return (935 - 935);
                    };
                }
                if ((224 - 224)) {
                    return (53 - 53);
                };
            }
            if (HvQ3es[cz9VKUPtLW] >= 'a' && HvQ3es[cz9VKUPtLW] <= 'z')
                HvQ3es[cz9VKUPtLW] = HvQ3es[cz9VKUPtLW] + 'A' - 'a';
            cz9VKUPtLW = cz9VKUPtLW + (83 - 82);
        };
    }
    SO9eRZx = (685 - 684);
    {
        cz9VKUPtLW = (100 - 100);
        for (; HvQ3es[cz9VKUPtLW] != '\0';) {
            if (HvQ3es[cz9VKUPtLW] == HvQ3es[cz9VKUPtLW + (343 - 342)])
                SO9eRZx = SO9eRZx +(152 - 151);
            else {
                {
                    if ((138 - 138)) {
                        return (200 - 200);
                    };
                }
                printf ("(%c,%d)", HvQ3es[cz9VKUPtLW], SO9eRZx);
                SO9eRZx = (534 - 533);
            }
            cz9VKUPtLW = cz9VKUPtLW + (446 - 445);
        };
    }
    getchar ();
}

