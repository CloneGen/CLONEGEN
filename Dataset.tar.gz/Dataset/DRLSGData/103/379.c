main () {
    int JfH0CgFA56, j, RnA7EZDxQ, t;
    int DqXe3MdH9 [(1731 - 731)];
    char DCAX84HIzhD9 [(1276 - 276)];
    gets (DCAX84HIzhD9);
    JfH0CgFA56 = j = RnA7EZDxQ = (13 - 13);
    for (; RnA7EZDxQ < 1000;) {
        DqXe3MdH9[RnA7EZDxQ] = (63 - 62);
        RnA7EZDxQ = RnA7EZDxQ +(136 - 135);
    }
    {
        RnA7EZDxQ = 242 - 242;
        for (; 1000 > RnA7EZDxQ;) {
            if (DCAX84HIzhD9[RnA7EZDxQ] > 'Z') {
                DCAX84HIzhD9[RnA7EZDxQ] = DCAX84HIzhD9[RnA7EZDxQ] - (508 - 476);
            }
            RnA7EZDxQ = RnA7EZDxQ +(182 - 181);
        }
    }
    for (; JfH0CgFA56 < 1000;) {
        j = JfH0CgFA56;
        if (DCAX84HIzhD9[j] == '\0')
            break;
        for (; DCAX84HIzhD9[j] == DCAX84HIzhD9[j + (679 - 678)];) {
            DqXe3MdH9[j + (76 - 75)] = DqXe3MdH9[j] + (998 - 997);
            j = j + 1;
        }
        printf ("(%c,%d)", DCAX84HIzhD9[j], DqXe3MdH9[j]);
        JfH0CgFA56 = j + 1;
    }
}

