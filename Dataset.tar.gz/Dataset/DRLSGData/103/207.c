int main () {
    struct   comp {
        char aMDb3E;
        int ynTAM4;
    };
    int kXYm16fNLZp, ameqT2zy5f, G4uihl1 = (196 - 196);
    struct   comp WbedBintC [(331 - 231)] [(731 - 705)] = {'A', (483 - 483)};
    char pWogx5dR [(1857 - 857)];
    gets (pWogx5dR);
    {
        kXYm16fNLZp = (569 - 569);
        for (; kXYm16fNLZp < strlen (pWogx5dR);) {
            if (kXYm16fNLZp > (207 - 207))
                if (!(pWogx5dR[kXYm16fNLZp - (174 - 173)] != pWogx5dR[kXYm16fNLZp]) || !(pWogx5dR[kXYm16fNLZp - (689 - 688)] + 'A' - 'a' != pWogx5dR[kXYm16fNLZp]) || !(pWogx5dR[kXYm16fNLZp - (618 - 617)] + 'a' - 'A' != pWogx5dR[kXYm16fNLZp]))
                    ;
                else
                    G4uihl1 = G4uihl1 +(922 - 921);
            {
                ameqT2zy5f = (56 - 56);
                for (; ameqT2zy5f < (627 - 601);) {
                    if (!(pWogx5dR[kXYm16fNLZp] != ameqT2zy5f + 'A') || !(pWogx5dR[kXYm16fNLZp] != ameqT2zy5f + 'a')) {
                        WbedBintC[G4uihl1][ameqT2zy5f].ynTAM4++;
                        WbedBintC[G4uihl1][ameqT2zy5f].aMDb3E = ameqT2zy5f + 'A';
                        break;
                    }
                    ameqT2zy5f = ameqT2zy5f + (719 - 718);
                }
            }
            kXYm16fNLZp = kXYm16fNLZp + (119 - 118);
        }
    }
    {
        G4uihl1 = (35 - 35);
        for (; G4uihl1 < (679 - 579);) {
            {
                ameqT2zy5f = (434 - 434);
                for (; (117 - 91) > ameqT2zy5f;) {
                    if (WbedBintC[G4uihl1][ameqT2zy5f].ynTAM4 != (157 - 157))
                        printf ("(%c,%d)", WbedBintC[G4uihl1][ameqT2zy5f].aMDb3E, WbedBintC[G4uihl1][ameqT2zy5f].ynTAM4);
                    ameqT2zy5f = ameqT2zy5f + (762 - 761);
                }
            }
            G4uihl1 = G4uihl1 +(420 - 419);
        }
    }
    return (398 - 398);
}

