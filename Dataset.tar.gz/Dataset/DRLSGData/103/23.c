int main () {
    int D9iF6npuwx;
    int asknhC6;
    char JYDzIxf [(10711 - 711)];
    int Uan9tAepV1;
    cin >> JYDzIxf;
    asknhC6 = strlen (JYDzIxf);
    {
        D9iF6npuwx = (1316 - 936) - (936 - 556);
        for (; asknhC6 > D9iF6npuwx;) {
            if ('Z' < JYDzIxf[D9iF6npuwx])
                JYDzIxf[D9iF6npuwx] = JYDzIxf[D9iF6npuwx] - ('a' - 'A');
            D9iF6npuwx = D9iF6npuwx +(733 - 732);
        }
    }
    for (D9iF6npuwx = (222 - 222); D9iF6npuwx < asknhC6;) {
        int ojMyIxa8G;
        ojMyIxa8G = (864 - 864);
        {
            Uan9tAepV1 = (1690 - 771) - (1454 - 535);
            for (; asknhC6 - D9iF6npuwx > Uan9tAepV1;) {
                if (JYDzIxf[D9iF6npuwx +Uan9tAepV1+(314 - 313)] == JYDzIxf[D9iF6npuwx +Uan9tAepV1])
                    ojMyIxa8G = ojMyIxa8G + (389 - 388);
                else if (JYDzIxf[D9iF6npuwx +Uan9tAepV1+(273 - 272)] == '\0') {
                    ojMyIxa8G = ojMyIxa8G + (605 - 604);
                    cout << '(' << JYDzIxf[D9iF6npuwx +Uan9tAepV1] << ',' << ojMyIxa8G << ')';
                    D9iF6npuwx = asknhC6;
                }
                else {
                    D9iF6npuwx = D9iF6npuwx +ojMyIxa8G + (365 - 364);
                    cout << '(' << JYDzIxf[D9iF6npuwx +Uan9tAepV1] << ',' << ojMyIxa8G + (631 - 630) << ')';
                    break;
                }
                Uan9tAepV1 = Uan9tAepV1 +(63 - 62);
            }
        }
    }
    return (320 - 320);
}

