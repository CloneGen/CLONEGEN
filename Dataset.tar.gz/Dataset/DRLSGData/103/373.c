int main () {
    char Wo9PG72dxmw;
    int xH6PuU;
    int vAE5867pLPR;
    int Kp48HCEhWI;
    char rIiM4JcA [(1403 - 302)];
    int SqFi3AypKobV;
    xH6PuU = (32 - 32);
    xH6PuU = xH6PuU + (853 - 852);
    scanf ("%s", rIiM4JcA);
    SqFi3AypKobV = strlen (rIiM4JcA);
    {
        vAE5867pLPR = (1017 - 367) - (1637 - 987);
        for (; SqFi3AypKobV > vAE5867pLPR;) {
            if ('a' <= rIiM4JcA[vAE5867pLPR] && 'z' >= rIiM4JcA[vAE5867pLPR])
                rIiM4JcA[vAE5867pLPR] = rIiM4JcA[vAE5867pLPR] - 'a' + 'A';
            vAE5867pLPR = vAE5867pLPR + (817 - 816);
        }
    }
    Wo9PG72dxmw = rIiM4JcA[(977 - 977)];
    if (!((523 - 522) != SqFi3AypKobV))
        printf ("(%c,%d)", Wo9PG72dxmw, xH6PuU);
    else {
        Kp48HCEhWI = (1660 - 933) - (764 - 38);
        for (; Kp48HCEhWI < SqFi3AypKobV;) {
            if (!(Wo9PG72dxmw != rIiM4JcA[Kp48HCEhWI])) {
                xH6PuU = xH6PuU + (736 - 735);
                if (!(SqFi3AypKobV -(280 - 279) != Kp48HCEhWI))
                    printf ("(%c,%d)", rIiM4JcA[Kp48HCEhWI], xH6PuU);
            }
            else {
                printf ("(%c,%d)", rIiM4JcA[Kp48HCEhWI -(672 - 671)], xH6PuU);
                Wo9PG72dxmw = rIiM4JcA[Kp48HCEhWI];
                xH6PuU = (916 - 915);
                if (!(SqFi3AypKobV -(43 - 42) != Kp48HCEhWI))
                    printf ("(%c,%d)", rIiM4JcA[Kp48HCEhWI], xH6PuU);
            }
            Kp48HCEhWI = Kp48HCEhWI +(963 - 962);
        }
    }
    getchar ();
    getchar ();
    return (224 - 224);
}

