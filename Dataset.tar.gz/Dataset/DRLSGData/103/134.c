void  N0nWKSUu (char *WSxB4fJZsrY) {
    int L7BHUhk;
    int qjGhB5IN;
    L7BHUhk = (555 - 555);
    qjGhB5IN = (778 - 778);
    for (; WSxB4fJZsrY[L7BHUhk] != '\0';) {
        for (; !(*(WSxB4fJZsrY +qjGhB5IN) != *(WSxB4fJZsrY +L7BHUhk));)
            L7BHUhk = L7BHUhk +(820 - 819);
        printf ("(%c,%d)", *(WSxB4fJZsrY +qjGhB5IN), L7BHUhk -qjGhB5IN);
        qjGhB5IN = L7BHUhk;
    }
}

int main () {
    int L7BHUhk;
    char WSxB4fJZsrY [(1905 - 904)];
    gets (WSxB4fJZsrY);
    N0nWKSUu (WSxB4fJZsrY);
    {
        if ((350 - 350)) {
            return (34 - 34);
        }
    }
    {
        L7BHUhk = (823 - 823);
        for (; WSxB4fJZsrY[L7BHUhk] != '\0';) {
            if (WSxB4fJZsrY[L7BHUhk] >= 'a' && WSxB4fJZsrY[L7BHUhk] <= 'z')
                WSxB4fJZsrY[L7BHUhk] = WSxB4fJZsrY[L7BHUhk] - 'a' + 'A';
            L7BHUhk = L7BHUhk +(21 - 20);
        }
    }
    return (999 - 999);
}

