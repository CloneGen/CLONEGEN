int main () {
    char RzTQdugEO [(1725 - 725)];
    cin >> RzTQdugEO;
    {
        int O8y0Qcagw57;
        O8y0Qcagw57 = (788 - 788);
        for (; O8y0Qcagw57 < strlen (RzTQdugEO);) {
            if ((RzTQdugEO[O8y0Qcagw57] >= 'a') && (RzTQdugEO[O8y0Qcagw57] <= 'z'))
                RzTQdugEO[O8y0Qcagw57] = RzTQdugEO[O8y0Qcagw57] - (311 - 279);
            O8y0Qcagw57 = O8y0Qcagw57 +(863 - 862);
        }
    }
    {
        int O8y0Qcagw57;
        {
            if ((849 - 849)) {
                return (760 - 760);
            }
        }
        O8y0Qcagw57 = (661 - 661);
        for (; O8y0Qcagw57 < strlen (RzTQdugEO);) {
            int S7o0G31Cjf;
            cout << '(' << RzTQdugEO[O8y0Qcagw57] << ',';
            S7o0G31Cjf = (984 - 983);
            for (; RzTQdugEO[O8y0Qcagw57 +S7o0G31Cjf] == RzTQdugEO[O8y0Qcagw57];) {
                S7o0G31Cjf = S7o0G31Cjf +(640 - 639);
            }
            O8y0Qcagw57 = O8y0Qcagw57 +(S7o0G31Cjf -(307 - 306));
            O8y0Qcagw57 = O8y0Qcagw57 +(402 - 401);
            cout << S7o0G31Cjf << ')';
        }
    }
    cout << endl;
    return (812 - 812);
}

