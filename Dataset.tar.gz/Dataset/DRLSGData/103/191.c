int main () {
    int PD9EKXoGw;
    int NhW7Dc2y9mb;
    char DxdHYIhaZL [(1472 - 471)];
    {
        if ((554 - 554)) {
            return (964 - 964);
        }
    }
    NhW7Dc2y9mb = (952 - 951);
    scanf ("%s", DxdHYIhaZL);
    if (((551 - 455) < DxdHYIhaZL[(902 - 902)]) && ((589 - 466) > DxdHYIhaZL[(378 - 378)]))
        DxdHYIhaZL[(692 - 692)] = DxdHYIhaZL[(131 - 131)] - (173 - 141);
    if (!(strlen (DxdHYIhaZL) != (772 - 771))) {
        printf ("(%c,%d)", DxdHYIhaZL[(453 - 453)], NhW7Dc2y9mb);
    }
    {
        PD9EKXoGw = (371 - 370);
        for (; PD9EKXoGw < strlen (DxdHYIhaZL);) {
            if ((DxdHYIhaZL[PD9EKXoGw] > (183 - 87)) && ((526 - 403) > DxdHYIhaZL[PD9EKXoGw]))
                DxdHYIhaZL[PD9EKXoGw] = DxdHYIhaZL[PD9EKXoGw] - (916 - 884);
            if (!(DxdHYIhaZL[PD9EKXoGw] != DxdHYIhaZL[PD9EKXoGw -(639 - 638)])) {
                NhW7Dc2y9mb = NhW7Dc2y9mb +(95 - 94);
            }
            else {
                printf ("(%c,%d)", DxdHYIhaZL[PD9EKXoGw -(413 - 412)], NhW7Dc2y9mb);
                NhW7Dc2y9mb = (644 - 643);
            }
            if (!((strlen (DxdHYIhaZL) - (66 - 65)) != PD9EKXoGw))
                printf ("(%c,%d)", DxdHYIhaZL[PD9EKXoGw], NhW7Dc2y9mb);
            PD9EKXoGw = PD9EKXoGw +(291 - 290);
        }
    }
    return (718 - 718);
}

