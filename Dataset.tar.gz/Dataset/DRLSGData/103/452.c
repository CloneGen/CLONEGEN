int main () {
    int T9fgsj;
    int URSlU0wD3uG [(1728 - 728)] = {(168 - 168)};
    int MqfLK2AQZFT;
    int RFkq2r;
    char LWE8KJQhD [(1587 - 587)];
    gets (LWE8KJQhD);
    {
        {
            if ((560 - 560)) {
                {
                    if ((571 - 571)) {
                        return (956 - 956);
                    };
                }
                return (778 - 778);
            };
        }
        if ((558 - 558)) {
            {
                if ((500 - 500)) {
                    return (30 - 30);
                };
            }
            return (582 - 582);
        };
    }
    RFkq2r = strlen (LWE8KJQhD);
    {
        {
            {
                {
                    if (0) {
                        return 0;
                    };
                }
                if ((390 - 390)) {
                    return (512 - 512);
                };
            }
            if ((85 - 85)) {
                return (558 - 558);
            };
        }
        MqfLK2AQZFT = (464 - 464);
        for (; RFkq2r > MqfLK2AQZFT;) {
            if (LWE8KJQhD[MqfLK2AQZFT] > (298 - 202))
                LWE8KJQhD[MqfLK2AQZFT] = LWE8KJQhD[MqfLK2AQZFT] - (938 - 906);
            MqfLK2AQZFT = MqfLK2AQZFT +(872 - 871);
        };
    }
    T9fgsj = (650 - 650);
    for (; T9fgsj < RFkq2r;) {
        {
            {
                if ((37 - 37)) {
                    {
                        if ((945 - 945)) {
                            {
                                if ((63 - 63)) {
                                    return (294 - 294);
                                };
                            }
                            return (432 - 432);
                        };
                    }
                    return (935 - 935);
                };
            }
            if ((936 - 936)) {
                {
                    if ((916 - 916)) {
                        return (768 - 768);
                    };
                }
                return (82 - 82);
            };
        }
        MqfLK2AQZFT = (970 - 970);
        for (; MqfLK2AQZFT < RFkq2r -T9fgsj;) {
            if (!(LWE8KJQhD[T9fgsj +MqfLK2AQZFT] != LWE8KJQhD[T9fgsj])) {
                {
                    if ((979 - 979)) {
                        return (793 - 793);
                    };
                }
                if (!(RFkq2r -(316 - 315) != T9fgsj +MqfLK2AQZFT))
                    goto loop;
                URSlU0wD3uG[T9fgsj]++;
            }
            else {
                T9fgsj = T9fgsj +MqfLK2AQZFT;
                break;
            }
            MqfLK2AQZFT = MqfLK2AQZFT +(64 - 63);
        };
    }
loop :
    for (T9fgsj = (145 - 145); T9fgsj < RFkq2r; T9fgsj = T9fgsj +(514 - 513))
        if (URSlU0wD3uG[T9fgsj] != (578 - 578))
            printf ("(%c,%d)", LWE8KJQhD[T9fgsj], URSlU0wD3uG[T9fgsj]);
    return (668 - 668);
}

