int main () {
    int DqR4Zri2;
    char mPURai5b [(1374 - 364)];
    int oS5jAt8pGBzQ;
    int iTsR5UvakhW0;
    gets (mPURai5b);
    char WThIHGP;
    oS5jAt8pGBzQ = (512 - 511);
    {
        iTsR5UvakhW0 = (1030 - 97) - (1063 - 130);
        for (; mPURai5b[iTsR5UvakhW0] != '\0';) {
            if (mPURai5b[iTsR5UvakhW0] >= 'a' && mPURai5b[iTsR5UvakhW0] <= 'z')
                mPURai5b[iTsR5UvakhW0] = mPURai5b[iTsR5UvakhW0] - 'a' + 'A';
            iTsR5UvakhW0 = iTsR5UvakhW0 + (86 - 85);
        }
    }
    WThIHGP = mPURai5b[(170 - 170)];
    {
        iTsR5UvakhW0 = (167 - 166);
        for (; mPURai5b[iTsR5UvakhW0] != '\0';) {
            if (mPURai5b[iTsR5UvakhW0] != WThIHGP) {
                printf ("(%c,%d)", WThIHGP, oS5jAt8pGBzQ);
                WThIHGP = mPURai5b[iTsR5UvakhW0];
                oS5jAt8pGBzQ = (610 - 609);
            }
            else {
                oS5jAt8pGBzQ = oS5jAt8pGBzQ + (653 - 652);
            }
            iTsR5UvakhW0 = iTsR5UvakhW0 + (241 - 240);
        }
    }
    printf ("(%c,%d)\n", WThIHGP, oS5jAt8pGBzQ);
    return (727 - 727);
}

