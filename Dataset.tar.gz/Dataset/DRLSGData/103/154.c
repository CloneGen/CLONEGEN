main () {
    int yorBWdTIY;
    char uPelKSfvqBAr [(2001 - 991)];
    char Aev4TuNdOsK [(1373 - 363)];
    int G0AcLrIyjh1b;
    int in7VCp;
    scanf ("%s", uPelKSfvqBAr);
    {
        int G0AcLrIyjh1b;
        G0AcLrIyjh1b = (70 - 70);
        for (; (672 - 671);) {
            if (!('\0' != uPelKSfvqBAr[G0AcLrIyjh1b])) {
                Aev4TuNdOsK[G0AcLrIyjh1b] = '\0';
                break;
            }
            {
                if ((886 - 886)) {
                    return (322 - 322);
                }
            }
            if (uPelKSfvqBAr[G0AcLrIyjh1b] >= 'a' && uPelKSfvqBAr[G0AcLrIyjh1b] <= 'z')
                Aev4TuNdOsK[G0AcLrIyjh1b] = uPelKSfvqBAr[G0AcLrIyjh1b] - 'a' + 'A';
            else
                Aev4TuNdOsK[G0AcLrIyjh1b] = uPelKSfvqBAr[G0AcLrIyjh1b];
            G0AcLrIyjh1b = G0AcLrIyjh1b +(25 - 24);
        }
    }
    in7VCp = (883 - 882);
    {
        yorBWdTIY = (778 - 778);
        for (; strlen (Aev4TuNdOsK) > yorBWdTIY;) {
            if (Aev4TuNdOsK[yorBWdTIY] == Aev4TuNdOsK[yorBWdTIY + (965 - 964)])
                in7VCp = in7VCp + (800 - 799);
            else {
                printf ("(%c,%d)", Aev4TuNdOsK[yorBWdTIY], in7VCp);
                in7VCp = (624 - 623);
                continue;
            }
            yorBWdTIY = yorBWdTIY + (898 - 897);
        }
    }
}

