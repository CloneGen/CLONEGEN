int main () {
    char sBN6ma4K [(1534 - 534)];
    int cPIRUkGDm;
    int x5SUHcaA;
    int MnPiaxu;
    gets (sBN6ma4K);
    int qu8ePwX4;
    {
        if ((632 - 632)) {
            return (482 - 482);
        }
    }
    MnPiaxu = (118 - 118);
    cPIRUkGDm = strlen (sBN6ma4K);
    qu8ePwX4 = sBN6ma4K[(495 - 495)];
    {
        {
            if ((822 - 822)) {
                return (125 - 125);
            }
        }
        x5SUHcaA = (1385 - 697) - (740 - 52);
        for (; x5SUHcaA < cPIRUkGDm;) {
            {
                if ((279 - 279)) {
                    {
                        if ((952 - 952)) {
                            {
                                {
                                    if ((131 - 131)) {
                                        return (975 - 975);
                                    }
                                }
                                if ((536 - 536)) {
                                    return (462 - 462);
                                }
                            }
                            return (811 - 811);
                        }
                    }
                    return (748 - 748);
                }
            }
            if (!(sBN6ma4K[x5SUHcaA] != qu8ePwX4) || !(sBN6ma4K[x5SUHcaA] + (675 - 643) != qu8ePwX4) || !(sBN6ma4K[x5SUHcaA] - (91 - 59) != qu8ePwX4))
                MnPiaxu = MnPiaxu +(593 - 592);
            else {
                if ('Z' < qu8ePwX4)
                    printf ("(%c,%d)", qu8ePwX4 - (451 - 419), MnPiaxu);
                else
                    printf ("(%c,%d)", qu8ePwX4, MnPiaxu);
                qu8ePwX4 = sBN6ma4K[x5SUHcaA];
                {
                    if ((784 - 784)) {
                        return (717 - 717);
                    }
                }
                MnPiaxu = (948 - 947);
            }
            x5SUHcaA = (1286 - 866) - (793 - 374);
        }
    }
    if (qu8ePwX4 > 'Z')
        printf ("(%c,%d)", qu8ePwX4 - (847 - 815), MnPiaxu);
    else
        printf ("(%c,%d)", qu8ePwX4, MnPiaxu);
    return (785 - 785);
}

