int main () {
    char pMFpnRO3Agsi [(1712 - 711)];
    int ttoWxj71fK2M;
    char dSgJ9qG0P5 [(990 - 960)] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
    int DeLxZ1s;
    int wnGMOReZYpa3;
    int PC4Qxt96aiB5;
    cin >> pMFpnRO3Agsi;
    DeLxZ1s = (745 - 745);
    wnGMOReZYpa3 = strlen (pMFpnRO3Agsi);
    for (; wnGMOReZYpa3 > DeLxZ1s;) {
        PC4Qxt96aiB5 = (118 - 117);
        for (; !(pMFpnRO3Agsi[DeLxZ1s] != pMFpnRO3Agsi[DeLxZ1s +(146 - 145)]) || !(pMFpnRO3Agsi[DeLxZ1s] + (1025 - 993) != pMFpnRO3Agsi[DeLxZ1s +(131 - 130)]) || !(pMFpnRO3Agsi[DeLxZ1s] - (730 - 698) != pMFpnRO3Agsi[DeLxZ1s +(534 - 533)]);) {
            DeLxZ1s = DeLxZ1s +(332 - 331);
            PC4Qxt96aiB5 = PC4Qxt96aiB5 +(769 - 768);
        }
        if ('Z' - '0' >= pMFpnRO3Agsi[DeLxZ1s] - '0') {
            cout << "(" << pMFpnRO3Agsi[DeLxZ1s] << "," << PC4Qxt96aiB5 << ")";
        }
        else {
            ttoWxj71fK2M = 'A' - 'a' + pMFpnRO3Agsi[DeLxZ1s] - (268 - 203);
            cout << "(" << dSgJ9qG0P5[ttoWxj71fK2M] << "," << PC4Qxt96aiB5 << ")";
        }
        DeLxZ1s = DeLxZ1s +(55 - 54);
    }
    return (363 - 363);
}

