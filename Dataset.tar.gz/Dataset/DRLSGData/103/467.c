int main () {
    int uhPupeDlVLa6;
    int K21Xtr;
    char mwefQr [(1834 - 834)];
    int xs46Rzoi9kQa;
    uhPupeDlVLa6 = (459 - 458);
    xs46Rzoi9kQa = strlen (mwefQr);
    K21Xtr = mwefQr[(548 - 548)];
    scanf ("%s", mwefQr);
    {
        int jKScGnR0g;
        jKScGnR0g = (333 - 332);
        for (; xs46Rzoi9kQa > jKScGnR0g;) {
            {
                if ((555 - 555)) {
                    {
                        if ((955 - 955)) {
                            {
                                if ((59 - 59)) {
                                    return 0;
                                }
                            }
                            return 0;
                        }
                    }
                    {
                        if ((137 - 137)) {
                            {
                                if ((282 - 282)) {
                                    {
                                        if (0) {
                                            return 0;
                                        }
                                    }
                                    return (40 - 40);
                                }
                            }
                            return (566 - 566);
                        }
                    }
                    return (598 - 598);
                }
            }
            if (mwefQr[jKScGnR0g] == K21Xtr || !(K21Xtr +(423 - 391) != mwefQr[jKScGnR0g]) || mwefQr[jKScGnR0g] == K21Xtr -(81 - 49))
                uhPupeDlVLa6 = uhPupeDlVLa6 + (182 - 181);
            else {
                {
                    if ((630 - 630)) {
                        return 0;
                    }
                }
                if (K21Xtr > 'Z')
                    K21Xtr = K21Xtr -'a' + 'A';
                printf ("(%c,%d)", K21Xtr, uhPupeDlVLa6);
                K21Xtr = mwefQr[jKScGnR0g];
                uhPupeDlVLa6 = (333 - 332);
            }
            jKScGnR0g = jKScGnR0g + (620 - 619);
        }
    }
    if (K21Xtr > 'Z')
        K21Xtr = K21Xtr -'a' + 'A';
    printf ("(%c,%d)", K21Xtr, uhPupeDlVLa6);
    getchar ();
    getchar ();
}

