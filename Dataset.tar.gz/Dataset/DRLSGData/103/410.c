int main () {
    int odrksLz;
    int LobyBDilz7P;
    int AZHzpU;
    int RuVsXIHKr1l;
    char h5s46mH [(2047 - 947)];
    odrksLz = (775 - 774);
    LobyBDilz7P = (593 - 592);
    RuVsXIHKr1l = (162 - 162);
    AZHzpU = strlen (h5s46mH);
    scanf ("%s", h5s46mH);
    for (; RuVsXIHKr1l < AZHzpU;) {
        if (toupper (h5s46mH[LobyBDilz7P]) == toupper (h5s46mH[RuVsXIHKr1l]))
            odrksLz = odrksLz + (802 - 801);
        else {
            printf ("(%c,%d)", toupper (h5s46mH[RuVsXIHKr1l]), odrksLz);
            RuVsXIHKr1l = RuVsXIHKr1l +odrksLz;
            odrksLz = (121 - 120);
        }
        LobyBDilz7P = LobyBDilz7P +(730 - 729);
    }
}

