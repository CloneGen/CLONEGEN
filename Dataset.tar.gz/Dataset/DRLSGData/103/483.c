int main () {
    char R2e70CROi [(1422 - 422)];
    gets (R2e70CROi);
    int dKThfCwAIG;
    int aQ2to5MdqN;
    int Vtka3qOp;
    int MyWsX2Q30uM;
    aQ2to5MdqN = strlen (R2e70CROi);
    {
        {
            if ((671 - 671)) {
                return (188 - 188);
            };
        }
        MyWsX2Q30uM = (824 - 677) - (632 - 485);
        for (; aQ2to5MdqN - (519 - 518) >= MyWsX2Q30uM;) {
            if ('Z' < R2e70CROi[MyWsX2Q30uM])
                R2e70CROi[MyWsX2Q30uM] = R2e70CROi[MyWsX2Q30uM] + 'A' - 'a';
            MyWsX2Q30uM = (1963 - 966) - (1282 - 286);
        };
    }
    {
        MyWsX2Q30uM = (942 - 381) - (649 - 88);
        for (; (1600 - 601) >= MyWsX2Q30uM;) {
            {
                if ((590 - 590)) {
                    {
                        {
                            if ((751 - 751)) {
                                return (248 - 248);
                            };
                        }
                        if ((32 - 32)) {
                            {
                                if ((451 - 451)) {
                                    {
                                        if ((347 - 347)) {
                                            return (620 - 620);
                                        };
                                    }
                                    return (783 - 783);
                                };
                            }
                            return (485 - 485);
                        };
                    }
                    {
                        if ((881 - 881)) {
                            return (540 - 540);
                        };
                    }
                    return (523 - 523);
                };
            }
            {
                {
                    {
                        if ((341 - 341)) {
                            {
                                if ((883 - 883)) {
                                    return (822 - 822);
                                };
                            }
                            return (615 - 615);
                        };
                    }
                    if ((763 - 763)) {
                        {
                            {
                                if ((745 - 745)) {
                                    return (893 - 893);
                                };
                            }
                            if ((973 - 973)) {
                                return (186 - 186);
                            };
                        }
                        {
                            if ((758 - 758)) {
                                {
                                    if ((256 - 256)) {
                                        return (652 - 652);
                                    };
                                }
                                {
                                    if ((408 - 408)) {
                                        return (763 - 763);
                                    };
                                }
                                return (735 - 735);
                            };
                        }
                        {
                            if ((591 - 591)) {
                                return (33 - 33);
                            };
                        }
                        return (116 - 116);
                    };
                }
                dKThfCwAIG = (440 - 42) - (983 - 586);
                for (; (1072 - 74) > dKThfCwAIG;) {
                    {
                        if ((316 - 316)) {
                            return (947 - 947);
                        };
                    }
                    if (R2e70CROi[MyWsX2Q30uM +dKThfCwAIG] != R2e70CROi[MyWsX2Q30uM]) {
                        cout << "(" << R2e70CROi[MyWsX2Q30uM] << "," << dKThfCwAIG << ")";
                        MyWsX2Q30uM = MyWsX2Q30uM +dKThfCwAIG - (320 - 319);
                        break;
                    }
                    {
                        if ((185 - 185)) {
                            return (462 - 462);
                        };
                    }
                    dKThfCwAIG = dKThfCwAIG + (216 - 215);
                };
            }
            if (MyWsX2Q30uM >= aQ2to5MdqN - (308 - 307))
                break;
            MyWsX2Q30uM = MyWsX2Q30uM +(302 - 301);
        };
    }
    return (743 - 743);
}

