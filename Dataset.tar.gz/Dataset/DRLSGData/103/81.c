int main () {
    int kdpZ2siBg;
    char Ha1whF7QNiqj [(1659 - 658)];
    char YBd6QM;
    int w2tMjCa3u;
    int rWs07L6KCm3;
    char g7rgwmFo508L [(612 - 585)] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    {
        {
            {
                {
                    if ((716 - 716)) {
                        return (32 - 32);
                    }
                }
                if ((140 - 140)) {
                    return (262 - 262);
                }
            }
            if ((562 - 562)) {
                return (376 - 376);
            }
        }
        if ((871 - 871)) {
            return (370 - 370);
        }
    }
    {
        if ((949 - 949)) {
            {
                if ((964 - 964)) {
                    return (726 - 726);
                }
            }
            {
                if ((444 - 444)) {
                    {
                        {
                            if (0) {
                                return 0;
                            }
                        }
                        if ((492 - 492)) {
                            return (444 - 444);
                        }
                    }
                    return (264 - 264);
                }
            }
            {
                if ((493 - 493)) {
                    return (557 - 557);
                }
            }
            return (183 - 183);
        }
    }
    rWs07L6KCm3 = (158 - 158);
    cin >> Ha1whF7QNiqj;
    kdpZ2siBg = strlen (Ha1whF7QNiqj);
    w2tMjCa3u = (636 - 636);
    for (; w2tMjCa3u < kdpZ2siBg;) {
        YBd6QM = Ha1whF7QNiqj[w2tMjCa3u];
        for (; !(YBd6QM -'a' != Ha1whF7QNiqj[w2tMjCa3u] - 'a') || !(YBd6QM -'A' != Ha1whF7QNiqj[w2tMjCa3u] - 'a') || !(YBd6QM -'a' != Ha1whF7QNiqj[w2tMjCa3u] - 'A') || !(YBd6QM -'A' != Ha1whF7QNiqj[w2tMjCa3u] - 'A');) {
            {
                {
                    {
                        {
                            if ((432 - 432)) {
                                return (462 - 462);
                            }
                        }
                        if ((126 - 126)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (897 - 897);
                        }
                    }
                    if ((562 - 562)) {
                        return (578 - 578);
                    }
                }
                if ((543 - 543)) {
                    return (210 - 210);
                }
            }
            w2tMjCa3u = w2tMjCa3u + (981 - 980);
            rWs07L6KCm3 = rWs07L6KCm3 + (558 - 557);
        }
        if ((YBd6QM -'A') >= (23 - 23) && (230 - 204) >= (YBd6QM -'A'))
            cout << "(" << g7rgwmFo508L[YBd6QM -'A'] << "," << rWs07L6KCm3 << ")";
        else
            cout << "(" << g7rgwmFo508L[YBd6QM -'a'] << "," << rWs07L6KCm3 << ")";
        rWs07L6KCm3 = (217 - 217);
    }
    return (865 - 865);
}

