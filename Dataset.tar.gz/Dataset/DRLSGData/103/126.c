int main () {
    char oQhWup6;
    char Jo1drbJfGQE [(1746 - 745)];
    int TyrDN5K6;
    int cnjJQxq;
    TyrDN5K6 = (952 - 951);
    for (; cin >> Jo1drbJfGQE;) {
        if (!((899 - 898) != strlen (Jo1drbJfGQE))) {
            oQhWup6 = Jo1drbJfGQE[(623 - 623)];
            if ((oQhWup6 >= 'a') && (oQhWup6 <= 'z'))
                oQhWup6 = oQhWup6 - 'a' + 'A';
            cout << '(' << oQhWup6 << ',' << (969 - 968) << ')' << endl;
            continue;
        }
        {
            if ((828 - 828)) {
                return (685 - 685);
            }
        }
        {
            cnjJQxq = (625 - 113) - (671 - 159);
            for (; cnjJQxq < strlen (Jo1drbJfGQE);) {
                if (cnjJQxq > (667 - 667)) {
                    if ((!(Jo1drbJfGQE[cnjJQxq] != Jo1drbJfGQE[cnjJQxq - (68 - 67)])) || (!(Jo1drbJfGQE[cnjJQxq] - 'A' + 'a' != Jo1drbJfGQE[cnjJQxq - (137 - 136)])) || (!(Jo1drbJfGQE[cnjJQxq] - 'a' + 'A' != Jo1drbJfGQE[cnjJQxq - (678 - 677)]))) {
                        TyrDN5K6 = TyrDN5K6 +(889 - 888);
                        if (!(strlen (Jo1drbJfGQE) - (534 - 533) != cnjJQxq)) {
                            {
                                if ((428 - 428)) {
                                    return (548 - 548);
                                }
                            }
                            oQhWup6 = Jo1drbJfGQE[cnjJQxq - (357 - 356)];
                            if ((oQhWup6 >= 'a') && (oQhWup6 <= 'z'))
                                oQhWup6 = oQhWup6 - 'a' + 'A';
                            cout << '(' << oQhWup6 << ',' << TyrDN5K6 << ')';
                        }
                    }
                    else {
                        {
                            if ((105 - 105)) {
                                return (168 - 168);
                            }
                        }
                        oQhWup6 = Jo1drbJfGQE[cnjJQxq - (405 - 404)];
                        if ((oQhWup6 >= 'a') && ('z' >= oQhWup6))
                            oQhWup6 = oQhWup6 - 'a' + 'A';
                        cout << '(' << oQhWup6 << ',' << TyrDN5K6 << ')';
                        TyrDN5K6 = (888 - 887);
                        if (!(strlen (Jo1drbJfGQE) - (847 - 846) != cnjJQxq)) {
                            oQhWup6 = Jo1drbJfGQE[cnjJQxq];
                            if (('a' <= oQhWup6) && (oQhWup6 <= 'z'))
                                oQhWup6 = oQhWup6 - 'a' + 'A';
                            cout << '(' << oQhWup6 << ',' << TyrDN5K6 << ')';
                        }
                    }
                }
                cnjJQxq = cnjJQxq + (642 - 641);
            }
        }
        cout << endl;
    }
    return (730 - 730);
}

