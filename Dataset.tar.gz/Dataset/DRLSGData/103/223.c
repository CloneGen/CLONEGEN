int main () {
    char hhwRt0X [(1166 - 164)];
    int p6rthiDoCUS2;
    int an6MrwKthCY;
    gets (hhwRt0X);
    char PbmHEBTgDjL5;
    int X0zgD68jnVC;
    X0zgD68jnVC = strlen (hhwRt0X);
    {
        an6MrwKthCY = (1546 - 908) - (1591 - 953);
        for (; an6MrwKthCY < X0zgD68jnVC;) {
            if (hhwRt0X[an6MrwKthCY] >= 'a' && hhwRt0X[an6MrwKthCY] <= 'z') {
                hhwRt0X[an6MrwKthCY] = hhwRt0X[an6MrwKthCY] - 'a' + 'A';
            }
            an6MrwKthCY = an6MrwKthCY + (445 - 444);
        }
    }
    PbmHEBTgDjL5 = hhwRt0X[(691 - 691)];
    p6rthiDoCUS2 = (299 - 299);
    {
        an6MrwKthCY = (1127 - 995) - (280 - 148);
        for (; an6MrwKthCY < X0zgD68jnVC;) {
            if (hhwRt0X[an6MrwKthCY] == PbmHEBTgDjL5) {
                p6rthiDoCUS2 = p6rthiDoCUS2 + (473 - 472);
            }
            else {
                printf ("(%c,%d)", PbmHEBTgDjL5, p6rthiDoCUS2);
                PbmHEBTgDjL5 = hhwRt0X[an6MrwKthCY];
                p6rthiDoCUS2 = (641 - 640);
            }
            an6MrwKthCY = an6MrwKthCY + (171 - 170);
        }
    }
    printf ("(%c,%d)", PbmHEBTgDjL5, p6rthiDoCUS2);
}

