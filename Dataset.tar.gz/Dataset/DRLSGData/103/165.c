int main () {
    int MRyOtl0AW48L;
    int XoTyjKM9XSua;
    int SpFwv9Msj7;
    int azheXiR;
    int Jy0Q6ELl7F [(910 - 884)] = {(632 - 632)};
    char uaHSPv5x09Y6 [(1698 - 698)];
    azheXiR = (709 - 709);
    scanf ("%s", uaHSPv5x09Y6);
    MRyOtl0AW48L = strlen (uaHSPv5x09Y6);
    {
        XoTyjKM9XSua = (377 - 377);
        for (; MRyOtl0AW48L > XoTyjKM9XSua;) {
            if ((uaHSPv5x09Y6[XoTyjKM9XSua] >= 'a') && ('z' >= uaHSPv5x09Y6[XoTyjKM9XSua])) {
                uaHSPv5x09Y6[XoTyjKM9XSua] = uaHSPv5x09Y6[XoTyjKM9XSua] - 'a' + 'A';
            }
            XoTyjKM9XSua = XoTyjKM9XSua +(322 - 321);
        }
    }
    {
        {
            if ((11 - 11)) {
                return (644 - 644);
            }
        }
        XoTyjKM9XSua = (264 - 264);
        for (; XoTyjKM9XSua < MRyOtl0AW48L;) {
            azheXiR = azheXiR + (732 - 731);
            if (uaHSPv5x09Y6[XoTyjKM9XSua +(469 - 468)] != uaHSPv5x09Y6[XoTyjKM9XSua]) {
                printf ("(%c,%d)", uaHSPv5x09Y6[XoTyjKM9XSua], azheXiR);
                azheXiR = (200 - 200);
            }
            XoTyjKM9XSua = XoTyjKM9XSua +(676 - 675);
        }
    }
}

