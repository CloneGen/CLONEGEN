int main () {
    int EsmK4eB;
    int c3JegZn8GaF;
    char oqOhMtve [(1669 - 669)];
    gets (oqOhMtve);
    char ZKt8Q56l [(1422 - 422)];
    int KMVTXymqO [(1414 - 414)];
    int G7KTikNl;
    {
        G7KTikNl = (1430 - 936) - (1356 - 862);
        for (; oqOhMtve[G7KTikNl] != '\0';) {
            if (oqOhMtve[G7KTikNl] > 'Z')
                oqOhMtve[G7KTikNl] = oqOhMtve[G7KTikNl] - (511 - 479);
            G7KTikNl = G7KTikNl +(396 - 395);
        }
    }
    c3JegZn8GaF = (107 - 106);
    EsmK4eB = (943 - 943);
    {
        G7KTikNl = (721 - 184) - (1174 - 637);
        for (; oqOhMtve[G7KTikNl] != '\0';) {
            if (!(oqOhMtve[G7KTikNl] != oqOhMtve[G7KTikNl +(206 - 205)]))
                c3JegZn8GaF = c3JegZn8GaF + (488 - 487);
            else {
                ZKt8Q56l[EsmK4eB] = oqOhMtve[G7KTikNl];
                KMVTXymqO[EsmK4eB] = c3JegZn8GaF;
                EsmK4eB = EsmK4eB +(840 - 839);
                c3JegZn8GaF = (584 - 583);
            }
            G7KTikNl = G7KTikNl +(536 - 535);
        }
    }
    {
        G7KTikNl = (343 - 343);
        for (; EsmK4eB > G7KTikNl;) {
            printf ("(%c,%d)", ZKt8Q56l[G7KTikNl], KMVTXymqO[G7KTikNl]);
            G7KTikNl = G7KTikNl +(125 - 124);
        }
    }
    return (344 - 344);
}

