int main () {
    int SthWeIL;
    int lUyRdD;
    int qjesfiglo;
    char fKDlrN4O7 [(1538 - 538)];
    gets (fKDlrN4O7);
    {
        {
            if ((998 - 998)) {
                {
                    if ((52 - 52)) {
                        {
                            if ((637 - 637)) {
                                return (47 - 47);
                            }
                        }
                        {
                            if ((782 - 782)) {
                                {
                                    if ((216 - 216)) {
                                        return (175 - 175);
                                    }
                                }
                                return (763 - 763);
                            }
                        }
                        return (891 - 891);
                    }
                }
                return (206 - 206);
            }
        }
        if ((320 - 320)) {
            {
                {
                    if ((46 - 46)) {
                        {
                            if ((225 - 225)) {
                                return (70 - 70);
                            }
                        }
                        return (756 - 756);
                    }
                }
                if ((852 - 852)) {
                    {
                        {
                            if ((596 - 596)) {
                                return (97 - 97);
                            }
                        }
                        if ((195 - 195)) {
                            return (634 - 634);
                        }
                    }
                    return (744 - 744);
                }
            }
            {
                {
                    if ((154 - 154)) {
                        return (587 - 587);
                    }
                }
                if ((404 - 404)) {
                    return (973 - 973);
                }
            }
            {
                {
                    if ((994 - 994)) {
                        {
                            if ((377 - 377)) {
                                return (892 - 892);
                            }
                        }
                        return (110 - 110);
                    }
                }
                if ((482 - 482)) {
                    return (211 - 211);
                }
            }
            return (646 - 646);
        }
    }
    SthWeIL = (63 - 63);
    qjesfiglo = strlen (fKDlrN4O7);
    for (; SthWeIL < qjesfiglo;) {
        int j7mjF3TrROb;
        {
            if ((735 - 735)) {
                return (49 - 49);
            }
        }
        j7mjF3TrROb = (502 - 501);
        lUyRdD = SthWeIL +(49 - 48);
        {
            if ((520 - 520)) {
                return (736 - 736);
            }
        }
        for (; (!(fKDlrN4O7[lUyRdD] != fKDlrN4O7[SthWeIL]) || !(fKDlrN4O7[lUyRdD] - 'a' + 'A' != fKDlrN4O7[SthWeIL]) || !(fKDlrN4O7[lUyRdD] + 'a' - 'A' != fKDlrN4O7[SthWeIL]));) {
            lUyRdD = lUyRdD + (559 - 558);
            j7mjF3TrROb = j7mjF3TrROb + (350 - 349);
        }
        if ('a' <= fKDlrN4O7[SthWeIL] && 'z' >= fKDlrN4O7[SthWeIL])
            fKDlrN4O7[SthWeIL] = fKDlrN4O7[SthWeIL] - 'a' + 'A';
        printf ("(%c,%d)", fKDlrN4O7[SthWeIL], j7mjF3TrROb);
        SthWeIL = lUyRdD;
    }
    {
        {
            if (0) {
                return 0;
            }
        }
        if ((390 - 390)) {
            return 0;
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

