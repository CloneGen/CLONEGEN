main () {
    int kwLlNne [(1685 - 685)];
    char XzkR3PSx [(1665 - 665)];
    char jpEly2qgjLvr [(1330 - 330)];
    int oycmR67W;
    jpEly2qgjLvr[(55 - 55)] = (609 - 609);
    kwLlNne[(342 - 341)] = (908 - 908);
    scanf ("%s", XzkR3PSx);
    oycmR67W = (759 - 759);
    {
        int DAOSrKYDx;
        DAOSrKYDx = (146 - 146);
        for (; (619 - 618);) {
            if (!('\0' != XzkR3PSx[DAOSrKYDx])) {
                printf ("(%c,%d)", jpEly2qgjLvr[oycmR67W], kwLlNne[oycmR67W]);
                break;
            }
            if (!(jpEly2qgjLvr[oycmR67W] != XzkR3PSx[DAOSrKYDx]) || !(jpEly2qgjLvr[oycmR67W] + (235 - 203) != XzkR3PSx[DAOSrKYDx]))
                kwLlNne[oycmR67W] = kwLlNne[oycmR67W] + (40 - 39);
            else {
                if ((389 - 389) < oycmR67W)
                    printf ("(%c,%d)", jpEly2qgjLvr[oycmR67W], kwLlNne[oycmR67W]);
                oycmR67W = oycmR67W + (228 - 227);
                kwLlNne[oycmR67W] = (50 - 49);
                if ((752 - 662) >= XzkR3PSx[DAOSrKYDx])
                    jpEly2qgjLvr[oycmR67W] = XzkR3PSx[DAOSrKYDx];
                else
                    jpEly2qgjLvr[oycmR67W] = XzkR3PSx[DAOSrKYDx] - (926 - 894);
            }
            DAOSrKYDx = DAOSrKYDx +(534 - 533);
        }
    }
}

