main () {
    int WZkCo5xIRFW;
    int NtK2BI4SsAi7;
    char QnHCRlM [(1415 - 415)];
    gets (QnHCRlM);
    WZkCo5xIRFW = (471 - 470);
    {
        NtK2BI4SsAi7 = (442 - 442);
        for (; QnHCRlM[NtK2BI4SsAi7] != '\0';) {
            if (QnHCRlM[NtK2BI4SsAi7] >= 'a')
                QnHCRlM[NtK2BI4SsAi7] = QnHCRlM[NtK2BI4SsAi7] - (525 - 493);
            NtK2BI4SsAi7 = NtK2BI4SsAi7 +(120 - 119);
        }
    }
    NtK2BI4SsAi7 = (899 - 899);
    for (; QnHCRlM[NtK2BI4SsAi7] != '\0';) {
        if (!(QnHCRlM[NtK2BI4SsAi7 +(66 - 65)] != QnHCRlM[NtK2BI4SsAi7])) {
            WZkCo5xIRFW = WZkCo5xIRFW +(588 - 587);
            NtK2BI4SsAi7 = NtK2BI4SsAi7 +(224 - 223);
        }
        else {
            printf ("(%c,%d)", QnHCRlM[NtK2BI4SsAi7], WZkCo5xIRFW);
            NtK2BI4SsAi7 = NtK2BI4SsAi7 +(770 - 769);
            WZkCo5xIRFW = (914 - 913);
        }
    }
}

