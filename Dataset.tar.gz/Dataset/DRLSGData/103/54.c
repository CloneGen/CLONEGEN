int main () {
    int PGZyAzwh6 [(729 - 702)] = {(952 - 952)};
    char vA3WeFbh [(1556 - 556)] = {(602 - 602)};
    int vOqwJH;
    int aL26G0;
    int RR9YhxM;
    aL26G0 = strlen (vA3WeFbh);
    RR9YhxM = (756 - 756);
    cin >> vA3WeFbh;
    {
        RR9YhxM = (920 - 920);
        for (; RR9YhxM < aL26G0;) {
            {
                {
                    if ((921 - 921)) {
                        return (140 - 140);
                    }
                }
                if ((611 - 611)) {
                    return (581 - 581);
                }
            }
            if ('a' <= vA3WeFbh[RR9YhxM])
                vA3WeFbh[RR9YhxM] = vA3WeFbh[RR9YhxM] - ('a' - 'A');
            RR9YhxM = RR9YhxM +(544 - 543);
        }
    }
    {
        {
            if (0) {
                return 0;
            }
        }
        if ((44 - 44)) {
            return (329 - 329);
        }
    }
    vOqwJH = (930 - 930);
    {
        RR9YhxM = (247 - 247);
        for (; aL26G0 > RR9YhxM;) {
            PGZyAzwh6[vA3WeFbh[RR9YhxM] - 'A']++;
            {
                {
                    {
                        if ((113 - 113)) {
                            {
                                if (0) {
                                    return 0;
                                }
                            }
                            return (349 - 349);
                        }
                    }
                    if ((137 - 137)) {
                        {
                            {
                                {
                                    if ((762 - 762)) {
                                        return (201 - 201);
                                    }
                                }
                                if ((196 - 196)) {
                                    return (53 - 53);
                                }
                            }
                            if ((64 - 64)) {
                                return (843 - 843);
                            }
                        }
                        return (858 - 858);
                    }
                }
                vOqwJH = RR9YhxM +(798 - 797);
                for (; aL26G0 > vOqwJH;) {
                    {
                        {
                            if ((557 - 557)) {
                                return (138 - 138);
                            }
                        }
                        if ((27 - 27)) {
                            return (11 - 11);
                        }
                    }
                    if (vA3WeFbh[vOqwJH] == vA3WeFbh[RR9YhxM])
                        PGZyAzwh6[vA3WeFbh[RR9YhxM] - 'A']++;
                    else
                        break;
                    vOqwJH = vOqwJH + (609 - 608);
                }
            }
            {
                if ((369 - 369)) {
                    {
                        {
                            if ((128 - 128)) {
                                return (918 - 918);
                            }
                        }
                        if ((132 - 132)) {
                            return (133 - 133);
                        }
                    }
                    {
                        if ((827 - 827)) {
                            return (212 - 212);
                        }
                    }
                    return (449 - 449);
                }
            }
            cout << '(' << vA3WeFbh[RR9YhxM] << ',' << PGZyAzwh6[vA3WeFbh[RR9YhxM] - 'A'] << ')';
            PGZyAzwh6[vA3WeFbh[RR9YhxM] - 'A'] = (164 - 164);
            RR9YhxM = vOqwJH - (695 - 694);
            RR9YhxM = RR9YhxM +(575 - 574);
        }
    }
    cout << endl;
    return (141 - 141);
}

