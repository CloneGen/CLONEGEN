main () {
    int DwcGfb;
    char jz78KVgQRBo [(10886 - 886)];
    int cKh9LslfRy;
    char OWKUTv6P;
    DwcGfb = (937 - 936);
    scanf ("%s", jz78KVgQRBo);
    OWKUTv6P = jz78KVgQRBo[(186 - 186)];
    if (!('\0' != jz78KVgQRBo[(237 - 236)])) {
        if (OWKUTv6P -'a' >= (315 - 315))
            printf ("(%c,1)", OWKUTv6P -'a' + 'A');
        else
            printf ("(%c,1)", OWKUTv6P);
    }
    else {
        cKh9LslfRy = (788 - 787);
        for (; jz78KVgQRBo[cKh9LslfRy] != '\0';) {
            if ((!(OWKUTv6P != jz78KVgQRBo[cKh9LslfRy])) || (!(OWKUTv6P != jz78KVgQRBo[cKh9LslfRy] - 'a' + 'A')) || (!(OWKUTv6P != jz78KVgQRBo[cKh9LslfRy] + 'a' - 'A'))) {
                {
                    if ((579 - 579)) {
                        return (255 - 255);
                    }
                }
                DwcGfb = DwcGfb +(106 - 105);
                if (!('\0' != jz78KVgQRBo[cKh9LslfRy + (418 - 417)])) {
                    if (OWKUTv6P -'a' >= (924 - 924))
                        printf ("(%c,%d)", OWKUTv6P -'a' + 'A', DwcGfb);
                    else
                        printf ("(%c,%d)", OWKUTv6P, DwcGfb);
                }
            }
            else {
                if (OWKUTv6P -'a' >= (333 - 333))
                    printf ("(%c,%d)", OWKUTv6P -'a' + 'A', DwcGfb);
                else
                    printf ("(%c,%d)", OWKUTv6P, DwcGfb);
                OWKUTv6P = jz78KVgQRBo[cKh9LslfRy];
                if (!('\0' != jz78KVgQRBo[cKh9LslfRy + (871 - 870)])) {
                    if (OWKUTv6P -'a' >= (830 - 830))
                        printf ("(%c,1)", jz78KVgQRBo[cKh9LslfRy] - 'a' + 'A');
                    else
                        printf ("(%c,1)", jz78KVgQRBo[cKh9LslfRy]);
                }
                DwcGfb = (145 - 144);
            }
            cKh9LslfRy = cKh9LslfRy + (948 - 947);
        }
    }
    getchar ();
    getchar ();
}

