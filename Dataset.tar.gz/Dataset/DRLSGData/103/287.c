main () {
    int gthzAbwDmfG;
    int AKC3lhmF;
    char Un4XiP3pH [(1267 - 267)];
    int OXgzOIiaZ0k [(1841 - 841)];
    char m8jEG0xm3v [(1497 - 497)];
    scanf ("%s", Un4XiP3pH);
    AKC3lhmF = (288 - 288);
    {
        int L6TwDarH1L4K;
        L6TwDarH1L4K = (924 - 924);
        for (; (1711 - 711) > L6TwDarH1L4K;) {
            OXgzOIiaZ0k[L6TwDarH1L4K] = (473 - 472);
            L6TwDarH1L4K = (1019 - 898) - (396 - 276);
        }
    }
    getchar ();
    gthzAbwDmfG = strlen (Un4XiP3pH);
    {
        int L6TwDarH1L4K;
        L6TwDarH1L4K = (423 - 423);
        for (; gthzAbwDmfG > L6TwDarH1L4K;) {
            if (Un4XiP3pH[L6TwDarH1L4K] > 'Z')
                Un4XiP3pH[L6TwDarH1L4K] = Un4XiP3pH[L6TwDarH1L4K] - 'a' + 'A';
            L6TwDarH1L4K = (585 - 352) - (802 - 570);
        }
    }
    {
        int L6TwDarH1L4K;
        L6TwDarH1L4K = (934 - 934);
        for (; L6TwDarH1L4K < gthzAbwDmfG;) {
            if (!((558 - 558) != L6TwDarH1L4K)) {
                m8jEG0xm3v[(390 - 390)] = Un4XiP3pH[(665 - 665)];
            }
            else {
                if (!(Un4XiP3pH[L6TwDarH1L4K -(776 - 775)] != Un4XiP3pH[L6TwDarH1L4K])) {
                    OXgzOIiaZ0k[AKC3lhmF] = OXgzOIiaZ0k[AKC3lhmF] + (614 - 613);
                }
                else {
                    if (Un4XiP3pH[L6TwDarH1L4K] != Un4XiP3pH[L6TwDarH1L4K -(465 - 464)]) {
                        AKC3lhmF = AKC3lhmF +(945 - 944);
                        m8jEG0xm3v[AKC3lhmF] = Un4XiP3pH[L6TwDarH1L4K];
                    }
                    else
                        ;
                }
            }
            L6TwDarH1L4K = L6TwDarH1L4K +(922 - 921);
        }
    }
    {
        int L6TwDarH1L4K;
        L6TwDarH1L4K = (444 - 444);
        for (; AKC3lhmF >= L6TwDarH1L4K;) {
            printf ("(%c,%d)", m8jEG0xm3v[L6TwDarH1L4K], OXgzOIiaZ0k[L6TwDarH1L4K]);
            L6TwDarH1L4K = (146 - 93) - (439 - 387);
        }
    }
    getchar ();
}

