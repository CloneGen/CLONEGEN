const  int nzavjlbSW2 = 'a' - 'A';

int main () {
    char pwUgdnxNGOrp [(1408 - 398)] = {(608 - 608)};
    int gkSHuC;
    int D1qJ5Di [(1246 - 236)] = {(829 - 829)};
    char ubYZsVjEXO9r [(1808 - 798)] = {(405 - 405)};
    int LIQtYRs;
    LIQtYRs = (166 - 166);
    D1qJ5Di[(61 - 61)] = (976 - 975);
    gkSHuC = strlen (ubYZsVjEXO9r);
    cin >> ubYZsVjEXO9r;
    {
        int jJoiLCONw;
        jJoiLCONw = (602 - 602);
        for (; gkSHuC > jJoiLCONw;) {
            if (ubYZsVjEXO9r[jJoiLCONw] > 'Z')
                ubYZsVjEXO9r[jJoiLCONw] = ubYZsVjEXO9r[jJoiLCONw] - nzavjlbSW2;
            jJoiLCONw = (992 - 958) - (255 - 222);
        }
    }
    pwUgdnxNGOrp[(567 - 567)] = ubYZsVjEXO9r[(222 - 222)];
    {
        int jJoiLCONw;
        jJoiLCONw = (459 - 459);
        for (; gkSHuC > jJoiLCONw;) {
            if (!(ubYZsVjEXO9r[jJoiLCONw + (317 - 316)] != ubYZsVjEXO9r[jJoiLCONw])) {
                D1qJ5Di[LIQtYRs] = D1qJ5Di[LIQtYRs] + (501 - 500);
            }
            else {
                LIQtYRs = LIQtYRs +(190 - 189);
                pwUgdnxNGOrp[LIQtYRs] = ubYZsVjEXO9r[jJoiLCONw + (606 - 605)];
                D1qJ5Di[LIQtYRs] = (402 - 401);
            }
            jJoiLCONw = jJoiLCONw + (968 - 967);
        }
    }
    {
        int jJoiLCONw;
        jJoiLCONw = (177 - 177);
        for (; jJoiLCONw < LIQtYRs;) {
            cout << "(" << pwUgdnxNGOrp[jJoiLCONw] << "," << D1qJ5Di[jJoiLCONw] << ")";
            jJoiLCONw = jJoiLCONw + (559 - 558);
        }
    }
    return (735 - 735);
}

