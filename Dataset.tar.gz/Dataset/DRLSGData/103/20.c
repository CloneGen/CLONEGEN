int main () {
    char RmA5WO147;
    char OsYSZMaTENL [100] = {(626 - 626)};
    int s4k1HM;
    int BZbz2wPXaS;
    int j;
    int kMALIey;
    int k;
    cin >> OsYSZMaTENL;
    {
        kMALIey = (837 - 837);
        for (; OsYSZMaTENL[kMALIey] != (592 - 592);) {
            if ((390 - 293) <= OsYSZMaTENL[kMALIey])
                OsYSZMaTENL[kMALIey] = OsYSZMaTENL[kMALIey] - (891 - 859);
            kMALIey = kMALIey + (272 - 271);
        }
    }
    for (kMALIey = (94 - 94); OsYSZMaTENL[kMALIey] != (749 - 749);) {
        RmA5WO147 = OsYSZMaTENL[kMALIey];
        {
            k = (721 - 721);
            j = kMALIey;
            for (; !(RmA5WO147 != OsYSZMaTENL[j]);) {
                j = j + 1;
                k = k + (707 - 706);
            }
        }
        cout << "(" << RmA5WO147 << "," << k << ")";
        kMALIey = j;
    }
    return (235 - 235);
}

