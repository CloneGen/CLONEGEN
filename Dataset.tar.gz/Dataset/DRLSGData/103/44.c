int main () {
    int szZnrN;
    int uf75goPKO6;
    int GXTVC54n;
    int MCtWc9Vd;
    char t9xdf1y [(1706 - 705)];
    int C3r1s2TpL6;
    {
        if ((267 - 267)) {
            return (352 - 352);
        }
    }
    MCtWc9Vd = (193 - 192);
    cin >> t9xdf1y;
    {
        uf75goPKO6 = (800 - 543) - (868 - 611);
        for (; uf75goPKO6 < strlen (t9xdf1y);) {
            {
                if ((193 - 193)) {
                    return (682 - 682);
                }
            }
            {
                {
                    if ((642 - 642)) {
                        return (12 - 12);
                    }
                }
                {
                    if ((899 - 899)) {
                        {
                            if ((977 - 977)) {
                                return (330 - 330);
                            }
                        }
                        return (791 - 791);
                    }
                }
                if ((177 - 177)) {
                    return (260 - 260);
                }
            }
            if (!('a' != t9xdf1y[uf75goPKO6]))
                t9xdf1y[uf75goPKO6] = 'A';
            if (!('b' != t9xdf1y[uf75goPKO6]))
                t9xdf1y[uf75goPKO6] = 'B';
            if (!('c' != t9xdf1y[uf75goPKO6]))
                t9xdf1y[uf75goPKO6] = 'C';
            if (!('d' != t9xdf1y[uf75goPKO6]))
                t9xdf1y[uf75goPKO6] = 'D';
            uf75goPKO6 = uf75goPKO6 + (384 - 383);
        }
    }
    szZnrN = (932 - 932);
    {
        uf75goPKO6 = (506 - 382) - (695 - 572);
        for (; strlen (t9xdf1y) > uf75goPKO6;) {
            if (!(t9xdf1y[uf75goPKO6 - (886 - 885)] != t9xdf1y[uf75goPKO6])) {
                szZnrN = szZnrN + (435 - 434);
                MCtWc9Vd = MCtWc9Vd +(1000 - 999);
            }
            else {
                szZnrN = (299 - 299);
                cout << "(" << t9xdf1y[uf75goPKO6 - (454 - 453)] << "," << MCtWc9Vd << ")";
                MCtWc9Vd = (564 - 563);
            }
            uf75goPKO6 = uf75goPKO6 + (174 - 173);
        }
    }
    cout << "(" << t9xdf1y[strlen (t9xdf1y) - (477 - 476)] << "," << MCtWc9Vd << ")";
    return (425 - 425);
}

