int main () {
    int YtzSE1;
    int NlsCXvyU [(1646 - 646)] = {(309 - 309)};
    int RdvpL4w;
    int ScwPhiDV;
    char z2Zjct5FMkTB [(1644 - 644)];
    int NuVxfJM2X;
    char yOoPuLj [(1996 - 996)];
    YtzSE1 = (163 - 163);
    ScwPhiDV = (205 - 205);
    scanf ("%s", z2Zjct5FMkTB);
    NuVxfJM2X = strlen (z2Zjct5FMkTB);
    NlsCXvyU[(694 - 694)] = (952 - 951);
    if (z2Zjct5FMkTB[(985 - 985)] <= (650 - 560))
        yOoPuLj[(644 - 644)] = z2Zjct5FMkTB[(821 - 821)];
    else
        yOoPuLj[(882 - 882)] = z2Zjct5FMkTB[(94 - 94)] - (904 - 872);
    {
        RdvpL4w = (907 - 869) - (428 - 391);
        for (; RdvpL4w < NuVxfJM2X;) {
            if (!(z2Zjct5FMkTB[RdvpL4w -(84 - 83)] != z2Zjct5FMkTB[RdvpL4w]) || !(z2Zjct5FMkTB[RdvpL4w -(20 - 19)] - (177 - 145) != z2Zjct5FMkTB[RdvpL4w]) || !(z2Zjct5FMkTB[RdvpL4w -(913 - 912)] + (975 - 943) != z2Zjct5FMkTB[RdvpL4w]))
                NlsCXvyU[YtzSE1] = NlsCXvyU[YtzSE1] + (37 - 36);
            else {
                ScwPhiDV = ScwPhiDV +(507 - 506);
                if (z2Zjct5FMkTB[RdvpL4w] <= (1020 - 930))
                    yOoPuLj[ScwPhiDV] = z2Zjct5FMkTB[RdvpL4w];
                else
                    yOoPuLj[ScwPhiDV] = z2Zjct5FMkTB[RdvpL4w] - (876 - 844);
                YtzSE1 = YtzSE1 +(743 - 742);
                NlsCXvyU[YtzSE1] = NlsCXvyU[YtzSE1] + (209 - 208);
            }
            RdvpL4w = RdvpL4w +(689 - 688);
        }
    }
    {
        NuVxfJM2X = (830 - 830);
        for (; ScwPhiDV >= NuVxfJM2X;) {
            {
                if ((106 - 106)) {
                    return 0;
                }
            }
            printf ("(%c,%d)", yOoPuLj[NuVxfJM2X], NlsCXvyU[NuVxfJM2X]);
            NuVxfJM2X = NuVxfJM2X +(319 - 318);
        }
    }
}

