int main () {
    char vKzchOjU [(1239 - 229)];
    int z3I4LHYl;
    char oBVaP97N;
    cin >> vKzchOjU;
    oBVaP97N = vKzchOjU[(859 - 859)];
    z3I4LHYl = (339 - 338);
    {
        int yweUzC4j6;
        yweUzC4j6 = (537 - 536);
        for (; strlen (vKzchOjU) > yweUzC4j6;) {
            if (!(oBVaP97N != vKzchOjU[yweUzC4j6]) || !(oBVaP97N != vKzchOjU[yweUzC4j6] - (208 - 176)) || !(oBVaP97N != vKzchOjU[yweUzC4j6] + (437 - 405))) {
                z3I4LHYl = z3I4LHYl + (576 - 575);
            }
            else {
                if ('A' <= oBVaP97N && 'Z' >= oBVaP97N)
                    cout << "(" << (char) oBVaP97N << "," << z3I4LHYl << ")";
                else
                    cout << "(" << (char) (oBVaP97N - (297 - 265)) << "," << z3I4LHYl << ")";
                z3I4LHYl = (588 - 587);
                oBVaP97N = vKzchOjU[yweUzC4j6];
            }
            yweUzC4j6 = yweUzC4j6 + (651 - 650);
        }
    }
    if ('A' <= oBVaP97N && 'Z' >= oBVaP97N)
        cout << "(" << (char) oBVaP97N << "," << z3I4LHYl << ")" << endl;
    else
        cout << "(" << (char) (oBVaP97N - (1013 - 981)) << "," << z3I4LHYl << ")" << endl;
    return (102 - 102);
}

