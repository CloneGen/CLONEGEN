main () {
    int Bo10w4e;
    char q3CLdhiWA1 [(1364 - 364)];
    int Srdu9tlTQHPM;
    char K0WXKB [(1761 - 761)];
    char sSs9vqfr1C8 [(1706 - 706)];
    int M5tk0JmnP [(1698 - 698)] = {(332 - 332)};
    int QXCKiJ;
    gets (K0WXKB);
    M5tk0JmnP[(311 - 311)] = (182 - 181);
    Bo10w4e = (248 - 248);
    Srdu9tlTQHPM = strlen (K0WXKB);
    {
        QXCKiJ = (759 - 759);
        for (; QXCKiJ <= Srdu9tlTQHPM;) {
            if ('a' > K0WXKB[QXCKiJ])
                q3CLdhiWA1[QXCKiJ] = K0WXKB[QXCKiJ];
            else
                q3CLdhiWA1[QXCKiJ] = K0WXKB[QXCKiJ] + 'A' - 'a';
            QXCKiJ = QXCKiJ +(307 - 306);
        }
    }
    sSs9vqfr1C8[(131 - 131)] = q3CLdhiWA1[(740 - 740)];
    {
        QXCKiJ = (871 - 870);
        for (; QXCKiJ <= Srdu9tlTQHPM;) {
            if (q3CLdhiWA1[QXCKiJ] == q3CLdhiWA1[QXCKiJ -(257 - 256)])
                M5tk0JmnP[Bo10w4e] = M5tk0JmnP[Bo10w4e] + (477 - 476);
            else {
                Bo10w4e = Bo10w4e +(139 - 138);
                sSs9vqfr1C8[Bo10w4e] = q3CLdhiWA1[QXCKiJ];
                M5tk0JmnP[Bo10w4e] = M5tk0JmnP[Bo10w4e] + (658 - 657);
            }
            QXCKiJ = QXCKiJ +(700 - 699);
        }
    }
    {
        QXCKiJ = (451 - 451);
        for (; QXCKiJ <= Bo10w4e -(597 - 596);) {
            printf ("(%c,%d)", sSs9vqfr1C8[QXCKiJ], M5tk0JmnP[QXCKiJ]);
            QXCKiJ = QXCKiJ +(164 - 163);
        }
    }
}

