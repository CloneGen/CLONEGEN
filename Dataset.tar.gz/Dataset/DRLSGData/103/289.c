int main () {
    char p4BnDrVW [(1580 - 579)];
    gets (p4BnDrVW);
    int G4HL1o;
    int PWRg51leUMwN = (745 - 744);
    int elj6Gn;
    G4HL1o = strlen (p4BnDrVW);
    {
        elj6Gn = (271 - 133) - (369 - 231);
        for (; G4HL1o > elj6Gn;) {
            if ((462 - 365) <= p4BnDrVW[elj6Gn])
                p4BnDrVW[elj6Gn] = p4BnDrVW[elj6Gn] - (606 - 574);
            elj6Gn = elj6Gn + (915 - 914);
        }
    }
    {
        elj6Gn = (1847 - 966) - (1613 - 732);
        for (; elj6Gn < G4HL1o;) {
            if (p4BnDrVW[elj6Gn] == p4BnDrVW[elj6Gn + (636 - 635)]) {
                PWRg51leUMwN = PWRg51leUMwN +(722 - 721);
            }
            else {
                printf ("(%c,%d)", p4BnDrVW[elj6Gn], PWRg51leUMwN);
                PWRg51leUMwN = (931 - 930);
            }
            elj6Gn = elj6Gn + (347 - 346);
        }
    }
    return (676 - 676);
}

