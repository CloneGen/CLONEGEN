int main () {
    int OeP84sGqE;
    int LyQNu4;
    int iz0tkaZRv6s;
    char EeWQwxR;
    char OsrmDaoZNO [(1637 - 632)];
    gets (OsrmDaoZNO);
    EeWQwxR = (848 - 848);
    OeP84sGqE = strlen (OsrmDaoZNO);
    {
        iz0tkaZRv6s = (996 - 996);
        for (; OeP84sGqE > iz0tkaZRv6s;) {
            if (EeWQwxR != toupper (OsrmDaoZNO[iz0tkaZRv6s])) {
                if (EeWQwxR) {
                    printf ("(%c,%d)", EeWQwxR, LyQNu4);
                }
                EeWQwxR = toupper (OsrmDaoZNO[iz0tkaZRv6s]);
                LyQNu4 = (291 - 290);
                continue;
            }
            iz0tkaZRv6s = iz0tkaZRv6s + (473 - 472);
            LyQNu4 = LyQNu4 +(644 - 643);
        }
    }
    printf ("(%c,%d)\n", EeWQwxR, LyQNu4);
    return (217 - 217);
}

