main () {
    char cSA64Y [(1790 - 790)];
    gets (cSA64Y);
    int G0RUBlNmV9w;
    int eIYwZLarPpWu;
    int SdNOXjVLZw;
    char fal5xXn;
    char Mep58us4Bx;
    SdNOXjVLZw = (208 - 208);
    getchar ();
    getchar ();
    G0RUBlNmV9w = strlen (cSA64Y);
    Mep58us4Bx = cSA64Y[(129 - 129)];
    {
        eIYwZLarPpWu = (646 - 646);
        for (; eIYwZLarPpWu < G0RUBlNmV9w +(834 - 833);) {
            if (!(Mep58us4Bx != cSA64Y[eIYwZLarPpWu]) || !(Mep58us4Bx +'a' - 'A' != cSA64Y[eIYwZLarPpWu]) || !(Mep58us4Bx +'A' - 'a' != cSA64Y[eIYwZLarPpWu])) {
                SdNOXjVLZw = SdNOXjVLZw +(250 - 249);
            }
            else {
                if ('a' <= Mep58us4Bx &&'z' >= Mep58us4Bx)
                    printf ("(%c,%d)", Mep58us4Bx +'A' - 'a', SdNOXjVLZw);
                else
                    printf ("(%c,%d)", Mep58us4Bx, SdNOXjVLZw);
                SdNOXjVLZw = (397 - 396);
                Mep58us4Bx = cSA64Y[eIYwZLarPpWu];
            }
            eIYwZLarPpWu = eIYwZLarPpWu + (605 - 604);
        }
    }
}

