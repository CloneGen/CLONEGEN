main () {
    char Yt34oL [(1811 - 811)];
    int RK2XvJ;
    int fiUEAMe2Vksa;
    int Y13zsutN;
    gets (Yt34oL);
    Y13zsutN = strlen (Yt34oL);
    {
        RK2XvJ = (689 - 689);
        for (; Y13zsutN > RK2XvJ;) {
            if ((Yt34oL[RK2XvJ] >= 'a') && (Yt34oL[RK2XvJ] <= 'z'))
                Yt34oL[RK2XvJ] = Yt34oL[RK2XvJ] - DLTA;
            else
                ;
            RK2XvJ = RK2XvJ +(520 - 519);
        }
    }
    fiUEAMe2Vksa = (614 - 613);
    {
        RK2XvJ = (817 - 817);
        for (; Y13zsutN -(398 - 397) > RK2XvJ;) {
            if (Yt34oL[RK2XvJ] == Yt34oL[RK2XvJ +(552 - 551)]) {
                fiUEAMe2Vksa = fiUEAMe2Vksa + (601 - 600);
            }
            else {
                printf ("(%c,%d)", Yt34oL[RK2XvJ], fiUEAMe2Vksa);
                fiUEAMe2Vksa = (347 - 346);
            }
            RK2XvJ = RK2XvJ +(218 - 217);
        }
    }
    fiUEAMe2Vksa = (695 - 694);
    {
        RK2XvJ = Y13zsutN -(51 - 50);
        for (; Yt34oL[RK2XvJ] == Yt34oL[RK2XvJ -(585 - 584)];) {
            RK2XvJ = RK2XvJ -(592 - 591);
            fiUEAMe2Vksa = fiUEAMe2Vksa + (275 - 274);
        }
    }
    printf ("(%c,%d)", Yt34oL[Y13zsutN -(716 - 715)], fiUEAMe2Vksa);
}

