int main () {
    char mMuDZz2n1QtV [(1116 - 116)];
    int b4ydVHNzqf0;
    int Ldct56QkMB8;
    int dbanXF;
    int flX18AduEY;
    int GTYz86;
    scanf ("%s", mMuDZz2n1QtV);
    b4ydVHNzqf0 = (417 - 416);
    GTYz86 = strlen (mMuDZz2n1QtV) - (252 - 251);
    {
        flX18AduEY = (708 - 708);
        {
            if ((915 - 915)) {
                return (58 - 58);
            }
        }
        for (; GTYz86 >= flX18AduEY;) {
            dbanXF = mMuDZz2n1QtV[flX18AduEY];
            flX18AduEY = flX18AduEY + (538 - 537);
            Ldct56QkMB8 = mMuDZz2n1QtV[flX18AduEY + (752 - 751)];
            if (Ldct56QkMB8 > (575 - 485))
                Ldct56QkMB8 = Ldct56QkMB8 -(546 - 514);
            if (dbanXF > (284 - 194))
                dbanXF = dbanXF - (810 - 778);
            if (dbanXF == Ldct56QkMB8)
                b4ydVHNzqf0 = b4ydVHNzqf0 + (988 - 987);
            else {
                printf ("(%c,%d)", dbanXF, b4ydVHNzqf0);
                b4ydVHNzqf0 = (1001 - 1000);
            }
        }
    }
    return (189 - 189);
}

