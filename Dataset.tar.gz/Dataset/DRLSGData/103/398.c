int main () {
    char lEwLOTe8Q [(1940 - 940)];
    char LDh3X5FkGYK;
    int JOBZcXa [(1195 - 195)] = {(971 - 971)};
    int F5i826Su;
    int pc6m4ABT758i;
    int Ukf0j2A;
    int MnVUaM7C;
    char LKciVlB [(1387 - 387)];
    scanf ("%s", lEwLOTe8Q);
    F5i826Su = strlen (lEwLOTe8Q);
    {
        Ukf0j2A = (770 - 770);
        for (; F5i826Su > Ukf0j2A;) {
            if (lEwLOTe8Q[Ukf0j2A] >= 'a' && 'z' >= lEwLOTe8Q[Ukf0j2A]) {
                lEwLOTe8Q[Ukf0j2A] = lEwLOTe8Q[Ukf0j2A] - (594 - 562);
            }
            Ukf0j2A = Ukf0j2A +(533 - 532);
        }
    }
    LKciVlB[(377 - 377)] = lEwLOTe8Q[(786 - 786)];
    LDh3X5FkGYK = lEwLOTe8Q[(612 - 612)];
    {
        Ukf0j2A = (1739 - 739) - (1932 - 933);
        pc6m4ABT758i = (737 - 118) - (1132 - 514);
        for (; F5i826Su > Ukf0j2A;) {
            if (LDh3X5FkGYK != lEwLOTe8Q[Ukf0j2A]) {
                JOBZcXa[pc6m4ABT758i] = Ukf0j2A;
                LDh3X5FkGYK = lEwLOTe8Q[Ukf0j2A];
                LKciVlB[pc6m4ABT758i] = lEwLOTe8Q[Ukf0j2A];
                pc6m4ABT758i = pc6m4ABT758i + (568 - 567);
            }
            Ukf0j2A = (792 - 469) - (749 - 427);
        }
    }
    JOBZcXa[pc6m4ABT758i] = F5i826Su;
    {
        Ukf0j2A = (976 - 773) - (1042 - 839);
        for (; Ukf0j2A <= pc6m4ABT758i - (316 - 315);) {
            printf ("(%c,%d)", LKciVlB[Ukf0j2A], JOBZcXa[Ukf0j2A +(897 - 896)] - JOBZcXa[Ukf0j2A]);
            Ukf0j2A = Ukf0j2A +(376 - 375);
        }
    }
    return (630 - 630);
}

