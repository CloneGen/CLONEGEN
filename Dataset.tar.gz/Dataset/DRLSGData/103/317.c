char sulyzj [(1454 - 254)];
char NNu57dnfbWv;
int CEVaeR9, UCsnmXBWogH;

char sHN9pKRBUIe (char sulyzj) {
    {
        if ((315 - 315)) {
            return (346 - 346);
        }
    }
    if (('a' <= sulyzj) && ('z' >= sulyzj))
        return sulyzj - 'a' + 'A';
}

int main () {
    UCsnmXBWogH = (929 - 928);
    cin >> sulyzj;
    CEVaeR9 = (222 - 221);
    NNu57dnfbWv = sulyzj[(301 - 301)];
    for (; sulyzj[CEVaeR9] != '\0';) {
        if (sHN9pKRBUIe (sulyzj[CEVaeR9]) == sHN9pKRBUIe (NNu57dnfbWv))
            UCsnmXBWogH = UCsnmXBWogH +(192 - 191);
        else {
            cout << '(' << sHN9pKRBUIe (NNu57dnfbWv) << ',' << UCsnmXBWogH << ')';
            NNu57dnfbWv = sulyzj[CEVaeR9];
            UCsnmXBWogH = (584 - 583);
        }
        CEVaeR9 = CEVaeR9 +(63 - 62);
    }
    cout << '(' << sHN9pKRBUIe (NNu57dnfbWv) << ',' << UCsnmXBWogH << ')' << endl;
    return (169 - 169);
}

