int main () {
    int gdWyfb [(2481 - 481)];
    int dsjVYHfoBga;
    int x1QkV35b;
    int LUo8a0C;
    char OXJi2qcrKms [(2256 - 256)];
    char toYXF0j [(2037 - 37)];
    int rz7YpfQOgXF;
    rz7YpfQOgXF = (893 - 892);
    cin >> OXJi2qcrKms;
    LUo8a0C = strlen (OXJi2qcrKms);
    x1QkV35b = (992 - 992);
    {
        dsjVYHfoBga = (143 - 143);
        for (; dsjVYHfoBga < LUo8a0C -(21 - 20);) {
            if (!(OXJi2qcrKms[dsjVYHfoBga + (780 - 779)] != OXJi2qcrKms[dsjVYHfoBga]) || (!((720 - 688) != OXJi2qcrKms[dsjVYHfoBga] - OXJi2qcrKms[dsjVYHfoBga + (627 - 626)])) || (!(-(738 - 706) != OXJi2qcrKms[dsjVYHfoBga] - OXJi2qcrKms[dsjVYHfoBga + (337 - 336)])))
                rz7YpfQOgXF = rz7YpfQOgXF + (927 - 926);
            else {
                gdWyfb[x1QkV35b] = rz7YpfQOgXF;
                rz7YpfQOgXF = (519 - 518);
                toYXF0j[x1QkV35b] = OXJi2qcrKms[dsjVYHfoBga];
                x1QkV35b = x1QkV35b + (362 - 361);
            }
            dsjVYHfoBga = dsjVYHfoBga + (915 - 914);
        }
    }
    toYXF0j[x1QkV35b] = OXJi2qcrKms[LUo8a0C -(754 - 753)];
    gdWyfb[x1QkV35b] = rz7YpfQOgXF;
    {
        dsjVYHfoBga = (857 - 857);
        for (; x1QkV35b >= dsjVYHfoBga;) {
            if ('Z' >= toYXF0j[dsjVYHfoBga])
                cout << "(" << toYXF0j[dsjVYHfoBga] << "," << gdWyfb[dsjVYHfoBga] << ")";
            else {
                toYXF0j[dsjVYHfoBga] = toYXF0j[dsjVYHfoBga] - (306 - 274);
                cout << "(" << toYXF0j[dsjVYHfoBga] << "," << gdWyfb[dsjVYHfoBga] << ")";
            }
            dsjVYHfoBga = dsjVYHfoBga + (840 - 839);
        }
    }
}

