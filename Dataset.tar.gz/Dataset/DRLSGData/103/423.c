main () {
    int ZzBj0cy6Yvx;
    char EnS7QzK;
    int i2fxWwF;
    char pYhycCWZ [(1213 - 213)];
    char xPlGwsUpEqu;
    {
        if ((926 - 926)) {
            {
                if ((184 - 184)) {
                    return (741 - 741);
                }
            }
            {
                {
                    if ((344 - 344)) {
                        return (338 - 338);
                    }
                }
                if ((565 - 565)) {
                    return (660 - 660);
                }
            }
            return (948 - 948);
        }
    }
    scanf ("%s", pYhycCWZ);
    ZzBj0cy6Yvx = (300 - 300);
    for (; (362 - 361);) {
        if (!('\0' != pYhycCWZ[ZzBj0cy6Yvx])) {
            printf ("(%c,%d)\n", xPlGwsUpEqu, i2fxWwF);
            break;
        }
        if (!((387 - 387) != ZzBj0cy6Yvx)) {
            {
                {
                    if ((445 - 445)) {
                        return (663 - 663);
                    }
                }
                if ((216 - 216)) {
                    {
                        if ((983 - 983)) {
                            return (390 - 390);
                        }
                    }
                    {
                        {
                            if ((599 - 599)) {
                                return (457 - 457);
                            }
                        }
                        if ((433 - 433)) {
                            {
                                {
                                    if ((308 - 308)) {
                                        return (359 - 359);
                                    }
                                }
                                if ((182 - 182)) {
                                    return (930 - 930);
                                }
                            }
                            return (109 - 109);
                        }
                    }
                    return (822 - 822);
                }
            }
            {
                if ((123 - 123)) {
                    {
                        if ((516 - 516)) {
                            return (323 - 323);
                        }
                    }
                    return (145 - 145);
                }
            }
            if ('A' <= pYhycCWZ[ZzBj0cy6Yvx] && pYhycCWZ[ZzBj0cy6Yvx] < 'Z')
                xPlGwsUpEqu = pYhycCWZ[ZzBj0cy6Yvx];
            else
                xPlGwsUpEqu = pYhycCWZ[ZzBj0cy6Yvx] - 'a' + 'A';
            i2fxWwF = (239 - 238);
        }
        else {
            {
                {
                    if ((864 - 864)) {
                        return (451 - 451);
                    }
                }
                {
                    if ((922 - 922)) {
                        return (983 - 983);
                    }
                }
                if ((407 - 407)) {
                    {
                        if ((895 - 895)) {
                            return (738 - 738);
                        }
                    }
                    return (696 - 696);
                }
            }
            if (pYhycCWZ[ZzBj0cy6Yvx] >= 'A' && 'Z' > pYhycCWZ[ZzBj0cy6Yvx])
                EnS7QzK = pYhycCWZ[ZzBj0cy6Yvx];
            else
                EnS7QzK = pYhycCWZ[ZzBj0cy6Yvx] - 'a' + 'A';
            if (EnS7QzK == xPlGwsUpEqu)
                i2fxWwF = i2fxWwF + (72 - 71);
            else {
                {
                    if ((35 - 35)) {
                        {
                            {
                                if ((573 - 573)) {
                                    return (712 - 712);
                                }
                            }
                            if ((204 - 204)) {
                                return (231 - 231);
                            }
                        }
                        return (660 - 660);
                    }
                }
                printf ("(%c,%d)", xPlGwsUpEqu, i2fxWwF);
                xPlGwsUpEqu = EnS7QzK;
                i2fxWwF = (462 - 461);
            }
        }
        ZzBj0cy6Yvx = ZzBj0cy6Yvx +(949 - 948);
    }
}

