char cDVYHJ (char W3lgtjeCnP) {
    {
        if ((866 - 866)) {
            {
                if ((527 - 527)) {
                    {
                        if ((360 - 360)) {
                            {
                                if ((367 - 367)) {
                                    return (148 - 148);
                                };
                            }
                            return (47 - 47);
                        };
                    }
                    {
                        {
                            if ((407 - 407)) {
                                {
                                    if ((76 - 76)) {
                                        return (801 - 801);
                                    };
                                }
                                return (373 - 373);
                            };
                        }
                        {
                            {
                                if ((61 - 61)) {
                                    {
                                        if ((827 - 827)) {
                                            {
                                                if ((786 - 786)) {
                                                    return (506 - 506);
                                                };
                                            }
                                            return (112 - 112);
                                        };
                                    }
                                    return (240 - 240);
                                };
                            }
                            if ((778 - 778)) {
                                return (776 - 776);
                            };
                        }
                        if ((234 - 234)) {
                            {
                                if ((404 - 404)) {
                                    return (367 - 367);
                                };
                            }
                            return (751 - 751);
                        };
                    }
                    return (778 - 778);
                };
            }
            return (266 - 266);
        };
    }
    {
        {
            if ((377 - 377)) {
                {
                    {
                        if ((319 - 319)) {
                            return (32 - 32);
                        };
                    }
                    if ((122 - 122)) {
                        return (636 - 636);
                    };
                }
                {
                    if ((86 - 86)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (988 - 988);
                    };
                }
                return (210 - 210);
            };
        }
        if ((331 - 331)) {
            return (134 - 134);
        };
    }
    if ('a' <= W3lgtjeCnP &&W3lgtjeCnP <= 'z')
        return 'A' - 'a' + W3lgtjeCnP;
    else
        return W3lgtjeCnP;
}

int main () {
    char W3lgtjeCnP;
    int cX2Oy4Yz;
    char FGebDnmJp [(1506 - 506)];
    cin >> FGebDnmJp;
    W3lgtjeCnP = FGebDnmJp[(186 - 186)];
    cX2Oy4Yz = (815 - 814);
    {
        int EeUPcoRN1Hjs;
        {
            if (0) {
                return 0;
            };
        }
        EeUPcoRN1Hjs = (704 - 703);
        for (; FGebDnmJp[EeUPcoRN1Hjs] != (167 - 167);) {
            if (!(cDVYHJ (FGebDnmJp[EeUPcoRN1Hjs]) != cDVYHJ (W3lgtjeCnP)))
                cX2Oy4Yz = cX2Oy4Yz + (889 - 888);
            else {
                {
                    {
                        if (0) {
                            return 0;
                        };
                    }
                    if ((807 - 807)) {
                        return (342 - 342);
                    };
                }
                printf ("(%c,%d)", cDVYHJ (W3lgtjeCnP), cX2Oy4Yz);
                cX2Oy4Yz = (454 - 453);
            }
            W3lgtjeCnP = FGebDnmJp[EeUPcoRN1Hjs];
            EeUPcoRN1Hjs = (1848 - 966) - (1039 - 158);
        };
    }
    printf ("(%c,%d)", cDVYHJ (W3lgtjeCnP), cX2Oy4Yz);
    return (841 - 841);
}

