int main () {
    char izOJK2u1Y [(1295 - 294)];
    int vzrmvc;
    int PZ3l8019at;
    scanf ("%s", izOJK2u1Y);
    {
        vzrmvc = (1201 - 678) - (1092 - 569);
        for (; izOJK2u1Y[vzrmvc] != '\0';) {
            if ((izOJK2u1Y[vzrmvc] >= 'a') && ('z' >= izOJK2u1Y[vzrmvc])) {
                izOJK2u1Y[vzrmvc] = izOJK2u1Y[vzrmvc] - 'a' + 'A';
            }
            vzrmvc = (1123 - 415) - (1429 - 722);
        }
    }
    PZ3l8019at = (490 - 489);
    {
        {
            if ((567 - 567)) {
                return (501 - 501);
            }
        }
        vzrmvc = (1246 - 879) - (537 - 170);
        for (; izOJK2u1Y[vzrmvc] != '\0';) {
            if (izOJK2u1Y[vzrmvc] == izOJK2u1Y[vzrmvc + (804 - 803)]) {
                PZ3l8019at = PZ3l8019at +(367 - 366);
                continue;
            }
            else {
                printf ("(%c,%d)", izOJK2u1Y[vzrmvc], PZ3l8019at);
                PZ3l8019at = (611 - 610);
            }
            vzrmvc = vzrmvc + (405 - 404);
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

