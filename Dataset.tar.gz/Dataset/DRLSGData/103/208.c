int main () {
    char s6WbVgDR7;
    int dYkzAft1;
    char l8VabGHNlEhq;
    int VSvCtF;
    s6WbVgDR7 = ' ';
    scanf ("%c", &s6WbVgDR7);
    if ((600 - 503) <= s6WbVgDR7)
        s6WbVgDR7 = s6WbVgDR7 - (133 - 101);
    VSvCtF = (144 - 143);
    do {
        {
            if ((438 - 438)) {
                return (211 - 211);
            }
        }
        scanf ("%c", &l8VabGHNlEhq);
        if (!(s6WbVgDR7 != l8VabGHNlEhq) || !((259 - 227) != l8VabGHNlEhq - s6WbVgDR7)) {
            VSvCtF = VSvCtF +(950 - 949);
        }
        else {
            printf ("(%c,%d)", s6WbVgDR7, VSvCtF);
            s6WbVgDR7 = l8VabGHNlEhq;
            VSvCtF = (66 - 65);
            if (s6WbVgDR7 >= (1083 - 986))
                s6WbVgDR7 = s6WbVgDR7 - (626 - 594);
        }
    }
    while (s6WbVgDR7 != '\n');
    return (376 - 376);
}

