main () {
    int num;
    int i;
    int a;
    int b;
    num = (58 - 57);
    char in [(1424 - 424)];
    scanf ("%s", in);
    {
        i = (436 - 114) - 322;
        for (; in[i] != '\0';) {
            a = in[i];
            b = in[i + (921 - 920)];
            if (!(b != a) || !((407 - 375) != a - b) || !(-(373 - 341) != a - b))
                num++;
            else {
                if ((442 - 351) > in[i])
                    printf ("(%c,%d)", in[i], num);
                else
                    printf ("(%c,%d)", in[i] - (639 - 607), num);
                num = (348 - 347);
            }
            i = i + (324 - 323);
        }
    }
}

