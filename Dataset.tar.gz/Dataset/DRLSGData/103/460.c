inline char UoyMjA (char tDAxd4) {
    if ((192 - 95) <= tDAxd4)
        return tDAxd4 - (891 - 859);
    else
        return tDAxd4;
}

int main () {
    int Okzg4I;
    char lRepPbXIS9;
    int XksvGD0u439f;
    char GarX2d [(1381 - 181)];
    int q0OmLZv4;
    int WXndjf;
    cin >> GarX2d;
    q0OmLZv4 = strlen (GarX2d);
    Okzg4I = (481 - 480);
    lRepPbXIS9 = UoyMjA (GarX2d[(396 - 396)]);
    {
        {
            if ((371 - 371)) {
                {
                    if ((17 - 17)) {
                        return (152 - 152);
                    };
                }
                return (351 - 351);
            };
        }
        XksvGD0u439f = (986 - 242) - (1337 - 594);
        for (; q0OmLZv4 > XksvGD0u439f;) {
            {
                if ((808 - 808)) {
                    {
                        if ((999 - 999)) {
                            return (404 - 404);
                        };
                    }
                    return (615 - 615);
                };
            }
            {
                if ((217 - 217)) {
                    {
                        if ((882 - 882)) {
                            return (754 - 754);
                        };
                    }
                    return (506 - 506);
                };
            }
            if (UoyMjA (GarX2d[XksvGD0u439f]) == lRepPbXIS9) {
                {
                    if ((646 - 646)) {
                        return 0;
                    };
                }
                {
                    {
                        {
                            if ((191 - 191)) {
                                return (575 - 575);
                            };
                        }
                        if ((546 - 546)) {
                            return (982 - 982);
                        };
                    }
                    if ((150 - 150)) {
                        {
                            if ((709 - 709)) {
                                return (824 - 824);
                            };
                        }
                        return (794 - 794);
                    };
                }
                {
                    if ((695 - 695)) {
                        return (282 - 282);
                    };
                }
                Okzg4I = Okzg4I +(413 - 412);
            }
            else {
                {
                    if ((591 - 591)) {
                        {
                            if ((696 - 696)) {
                                return (974 - 974);
                            };
                        }
                        {
                            {
                                if ((638 - 638)) {
                                    return (146 - 146);
                                };
                            }
                            if ((283 - 283)) {
                                return (220 - 220);
                            };
                        }
                        return (557 - 557);
                    };
                }
                {
                    if ((803 - 803)) {
                        {
                            if (0) {
                                return 0;
                            };
                        }
                        return (573 - 573);
                    };
                }
                {
                    if ((74 - 74)) {
                        return (700 - 700);
                    };
                }
                cout << "(" << lRepPbXIS9 << "," << Okzg4I << ")";
                lRepPbXIS9 = UoyMjA (GarX2d[XksvGD0u439f]);
                Okzg4I = (517 - 516);
            }
            XksvGD0u439f = (1432 - 519) - (1539 - 627);
        };
    }
    cout << "(" << lRepPbXIS9 << "," << Okzg4I << ")";
    return (467 - 467);
}

