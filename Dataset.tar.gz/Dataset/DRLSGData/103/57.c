int main () {
    char CZWnSj34gRpH [(1344 - 344)];
    char gSOIZgVFrvu;
    char K8TbYiPG;
    char kWYIfDAhCbv4;
    scanf ("%s", CZWnSj34gRpH);
    {
        {
            if ((613 - 613)) {
                return (489 - 489);
            }
        }
        kWYIfDAhCbv4 = (352 - 53) - (783 - 484);
        for (; kWYIfDAhCbv4 <= (744 - 644);) {
            {
                if ((61 - 61)) {
                    {
                        if ((214 - 214)) {
                            {
                                {
                                    if ((387 - 387)) {
                                        return (905 - 905);
                                    }
                                }
                                if ((273 - 273)) {
                                    return (807 - 807);
                                }
                            }
                            return (780 - 780);
                        }
                    }
                    return (873 - 873);
                }
            }
            if (CZWnSj34gRpH[kWYIfDAhCbv4] <= 'z' && CZWnSj34gRpH[kWYIfDAhCbv4] >= 'a')
                CZWnSj34gRpH[kWYIfDAhCbv4] = CZWnSj34gRpH[kWYIfDAhCbv4] + 'A' - 'a';
            kWYIfDAhCbv4 = kWYIfDAhCbv4 + (47 - 46);
        }
    }
    kWYIfDAhCbv4 = (754 - 754);
    {
        kWYIfDAhCbv4 = (1720 - 813) - (1493 - 586);
        for (; kWYIfDAhCbv4 <= (1923 - 924);) {
            if (CZWnSj34gRpH[kWYIfDAhCbv4] == '\0') {
                gSOIZgVFrvu = kWYIfDAhCbv4 - (252 - 251);
                break;
            }
            kWYIfDAhCbv4 = kWYIfDAhCbv4 + (920 - 919);
        }
    }
    {
        if ((284 - 284)) {
            return (673 - 673);
        }
    }
    K8TbYiPG = (320 - 319);
    {
        kWYIfDAhCbv4 = (1175 - 339) - (1192 - 356);
        for (; kWYIfDAhCbv4 <= gSOIZgVFrvu;) {
            {
                {
                    if ((183 - 183)) {
                        return (497 - 497);
                    }
                }
                {
                    {
                        if ((998 - 998)) {
                            return (573 - 573);
                        }
                    }
                    {
                        if ((710 - 710)) {
                            return (544 - 544);
                        }
                    }
                    if ((28 - 28)) {
                        {
                            if ((339 - 339)) {
                                return (683 - 683);
                            }
                        }
                        return (98 - 98);
                    }
                }
                {
                    if ((416 - 416)) {
                        return (751 - 751);
                    }
                }
                if ((780 - 780)) {
                    {
                        if ((44 - 44)) {
                            return (38 - 38);
                        }
                    }
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (598 - 598);
                }
            }
            if (CZWnSj34gRpH[kWYIfDAhCbv4] == CZWnSj34gRpH[kWYIfDAhCbv4 + (719 - 718)]) {
                K8TbYiPG = K8TbYiPG +(545 - 544);
            }
            else {
                printf ("(%c,%d)", CZWnSj34gRpH[kWYIfDAhCbv4], K8TbYiPG);
                K8TbYiPG = (516 - 515);
                continue;
            }
            kWYIfDAhCbv4 = kWYIfDAhCbv4 + (197 - 196);
        }
    }
    return (766 - 766);
}

