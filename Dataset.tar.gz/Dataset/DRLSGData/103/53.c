main () {
    int rn3iQ4;
    char XuKlFn39w2 [(1372 - 372)];
    int mKrJCmE3ob;
    int GpBvAX6F;
    int i12YTxeBuVO [(1446 - 446)];
    int lWs34y [(1949 - 949)] = {(742 - 742)};
    rn3iQ4 = (234 - 234);
    scanf ("%s", XuKlFn39w2);
    GpBvAX6F = strlen (XuKlFn39w2);
    i12YTxeBuVO[(907 - 907)] = XuKlFn39w2[(57 - 57)];
    {
        mKrJCmE3ob = (1880 - 963) - (1273 - 357);
        for (; GpBvAX6F > mKrJCmE3ob;) {
            {
                if ((985 - 985)) {
                    return (657 - 657);
                }
            }
            {
                {
                    if ((604 - 604)) {
                        return (71 - 71);
                    }
                }
                if ((887 - 887)) {
                    {
                        {
                            if ((344 - 344)) {
                                return (403 - 403);
                            }
                        }
                        if ((875 - 875)) {
                            return (445 - 445);
                        }
                    }
                    {
                        if ((616 - 616)) {
                            return (52 - 52);
                        }
                    }
                    return (543 - 543);
                }
            }
            if (!(XuKlFn39w2[mKrJCmE3ob - (848 - 847)] != XuKlFn39w2[mKrJCmE3ob]) || !(XuKlFn39w2[mKrJCmE3ob - (733 - 732)] - 'a' + 'A' != XuKlFn39w2[mKrJCmE3ob]) || !(XuKlFn39w2[mKrJCmE3ob - (759 - 758)] - 'A' + 'a' != XuKlFn39w2[mKrJCmE3ob]))
                lWs34y[rn3iQ4] = lWs34y[rn3iQ4] + (685 - 684);
            else {
                {
                    if ((844 - 844)) {
                        return (399 - 399);
                    }
                }
                {
                    if ((828 - 828)) {
                        return (626 - 626);
                    }
                }
                {
                    if ((571 - 571)) {
                        return (704 - 704);
                    }
                }
                rn3iQ4 = rn3iQ4 + (208 - 207);
                {
                    if ((44 - 44)) {
                        return 0;
                    }
                }
                i12YTxeBuVO[rn3iQ4] = XuKlFn39w2[mKrJCmE3ob];
            }
            mKrJCmE3ob = mKrJCmE3ob + (735 - 734);
        }
    }
    {
        mKrJCmE3ob = (728 - 201) - (736 - 209);
        for (; rn3iQ4 >= mKrJCmE3ob;) {
            if (i12YTxeBuVO[mKrJCmE3ob] <= 'z' && 'a' <= i12YTxeBuVO[mKrJCmE3ob])
                i12YTxeBuVO[mKrJCmE3ob] = i12YTxeBuVO[mKrJCmE3ob] - 'a' + 'A';
            mKrJCmE3ob = mKrJCmE3ob + (657 - 656);
        }
    }
    {
        {
            if ((187 - 187)) {
                return (719 - 719);
            }
        }
        mKrJCmE3ob = (541 - 541);
        for (; mKrJCmE3ob <= rn3iQ4;) {
            printf ("(%c,%d)", i12YTxeBuVO[mKrJCmE3ob], lWs34y[mKrJCmE3ob] + (668 - 667));
            mKrJCmE3ob = mKrJCmE3ob + (310 - 309);
        }
    }
}

