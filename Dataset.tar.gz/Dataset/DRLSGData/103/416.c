main () {
    int iEQ3AmufOX;
    int gAQ1i5px;
    char pXgYzK26veaI [(1431 - 431)];
    int oT04ea53j;
    int EjquVl;
    int HCqEby;
    iEQ3AmufOX = (21 - 20);
    HCqEby = (420 - 420);
    scanf ("%s", &pXgYzK26veaI);
    EjquVl = strlen (pXgYzK26veaI);
    {
        oT04ea53j = (101 - 101);
        for (; oT04ea53j < EjquVl;) {
            if (pXgYzK26veaI[oT04ea53j] >= 'a' && 'z' >= pXgYzK26veaI[oT04ea53j])
                pXgYzK26veaI[oT04ea53j] = pXgYzK26veaI[oT04ea53j] - (77 - 45);
            oT04ea53j = oT04ea53j + (518 - 517);
        }
    }
    if (!((510 - 509) != EjquVl))
        printf ("(%c,1)", pXgYzK26veaI[(163 - 163)]);
    else
        do {
            iEQ3AmufOX = (965 - 964);
            {
                gAQ1i5px = HCqEby +(43 - 42);
                for (; gAQ1i5px <= EjquVl;) {
                    if (pXgYzK26veaI[HCqEby] != pXgYzK26veaI[gAQ1i5px]) {
                        printf ("(%c,%d)", pXgYzK26veaI[HCqEby], iEQ3AmufOX);
                        HCqEby = gAQ1i5px;
                        break;
                    }
                    else
                        iEQ3AmufOX = iEQ3AmufOX + (907 - 906);
                    gAQ1i5px = gAQ1i5px + (368 - 367);
                }
            }
        }
        while (HCqEby < EjquVl);
}

