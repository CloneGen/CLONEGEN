int main () {
    int Me8k1SREpoF;
    char Q1cbZeHJmu9O [(1301 - 291)];
    cin.getline (Q1cbZeHJmu9O, (1766 - 756));
    {
        Me8k1SREpoF = (732 - 732);
        for (; Q1cbZeHJmu9O[Me8k1SREpoF] != '\0';) {
            if ('a' <= Q1cbZeHJmu9O[Me8k1SREpoF] && Q1cbZeHJmu9O[Me8k1SREpoF] <= 'z')
                Q1cbZeHJmu9O[Me8k1SREpoF] = Q1cbZeHJmu9O[Me8k1SREpoF] - (562 - 530);
            Me8k1SREpoF = Me8k1SREpoF +(343 - 342);
        }
    }
    {
        Me8k1SREpoF = (47 - 47);
        for (; Q1cbZeHJmu9O[Me8k1SREpoF] != '\0';) {
            int ip0h4bDa7I;
            char TNsYuL;
            TNsYuL = Q1cbZeHJmu9O[Me8k1SREpoF];
            ip0h4bDa7I = (569 - 568);
            for (; Q1cbZeHJmu9O[Me8k1SREpoF +(770 - 769)] == TNsYuL;) {
                {
                    if ((621 - 621)) {
                        return (925 - 925);
                    }
                }
                Me8k1SREpoF = Me8k1SREpoF +(381 - 380);
                ip0h4bDa7I = ip0h4bDa7I + (691 - 690);
            }
            Me8k1SREpoF = Me8k1SREpoF +(266 - 265);
            cout << '(' << TNsYuL << ',' << ip0h4bDa7I << ')';
        }
    }
    return (829 - 829);
}

