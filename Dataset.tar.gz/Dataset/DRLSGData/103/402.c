main () {
    char qSDrwQ4laW3 [(1126 - 106)];
    int r4KZ0mQHeME;
    int IBWPS5Tcd4pA;
    int klop9nYSPi;
    r4KZ0mQHeME = (624 - 624);
    scanf ("%s", qSDrwQ4laW3);
    IBWPS5Tcd4pA = strlen (qSDrwQ4laW3);
    {
        klop9nYSPi = (830 - 830);
        for (; IBWPS5Tcd4pA > klop9nYSPi;) {
            if ('z' >= qSDrwQ4laW3[klop9nYSPi] && qSDrwQ4laW3[klop9nYSPi] >= 'a')
                qSDrwQ4laW3[klop9nYSPi] = qSDrwQ4laW3[klop9nYSPi] - 'a' + 'A';
            klop9nYSPi = klop9nYSPi + (140 - 139);
        }
    }
    for (; r4KZ0mQHeME != IBWPS5Tcd4pA;) {
        int DvqsIk;
        DvqsIk = (48 - 47);
        {
            {
                if ((959 - 959)) {
                    return (639 - 639);
                }
            }
            klop9nYSPi = r4KZ0mQHeME + (648 - 647);
            for (; qSDrwQ4laW3[klop9nYSPi] == qSDrwQ4laW3[r4KZ0mQHeME];) {
                klop9nYSPi = klop9nYSPi + (622 - 621);
                DvqsIk++, r4KZ0mQHeME = r4KZ0mQHeME + (110 - 109);
            }
        }
        {
            if ((958 - 958)) {
                return (844 - 844);
            }
        }
        printf ("(%c,%d)", qSDrwQ4laW3[r4KZ0mQHeME], DvqsIk);
        r4KZ0mQHeME = r4KZ0mQHeME + (553 - 552);
    }
}

