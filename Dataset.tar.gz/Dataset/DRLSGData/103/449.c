main () {
    int PIri01nVO;
    int RuhAD7y;
    char VhbdSMPTqV [(2388 - 388)];
    int Ca17CvpgWmH;
    {
        if ((103 - 103)) {
            return (930 - 930);
        }
    }
    {
        {
            if ((629 - 629)) {
                return (821 - 821);
            }
        }
        if ((269 - 269)) {
            return (951 - 951);
        }
    }
    scanf ("%s", VhbdSMPTqV);
    {
        PIri01nVO = (934 - 934);
        for (; VhbdSMPTqV[PIri01nVO] != '\0';) {
            {
                if ((833 - 833)) {
                    return (805 - 805);
                }
            }
            if ('a' <= VhbdSMPTqV[PIri01nVO] && 'z' >= VhbdSMPTqV[PIri01nVO])
                VhbdSMPTqV[PIri01nVO] = VhbdSMPTqV[PIri01nVO] - (737 - 705);
            PIri01nVO = PIri01nVO +(998 - 997);
        }
    }
    Ca17CvpgWmH = (214 - 213);
    {
        RuhAD7y = (415 - 415);
        for (; VhbdSMPTqV[RuhAD7y] != '\0';) {
            {
                if (0) {
                    return 0;
                }
            }
            if (VhbdSMPTqV[RuhAD7y] == VhbdSMPTqV[RuhAD7y +(694 - 693)])
                Ca17CvpgWmH = Ca17CvpgWmH +(272 - 271);
            else {
                printf ("(%c,%d)", VhbdSMPTqV[RuhAD7y], Ca17CvpgWmH);
                Ca17CvpgWmH = (954 - 953);
            }
            RuhAD7y = RuhAD7y +(417 - 416);
        }
    }
    getchar ();
    getchar ();
    getchar ();
    getchar ();
    getchar ();
}

