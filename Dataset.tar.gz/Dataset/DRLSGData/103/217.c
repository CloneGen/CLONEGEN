int main () {
    int pZh8HmxV1ewz;
    int rM4fWq5nrd68;
    int WgRxVKDBM2;
    char TPyF7vszJ [(1040 - 940)];
    gets (TPyF7vszJ);
    int QJeSAHWj;
    WgRxVKDBM2 = strlen (TPyF7vszJ);
    QJeSAHWj = (422 - 421);
    {
        rM4fWq5nrd68 = (839 - 839);
        for (; rM4fWq5nrd68 < WgRxVKDBM2;) {
            if (TPyF7vszJ[rM4fWq5nrd68] >= 'A' && TPyF7vszJ[rM4fWq5nrd68] <= 'Z') {
                if (!(TPyF7vszJ[rM4fWq5nrd68] != TPyF7vszJ[rM4fWq5nrd68 + (385 - 384)]) || !(TPyF7vszJ[rM4fWq5nrd68] + (557 - 525) != TPyF7vszJ[rM4fWq5nrd68 + (185 - 184)])) {
                    QJeSAHWj = QJeSAHWj +(173 - 172);
                    continue;
                }
                else {
                    printf ("(%c,%d)", TPyF7vszJ[rM4fWq5nrd68], QJeSAHWj);
                    QJeSAHWj = (412 - 411);
                    continue;
                }
            }
            else if (TPyF7vszJ[rM4fWq5nrd68] >= 'a' && TPyF7vszJ[rM4fWq5nrd68] <= 'z') {
                if (TPyF7vszJ[rM4fWq5nrd68 + (824 - 823)] == TPyF7vszJ[rM4fWq5nrd68] || TPyF7vszJ[rM4fWq5nrd68 + (723 - 722)] == TPyF7vszJ[rM4fWq5nrd68] - (266 - 234)) {
                    QJeSAHWj = QJeSAHWj +(857 - 856);
                    continue;
                }
                else {
                    printf ("(%c,%d)", TPyF7vszJ[rM4fWq5nrd68] - (140 - 108), QJeSAHWj);
                    QJeSAHWj = (442 - 441);
                    continue;
                }
            }
            else
                ;
            rM4fWq5nrd68 = rM4fWq5nrd68 + (787 - 786);
        }
    }
    return (784 - 784);
}

