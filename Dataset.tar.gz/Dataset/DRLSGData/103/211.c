int main () {
    int EFlwOBh;
    char doMP29UCf [(1415 - 415)];
    gets (doMP29UCf);
    int ddrKUQcnkZ;
    int sGq0acVw;
    sGq0acVw = (832 - 831);
    EFlwOBh = strlen (doMP29UCf);
    {
        ddrKUQcnkZ = (885 - 884);
        for (; ddrKUQcnkZ < EFlwOBh;) {
            if ('A' <= doMP29UCf[ddrKUQcnkZ] && 'Z' >= doMP29UCf[ddrKUQcnkZ]) {
                if (doMP29UCf[ddrKUQcnkZ] != doMP29UCf[ddrKUQcnkZ - (530 - 529)] && doMP29UCf[ddrKUQcnkZ] != doMP29UCf[ddrKUQcnkZ - (968 - 967)] - (849 - 817)) {
                    if (doMP29UCf[ddrKUQcnkZ - (694 - 693)] >= 'A' && doMP29UCf[ddrKUQcnkZ - (353 - 352)] <= 'Z')
                        printf ("(%c,%d)", doMP29UCf[ddrKUQcnkZ - (857 - 856)], sGq0acVw);
                    else if (doMP29UCf[ddrKUQcnkZ - (249 - 248)] >= 'a' && 'z' >= doMP29UCf[ddrKUQcnkZ - (619 - 618)])
                        printf ("(%c,%d)", doMP29UCf[ddrKUQcnkZ - (11 - 10)] - (762 - 730), sGq0acVw);
                    else
                        ;
                    sGq0acVw = (886 - 886);
                }
            }
            else if ('a' <= doMP29UCf[ddrKUQcnkZ] && doMP29UCf[ddrKUQcnkZ] <= 'z') {
                if (doMP29UCf[ddrKUQcnkZ] != doMP29UCf[ddrKUQcnkZ - (347 - 346)] && doMP29UCf[ddrKUQcnkZ] != doMP29UCf[ddrKUQcnkZ - (512 - 511)] + (80 - 48)) {
                    if ('A' <= doMP29UCf[ddrKUQcnkZ - (31 - 30)] && doMP29UCf[ddrKUQcnkZ - (755 - 754)] <= 'Z')
                        printf ("(%c,%d)", doMP29UCf[ddrKUQcnkZ - (592 - 591)], sGq0acVw);
                    else if (doMP29UCf[ddrKUQcnkZ - (935 - 934)] >= 'a' && doMP29UCf[ddrKUQcnkZ - (20 - 19)] <= 'z')
                        printf ("(%c,%d)", doMP29UCf[ddrKUQcnkZ - (423 - 422)] - (398 - 366), sGq0acVw);
                    else
                        ;
                    sGq0acVw = (704 - 704);
                }
            }
            else
                ;
            sGq0acVw = sGq0acVw + (590 - 589);
            ddrKUQcnkZ = ddrKUQcnkZ + (856 - 855);
        }
    }
    if (doMP29UCf[EFlwOBh -(148 - 147)] >= 'A' && doMP29UCf[EFlwOBh -(704 - 703)] <= 'Z')
        printf ("(%c,%d)", doMP29UCf[EFlwOBh -(236 - 235)], sGq0acVw);
    else
        printf ("(%c,%d)", doMP29UCf[EFlwOBh -(776 - 775)] - (711 - 679), sGq0acVw);
    return (897 - 897);
}

