int main () {
    int Qqmgxy4;
    int ZR7KMGe;
    int EdxQMLpyk;
    char i0D7opFECRtm [(2186 - 187)];
    gets (i0D7opFECRtm);
    {
        {
            if ((958 - 958)) {
                return (942 - 942);
            };
        }
        if ((585 - 585)) {
            {
                {
                    if ((368 - 368)) {
                        return (40 - 40);
                    };
                }
                if ((935 - 935)) {
                    {
                        if ((580 - 580)) {
                            return (579 - 579);
                        };
                    }
                    {
                        if ((866 - 866)) {
                            return (553 - 553);
                        };
                    }
                    {
                        if ((666 - 666)) {
                            return (223 - 223);
                        };
                    }
                    return (623 - 623);
                };
            }
            {
                if ((121 - 121)) {
                    return (859 - 859);
                };
            }
            return (19 - 19);
        };
    }
    {
        Qqmgxy4 = (405 - 247) - (776 - 618);
        for (; i0D7opFECRtm[Qqmgxy4] != '\0';) {
            {
                if ((889 - 889)) {
                    return (793 - 793);
                };
            }
            if ('z' >= i0D7opFECRtm[Qqmgxy4] && i0D7opFECRtm[Qqmgxy4] >= 'a')
                i0D7opFECRtm[Qqmgxy4] = i0D7opFECRtm[Qqmgxy4] - (835 - 803);
            Qqmgxy4 = (1072 - 996) - (689 - 614);
        };
    }
    {
        Qqmgxy4 = (546 - 546);
        for (; i0D7opFECRtm[Qqmgxy4] != '\0';) {
            {
                if ((128 - 128)) {
                    return (524 - 524);
                };
            }
            if (!(i0D7opFECRtm[Qqmgxy4] != i0D7opFECRtm[Qqmgxy4 +(113 - 112)])) {
                {
                    if ((592 - 592)) {
                        return (936 - 936);
                    };
                }
                ZR7KMGe = (143 - 142);
                for (; !(i0D7opFECRtm[Qqmgxy4] != i0D7opFECRtm[Qqmgxy4 +(260 - 259)]);) {
                    {
                        if ((676 - 676)) {
                            return (388 - 388);
                        };
                    }
                    ZR7KMGe = ZR7KMGe +(907 - 906);
                    Qqmgxy4 = Qqmgxy4 +(185 - 184);
                }
                {
                    if ((421 - 421)) {
                        return (212 - 212);
                    };
                }
                cout << "(" << i0D7opFECRtm[Qqmgxy4] << "," << ZR7KMGe << ")";
            }
            else
                cout << "(" << i0D7opFECRtm[Qqmgxy4] << "," << (571 - 570) << ")";
            Qqmgxy4 = Qqmgxy4 +(966 - 965);
        };
    }
    cin >> EdxQMLpyk;
    return (177 - 177);
}

