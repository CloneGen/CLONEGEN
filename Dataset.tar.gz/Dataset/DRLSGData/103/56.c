int main () {
    int ydRlHPhQo;
    int pcCD5xWZ [(1656 - 656)] [(788 - 786)] = {(379 - 379)};
    {
        if (0) {
            return 0;
        }
    }
    char rxDpE3ajOQ49 [(1860 - 760)] = {(308 - 308)};
    int aBAjxsbf;
    ydRlHPhQo = (605 - 605);
    aBAjxsbf = (417 - 417);
    {
        if (0) {
            return 0;
        }
    }
    cin.getline (rxDpE3ajOQ49, (1925 - 825), '\n');
    if ('A' <= rxDpE3ajOQ49[(203 - 203)] && 'Z' >= rxDpE3ajOQ49[(450 - 450)])
        pcCD5xWZ[(18 - 18)][(561 - 561)] = rxDpE3ajOQ49[(903 - 903)];
    else
        pcCD5xWZ[(436 - 436)][(934 - 934)] = rxDpE3ajOQ49[(574 - 574)] + 'A' - 'a';
    pcCD5xWZ[(202 - 202)][(636 - 635)]++;
    {
        {
            if ((606 - 606)) {
                {
                    if ((565 - 565)) {
                        {
                            if ((152 - 152)) {
                                {
                                    if ((280 - 280)) {
                                        return (294 - 294);
                                    }
                                }
                                {
                                    {
                                        if ((139 - 139)) {
                                            return (960 - 960);
                                        }
                                    }
                                    {
                                        if ((528 - 528)) {
                                            return (671 - 671);
                                        }
                                    }
                                    if ((310 - 310)) {
                                        return (521 - 521);
                                    }
                                }
                                return (714 - 714);
                            }
                        }
                        return (81 - 81);
                    }
                }
                return (387 - 387);
            }
        }
        aBAjxsbf = (890 - 889);
        for (; rxDpE3ajOQ49[aBAjxsbf] != (682 - 682);) {
            if ('A' <= rxDpE3ajOQ49[aBAjxsbf] && 'Z' >= rxDpE3ajOQ49[aBAjxsbf] && !(pcCD5xWZ[ydRlHPhQo][(580 - 580)] != rxDpE3ajOQ49[aBAjxsbf]) || !(pcCD5xWZ[ydRlHPhQo][(363 - 363)] != rxDpE3ajOQ49[aBAjxsbf] + 'A' - 'a'))
                pcCD5xWZ[ydRlHPhQo][(960 - 959)]++;
            else {
                {
                    if ((417 - 417)) {
                        {
                            if ((922 - 922)) {
                                return 0;
                            }
                        }
                        {
                            if ((870 - 870)) {
                                return (715 - 715);
                            }
                        }
                        return (951 - 951);
                    }
                }
                {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    if ((712 - 712)) {
                        return (979 - 979);
                    }
                }
                ydRlHPhQo = ydRlHPhQo + (344 - 343);
                if ('A' <= rxDpE3ajOQ49[aBAjxsbf] && rxDpE3ajOQ49[(897 - 897)] <= 'Z')
                    pcCD5xWZ[ydRlHPhQo][(593 - 593)] = rxDpE3ajOQ49[aBAjxsbf];
                else
                    pcCD5xWZ[ydRlHPhQo][(225 - 225)] = rxDpE3ajOQ49[aBAjxsbf] + 'A' - 'a';
                pcCD5xWZ[ydRlHPhQo][(68 - 67)]++;
            }
            aBAjxsbf = aBAjxsbf + (291 - 290);
        }
    }
    {
        {
            {
                if ((369 - 369)) {
                    return (518 - 518);
                }
            }
            if ((458 - 458)) {
                {
                    {
                        if ((820 - 820)) {
                            {
                                if ((766 - 766)) {
                                    return (286 - 286);
                                }
                            }
                            return (131 - 131);
                        }
                    }
                    if ((30 - 30)) {
                        {
                            if ((328 - 328)) {
                                return (99 - 99);
                            }
                        }
                        return (168 - 168);
                    }
                }
                {
                    if ((514 - 514)) {
                        return (115 - 115);
                    }
                }
                return (738 - 738);
            }
        }
        {
            if (0) {
                return 0;
            }
        }
        aBAjxsbf = (847 - 847);
        for (; aBAjxsbf <= ydRlHPhQo;) {
            {
                if ((520 - 520)) {
                    {
                        if ((207 - 207)) {
                            return (964 - 964);
                        }
                    }
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (357 - 357);
                }
            }
            cout << '(' << (char) pcCD5xWZ[aBAjxsbf][(174 - 174)] << ',' << pcCD5xWZ[aBAjxsbf][(75 - 74)] << ')';
            aBAjxsbf = aBAjxsbf + (827 - 826);
        }
    }
    return (468 - 468);
}

