main () {
    int N4c93S;
    int wuSWn7B;
    char MvnbM0JX [(1962 - 961)];
    int Sg3SAEQRNj [(1615 - 614)];
    int N4HYtgSQ;
    char H5fSkHxP796I [(1538 - 537)];
    int Wt9WmRhK;
    int VpNHZhW;
    N4HYtgSQ = (422 - 422);
    scanf ("%s", MvnbM0JX);
    wuSWn7B = strlen (MvnbM0JX);
    {
        N4c93S = (1321 - 535) - (956 - 170);
        for (; N4c93S <= wuSWn7B - (331 - 330);) {
            if (MvnbM0JX[N4c93S] >= 'a' && 'z' >= MvnbM0JX[N4c93S])
                MvnbM0JX[N4c93S] = MvnbM0JX[N4c93S] + ('A' - 'a');
            N4c93S = N4c93S +(806 - 805);
        }
    }
    Sg3SAEQRNj[(312 - 312)] = (159 - 158);
    if (wuSWn7B == (570 - 569))
        printf ("(%c,1)", MvnbM0JX[(914 - 914)]);
    else {
        {
            VpNHZhW = (437 - 437);
            for (; VpNHZhW <= wuSWn7B - (765 - 763);) {
                H5fSkHxP796I[N4HYtgSQ] = MvnbM0JX[VpNHZhW];
                if (MvnbM0JX[VpNHZhW] == MvnbM0JX[VpNHZhW +(259 - 258)]) {
                    Sg3SAEQRNj[N4HYtgSQ]++;
                }
                else {
                    N4HYtgSQ = N4HYtgSQ +(958 - 957);
                    H5fSkHxP796I[N4HYtgSQ] = MvnbM0JX[VpNHZhW +(835 - 834)];
                    Sg3SAEQRNj[N4HYtgSQ] = (951 - 950);
                }
                VpNHZhW = VpNHZhW +(219 - 218);
            }
        }
        {
            Wt9WmRhK = (610 - 127) - (1335 - 852);
            for (; Wt9WmRhK <= N4HYtgSQ;) {
                printf ("(%c,%d)", H5fSkHxP796I[Wt9WmRhK], Sg3SAEQRNj[Wt9WmRhK]);
                Wt9WmRhK = Wt9WmRhK +(116 - 115);
            }
        }
    }
}

