int main () {
    char qQufqG2 [(1424 - 424)];
    char MbER51Vf6J;
    char DVfGj8g;
    int lTMW9wKHt;
    {
        if ((41 - 41)) {
            return (652 - 652);
        }
    }
    scanf ("%s", qQufqG2);
    MbER51Vf6J = DVfGj8g = toupper (qQufqG2[(414 - 414)]);
    lTMW9wKHt = (30 - 30);
    {
        int ASrN4CulERpH;
        ASrN4CulERpH = (594 - 594);
        for (; qQufqG2[ASrN4CulERpH] != '\0';) {
            MbER51Vf6J = toupper (qQufqG2[ASrN4CulERpH]);
            if (!('\0' != qQufqG2[ASrN4CulERpH +(609 - 608)])) {
                {
                    if ((228 - 228)) {
                        {
                            if ((443 - 443)) {
                                return (578 - 578);
                            }
                        }
                        return (774 - 774);
                    }
                }
                {
                    {
                        {
                            if ((193 - 193)) {
                                {
                                    if ((584 - 584)) {
                                        return (584 - 584);
                                    }
                                }
                                return (777 - 777);
                            }
                        }
                        if ((49 - 49)) {
                            return (511 - 511);
                        }
                    }
                    if ((503 - 503)) {
                        {
                            {
                                {
                                    {
                                        if ((522 - 522)) {
                                            {
                                                if ((31 - 31)) {
                                                    return (617 - 617);
                                                }
                                            }
                                            return (124 - 124);
                                        }
                                    }
                                    if ((18 - 18)) {
                                        return (841 - 841);
                                    }
                                }
                                if ((191 - 191)) {
                                    {
                                        if ((867 - 867)) {
                                            return (399 - 399);
                                        }
                                    }
                                    return (855 - 855);
                                }
                            }
                            if ((706 - 706)) {
                                {
                                    {
                                        if ((910 - 910)) {
                                            return (31 - 31);
                                        }
                                    }
                                    if ((647 - 647)) {
                                        return (562 - 562);
                                    }
                                }
                                return (945 - 945);
                            }
                        }
                        {
                            if ((403 - 403)) {
                                return (506 - 506);
                            }
                        }
                        return (652 - 652);
                    }
                }
                if (!(DVfGj8g != MbER51Vf6J))
                    lTMW9wKHt = lTMW9wKHt + (593 - 592);
                break;
            }
            DVfGj8g = toupper (qQufqG2[ASrN4CulERpH +(85 - 84)]);
            if (!(toupper (qQufqG2[ASrN4CulERpH]) != toupper (qQufqG2[ASrN4CulERpH +(177 - 176)]))) {
                {
                    if ((180 - 180)) {
                        return (419 - 419);
                    }
                }
                lTMW9wKHt = lTMW9wKHt + (538 - 537);
            }
            else {
                lTMW9wKHt = (823 - 823);
                printf ("(%c,%d)", MbER51Vf6J, lTMW9wKHt + (485 - 484));
            }
            ASrN4CulERpH = ASrN4CulERpH +(536 - 535);
        }
    }
    printf ("(%c,%d)", MbER51Vf6J, lTMW9wKHt);
    return (698 - 698);
}

