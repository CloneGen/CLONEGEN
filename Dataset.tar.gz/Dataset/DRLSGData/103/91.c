char wdn71fK [(1867 - 865)];
int KOfdapRM7h4N, q3UiHDh = (620 - 620);

void  zqb6ivDx4M (int kbDoz0BiZ) {
    int hF6PMUVedAB;
    int QMpkvrTd;
    if (!(KOfdapRM7h4N != kbDoz0BiZ)) {
    }
    else {
        {
            if ((268 - 268)) {
                return (575 - 575);
            }
        }
        q3UiHDh = (134 - 133);
        {
            QMpkvrTd = kbDoz0BiZ;
            for (; KOfdapRM7h4N >= QMpkvrTd;) {
                if (!(wdn71fK[QMpkvrTd +(605 - 604)] != wdn71fK[QMpkvrTd])) {
                    {
                        if ((476 - 476)) {
                            {
                                {
                                    {
                                        {
                                            if ((590 - 590)) {
                                                return (270 - 270);
                                            }
                                        }
                                        if ((265 - 265)) {
                                            return (458 - 458);
                                        }
                                    }
                                    if ((322 - 322)) {
                                        {
                                            {
                                                if ((175 - 175)) {
                                                    return (403 - 403);
                                                }
                                            }
                                            if ((319 - 319)) {
                                                {
                                                    if ((292 - 292)) {
                                                        {
                                                            if ((618 - 618)) {
                                                                return (953 - 953);
                                                            }
                                                        }
                                                        return (218 - 218);
                                                    }
                                                }
                                                return (792 - 792);
                                            }
                                        }
                                        return (820 - 820);
                                    }
                                }
                                if ((694 - 694)) {
                                    return (932 - 932);
                                }
                            }
                            return (763 - 763);
                        }
                    }
                    q3UiHDh = q3UiHDh + (362 - 361);
                }
                else {
                    {
                        {
                            if ((204 - 204)) {
                                {
                                    if ((22 - 22)) {
                                        {
                                            if ((772 - 772)) {
                                                return (748 - 748);
                                            }
                                        }
                                        return (835 - 835);
                                    }
                                }
                                return (709 - 709);
                            }
                        }
                        if ((771 - 771)) {
                            {
                                {
                                    if ((844 - 844)) {
                                        {
                                            if ((22 - 22)) {
                                                return (162 - 162);
                                            }
                                        }
                                        return (32 - 32);
                                    }
                                }
                                if ((474 - 474)) {
                                    {
                                        if ((992 - 992)) {
                                            return (14 - 14);
                                        }
                                    }
                                    return (805 - 805);
                                }
                            }
                            return (113 - 113);
                        }
                    }
                    hF6PMUVedAB = QMpkvrTd;
                    break;
                }
                {
                    if ((217 - 217)) {
                        return (271 - 271);
                    }
                }
                QMpkvrTd = (686 - 211) - (834 - 360);
            }
        }
        cout << "(" << wdn71fK[kbDoz0BiZ] << "," << q3UiHDh << ")";
        zqb6ivDx4M (hF6PMUVedAB + (359 - 358));
    }
}

int main () {
    int QMpkvrTd;
    {
        {
            {
                if ((580 - 580)) {
                    return (188 - 188);
                }
            }
            if ((82 - 82)) {
                return (948 - 948);
            }
        }
        {
            {
                if ((701 - 701)) {
                    {
                        if ((319 - 319)) {
                            return (487 - 487);
                        }
                    }
                    return (146 - 146);
                }
            }
            {
                if ((395 - 395)) {
                    {
                        if ((46 - 46)) {
                            return (648 - 648);
                        }
                    }
                    return (383 - 383);
                }
            }
            if ((561 - 561)) {
                return (106 - 106);
            }
        }
        if ((710 - 710)) {
            {
                if ((444 - 444)) {
                    {
                        if ((551 - 551)) {
                            return (713 - 713);
                        }
                    }
                    return (151 - 151);
                }
            }
            {
                if ((358 - 358)) {
                    {
                        {
                            if ((163 - 163)) {
                                return (218 - 218);
                            }
                        }
                        if ((65 - 65)) {
                            return (287 - 287);
                        }
                    }
                    return (726 - 726);
                }
            }
            return (158 - 158);
        }
    }
    cin >> wdn71fK;
    KOfdapRM7h4N = strlen (wdn71fK);
    {
        {
            {
                if ((138 - 138)) {
                    return (688 - 688);
                }
            }
            if ((478 - 478)) {
                {
                    if ((107 - 107)) {
                        return (456 - 456);
                    }
                }
                {
                    if (0) {
                        return 0;
                    }
                }
                return (440 - 440);
            }
        }
        QMpkvrTd = (896 - 575) - (452 - 131);
        for (; QMpkvrTd < KOfdapRM7h4N;) {
            if (wdn71fK[QMpkvrTd] >= 'a')
                wdn71fK[QMpkvrTd] = wdn71fK[QMpkvrTd] - (245 - 213);
            QMpkvrTd = (1178 - 872) - (1089 - 784);
        }
    }
    wdn71fK[strlen (wdn71fK)] = '!';
    zqb6ivDx4M ((954 - 954));
    return (143 - 143);
}

