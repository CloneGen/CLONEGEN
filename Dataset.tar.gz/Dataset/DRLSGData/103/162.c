main () {
    int LLC1s9Uup2qB;
    char P9uZYadl;
    int MW2ucRjBqU;
    int MH1qgKc;
    char UiobDu0jaHy [(10631 - 631)];
    gets (UiobDu0jaHy);
    MW2ucRjBqU = (603 - 603);
    getchar ();
    getchar ();
    P9uZYadl = UiobDu0jaHy[(542 - 542)];
    MH1qgKc = strlen (UiobDu0jaHy);
    {
        LLC1s9Uup2qB = (792 - 792);
        for (; MH1qgKc > LLC1s9Uup2qB;) {
            {
                int XnpD0KWc5HV;
                XnpD0KWc5HV = 'a';
                for (; XnpD0KWc5HV <= 'z';) {
                    if (!(XnpD0KWc5HV != UiobDu0jaHy[LLC1s9Uup2qB]))
                        UiobDu0jaHy[LLC1s9Uup2qB] = XnpD0KWc5HV -(808 - 776);
                    XnpD0KWc5HV = XnpD0KWc5HV +(770 - 769);
                }
            }
            LLC1s9Uup2qB = LLC1s9Uup2qB +(97 - 96);
        }
    }
    {
        LLC1s9Uup2qB = (39 - 39);
        for (; MH1qgKc >= LLC1s9Uup2qB;) {
            if (UiobDu0jaHy[LLC1s9Uup2qB] == P9uZYadl)
                MW2ucRjBqU = MW2ucRjBqU +(529 - 528);
            else {
                printf ("(%c,%d)", P9uZYadl, MW2ucRjBqU);
                P9uZYadl = UiobDu0jaHy[LLC1s9Uup2qB];
                LLC1s9Uup2qB = LLC1s9Uup2qB -(27 - 26);
                MW2ucRjBqU = (34 - 34);
            }
            LLC1s9Uup2qB = LLC1s9Uup2qB +(418 - 417);
        }
    }
}

