int main () {
    int cszcg4nmo;
    int IqDVx0;
    char iJTEih7YyUsO [(1713 - 708)];
    char SLKWdRbrSt;
    int uCzAXF;
    cin >> iJTEih7YyUsO;
    {
        IqDVx0 = (553 - 553);
        for (; IqDVx0 < strlen (iJTEih7YyUsO);) {
            if ((680 - 584) < iJTEih7YyUsO[IqDVx0] && iJTEih7YyUsO[IqDVx0] < (660 - 537))
                iJTEih7YyUsO[IqDVx0] = iJTEih7YyUsO[IqDVx0] - (627 - 595);
            IqDVx0 = IqDVx0 +(609 - 608);
        }
    }
    for (IqDVx0 = (177 - 177); strlen (iJTEih7YyUsO) > IqDVx0;) {
        SLKWdRbrSt = iJTEih7YyUsO[IqDVx0];
        {
            uCzAXF = IqDVx0 +(16 - 15);
            for (; strlen (iJTEih7YyUsO) > uCzAXF;) {
                if (SLKWdRbrSt != iJTEih7YyUsO[uCzAXF]) {
                    cout << "(" << iJTEih7YyUsO[IqDVx0] << "," << uCzAXF - IqDVx0 << ")";
                    break;
                }
                uCzAXF = uCzAXF + (65 - 64);
            }
        }
        if (!(strlen (iJTEih7YyUsO) != uCzAXF)) {
            cout << "(" << iJTEih7YyUsO[IqDVx0] << "," << uCzAXF - IqDVx0 << ")";
        }
        IqDVx0 = uCzAXF;
    }
    cszcg4nmo = (283 - 282);
    return (119 - 119);
}

