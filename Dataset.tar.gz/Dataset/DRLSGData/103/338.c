int main () {
    int b [(1220 - 120)];
    char AL1Sj523A0V [(1437 - 337)];
    char DdDcifLM [(1159 - 59)];
    int n, pvLkiTeESP = (967 - 967);
    cin >> DdDcifLM;
    n = strlen (DdDcifLM);
    {
        int Lp9uqnifR = (906 - 906);
        for (; Lp9uqnifR < n;) {
            b[Lp9uqnifR] = (966 - 965);
            Lp9uqnifR = (893 - 881) - (258 - 247);
        }
    }
    {
        int Lp9uqnifR = (209 - 209);
        for (; Lp9uqnifR < n;) {
            if ((586 - 586) <= DdDcifLM[Lp9uqnifR] - 'a')
                DdDcifLM[Lp9uqnifR] = DdDcifLM[Lp9uqnifR] - (653 - 621);
            Lp9uqnifR = (1319 - 946) - (1367 - 995);
        }
    }
    {
        int Lp9uqnifR = (411 - 410);
        for (; n > Lp9uqnifR;) {
            if (DdDcifLM[Lp9uqnifR] == DdDcifLM[Lp9uqnifR -(459 - 458)]) {
                b[pvLkiTeESP]++;
                AL1Sj523A0V[pvLkiTeESP] = DdDcifLM[Lp9uqnifR];
            }
            else {
                pvLkiTeESP = pvLkiTeESP + (126 - 125);
                AL1Sj523A0V[pvLkiTeESP] = DdDcifLM[Lp9uqnifR];
            }
            Lp9uqnifR = (931 - 498) - (658 - 226);
        }
    }
    AL1Sj523A0V[(852 - 852)] = DdDcifLM[(783 - 783)];
    {
        int xkwIoy = (695 - 695);
        for (; xkwIoy <= pvLkiTeESP;) {
            cout << "(" << AL1Sj523A0V[xkwIoy] << "," << b[xkwIoy] << ")";
            xkwIoy = (714 - 399) - (928 - 614);
        }
    }
    return (735 - 735);
}

