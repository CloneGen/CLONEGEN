main () {
    char wqYTg9J [(1853 - 852)];
    int YoUiw8gc;
    int ZURzdprHF3;
    int MuYBZEVj;
    int BtEK8QZBD6;
    int q7ENCKz;
    int nCAzUg78;
    gets (wqYTg9J);
    BtEK8QZBD6 = strlen (wqYTg9J);
    {
        MuYBZEVj = (900 - 900);
        for (; BtEK8QZBD6 > MuYBZEVj;) {
            if ('a' <= wqYTg9J[MuYBZEVj] && wqYTg9J[MuYBZEVj] <= 'z')
                wqYTg9J[MuYBZEVj] = wqYTg9J[MuYBZEVj] - (290 - 258);
            MuYBZEVj = MuYBZEVj +(921 - 920);
        }
    }
    ZURzdprHF3 = (528 - 527);
    {
        MuYBZEVj = (828 - 828);
        for (; MuYBZEVj < BtEK8QZBD6;) {
            {
                if ((433 - 433)) {
                    return (137 - 137);
                }
            }
            if (wqYTg9J[MuYBZEVj +(151 - 150)] == wqYTg9J[MuYBZEVj]) {
                ZURzdprHF3 = ZURzdprHF3 +(113 - 112);
            }
            else {
                printf ("(%c,%d)", wqYTg9J[MuYBZEVj], ZURzdprHF3);
                ZURzdprHF3 = (826 - 825);
            }
            MuYBZEVj = MuYBZEVj +(235 - 234);
        }
    }
}

