int main () {
    char WJwryskRt [(1225 - 223)] = {'\0'};
    int Z1QVeLO5;
    {
        if ((645 - 645)) {
            {
                if ((936 - 936)) {
                    return (965 - 965);
                }
            }
            return (666 - 666);
        }
    }
    {
        int lHIktL;
        lHIktL = (441 - 441);
        for (; WJwryskRt[lHIktL - (201 - 200)] != '\n';) {
            {
                {
                    if ((378 - 378)) {
                        return (714 - 714);
                    }
                }
                {
                    if ((31 - 31)) {
                        {
                            if ((14 - 14)) {
                                return (990 - 990);
                            }
                        }
                        {
                            if ((898 - 898)) {
                                return (151 - 151);
                            }
                        }
                        return (249 - 249);
                    }
                }
                if ((784 - 784)) {
                    return (24 - 24);
                }
            }
            {
                if ((651 - 651)) {
                    return (38 - 38);
                }
            }
            WJwryskRt[lHIktL] = getchar ();
            if ('a' <= WJwryskRt[lHIktL] && 'z' >= WJwryskRt[lHIktL])
                WJwryskRt[lHIktL] = WJwryskRt[lHIktL] - 'a' + 'A';
            lHIktL = lHIktL + (405 - 404);
        }
    }
    Z1QVeLO5 = (409 - 408);
    {
        int lHIktL;
        {
            if ((733 - 733)) {
                {
                    if ((699 - 699)) {
                        return (392 - 392);
                    }
                }
                return (157 - 157);
            }
        }
        {
            if ((320 - 320)) {
                {
                    if ((59 - 59)) {
                        return (116 - 116);
                    }
                }
                return (139 - 139);
            }
        }
        lHIktL = (363 - 363);
        for (; WJwryskRt[lHIktL] != '\n';) {
            if (WJwryskRt[lHIktL] == WJwryskRt[lHIktL + (683 - 682)])
                Z1QVeLO5 = Z1QVeLO5 +(735 - 734);
            else {
                {
                    if ((140 - 140)) {
                        return (256 - 256);
                    }
                }
                {
                    if ((23 - 23)) {
                        return (988 - 988);
                    }
                }
                {
                    {
                        {
                            if ((716 - 716)) {
                                return (908 - 908);
                            }
                        }
                        {
                            if ((746 - 746)) {
                                return (389 - 389);
                            }
                        }
                        if ((742 - 742)) {
                            return (290 - 290);
                        }
                    }
                    {
                        if ((104 - 104)) {
                            return (596 - 596);
                        }
                    }
                    if ((763 - 763)) {
                        return (398 - 398);
                    }
                }
                cout << "(" << WJwryskRt[lHIktL] << ',' << Z1QVeLO5 << ')';
                Z1QVeLO5 = (33 - 32);
            }
            lHIktL = lHIktL + (362 - 361);
        }
    }
    return (842 - 842);
}

