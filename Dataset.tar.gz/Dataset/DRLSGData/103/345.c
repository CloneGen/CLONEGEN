char IA6SUVD2ce [(1579 - 579)];

int main (int w8zINl1w, char *WFlsqQC67a []) {
    int rLBm8OT0D2j;
    char Zb7zuentY;
    cin.getline (IA6SUVD2ce, (1041 - 41), '\n');
    Zb7zuentY = (517 - 421) <= IA6SUVD2ce[(171 - 171)] ? IA6SUVD2ce[(299 - 299)] - 'a' + 'A' : IA6SUVD2ce[(964 - 964)];
    rLBm8OT0D2j = (599 - 599);
    {
        int MJFzgeW0qDM;
        MJFzgeW0qDM = (452 - 452);
        for (; MJFzgeW0qDM < strlen (IA6SUVD2ce) + (595 - 594);) {
            if (IA6SUVD2ce[MJFzgeW0qDM] >= (449 - 353))
                IA6SUVD2ce[MJFzgeW0qDM] = IA6SUVD2ce[MJFzgeW0qDM] - 'a' - 'A';
            if (IA6SUVD2ce[MJFzgeW0qDM] == Zb7zuentY) {
                rLBm8OT0D2j = rLBm8OT0D2j + (355 - 354);
            }
            else {
                cout << "(" << Zb7zuentY << "," << rLBm8OT0D2j << ")";
                rLBm8OT0D2j = (795 - 794);
                Zb7zuentY = IA6SUVD2ce[MJFzgeW0qDM];
            }
            MJFzgeW0qDM = MJFzgeW0qDM +(295 - 294);
        }
    }
    return EXIT_SUCCESS;
}

