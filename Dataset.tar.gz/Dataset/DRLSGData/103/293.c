int main () {
    int aSmVCjFnGE6;
    int b4W1pCn;
    int p9ens0QVA;
    int rv0MymozF3;
    char npMxW3QIE [(1123 - 123)];
    rv0MymozF3 = (537 - 537);
    aSmVCjFnGE6 = (30 - 30);
    cin >> npMxW3QIE;
    b4W1pCn = strlen (npMxW3QIE);
    for (; aSmVCjFnGE6 < b4W1pCn;) {
        if (!(npMxW3QIE[aSmVCjFnGE6] != npMxW3QIE[aSmVCjFnGE6 + (744 - 743)]) || !(npMxW3QIE[aSmVCjFnGE6] + (757 - 725) != npMxW3QIE[aSmVCjFnGE6 + (919 - 918)]) || !(npMxW3QIE[aSmVCjFnGE6] - (148 - 116) != npMxW3QIE[aSmVCjFnGE6 + (533 - 532)])) {
            aSmVCjFnGE6 = aSmVCjFnGE6 + (579 - 578);
            rv0MymozF3 = rv0MymozF3 + (411 - 410);
            continue;
        }
        if (npMxW3QIE[aSmVCjFnGE6 + (68 - 67)] != npMxW3QIE[aSmVCjFnGE6]) {
            if (npMxW3QIE[aSmVCjFnGE6] >= 'a') {
                npMxW3QIE[aSmVCjFnGE6] = npMxW3QIE[aSmVCjFnGE6] - (999 - 967);
                cout << "(" << npMxW3QIE[aSmVCjFnGE6] << "," << rv0MymozF3 + (54 - 53) << ")";
                aSmVCjFnGE6 = aSmVCjFnGE6 + (113 - 112);
                rv0MymozF3 = (120 - 120);
                continue;
            }
            if (npMxW3QIE[aSmVCjFnGE6] < 'a') {
                cout << "(" << npMxW3QIE[aSmVCjFnGE6] << "," << rv0MymozF3 + (996 - 995) << ")";
                aSmVCjFnGE6 = aSmVCjFnGE6 + (985 - 984);
                rv0MymozF3 = (968 - 968);
                continue;
            }
        }
    }
    return (416 - 416);
}

