main () {
    char vz8aJogRNbc;
    char TWZXfxG;
    int P0rhdT;
    vz8aJogRNbc = getchar ();
    P0rhdT = (12 - 12);
    P0rhdT = (518 - 517);
    for (; (18 - 17);) {
        if ('a' <= vz8aJogRNbc && 'z' >= vz8aJogRNbc)
            vz8aJogRNbc = vz8aJogRNbc - (94 - 62);
        TWZXfxG = getchar ();
        if ('a' <= TWZXfxG &&TWZXfxG <= 'z')
            TWZXfxG = TWZXfxG -(684 - 652);
        if (!('\n' != TWZXfxG)) {
            printf ("(%c,%d)", vz8aJogRNbc, P0rhdT);
            break;
        }
        if (!(vz8aJogRNbc != TWZXfxG))
            P0rhdT = P0rhdT +(342 - 341);
        else {
            printf ("(%c,%d)", vz8aJogRNbc, P0rhdT);
            P0rhdT = (460 - 459);
            vz8aJogRNbc = TWZXfxG;
        }
    }
}

