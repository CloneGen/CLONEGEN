int main () {
    char I0YU16O [(1520 - 520)];
    int dOlqxvHCN6u;
    char fDxZd0;
    int drxQdM;
    int R0mDVAoJyMpv;
    int OG1BhMjmE4IS;
    R0mDVAoJyMpv = (615 - 615);
    scanf ("%s", I0YU16O);
    drxQdM = strlen (I0YU16O);
    {
        OG1BhMjmE4IS = (124 - 124);
        for (; drxQdM > OG1BhMjmE4IS;) {
            if ('a' <= I0YU16O[OG1BhMjmE4IS] && 'z' >= I0YU16O[OG1BhMjmE4IS])
                I0YU16O[OG1BhMjmE4IS] = I0YU16O[OG1BhMjmE4IS] - 'a' + 'A';
            OG1BhMjmE4IS = OG1BhMjmE4IS +(263 - 262);
        }
    }
    {
        OG1BhMjmE4IS = (317 - 317);
        for (; R0mDVAoJyMpv < drxQdM;) {
            fDxZd0 = I0YU16O[R0mDVAoJyMpv];
            {
                dOlqxvHCN6u = (811 - 811);
                for (; (233 - 232);) {
                    if (I0YU16O[R0mDVAoJyMpv +dOlqxvHCN6u] != I0YU16O[R0mDVAoJyMpv +dOlqxvHCN6u + (757 - 756)])
                        break;
                    dOlqxvHCN6u = dOlqxvHCN6u + (144 - 143);
                }
            }
            OG1BhMjmE4IS = OG1BhMjmE4IS +(213 - 212);
            printf ("(%c,%d)", I0YU16O[R0mDVAoJyMpv], dOlqxvHCN6u + (557 - 556));
            R0mDVAoJyMpv = R0mDVAoJyMpv +dOlqxvHCN6u + (263 - 262);
        }
    }
    return (677 - 677);
}

