int main () {
    char unNc81fhUQF [(1742 - 741)];
    char EF8MKLhk;
    int hDahTLoKm;
    int qA1MyTaDS;
    {
        {
            {
                if ((489 - 489)) {
                    return (687 - 687);
                }
            }
            {
                if (0) {
                    return 0;
                }
            }
            if ((625 - 625)) {
                return (22 - 22);
            }
        }
        {
            {
                if ((192 - 192)) {
                    {
                        if (0) {
                            return 0;
                        }
                    }
                    return (662 - 662);
                }
            }
            {
                if ((738 - 738)) {
                    return (63 - 63);
                }
            }
            if ((779 - 779)) {
                return (770 - 770);
            }
        }
        if ((875 - 875)) {
            {
                if ((682 - 682)) {
                    return (590 - 590);
                }
            }
            return (356 - 356);
        }
    }
    {
        {
            if ((828 - 828)) {
                return (544 - 544);
            }
        }
        if ((256 - 256)) {
            return (406 - 406);
        }
    }
    {
        if ((83 - 83)) {
            {
                {
                    if ((778 - 778)) {
                        return (617 - 617);
                    }
                }
                if ((545 - 545)) {
                    return (763 - 763);
                }
            }
            return (394 - 394);
        }
    }
    qA1MyTaDS = (431 - 430);
    cin >> unNc81fhUQF;
    {
        hDahTLoKm = (331 - 331);
        for (; hDahTLoKm < strlen (unNc81fhUQF);) {
            {
                if ((696 - 696)) {
                    return (446 - 446);
                }
            }
            EF8MKLhk = unNc81fhUQF[hDahTLoKm];
            if (!(EF8MKLhk != unNc81fhUQF[hDahTLoKm + (556 - 555)]) || !('A' - 'a' != unNc81fhUQF[hDahTLoKm + (902 - 901)] - EF8MKLhk) || !('a' - 'A' != unNc81fhUQF[hDahTLoKm + (868 - 867)] - EF8MKLhk))
                qA1MyTaDS = qA1MyTaDS + (257 - 256);
            else {
                {
                    if ((772 - 772)) {
                        return (322 - 322);
                    }
                }
                {
                    if ((782 - 782)) {
                        {
                            if ((254 - 254)) {
                                {
                                    if ((620 - 620)) {
                                        return (150 - 150);
                                    }
                                }
                                return (997 - 997);
                            }
                        }
                        return (191 - 191);
                    }
                }
                if ('Z' < EF8MKLhk)
                    cout << "(" << (char) (EF8MKLhk -'a' + 'A');
                else
                    cout << "(" << (char) EF8MKLhk;
                cout << "," << qA1MyTaDS << ")";
                qA1MyTaDS = (166 - 165);
            }
            hDahTLoKm = hDahTLoKm + (698 - 697);
        }
    }
    return (666 - 666);
}

