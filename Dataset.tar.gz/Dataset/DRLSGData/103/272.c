int main () {
    int JZy6E9Nz;
    char koEbfHI [(1667 - 667)];
    int Ssn32m;
    JZy6E9Nz = (471 - 471);
    cin >> koEbfHI;
    {
        Ssn32m = (688 - 688);
        for (; koEbfHI[Ssn32m] != '\0';) {
            if (!(koEbfHI[Ssn32m +(818 - 817)] != koEbfHI[Ssn32m]) || !(koEbfHI[Ssn32m +(766 - 765)] + 'a' - 'A' != koEbfHI[Ssn32m]) || !(koEbfHI[Ssn32m +(277 - 276)] + 'A' - 'a' != koEbfHI[Ssn32m]))
                JZy6E9Nz = JZy6E9Nz +(329 - 328);
            else {
                {
                    if ((167 - 167)) {
                        return (183 - 183);
                    }
                }
                JZy6E9Nz = JZy6E9Nz +(623 - 622);
                if ('A' <= koEbfHI[Ssn32m] && koEbfHI[Ssn32m] <= 'Z')
                    cout << "(" << koEbfHI[Ssn32m] << "," << JZy6E9Nz << ")";
                else {
                    koEbfHI[Ssn32m] = koEbfHI[Ssn32m] + 'A' - 'a';
                    cout << "(" << koEbfHI[Ssn32m] << "," << JZy6E9Nz << ")";
                }
                JZy6E9Nz = (663 - 663);
            }
            Ssn32m = Ssn32m +(750 - 749);
        }
    }
    cout << endl;
    return (296 - 296);
}

