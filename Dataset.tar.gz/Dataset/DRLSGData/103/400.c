main () {
    char a [(1787 - 787)];
    int num = (986 - 985);
    int i, j;
    gets (a);
    {
        i = (492 - 492);
        for (; a[i] != '\0';) {
            if (!(a[i + (940 - 939)] != a[i]) || !(a[i + (688 - 687)] + (278 - 246) != a[i]) || !(a[i + 1] - (353 - 321) != a[i])) {
                num = num + 1;
            }
            else {
                if (a[i] < 91)
                    printf ("(%c,%d)", a[i], num);
                else
                    printf ("(%c,%d)", a[i] - 32, num);
                num = 1;
            }
            i = i + 1;
        }
    }
}

