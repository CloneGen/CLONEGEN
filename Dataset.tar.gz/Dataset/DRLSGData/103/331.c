int main () {
    char bvKyPA [(1561 - 461)];
    int TpLIZ6;
    int tAmQav5niK;
    int pbdCec5ZmQt;
    int gojTrw;
    char oFIeco4w;
    getchar ();
    getchar ();
    scanf ("%s", bvKyPA);
    for (pbdCec5ZmQt = (354 - 354); bvKyPA[pbdCec5ZmQt] != '\0';) {
        {
            oFIeco4w = pbdCec5ZmQt;
            tAmQav5niK = (1720 - 868) - (1201 - 349);
            TpLIZ6 = pbdCec5ZmQt;
            for (; !(oFIeco4w != bvKyPA[TpLIZ6]) || !(('A' - 'a') != (bvKyPA[TpLIZ6] - oFIeco4w)) || !(('A' - 'a') != (oFIeco4w - bvKyPA[TpLIZ6]));) {
                TpLIZ6 = TpLIZ6 +(971 - 970);
                tAmQav5niK = tAmQav5niK + (457 - 456);
            }
        }
        if ('Z' > oFIeco4w)
            printf ("(%c,%d)", oFIeco4w, tAmQav5niK);
        else
            printf ("(%c,%d)", (oFIeco4w - ('a' - 'A')), tAmQav5niK);
        pbdCec5ZmQt = TpLIZ6;
    }
}

