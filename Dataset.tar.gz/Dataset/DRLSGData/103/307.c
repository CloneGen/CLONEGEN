int main () {
    char ATZI2h [(1946 - 846)] = {'\0'};
    int HqMiycGpU;
    int jBMrSEbcOJ6Z;
    int JPngQbVsv4;
    cin >> ATZI2h;
    {
        JPngQbVsv4 = (1504 - 807) - (1397 - 700);
        for (; JPngQbVsv4 < strlen (ATZI2h);) {
            if ('a' <= ATZI2h[JPngQbVsv4] && ATZI2h[JPngQbVsv4] <= 'z')
                ATZI2h[JPngQbVsv4] = ATZI2h[JPngQbVsv4] - (405 - 373);
            JPngQbVsv4 = JPngQbVsv4 +(851 - 850);
        }
    }
    {
        JPngQbVsv4 = (1782 - 957) - (1644 - 819);
        for (; strlen (ATZI2h) > JPngQbVsv4;) {
            {
                HqMiycGpU = (92 - 92);
                for (; HqMiycGpU < strlen (ATZI2h) - JPngQbVsv4;) {
                    if (ATZI2h[JPngQbVsv4] == ATZI2h[JPngQbVsv4 +HqMiycGpU])
                        jBMrSEbcOJ6Z = HqMiycGpU +(346 - 345);
                    else
                        break;
                    HqMiycGpU = HqMiycGpU +(276 - 275);
                }
            }
            cout << "(" << ATZI2h[JPngQbVsv4] << ',' << jBMrSEbcOJ6Z << ")";
            JPngQbVsv4 = JPngQbVsv4 +jBMrSEbcOJ6Z - (30 - 29);
            JPngQbVsv4 = (927 - 343) - (757 - 174);
        }
    }
    return (958 - 958);
}

