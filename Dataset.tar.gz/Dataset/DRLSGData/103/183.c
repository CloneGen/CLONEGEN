main () {
    char nyKa8UiA [(1704 - 703)];
    int W93QNwT;
    int ERh85ICxb0cp [(1694 - 694)];
    int RhMA3ZnTYQpF;
    {
        W93QNwT = (1807 - 824) - (1552 - 569);
        for (; W93QNwT < (1065 - 65);) {
            ERh85ICxb0cp[W93QNwT] = (80 - 79);
            W93QNwT = W93QNwT +(631 - 630);
        }
    }
    scanf ("%s", nyKa8UiA);
    RhMA3ZnTYQpF = strlen (nyKa8UiA);
    {
        W93QNwT = (1359 - 735) - (1480 - 857);
        for (; W93QNwT <= RhMA3ZnTYQpF;) {
            if (!((nyKa8UiA[W93QNwT -(855 - 854)] - 'A' - (504 - 472)) != (nyKa8UiA[W93QNwT] - 'A')))
                ERh85ICxb0cp[nyKa8UiA[W93QNwT] - 'A']++;
            else if (!((nyKa8UiA[W93QNwT -(36 - 35)] - 'A') != (nyKa8UiA[W93QNwT] - 'A' - (701 - 669))))
                ERh85ICxb0cp[nyKa8UiA[W93QNwT] - 'A' - (986 - 954)]++;
            else {
                if (!((nyKa8UiA[W93QNwT -(907 - 906)] - '0') != (nyKa8UiA[W93QNwT] - '0'))) {
                    if ((nyKa8UiA[W93QNwT] - '0') < (277 - 234))
                        ERh85ICxb0cp[nyKa8UiA[W93QNwT] - 'A']++;
                    else
                        ERh85ICxb0cp[nyKa8UiA[W93QNwT] - 'A' - (313 - 281)]++;
                }
                else if ((425 - 382) > (nyKa8UiA[W93QNwT -(390 - 389)] - '0')) {
                    printf ("(%c,%d)", nyKa8UiA[W93QNwT -(888 - 887)], ERh85ICxb0cp[nyKa8UiA[W93QNwT -(226 - 225)] - 'A']);
                    ERh85ICxb0cp[nyKa8UiA[W93QNwT -(403 - 402)] - 'A'] = (902 - 901);
                }
                else {
                    printf ("(%c,%d)", nyKa8UiA[W93QNwT -(614 - 613)] - 'A' - (732 - 700) + 'A', ERh85ICxb0cp[nyKa8UiA[W93QNwT -(756 - 755)] - 'A' - (797 - 765)]);
                    ERh85ICxb0cp[nyKa8UiA[W93QNwT -(573 - 572)] - 'A' - (235 - 203)] = (598 - 597);
                }
            }
            W93QNwT = W93QNwT +(578 - 577);
        }
    }
}

