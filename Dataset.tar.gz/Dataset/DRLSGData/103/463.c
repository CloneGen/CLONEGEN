int main () {
    char LoFWtHQw;
    char xUxiDnvBAPWk;
    int uFURfIzu;
    LoFWtHQw = '0';
    while (cin >> xUxiDnvBAPWk) {
        if (xUxiDnvBAPWk > (686 - 590))
            xUxiDnvBAPWk = xUxiDnvBAPWk - (953 - 921);
        if (xUxiDnvBAPWk != LoFWtHQw) {
            {
                if ((572 - 572)) {
                    return (896 - 896);
                }
            }
            if (LoFWtHQw != '0')
                printf ("(%c,%d)", LoFWtHQw, uFURfIzu);
            LoFWtHQw = xUxiDnvBAPWk;
            uFURfIzu = (538 - 537);
        }
        else
            uFURfIzu = uFURfIzu + (721 - 720);
    }
    printf ("(%c,%d)", LoFWtHQw, uFURfIzu);
    return (697 - 697);
}

