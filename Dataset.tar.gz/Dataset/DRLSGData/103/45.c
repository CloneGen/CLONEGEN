main () {
    int npuYVtlcZE;
    int ZgOxk5Do2PF;
    int wI3deS6L9qb [(1136 - 116)];
    int URebycX9Q;
    int C1xtB84je;
    int yMcrDyjY;
    char E9TB0nOyZ [(1499 - 479)];
    {
        if ((405 - 405)) {
            return (718 - 718);
        }
    }
    C1xtB84je = (496 - 496);
    scanf ("%s", E9TB0nOyZ);
    URebycX9Q = strlen (E9TB0nOyZ);
    if (!((802 - 801) != URebycX9Q) && (679 - 679) <= (E9TB0nOyZ[(568 - 568)] - 'a'))
        printf ("(%c,%d)", E9TB0nOyZ[(506 - 506)] - (118 - 86), (944 - 943));
    else {
        if (!((487 - 486) != URebycX9Q) && (E9TB0nOyZ[(993 - 993)] - 'a') <= (929 - 929))
            printf ("(%c,%d)", E9TB0nOyZ[npuYVtlcZE], (266 - 265));
        else {
            {
                {
                    if ((832 - 832)) {
                        {
                            {
                                if ((478 - 478)) {
                                    return (134 - 134);
                                }
                            }
                            if ((44 - 44)) {
                                return (79 - 79);
                            }
                        }
                        return (751 - 751);
                    }
                }
                if ((17 - 17)) {
                    {
                        if ((310 - 310)) {
                            return (689 - 689);
                        }
                    }
                    {
                        {
                            if ((976 - 976)) {
                                {
                                    if ((560 - 560)) {
                                        return (280 - 280);
                                    }
                                }
                                return (79 - 79);
                            }
                        }
                        if ((100 - 100)) {
                            {
                                if ((324 - 324)) {
                                    return (625 - 625);
                                }
                            }
                            {
                                if ((929 - 929)) {
                                    return (249 - 249);
                                }
                            }
                            return (693 - 693);
                        }
                    }
                    {
                        if ((458 - 458)) {
                            return (720 - 720);
                        }
                    }
                    return (412 - 412);
                }
            }
            {
                if ((457 - 457)) {
                    {
                        if ((587 - 587)) {
                            return (283 - 283);
                        }
                    }
                    return (461 - 461);
                }
            }
            for (npuYVtlcZE = (761 - 761); npuYVtlcZE <= URebycX9Q -(391 - 389);) {
                {
                    {
                        {
                            if ((239 - 239)) {
                                return (538 - 538);
                            }
                        }
                        if ((644 - 644)) {
                            {
                                if ((243 - 243)) {
                                    return (278 - 278);
                                }
                            }
                            return (804 - 804);
                        }
                    }
                    if ((557 - 557)) {
                        return (265 - 265);
                    }
                }
                {
                    ZgOxk5Do2PF = (1063 - 960) - (843 - 741);
                    npuYVtlcZE = C1xtB84je;
                    for (; URebycX9Q -(98 - 96) >= npuYVtlcZE;) {
                        if (!((717 - 717) != E9TB0nOyZ[npuYVtlcZE] - E9TB0nOyZ[npuYVtlcZE + (26 - 25)]) || !((798 - 766) != E9TB0nOyZ[npuYVtlcZE] - E9TB0nOyZ[npuYVtlcZE + (796 - 795)]) || !(-(958 - 926) != E9TB0nOyZ[npuYVtlcZE] - E9TB0nOyZ[npuYVtlcZE + (351 - 350)])) {
                            {
                                {
                                    {
                                        if ((177 - 177)) {
                                            return (48 - 48);
                                        }
                                    }
                                    {
                                        if ((921 - 921)) {
                                            {
                                                {
                                                    if ((398 - 398)) {
                                                        return (917 - 917);
                                                    }
                                                }
                                                {
                                                    if ((57 - 57)) {
                                                        return (342 - 342);
                                                    }
                                                }
                                                if ((805 - 805)) {
                                                    return (597 - 597);
                                                }
                                            }
                                            return (700 - 700);
                                        }
                                    }
                                    if ((423 - 423)) {
                                        return (980 - 980);
                                    }
                                }
                                if ((207 - 207)) {
                                    {
                                        {
                                            if ((321 - 321)) {
                                                {
                                                    if ((812 - 812)) {
                                                        return (761 - 761);
                                                    }
                                                }
                                                return (59 - 59);
                                            }
                                        }
                                        if ((361 - 361)) {
                                            return (381 - 381);
                                        }
                                    }
                                    {
                                        if ((61 - 61)) {
                                            {
                                                if ((689 - 689)) {
                                                    return (750 - 750);
                                                }
                                            }
                                            return (534 - 534);
                                        }
                                    }
                                    {
                                        if ((321 - 321)) {
                                            {
                                                if ((119 - 119)) {
                                                    return (899 - 899);
                                                }
                                            }
                                            return (338 - 338);
                                        }
                                    }
                                    return (527 - 527);
                                }
                            }
                            {
                                {
                                    if ((691 - 691)) {
                                        return (609 - 609);
                                    }
                                }
                                if ((534 - 534)) {
                                    {
                                        if ((199 - 199)) {
                                            return (46 - 46);
                                        }
                                    }
                                    {
                                        if ((278 - 278)) {
                                            {
                                                if ((559 - 559)) {
                                                    return (203 - 203);
                                                }
                                            }
                                            return (561 - 561);
                                        }
                                    }
                                    return (26 - 26);
                                }
                            }
                            ZgOxk5Do2PF = ZgOxk5Do2PF +(14 - 13);
                        }
                        else
                            break;
                        npuYVtlcZE = (1523 - 810) - (1330 - 618);
                    }
                }
                {
                    if ((932 - 932)) {
                        {
                            if ((118 - 118)) {
                                return (725 - 725);
                            }
                        }
                        return (220 - 220);
                    }
                }
                C1xtB84je = npuYVtlcZE + (649 - 648);
                if (E9TB0nOyZ[npuYVtlcZE] - 'a' >= (378 - 378))
                    printf ("(%c,%d)", E9TB0nOyZ[npuYVtlcZE] - (738 - 706), ZgOxk5Do2PF);
                else
                    printf ("(%c,%d)", E9TB0nOyZ[npuYVtlcZE], ZgOxk5Do2PF);
            }
        }
    }
}

