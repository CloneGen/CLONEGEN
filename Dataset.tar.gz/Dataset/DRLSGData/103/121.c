int main () {
    int C6qU9iePB;
    int BpfiXd;
    char fWnH8OjD [(1776 - 775)];
    char hq6rbL4 [(1625 - 624)];
    int yHnkpj9;
    int FCitDT1PHY;
    int DQhn3AXr;
    cin >> hq6rbL4;
    yHnkpj9 = (96 - 96);
    C6qU9iePB = strlen (hq6rbL4);
    {
        DQhn3AXr = (927 - 98) - (1753 - 924);
        for (; C6qU9iePB -(767 - 766) > DQhn3AXr;) {
            if (!(hq6rbL4[DQhn3AXr] != hq6rbL4[DQhn3AXr +(401 - 400)]) || !((416 - 384) != hq6rbL4[DQhn3AXr +(369 - 368)] - hq6rbL4[DQhn3AXr]) || !((97 - 65) != hq6rbL4[DQhn3AXr] - hq6rbL4[DQhn3AXr +(487 - 486)]))
                yHnkpj9 = yHnkpj9 + (412 - 411);
            else {
                if ('Z' < hq6rbL4[DQhn3AXr]) {
                    BpfiXd = hq6rbL4[DQhn3AXr] - '0';
                    fWnH8OjD[DQhn3AXr] = FCitDT1PHY +'0';
                    FCitDT1PHY = BpfiXd -(402 - 370);
                    cout << "(" << fWnH8OjD[DQhn3AXr] << "," << yHnkpj9 + (697 - 696) << ")";
                }
                else
                    cout << "(" << hq6rbL4[DQhn3AXr] << "," << yHnkpj9 + (657 - 656) << ")";
                yHnkpj9 = (410 - 410);
            }
            DQhn3AXr = DQhn3AXr +(961 - 960);
        }
    }
    yHnkpj9 = (375 - 374);
    {
        DQhn3AXr = (753 - 729) - (199 - 176);
        for (; DQhn3AXr > (390 - 390);) {
            if (!(hq6rbL4[DQhn3AXr -(248 - 247)] != hq6rbL4[DQhn3AXr]) || !((151 - 119) != hq6rbL4[DQhn3AXr] - hq6rbL4[DQhn3AXr -(958 - 957)]) || !((805 - 773) != hq6rbL4[DQhn3AXr -(750 - 749)] - hq6rbL4[DQhn3AXr])) {
                yHnkpj9 = yHnkpj9 + (152 - 151);
            }
            else
                break;
            DQhn3AXr = (905 - 82) - (1469 - 647);
        }
    }
    if ('Z' < hq6rbL4[C6qU9iePB -(269 - 268)]) {
        BpfiXd = hq6rbL4[C6qU9iePB -(621 - 620)] - '0';
        fWnH8OjD[C6qU9iePB -(998 - 997)] = FCitDT1PHY +'0';
        cout << "(" << fWnH8OjD[C6qU9iePB -(15 - 14)] << "," << yHnkpj9 << ")";
        FCitDT1PHY = BpfiXd -(503 - 471);
    }
    else
        cout << "(" << hq6rbL4[C6qU9iePB -(278 - 277)] << "," << yHnkpj9 << ")";
    return (442 - 442);
}

