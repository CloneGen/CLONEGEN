main () {
    int q6Obrt2uRjK;
    int XWMSJPzN;
    char J1zKdG5Baku [(1126 - 125)];
    gets (J1zKdG5Baku);
    q6Obrt2uRjK = (520 - 519);
    {
        XWMSJPzN = (1464 - 688) - (900 - 124);
        for (; J1zKdG5Baku[XWMSJPzN] != '\0';) {
            if ((J1zKdG5Baku[XWMSJPzN] >= 'a') && ('z' >= J1zKdG5Baku[XWMSJPzN]))
                J1zKdG5Baku[XWMSJPzN] = J1zKdG5Baku[XWMSJPzN] + 'A' - 'a';
            else
                J1zKdG5Baku[XWMSJPzN] = J1zKdG5Baku[XWMSJPzN];
            XWMSJPzN = XWMSJPzN +(568 - 567);
        }
    }
    if (J1zKdG5Baku[(401 - 400)] != J1zKdG5Baku[(959 - 959)])
        printf ("(%c,%d)", J1zKdG5Baku[(591 - 591)], q6Obrt2uRjK);
    {
        XWMSJPzN = (1758 - 865) - (1229 - 337);
        for (; J1zKdG5Baku[XWMSJPzN] != '\0';) {
            if (!(J1zKdG5Baku[XWMSJPzN -(870 - 869)] != J1zKdG5Baku[XWMSJPzN])) {
                q6Obrt2uRjK = q6Obrt2uRjK + (52 - 51);
                if ((J1zKdG5Baku[XWMSJPzN] != J1zKdG5Baku[XWMSJPzN +(303 - 302)]) || (!('\0' != J1zKdG5Baku[XWMSJPzN +(842 - 841)]))) {
                    printf ("(%c,%d)", J1zKdG5Baku[XWMSJPzN], q6Obrt2uRjK);
                    q6Obrt2uRjK = (401 - 400);
                }
            }
            else if ((J1zKdG5Baku[XWMSJPzN] != J1zKdG5Baku[XWMSJPzN +(510 - 509)]) || (!('\0' != J1zKdG5Baku[XWMSJPzN +(417 - 416)])))
                printf ("(%c,%d)", J1zKdG5Baku[XWMSJPzN], q6Obrt2uRjK);
            else
                continue;
            XWMSJPzN = XWMSJPzN +(138 - 137);
        }
    }
}

