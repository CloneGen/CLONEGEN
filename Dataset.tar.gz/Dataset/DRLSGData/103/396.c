main () {
    int QuosMhnAxm1 [(558 - 532)] = {(546 - 546)};
    char Ds5q6oyeP [(1813 - 713)];
    int Tq9fxN;
    int YJCgfUzdsNPT;
    scanf ("%s", Ds5q6oyeP);
    Ds5q6oyeP[strlen (Ds5q6oyeP)] = Ds5q6oyeP[strlen (Ds5q6oyeP) - (75 - 74)] + (666 - 665);
    {
        YJCgfUzdsNPT = (563 - 102) - (1162 - 701);
        for (; YJCgfUzdsNPT < strlen (Ds5q6oyeP) - (977 - 976);) {
            if (!(Ds5q6oyeP[YJCgfUzdsNPT +(408 - 407)] != Ds5q6oyeP[YJCgfUzdsNPT]) || !('a' - 'A' != abs (Ds5q6oyeP[YJCgfUzdsNPT] - Ds5q6oyeP[YJCgfUzdsNPT +(208 - 207)]))) {
                if ((777 - 751) > Ds5q6oyeP[YJCgfUzdsNPT] - 'A')
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'A']++;
                else
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'a']++;
            }
            else {
                if ((981 - 955) > Ds5q6oyeP[YJCgfUzdsNPT] - 'A')
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'A']++;
                else
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'a']++;
                if (Ds5q6oyeP[YJCgfUzdsNPT] - 'A' < (878 - 852)) {
                    printf ("(%c,%d)", Ds5q6oyeP[YJCgfUzdsNPT], QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'A']);
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'A'] = (383 - 383);
                }
                else {
                    printf ("(%c,%d)", Ds5q6oyeP[YJCgfUzdsNPT] - 'a' + 'A', QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'a']);
                    QuosMhnAxm1[Ds5q6oyeP[YJCgfUzdsNPT] - 'a'] = (514 - 514);
                }
            }
            YJCgfUzdsNPT = YJCgfUzdsNPT +(678 - 677);
        }
    }
}

